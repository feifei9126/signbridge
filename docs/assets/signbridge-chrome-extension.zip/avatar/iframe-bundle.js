// src/avatar/iframe-bundle.js
import * as THREE from "./three.module.js";
import { GLTFLoader } from "./jsm/loaders/GLTFLoader.js";

// src/avatar/humanoid-rig.js
var HUMANOID_BONES = Object.freeze([
  "root",
  "body",
  "hips",
  "spine",
  "chest",
  "upperChest",
  "neck",
  "neck2",
  "neck3",
  "head",
  "rightShoulder",
  "rightUpperArm",
  "rightLowerArm",
  "rightHand",
  "leftShoulder",
  "leftUpperArm",
  "leftLowerArm",
  "leftHand",
  "rightThumbMetacarpal",
  "rightThumbProximal",
  "rightThumbDistal",
  "rightIndexProximal",
  "rightIndexIntermediate",
  "rightIndexDistal",
  "rightMiddleProximal",
  "rightMiddleIntermediate",
  "rightMiddleDistal",
  "rightRingProximal",
  "rightRingIntermediate",
  "rightRingDistal",
  "rightLittleProximal",
  "rightLittleIntermediate",
  "rightLittleDistal",
  "leftThumbMetacarpal",
  "leftThumbProximal",
  "leftThumbDistal",
  "leftIndexProximal",
  "leftIndexIntermediate",
  "leftIndexDistal",
  "leftMiddleProximal",
  "leftMiddleIntermediate",
  "leftMiddleDistal",
  "leftRingProximal",
  "leftRingIntermediate",
  "leftRingDistal",
  "leftLittleProximal",
  "leftLittleIntermediate",
  "leftLittleDistal",
  "jaw",
  "leftUpperEyelid",
  "rightUpperEyelid",
  "leftLowerEyelid",
  "rightLowerEyelid"
]);
var REQUIRED_SIGNING_BONES = Object.freeze([
  "rightUpperArm",
  "rightLowerArm",
  "rightHand",
  "leftUpperArm",
  "leftLowerArm",
  "leftHand",
  "rightThumbMetacarpal",
  "rightThumbProximal",
  "rightThumbDistal",
  "rightIndexProximal",
  "rightIndexIntermediate",
  "rightIndexDistal",
  "rightMiddleProximal",
  "rightMiddleIntermediate",
  "rightMiddleDistal",
  "rightRingProximal",
  "rightRingIntermediate",
  "rightRingDistal",
  "rightLittleProximal",
  "rightLittleIntermediate",
  "rightLittleDistal",
  "leftThumbMetacarpal",
  "leftThumbProximal",
  "leftThumbDistal",
  "leftIndexProximal",
  "leftIndexIntermediate",
  "leftIndexDistal",
  "leftMiddleProximal",
  "leftMiddleIntermediate",
  "leftMiddleDistal",
  "leftRingProximal",
  "leftRingIntermediate",
  "leftRingDistal",
  "leftLittleProximal",
  "leftLittleIntermediate",
  "leftLittleDistal"
]);
var GODETTE_PROFILE = Object.freeze({
  id: "godette-v1",
  motionSpace: "humanoid-local-v1",
  bones: Object.freeze({
    root: ["Root_225"],
    body: ["Body_220"],
    hips: ["Hip_218"],
    spine: ["Spine_1_199"],
    chest: ["Spine_2_198"],
    upperChest: ["Ribcage_197"],
    neck: ["Neck_1_132"],
    neck2: ["Neck_2_131"],
    neck3: ["Neck_3_130"],
    head: ["Head_129"],
    rightShoulder: ["ClavicR_192", "Clavic.R_192"],
    rightUpperArm: ["Arm_Upper_1R_187", "Arm_Upper_1.R_187"],
    rightLowerArm: ["Arm_Lower_1R_185", "Arm_Lower_1.R_185"],
    rightHand: ["HandR_184", "Hand.R_184"],
    leftShoulder: ["ClavicL_162", "Clavic.L_162"],
    leftUpperArm: ["Arm_Upper_1L_157", "Arm_Upper_1.L_157"],
    leftLowerArm: ["Arm_Lower_1L_155", "Arm_Lower_1.L_155"],
    leftHand: ["HandL_154", "Hand.L_154"],
    rightThumbMetacarpal: ["ThumbR_178", "Thumb.R_178"],
    rightThumbProximal: ["ThumbR002_177", "Thumb.R.002_177"],
    rightThumbDistal: ["ThumbR001_176", "Thumb.R.001_176"],
    rightIndexProximal: ["Finger_1R_166", "Finger_1.R_166"],
    rightIndexIntermediate: ["Finger_1R002_165", "Finger_1.R.002_165"],
    rightIndexDistal: ["Finger_1R001_164", "Finger_1.R.001_164"],
    rightMiddleProximal: ["Finger_2R_169", "Finger_2.R_169"],
    rightMiddleIntermediate: ["Finger_2R002_168", "Finger_2.R.002_168"],
    rightMiddleDistal: ["Finger_2R001_167", "Finger_2.R.001_167"],
    rightRingProximal: ["Finger_3R_172", "Finger_3.R_172"],
    rightRingIntermediate: ["Finger_3R002_171", "Finger_3.R.002_171"],
    rightRingDistal: ["Finger_3R001_170", "Finger_3.R.001_170"],
    rightLittleProximal: ["Finger_4R_175", "Finger_4.R_175"],
    rightLittleIntermediate: ["Finger_4R002_174", "Finger_4.R.002_174"],
    rightLittleDistal: ["Finger_4R001_173", "Finger_4.R.001_173"],
    leftThumbMetacarpal: ["ThumbL_148", "Thumb.L_148"],
    leftThumbProximal: ["ThumbL002_147", "Thumb.L.002_147"],
    leftThumbDistal: ["ThumbL001_146", "Thumb.L.001_146"],
    leftIndexProximal: ["Finger_1L_136", "Finger_1.L_136"],
    leftIndexIntermediate: ["Finger_1L002_135", "Finger_1.L.002_135"],
    leftIndexDistal: ["Finger_1L001_134", "Finger_1.L.001_134"],
    leftMiddleProximal: ["Finger_2L_139", "Finger_2.L_139"],
    leftMiddleIntermediate: ["Finger_2L002_138", "Finger_2.L.002_138"],
    leftMiddleDistal: ["Finger_2L001_137", "Finger_2.L.001_137"],
    leftRingProximal: ["Finger_3L_142", "Finger_3.L_142"],
    leftRingIntermediate: ["Finger_3L002_141", "Finger_3.L.002_141"],
    leftRingDistal: ["Finger_3L001_140", "Finger_3.L.001_140"],
    leftLittleProximal: ["Finger_4L_145", "Finger_4.L_145"],
    leftLittleIntermediate: ["Finger_4L002_144", "Finger_4.L.002_144"],
    leftLittleDistal: ["Finger_4L001_143", "Finger_4.L.001_143"],
    jaw: ["Jaw_4"],
    leftUpperEyelid: ["Eyelid_Control_UpperL_14"],
    rightUpperEyelid: ["Eyelid_Control_UpperR_15"],
    leftLowerEyelid: ["Eyelid_Control_LowerL_16"],
    rightLowerEyelid: ["Eyelid_Control_LowerR_17"]
  })
});
var LEGACY_BONE_ALIASES = Object.freeze({
  hip: "hips",
  ribcage: "upperChest",
  rShoulder: "rightShoulder",
  rUpperArm: "rightUpperArm",
  rForearm: "rightLowerArm",
  rHand: "rightHand",
  lShoulder: "leftShoulder",
  lUpperArm: "leftUpperArm",
  lForearm: "leftLowerArm",
  lHand: "leftHand",
  rthumb: "rightThumbMetacarpal",
  rindex: "rightIndexIntermediate",
  rmiddle: "rightMiddleIntermediate",
  rring: "rightRingIntermediate",
  rpinky: "rightLittleIntermediate",
  lthumb: "leftThumbMetacarpal",
  lindex: "leftIndexIntermediate",
  lmiddle: "leftMiddleIntermediate",
  lring: "leftRingIntermediate",
  lpinky: "leftLittleIntermediate",
  lUpperEyelid: "leftUpperEyelid",
  rUpperEyelid: "rightUpperEyelid",
  lLowerEyelid: "leftLowerEyelid",
  rLowerEyelid: "rightLowerEyelid"
});
function normalizeBoneName(name) {
  return String(name || "").replace(/[._\s-]/g, "").toLowerCase();
}
function canonicalizePose(pose = {}) {
  const canonical = {};
  for (const [name, rotation] of Object.entries(pose)) {
    canonical[LEGACY_BONE_ALIASES[name] || name] = rotation;
  }
  return canonical;
}
function indexSceneBones(root) {
  const exact = /* @__PURE__ */ new Map();
  const normalized = /* @__PURE__ */ new Map();
  const skeletons = /* @__PURE__ */ new Set();
  root?.traverse?.((object) => {
    if (object.isBone) {
      exact.set(object.name, object);
      normalized.set(normalizeBoneName(object.name), object);
    }
    if (object.isSkinnedMesh && object.skeleton) skeletons.add(object.skeleton);
  });
  return { exact, normalized, skeletons: [...skeletons] };
}
function resolveProfileBones(root, profile = GODETTE_PROFILE) {
  const index = indexSceneBones(root);
  const bones = {};
  for (const [canonicalName, candidates] of Object.entries(profile.bones)) {
    for (const candidate of candidates) {
      const bone = index.exact.get(candidate) || index.normalized.get(normalizeBoneName(candidate));
      if (bone) {
        bones[canonicalName] = bone;
        break;
      }
    }
  }
  return { bones, skeletons: index.skeletons };
}
function createHumanoidRig(root, profile = GODETTE_PROFILE) {
  const { bones, skeletons } = resolveProfileBones(root, profile);
  const rest = {};
  for (const [name, bone] of Object.entries(bones)) {
    rest[name] = {
      quaternion: bone.quaternion.clone(),
      rotation: {
        x: bone.rotation.x,
        y: bone.rotation.y,
        z: bone.rotation.z,
        order: bone.rotation.order
      }
    };
  }
  function update() {
    for (const skeleton of skeletons) skeleton.update();
  }
  function createTargets(pose = {}) {
    const canonicalPose = canonicalizePose(pose);
    const targets = {};
    for (const [name, bone] of Object.entries(bones)) {
      const base = rest[name];
      const delta = canonicalPose[name];
      if (!delta) {
        targets[name] = base.quaternion.clone();
        continue;
      }
      const rotation = bone.rotation.clone();
      rotation.set(
        base.rotation.x + (delta.x || 0),
        base.rotation.y + (delta.y || 0),
        base.rotation.z + (delta.z || 0),
        base.rotation.order
      );
      targets[name] = bone.quaternion.clone().setFromEuler(rotation);
    }
    return targets;
  }
  function capture() {
    const snapshot = {};
    for (const [name, bone] of Object.entries(bones)) {
      snapshot[name] = bone.quaternion.clone();
    }
    return snapshot;
  }
  function capturePose() {
    const pose = {};
    for (const [name, bone] of Object.entries(bones)) {
      const base = rest[name].rotation;
      pose[name] = {
        x: bone.rotation.x - base.x,
        y: bone.rotation.y - base.y,
        z: bone.rotation.z - base.z
      };
    }
    return pose;
  }
  function interpolate(from, targets, amount) {
    for (const [name, bone] of Object.entries(bones)) {
      const start = from[name] || rest[name].quaternion;
      const target = targets[name] || rest[name].quaternion;
      bone.quaternion.copy(start).slerp(target, amount);
    }
    update();
  }
  function applyPose(pose) {
    const targets = createTargets(pose);
    for (const [name, bone] of Object.entries(bones)) {
      bone.quaternion.copy(targets[name]);
    }
    update();
  }
  function reset() {
    for (const [name, bone] of Object.entries(bones)) {
      bone.quaternion.copy(rest[name].quaternion);
    }
    update();
  }
  const missing = REQUIRED_SIGNING_BONES.filter((name) => !bones[name]);
  return {
    profile,
    bones,
    rest,
    missing,
    isSigningReady: missing.length === 0,
    createTargets,
    capture,
    capturePose,
    interpolate,
    applyPose,
    reset,
    update
  };
}

// src/avatar/motion-player.js
function easeInOut(amount) {
  return amount < 0.5 ? 2 * amount * amount : -1 + (4 - 2 * amount) * amount;
}
function normalizeMotionFrames(input) {
  const frames = Array.isArray(input) ? input : input?.frames;
  if (!Array.isArray(frames) || frames.length === 0) return [];
  return frames.map((frame) => ({
    value: frame?.value && typeof frame.value === "object" ? frame.value : {},
    duration: Number.isFinite(frame?.duration) && frame.duration > 0 ? frame.duration : 0.8
  }));
}
function createMotionPlayer(rig2, {
  requestFrame = requestAnimationFrame,
  cancelFrame = cancelAnimationFrame,
  setTimer = setTimeout,
  clearTimer = clearTimeout,
  now = () => performance.now(),
  maxPendingMotions = 2,
  maxPendingAgeMs = 6e3,
  onComplete = () => {
  }
} = {}) {
  let queue = [];
  let timerId = null;
  let frameId = null;
  let playing = false;
  let pendingMotions = [];
  let currentKey = null;
  function stop({ reset = false } = {}) {
    playing = false;
    queue = [];
    pendingMotions = [];
    currentKey = null;
    if (timerId !== null) clearTimer(timerId);
    if (frameId !== null) cancelFrame(frameId);
    timerId = null;
    frameId = null;
    if (reset) rig2.reset();
  }
  function playNext() {
    if (frameId !== null) cancelFrame(frameId);
    frameId = null;
    timerId = null;
    if (playing && queue.length === 0) {
      pendingMotions = pendingMotions.filter(
        (motion) => now() - motion.receivedAt <= maxPendingAgeMs
      );
      const next = pendingMotions.shift();
      queue = next?.frames || [];
      currentKey = next?.key ?? null;
    }
    if (!playing || queue.length === 0) {
      playing = false;
      onComplete();
      return;
    }
    const frame = queue.shift();
    const durationMs = frame.duration * 1e3;
    const blendMs = Math.max(1, Math.min(durationMs * 0.35, 150));
    const from = rig2.capture();
    const targets = rig2.createTargets(frame.value);
    const startedAt = now();
    function blend() {
      const elapsed = now() - startedAt;
      const amount = Math.min(elapsed / blendMs, 1);
      rig2.interpolate(from, targets, easeInOut(amount));
      if (amount < 1 && playing) frameId = requestFrame(blend);
      else frameId = null;
    }
    blend();
    timerId = setTimer(playNext, durationMs);
  }
  function play(motion) {
    const frames = normalizeMotionFrames(motion);
    if (frames.length === 0) return false;
    stop();
    queue = frames;
    playing = true;
    playNext();
    return true;
  }
  function enqueue(motion, { key = null } = {}) {
    const frames = normalizeMotionFrames(motion);
    if (frames.length === 0) return false;
    if (key !== null && (key === currentKey || pendingMotions.some((item) => item.key === key))) {
      return false;
    }
    if (!playing) {
      queue = frames;
      currentKey = key;
      playing = true;
      playNext();
    } else {
      pendingMotions = pendingMotions.filter(
        (item) => now() - item.receivedAt <= maxPendingAgeMs
      );
      pendingMotions.push({ frames, key, receivedAt: now() });
      while (pendingMotions.length > maxPendingMotions) pendingMotions.shift();
    }
    return true;
  }
  return {
    play,
    enqueue,
    stop,
    get isPlaying() {
      return playing;
    }
  };
}

// src/avatar/pose-engine.js
function deg(x, y, z) {
  const d = Math.PI / 180;
  return { x: (x || 0) * d, y: (y || 0) * d, z: (z || 0) * d };
}
function frm(pose, dur) {
  return { value: pose, duration: dur || 0.8 };
}
function motionClip(id, frames, metadata = {}) {
  if (!id || !Array.isArray(frames) || frames.length === 0) {
    throw new TypeError("A motion clip requires an id and at least one frame.");
  }
  return {
    id,
    version: 1,
    space: "humanoid-local-v1",
    frames,
    metadata
  };
}

// src/avatar/sign-language-data.js
var FINGERS = ["Index", "Middle", "Ring", "Little"];
function setFinger(pose, side, finger, [proximal, intermediate, distal]) {
  pose[`${side}${finger}Proximal`] = deg(proximal, 0, 0);
  pose[`${side}${finger}Intermediate`] = deg(intermediate, 0, 0);
  pose[`${side}${finger}Distal`] = deg(distal, 0, 0);
}
function setThumb(pose, side, rotations) {
  const [metacarpal, proximal, distal] = rotations;
  pose[`${side}ThumbMetacarpal`] = metacarpal;
  pose[`${side}ThumbProximal`] = proximal;
  pose[`${side}ThumbDistal`] = distal;
}
function handShape(name, side = "right") {
  if (name === "relax") return {};
  const pose = {};
  const mirror = side === "left" ? -1 : 1;
  const fistFinger = [-25, -55, -30];
  const flatFinger = [8, 14, 8];
  const fistThumb = [deg(-10, 0, 0), deg(-20, 0, 0), deg(-10, 0, 0)];
  const flatThumb = [deg(8, 0, 0), deg(14, 0, 0), deg(8, 0, 0)];
  if (name === "fist") {
    for (const finger of FINGERS) setFinger(pose, side, finger, fistFinger);
    setThumb(pose, side, fistThumb);
  } else if (name === "flat") {
    for (const finger of FINGERS) setFinger(pose, side, finger, flatFinger);
    setThumb(pose, side, flatThumb);
  } else if (name === "point") {
    for (const finger of FINGERS) {
      setFinger(
        pose,
        side,
        finger,
        finger === "Index" ? flatFinger : fistFinger
      );
    }
    setThumb(pose, side, fistThumb);
  } else if (name === "thumbUp") {
    for (const finger of FINGERS) setFinger(pose, side, finger, fistFinger);
    setThumb(pose, side, [
      deg(0, 63 * mirror, 63 * mirror),
      deg(0, 0, 0),
      deg(0, 0, 0)
    ]);
  } else if (name === "peace") {
    for (const finger of FINGERS) {
      setFinger(
        pose,
        side,
        finger,
        finger === "Index" || finger === "Middle" ? flatFinger : fistFinger
      );
    }
    setThumb(pose, side, fistThumb);
  } else if (name === "ok") {
    setFinger(pose, side, "Index", [-20, -45, -25]);
    for (const finger of ["Middle", "Ring", "Little"]) {
      setFinger(pose, side, finger, [-15, -35, -20]);
    }
    setThumb(pose, side, [
      deg(-10, 30 * mirror, 0),
      deg(-10, 0, 0),
      deg(0, 0, 0)
    ]);
  }
  return pose;
}
function gesture(arm, shape, lArm, lShape) {
  const p = {};
  p.rightShoulder = deg(arm[0] || 0, arm[1] || 0, arm[2] || 0);
  p.rightUpperArm = deg(arm[3] || 0, arm[4] || 0, arm[5] || 0);
  p.rightLowerArm = deg(arm[6] || 0, arm[7] || 0, arm[8] || 0);
  p.rightHand = deg(arm[9] || 0, arm[10] || 0, arm[11] || 0);
  if (lArm) {
    p.leftShoulder = deg(lArm[0] || 0, lArm[1] || 0, lArm[2] || 0);
    p.leftUpperArm = deg(lArm[3] || 0, lArm[4] || 0, lArm[5] || 0);
    p.leftLowerArm = deg(lArm[6] || 0, lArm[7] || 0, lArm[8] || 0);
    p.leftHand = deg(lArm[9] || 0, lArm[10] || 0, lArm[11] || 0);
  }
  if (shape) {
    const s = handShape(shape, "right");
    for (const k in s) p[k] = s[k];
  }
  if (lShape) {
    const s = handShape(lShape, "left");
    for (const k in s) p[k] = s[k];
  }
  return p;
}
var A = [0, 0, 0, 35, 50, -15, 15, 0, 0, 0, 0, 0];
var AL = [0, 0, 0, 30, 50, -10, 10, 0, 0, 0, 0, 0];
var AT = [0, 0, 0, 55, 5, -10, 20, 0, 0, 0, 10, 10];
var AW = [10, 20, 0, 35, 20, 0, 15, 5, 0, 10, 0, 0];
var AWL = [10, -20, 0, 35, -5, 0, 15, -5, 0, 10, 0, 0];
var AD = [0, 0, 0, 35, 40, -10, 20, 0, 0, 0, -5, 0];
var APL = [0, 0, 0, 40, 50, -15, 20, 0, 0, 5, 0, 0];
var AW2 = [15, 20, 0, 50, 40, -15, 25, 5, 0, 5, 0, 0];
var SIGNS = {
  csl_hello: {
    id: "csl_hello",
    gloss: "\u4F60\u597D",
    texts: ["\u4F60\u597D", "\u60A8\u597D", "\u55E8", "hello", "hi"],
    tags: ["greeting"],
    frames: [frm(gesture(A, "point"), 0.6), frm(gesture(A, "thumbUp"), 0.7)],
    meta: { handshape: "point+thumbUp", location: "chest", movement: "none" }
  },
  csl_thanks: {
    id: "csl_thanks",
    gloss: "\u8C22\u8C22",
    texts: ["\u8C22\u8C22", "\u591A\u8C22", "\u611F\u8C22", "thanks"],
    tags: ["polite"],
    frames: [frm(gesture(AT, "fist"), 0.8)],
    meta: { handshape: "fist", location: "chest", movement: "nod" }
  },
  csl_yes: {
    id: "csl_yes",
    gloss: "\u662F",
    texts: ["\u662F", "\u5BF9", "\u6B63\u786E", "yes", "ok"],
    tags: ["confirm"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "nod" }
  },
  csl_no: {
    id: "csl_no",
    gloss: "\u4E0D",
    texts: ["\u4E0D", "\u6CA1", "\u6CA1\u6709", "\u522B", "no", "not"],
    tags: ["negation"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "chest", movement: "sway" }
  },
  csl_good: {
    id: "csl_good",
    gloss: "\u597D",
    texts: ["\u597D", "\u68D2", "\u4F18\u79C0", "good", "great"],
    tags: ["positive"],
    frames: [frm(gesture(A, "thumbUp"), 0.7)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_me: {
    id: "csl_me",
    gloss: "\u6211",
    texts: ["\u6211", "\u81EA\u5DF1", "me", "I"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 35, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "chest", movement: "self" }
  },
  csl_you: {
    id: "csl_you",
    gloss: "\u4F60",
    texts: ["\u4F60", "\u60A8", "you"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "forward", movement: "none" }
  },
  csl_help: {
    id: "csl_help",
    gloss: "\u5E2E\u52A9",
    texts: ["\u5E2E\u52A9", "\u5E2E\u5FD9", "\u5E2E", "help"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 40, 40, -10, 25, 0, 0, -5, 5, 0], "flat"), 0.7)
    ],
    meta: { handshape: "flat", location: "chest", movement: "support" }
  },
  csl_welcome: {
    id: "csl_welcome",
    gloss: "\u6B22\u8FCE",
    texts: ["\u6B22\u8FCE", "welcome"],
    tags: ["greeting"],
    frames: [frm(gesture(AW, "flat", AWL, "flat"), 0.8)],
    meta: { handshape: "flat", location: "side", movement: "open" }
  },
  csl_love: {
    id: "csl_love",
    gloss: "\u7231",
    texts: ["\u7231", "\u559C\u6B22", "love", "like"],
    tags: ["emotion"],
    frames: [frm(gesture(AL, "fist", AL, "fist"), 0.8)],
    meta: { handshape: "fist", location: "heart", movement: "none" }
  },
  csl_goodbye: {
    id: "csl_goodbye",
    gloss: "\u518D\u89C1",
    texts: ["\u518D\u89C1", "\u62DC\u62DC", "bye", "goodbye"],
    tags: ["greeting"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.6),
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.4),
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.4)
    ],
    meta: { handshape: "flat", location: "side", movement: "wave" }
  },
  csl_happy: {
    id: "csl_happy",
    gloss: "\u5F00\u5FC3",
    texts: ["\u5F00\u5FC3", "\u9AD8\u5174", "\u5FEB\u4E50", "happy"],
    tags: ["emotion"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 0, 0, 0], "flat"), 0.6)
    ],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_true: {
    id: "csl_true",
    gloss: "\u771F",
    texts: ["\u771F", "\u771F\u7684", "\u786E\u5B9E", "true", "really"],
    tags: ["confirm"],
    frames: [frm(gesture(A, "point"), 0.5)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_too: {
    id: "csl_too",
    gloss: "\u592A",
    texts: ["\u592A", "\u5F88", "\u975E\u5E38", "very", "too"],
    tags: ["degree"],
    frames: [frm(gesture(A, "thumbUp"), 0.5)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_what: {
    id: "csl_what",
    gloss: "\u4EC0\u4E48",
    texts: ["\u4EC0\u4E48", "\u5565", "what"],
    tags: ["question"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_he: {
    id: "csl_he",
    gloss: "\u4ED6",
    texts: ["\u4ED6", "\u5979", "\u5B83", "he", "she"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 40, 60, -15, 20, 0, 0, 5, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "side", movement: "none" }
  },
  csl_we: {
    id: "csl_we",
    gloss: "\u6211\u4EEC",
    texts: ["\u6211\u4EEC", "\u54B1\u4EEC", "we", "us"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 30, 40, -10, 20, 0, 0, 5, 0, 0], "point"), 0.7)
    ],
    meta: { handshape: "point", location: "chest", movement: "arc" }
  },
  csl_this: {
    id: "csl_this",
    gloss: "\u8FD9",
    texts: ["\u8FD9", "\u8FD9\u4E2A", "this"],
    tags: ["demonstrative"],
    frames: [frm(gesture(AD, "point"), 0.5)],
    meta: { handshape: "point", location: "down", movement: "none" }
  },
  csl_that: {
    id: "csl_that",
    gloss: "\u90A3",
    texts: ["\u90A3", "\u90A3\u4E2A", "that"],
    tags: ["demonstrative"],
    frames: [
      frm(gesture([0, 0, 0, 40, 60, -15, 20, 0, 0, 5, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "forward", movement: "none" }
  },
  csl_who: {
    id: "csl_who",
    gloss: "\u8C01",
    texts: ["\u8C01", "who"],
    tags: ["question"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_how: {
    id: "csl_how",
    gloss: "\u600E\u4E48",
    texts: ["\u600E\u4E48", "\u600E\u6837", "how"],
    tags: ["question"],
    frames: [frm(gesture(A, "flat"), 0.6)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_where: {
    id: "csl_where",
    gloss: "\u54EA",
    texts: ["\u54EA", "\u54EA\u91CC", "where"],
    tags: ["question"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_have: {
    id: "csl_have",
    gloss: "\u6709",
    texts: ["\u6709", "have", "has"],
    tags: ["state"],
    frames: [frm(gesture(A, "thumbUp"), 0.6)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_can: {
    id: "csl_can",
    gloss: "\u53EF\u4EE5",
    texts: ["\u53EF\u4EE5", "\u80FD", "can", "may"],
    tags: ["modal"],
    frames: [frm(gesture(A, "ok"), 0.6)],
    meta: { handshape: "ok", location: "chest", movement: "nod" }
  },
  csl_want: {
    id: "csl_want",
    gloss: "\u8981",
    texts: ["\u8981", "\u60F3", "want", "need"],
    tags: ["modal"],
    frames: [frm(gesture(A, "flat"), 0.6)],
    meta: { handshape: "flat", location: "chest", movement: "pull" }
  },
  csl_come: {
    id: "csl_come",
    gloss: "\u6765",
    texts: ["\u6765", "\u8FC7\u6765", "come"],
    tags: ["action"],
    frames: [frm(gesture(APL, "flat"), 0.6)],
    meta: { handshape: "flat", location: "side", movement: "beckon" }
  },
  csl_go: {
    id: "csl_go",
    gloss: "\u53BB",
    texts: ["\u53BB", "\u8D70", "go"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 0, 0, 0], "flat"), 0.5)
    ],
    meta: { handshape: "flat", location: "forward", movement: "push" }
  },
  csl_say: {
    id: "csl_say",
    gloss: "\u8BF4",
    texts: ["\u8BF4", "\u8BB2", "say", "speak"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 35, 40, -15, 20, 0, 0, -5, 0, 0], "flat"), 0.6)
    ],
    meta: { handshape: "flat", location: "mouth", movement: "none" }
  },
  csl_see: {
    id: "csl_see",
    gloss: "\u770B",
    texts: ["\u770B", "\u89C1", "see", "look"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 35, 35, -10, 20, 0, 0, 0, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "eyes", movement: "none" }
  },
  csl_know: {
    id: "csl_know",
    gloss: "\u77E5\u9053",
    texts: ["\u77E5\u9053", "\u61C2", "know", "understand"],
    tags: ["cognition"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "temple", movement: "none" }
  },
  csl_big: {
    id: "csl_big",
    gloss: "\u5927",
    texts: ["\u5927", "big", "large"],
    tags: ["size"],
    frames: [frm(gesture(AW2, "flat"), 0.6)],
    meta: { handshape: "flat", location: "side", movement: "spread" }
  },
  csl_small: {
    id: "csl_small",
    gloss: "\u5C0F",
    texts: ["\u5C0F", "small", "little"],
    tags: ["size"],
    frames: [
      frm(gesture([0, 0, 0, 35, 30, -10, 20, 0, 0, 0, 0, 0], "flat"), 0.5)
    ],
    meta: { handshape: "flat", location: "chest", movement: "close" }
  },
  csl_many: {
    id: "csl_many",
    gloss: "\u591A",
    texts: ["\u591A", "\u5F88\u591A", "many", "much"],
    tags: ["quantity"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_up: {
    id: "csl_up",
    gloss: "\u4E0A",
    texts: ["\u4E0A", "up", "above"],
    tags: ["direction"],
    frames: [
      frm(gesture([0, 0, 0, 40, 40, -15, 15, 0, 0, 10, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "up", movement: "none" }
  },
  csl_down: {
    id: "csl_down",
    gloss: "\u4E0B",
    texts: ["\u4E0B", "down", "below"],
    tags: ["direction"],
    frames: [
      frm(gesture([0, 0, 0, 35, 40, -15, 25, 0, 0, -5, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "down", movement: "none" }
  },
  csl_now: {
    id: "csl_now",
    gloss: "\u73B0\u5728",
    texts: ["\u73B0\u5728", "now"],
    tags: ["time"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_today: {
    id: "csl_today",
    gloss: "\u4ECA\u5929",
    texts: ["\u4ECA\u5929", "today"],
    tags: ["time"],
    frames: [frm(gesture(A, "point"), 0.5)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_also: {
    id: "csl_also",
    gloss: "\u4E5F",
    texts: ["\u4E5F", "also", "too"],
    tags: ["conjunction"],
    frames: [frm(gesture(A, "point"), 0.5)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_all: {
    id: "csl_all",
    gloss: "\u90FD",
    texts: ["\u90FD", "\u5168\u90E8", "all"],
    tags: ["quantity"],
    frames: [frm(gesture(AW2, "flat", AWL, "flat"), 0.6)],
    meta: { handshape: "flat", location: "side", movement: "arc" }
  },
  csl_but: {
    id: "csl_but",
    gloss: "\u4F46\u662F",
    texts: ["\u4F46\u662F", "\u4F46", "but"],
    tags: ["conjunction"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_if: {
    id: "csl_if",
    gloss: "\u5982\u679C",
    texts: ["\u5982\u679C", "\u8981\u662F", "if"],
    tags: ["conjunction"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_very: {
    id: "csl_very",
    gloss: "\u5F88",
    texts: ["\u5F88", "\u975E\u5E38", "very", "quite"],
    tags: ["degree"],
    frames: [frm(gesture(A, "thumbUp"), 0.5)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_and: {
    id: "csl_and",
    gloss: "\u548C",
    texts: ["\u548C", "\u8DDF", "\u4E0E", "and"],
    tags: ["conjunction"],
    frames: [
      frm(gesture([0, 0, 0, 35, 40, -15, 20, 0, 0, 5, 0, 0], "flat"), 0.5)
    ],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_new: {
    id: "csl_new",
    gloss: "\u65B0",
    texts: ["\u65B0", "new"],
    tags: ["quality"],
    frames: [frm(gesture(APL, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_old: {
    id: "csl_old",
    gloss: "\u8001",
    texts: ["\u8001", "\u65E7", "old"],
    tags: ["quality"],
    frames: [frm(gesture(AD, "fist"), 0.5)],
    meta: { handshape: "fist", location: "chest", movement: "none" }
  },
  csl_one: {
    id: "csl_one",
    gloss: "\u4E00",
    texts: ["\u4E00", "one"],
    tags: ["number"],
    frames: [frm(gesture(A, "point"), 0.4)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_two: {
    id: "csl_two",
    gloss: "\u4E8C",
    texts: ["\u4E8C", "\u4E24", "two"],
    tags: ["number"],
    frames: [frm(gesture(A, "peace"), 0.4)],
    meta: { handshape: "peace", location: "chest", movement: "none" }
  },
  csl_three: {
    id: "csl_three",
    gloss: "\u4E09",
    texts: ["\u4E09", "three"],
    tags: ["number"],
    frames: [frm(gesture(A, "ok"), 0.4)],
    meta: { handshape: "ok", location: "chest", movement: "none" }
  },
  csl_please: {
    id: "csl_please",
    gloss: "\u8BF7",
    texts: ["\u8BF7", "please"],
    tags: ["polite"],
    frames: [frm(gesture(APL, "flat"), 0.7)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_do: {
    id: "csl_do",
    gloss: "\u505A",
    texts: ["\u505A", "\u5E72", "do"],
    tags: ["action"],
    frames: [frm(gesture(A, "fist"), 0.5)],
    meta: { handshape: "fist", location: "chest", movement: "none" }
  },
  csl_people: {
    id: "csl_people",
    gloss: "\u4EBA",
    texts: ["\u4EBA", "person", "people"],
    tags: ["noun"],
    frames: [
      frm(gesture([0, 0, 0, 35, 50, -15, 25, 0, 0, 0, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "side", movement: "none" }
  },
  csl_self: {
    id: "csl_self",
    gloss: "\u81EA\u5DF1",
    texts: ["\u81EA\u5DF1", "self"],
    tags: ["pronoun"],
    frames: [frm(gesture(AL, "fist", AL, "fist"), 0.6)],
    meta: { handshape: "fist", location: "chest", movement: "self" }
  }
};
for (const sign of Object.values(SIGNS)) {
  sign.motion = motionClip(sign.id, sign.frames, {
    gloss: sign.gloss,
    tags: sign.tags,
    ...sign.meta
  });
}
var SINGLE_CHARS = {};
function addChar(c, frames) {
  SINGLE_CHARS[c] = frames;
}
addChar("\u4F60", [frm(gesture(A, "point"), 0.6)]);
addChar("\u597D", [frm(gesture(A, "thumbUp"), 0.7)]);
addChar("\u8C22", [frm(gesture(AT, "fist"), 0.8)]);
addChar("\u6211", [
  frm(gesture([0, 0, 0, 35, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.6)
]);
addChar("\u7231", [frm(gesture(AL, "fist", AL, "fist"), 0.8)]);
addChar("\u662F", [frm(gesture(A, "point"), 0.6)]);
addChar("\u5BF9", [frm(gesture(A, "point"), 0.6)]);
addChar("\u4E0D", [
  frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.5)
]);
addChar("\u5E2E", [
  frm(gesture([0, 0, 0, 40, 40, -10, 25, 0, 0, -5, 5, 0], "flat"), 0.6)
]);
addChar("\u52A9", [
  frm(gesture([0, 0, 0, 40, 40, -10, 25, 0, 0, -5, 5, 0], "flat"), 0.6)
]);
addChar("\u518D", [
  frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.6)
]);
addChar("\u89C1", [
  frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.6)
]);
addChar("\u6B22", [frm(gesture(AW, "flat", AWL, "flat"), 0.6)]);
addChar("\u8FCE", [frm(gesture(AW, "flat", AWL, "flat"), 0.6)]);
addChar("\u559C", [frm(gesture(AL, "fist", AL, "fist"), 0.7)]);
addChar(" ", [frm({}, 0.3)]);
function buildLookup() {
  const lookup = {};
  for (const sign of Object.values(SIGNS)) {
    for (const text of sign.texts) {
      if (!lookup[text]) lookup[text] = sign.frames;
    }
  }
  return lookup;
}
function normalizeText(text) {
  if (!text) return "";
  return text.replace(/[，。！？、；："“”（）【】《》\s]+/g, " ").replace(/[^\u4e00-\u9fff\u3400-\u4dbf a-zA-Z0-9'’-]/g, " ").replace(/\s+/g, " ").trim();
}
var FUNCTION_WORDS = /* @__PURE__ */ new Set([
  "\u7684",
  "\u4E86",
  "\u7740",
  "\u8FC7",
  "\u5427",
  "\u5417",
  "\u5462",
  "\u554A",
  "\u561B",
  "\u5457",
  "\u54E6",
  "\u55EF",
  "\u5440",
  "\u5566",
  "\u54C8",
  "\u54C7",
  "\u54CE",
  "\u5582",
  "\u4E2A"
]);
var wordSegmenter = new Intl.Segmenter("zh", { granularity: "word" });
function wordTokens(text) {
  return [...wordSegmenter.segment(text)].filter((token) => token.isWordLike);
}
function translationAliasKey(text) {
  const tokens = wordTokens(normalizeText(text).toLowerCase()).map(
    (token) => token.segment
  );
  return tokens.length ? JSON.stringify(tokens) : "";
}
function compileTranslationMatchers(customMotions = []) {
  return [...Object.values(SIGNS), ...customMotions].flatMap(
    (sign) => sign.texts.map((text) => ({
      id: sign.id,
      sign,
      text: normalizeText(text).toLowerCase(),
      tokens: wordTokens(normalizeText(text).toLowerCase()).map(
        (token) => token.segment
      )
    }))
  ).filter((entry) => entry.text && entry.tokens.length).sort((a, b) => b.text.length - a.text.length);
}
var SIGN_MATCHERS = compileTranslationMatchers();
function neutralGesture() {
  return { frames: [frm({}, 0.5)], matches: [] };
}
function translateText(subtitleText, maxSigns = 12, matchers = SIGN_MATCHERS) {
  const text = normalizeText(subtitleText).toLowerCase();
  if (!text) return null;
  const tokens = wordTokens(text);
  const matches = [];
  const unmatched = [];
  const skipped = [];
  let cursor = 0;
  while (cursor < tokens.length && matches.length < maxSigns) {
    const signMatch = matchers.find(
      (entry) => entry.tokens.every(
        (token, offset) => tokens[cursor + offset]?.segment === token
      )
    );
    if (signMatch) {
      matches.push({
        id: signMatch.id,
        text: signMatch.text,
        gloss: signMatch.sign.gloss,
        frames: signMatch.sign.frames
      });
      cursor += signMatch.tokens.length;
      continue;
    }
    const word = tokens[cursor].segment;
    if (FUNCTION_WORDS.has(word)) {
      skipped.push(word);
    } else if (SINGLE_CHARS[word]) {
      matches.push({
        id: `char_${word}`,
        text: word,
        gloss: word,
        frames: SINGLE_CHARS[word]
      });
    } else {
      unmatched.push(word);
    }
    cursor += 1;
  }
  return {
    frames: matches.length ? [...matches.flatMap((match) => match.frames), frm({}, 0.25)] : neutralGesture().frames,
    unmatched,
    skipped,
    truncated: cursor < tokens.length,
    remainingText: cursor < tokens.length ? text.slice(tokens[cursor].index) : "",
    matches: matches.map((match) => ({
      id: match.id,
      text: match.text,
      gloss: match.gloss
    }))
  };
}
var GESTURES = buildLookup();

// src/avatar/motion-asset.js
var MAX_MOTION_BYTES = 2 * 1024 * 1024;
var MAX_MOTION_FRAMES = 240;
var knownBones = new Set(HUMANOID_BONES);
function invalid(detail, message = "motionInvalidData") {
  const error = new Error(message);
  error.detail = detail;
  throw error;
}
function plainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function boundedText(value, field, limit = 100) {
  if (typeof value !== "string" || !value.trim() || value.length > limit)
    invalid(field);
  return value.trim();
}
function textList(value, field, max = 20) {
  if (!Array.isArray(value) || value.length > max) invalid(field);
  return [...new Set(value.map((text) => boundedText(text, field)))];
}
function createRigBinding(rig2) {
  if (!rig2?.rest || !rig2?.profile) invalid("rig", "motionModelNotReady");
  const rest = Object.keys(rig2.rest).sort().map((name) => {
    const bone = rig2.bones[name];
    const rotation = rig2.rest[name].rotation;
    return [
      name,
      bone.name,
      bone.parent?.name || "",
      rotation.order,
      ...[
        rotation.x,
        rotation.y,
        rotation.z,
        ...bone.position.toArray(),
        ...bone.scale.toArray()
      ].map((value) => Number(value.toFixed(9)))
    ];
  });
  return { profile: rig2.profile.id, rest: JSON.stringify(rest) };
}
function validateMotionAsset(input, rig2) {
  if (!plainObject(input) || input.type !== "signbridge-motion" || input.version !== 1 || input.space !== "humanoid-local-v1" || input.unit !== "radians")
    invalid("type/version/space/unit");
  const id = boundedText(input.id, "id", 90);
  if (!/^custom_[a-zA-Z0-9_-]+$/.test(id)) invalid("id");
  const binding = createRigBinding(rig2);
  if (input.rig?.profile !== binding.profile || input.rig?.rest !== binding.rest)
    invalid("rig", "motionRigMismatch");
  if (!Array.isArray(input.frames) || !input.frames.length || input.frames.length > MAX_MOTION_FRAMES)
    invalid("frames");
  let total = 0;
  const frames = input.frames.map((frame, index) => {
    if (!plainObject(frame?.value) || !Number.isFinite(frame.duration) || frame.duration < 0.05 || frame.duration > 10)
      invalid(`frames[${index}]`);
    total += frame.duration;
    const value = {};
    for (const [name, rotation] of Object.entries(frame.value)) {
      if (!knownBones.has(name) || !rig2.bones[name] || !plainObject(rotation))
        invalid(`frames[${index}].${name}`);
      for (const axis of ["x", "y", "z"]) {
        if (!Number.isFinite(rotation[axis]) || Math.abs(rotation[axis]) > Math.PI * 2)
          invalid(`${name}.${axis}`);
      }
      value[name] = { x: rotation.x, y: rotation.y, z: rotation.z };
    }
    return { value, duration: frame.duration };
  });
  if (total > 120) invalid("duration > 120s");
  return {
    type: "signbridge-motion",
    version: 1,
    id,
    gloss: boundedText(input.gloss, "gloss"),
    texts: textList(input.texts, "texts"),
    tags: textList(input.tags, "tags"),
    space: "humanoid-local-v1",
    unit: "radians",
    rig: binding,
    frames
  };
}
function serializeMotionAsset(asset, round = false) {
  return JSON.stringify(asset, (_key, value) => {
    if (round && typeof value === "number") return Number(value.toFixed(8));
    if (plainObject(value))
      return Object.fromEntries(
        Object.keys(value).sort().map((key) => [key, value[key]])
      );
    return value;
  });
}
function motionIdentity(asset) {
  return serializeMotionAsset(asset, true);
}

// src/avatar/motion-pack.js
var MAX_MOTION_PACK_BYTES = 8 * 1024 * 1024;
var MAX_MOTION_PACK_ASSETS = 500;
function reject(message = "motionPackInvalid") {
  throw new Error(message);
}
function validateMotionPack(input, rig2) {
  if (input?.type !== "signbridge-motion-pack" || input.version !== 1 || typeof input.createdAt !== "string" || !Number.isFinite(Date.parse(input.createdAt)) || !Array.isArray(input.motions))
    reject();
  if (!input.motions.length) reject("motionPackEmpty");
  if (input.motions.length > MAX_MOTION_PACK_ASSETS)
    reject("motionPackTooLarge");
  const ids = /* @__PURE__ */ new Set();
  const motions = input.motions.map((entry) => {
    const asset = validateMotionAsset(entry?.asset, rig2);
    if (ids.has(asset.id)) reject("motionPackDuplicateId");
    ids.add(asset.id);
    if (new Blob([serializeMotionAsset(asset)]).size > MAX_MOTION_BYTES)
      reject("motionPackTooLarge");
    return { asset, wasEnabled: entry.wasEnabled === true };
  });
  const pack = {
    type: "signbridge-motion-pack",
    version: 1,
    createdAt: input.createdAt,
    motions
  };
  if (new Blob([JSON.stringify(pack, null, 2)]).size > MAX_MOTION_PACK_BYTES)
    reject("motionPackTooLarge");
  return pack;
}
function createMotionPack(entries, rig2) {
  return validateMotionPack(
    {
      type: "signbridge-motion-pack",
      version: 1,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      motions: entries.map((entry) => ({
        asset: entry.asset,
        wasEnabled: entry.enabled === true
      }))
    },
    rig2
  );
}
function inspectMotionPack(input, stored, rig2) {
  const pack = validateMotionPack(input, rig2);
  const aliases = /* @__PURE__ */ new Map();
  function addAliases(asset) {
    for (const text of asset.texts) {
      const key = translationAliasKey(text);
      if (!aliases.has(key)) aliases.set(key, /* @__PURE__ */ new Set());
      aliases.get(key).add(asset.id);
    }
  }
  Object.values(SIGNS).forEach(addAliases);
  const valid = /* @__PURE__ */ new Map();
  for (const [id, entry] of Object.entries(stored)) {
    try {
      const asset = validateMotionAsset(entry?.asset, rig2);
      if (asset.id !== id) continue;
      valid.set(id, asset);
      addAliases(asset);
    } catch {
      continue;
    }
  }
  pack.motions.forEach((entry) => addAliases(entry.asset));
  const counts = { new: 0, existing: 0, conflict: 0 };
  const items = pack.motions.map(({ asset, wasEnabled }) => {
    let state = "new";
    if (Object.hasOwn(stored, asset.id)) {
      state = valid.has(asset.id) && serializeMotionAsset(valid.get(asset.id)) === serializeMotionAsset(asset) ? "existing" : "conflict";
    }
    counts[state] += 1;
    return {
      id: asset.id,
      gloss: asset.gloss,
      state,
      wasEnabled,
      aliasConflicts: asset.texts.filter((text) => {
        const key = translationAliasKey(text);
        return !key || [...aliases.get(key)].some((id) => id !== asset.id);
      }),
      emptyTexts: asset.texts.length === 0
    };
  });
  return { pack, items, counts, revision: serializeMotionAsset(stored) };
}

// src/avatar/motion-library.js
var MOTION_STORAGE_PREFIX = "signbridge.motion.v1.";
var normalizedAlias = translationAliasKey;
var builtinAliases = new Set(
  Object.values(SIGNS).flatMap((sign) => sign.texts.map(normalizedAlias))
);
function motionError(message, detail = "") {
  const error = new Error(message);
  error.detail = detail;
  return error;
}
function isConfirmed(entry) {
  return entry.enabled === true && typeof entry.review?.confirmedAt === "string" && entry.review.assetJson === serializeMotionAsset(entry.asset);
}
function aliasConflict(asset, aliases) {
  if (!asset.texts.length) return "texts";
  return asset.texts.find(
    (text) => !normalizedAlias(text) || aliases.has(normalizedAlias(text))
  ) ?? null;
}
function selectEnabledMotions(entries) {
  const used = new Set(builtinAliases);
  const motions = [];
  for (const entry of [...entries].sort(
    (first, second) => first.asset.id.localeCompare(second.asset.id)
  )) {
    if (!isConfirmed(entry) || aliasConflict(entry.asset, used) !== null)
      continue;
    motions.push(entry.asset);
    entry.asset.texts.forEach((text) => used.add(normalizedAlias(text)));
  }
  return motions;
}
function createMotionLibrary(rig2, storage = globalThis.chrome?.storage, locks = globalThis.navigator?.locks) {
  if (!storage?.local) throw motionError("motionStorageUnavailable");
  const area = storage.local;
  const write = (operation) => locks ? locks.request(MOTION_STORAGE_PREFIX, operation) : operation();
  async function list() {
    const values = await area.get(null);
    const entries = [];
    let invalidCount = 0;
    for (const [key, stored] of Object.entries(values)) {
      if (!key.startsWith(MOTION_STORAGE_PREFIX)) continue;
      try {
        const asset = validateMotionAsset(stored.asset, rig2);
        if (key !== MOTION_STORAGE_PREFIX + asset.id)
          throw motionError("motionInvalidData");
        entries.push({
          asset,
          enabled: isConfirmed({ ...stored, asset }),
          review: stored.review
        });
      } catch {
        invalidCount += 1;
      }
    }
    return { entries, invalidCount };
  }
  async function saveDraft(input) {
    const asset = validateMotionAsset(input, rig2);
    const entry = { asset, enabled: false, review: null };
    await write(() => area.set({ [MOTION_STORAGE_PREFIX + asset.id]: entry }));
    return entry;
  }
  async function setEnabled(id, enabled, expectedAsset) {
    return write(async () => {
      const { entries } = await list();
      const entry = entries.find((candidate) => candidate.asset.id === id);
      if (!entry) throw motionError("motionSelectFirst");
      if (enabled) {
        if (motionIdentity(entry.asset) !== motionIdentity(expectedAsset))
          throw motionError("motionSaveFirst");
        const aliases = new Set(builtinAliases);
        for (const other of entries) {
          if (other.asset.id !== id && isConfirmed(other))
            other.asset.texts.forEach(
              (text) => aliases.add(normalizedAlias(text))
            );
        }
        const conflict = aliasConflict(entry.asset, aliases);
        if (conflict !== null)
          throw motionError("motionAliasConflict", conflict);
      }
      await area.set({
        [MOTION_STORAGE_PREFIX + id]: {
          asset: entry.asset,
          enabled,
          review: enabled ? {
            confirmedAt: (/* @__PURE__ */ new Date()).toISOString(),
            assetJson: serializeMotionAsset(entry.asset)
          } : null
        }
      });
    });
  }
  async function storedMotions() {
    const values = await area.get(null);
    return Object.fromEntries(
      Object.entries(values).filter(([key]) => key.startsWith(MOTION_STORAGE_PREFIX)).map(([key, value]) => [
        key.slice(MOTION_STORAGE_PREFIX.length),
        value
      ])
    );
  }
  async function exportPack() {
    const { entries, invalidCount } = await list();
    if (invalidCount) throw motionError("motionPackInvalidStored");
    return createMotionPack(entries, rig2);
  }
  async function previewPack(input) {
    const pack = validateMotionPack(input, rig2);
    return inspectMotionPack(pack, await storedMotions(), rig2);
  }
  async function importPack(input, expectedRevision) {
    if (!locks?.request) throw motionError("motionPackLockUnavailable");
    const pack = validateMotionPack(input, rig2);
    return write(async () => {
      const plan = inspectMotionPack(pack, await storedMotions(), rig2);
      if (plan.revision !== expectedRevision)
        throw motionError("motionPackStale");
      if (plan.counts.conflict) throw motionError("motionPackConflict");
      const newIds = new Set(
        plan.items.filter((item) => item.state === "new").map((item) => item.id)
      );
      const updates = Object.fromEntries(
        pack.motions.filter(({ asset }) => newIds.has(asset.id)).map(({ asset }) => [
          MOTION_STORAGE_PREFIX + asset.id,
          { asset, enabled: false, review: null }
        ])
      );
      if (newIds.size) await area.set(updates);
      return { imported: newIds.size, skipped: plan.counts.existing };
    });
  }
  function subscribe(listener) {
    const handler = (changes, areaName) => {
      if (areaName === "local" && Object.keys(changes).some(
        (key) => key.startsWith(MOTION_STORAGE_PREFIX)
      ))
        listener();
    };
    storage.onChanged.addListener(handler);
    return () => storage.onChanged.removeListener(handler);
  }
  return {
    list,
    saveDraft,
    setEnabled,
    subscribe,
    exportPack,
    previewPack,
    importPack
  };
}

// src/avatar/iframe-bundle.js
var renderer;
var scene;
var camera;
var rig = null;
var motionPlayer = null;
var modelRoot = null;
var baseModelY = -0.65;
var modelReady = false;
var modelLoading = false;
var renderFrameId = null;
var breathingFrameId = null;
var blinkTimerId = null;
var translationMatchers = compileTranslationMatchers();
var unsubscribeMotions = null;
var motionLibraryVersion = 0;
var motionLibraryIdentity = "[]";
async function loadMotionLibrary() {
  try {
    const library = createMotionLibrary(rig);
    async function refresh() {
      const version = ++motionLibraryVersion;
      try {
        const { entries, invalidCount } = await library.list();
        if (version !== motionLibraryVersion || !modelReady) return;
        const motions = selectEnabledMotions(entries);
        const identity = JSON.stringify(motions);
        if (identity !== motionLibraryIdentity) {
          motionPlayer?.stop({ reset: true });
          translationMatchers = compileTranslationMatchers(motions);
          motionLibraryIdentity = identity;
        }
        console.log("[SB] Motion library:", {
          enabled: motions.length,
          invalid: invalidCount
        });
      } catch (error) {
        if (version !== motionLibraryVersion) return;
        motionPlayer?.stop({ reset: true });
        translationMatchers = compileTranslationMatchers();
        motionLibraryIdentity = "[]";
        console.warn("[SB] Motion library unavailable:", error.message);
      }
    }
    unsubscribeMotions = library.subscribe(refresh);
    await refresh();
  } catch (error) {
    console.warn("[SB] Motion library unavailable:", error.message);
  }
}
function textToAnimation(text, manual = false) {
  if (!text) return false;
  const result = translateText(text, 12, translationMatchers);
  if (!result) return false;
  console.log("[SB] Translation coverage:", {
    matches: result.matches.map((match) => match.text),
    motionIds: result.matches.map((match) => match.id),
    unmatched: result.unmatched,
    truncated: result.truncated,
    remainingText: result.remainingText
  });
  if (!result.matches.length) return false;
  if (manual) return motionPlayer?.play(result) || false;
  return motionPlayer?.enqueue(result, {
    key: normalizeText(text).toLowerCase()
  }) || false;
}
function init(modelUrl) {
  if (modelReady) {
    notify("READY", {});
    return;
  }
  if (modelLoading) return;
  modelLoading = true;
  console.log("[SB] Loading:", modelUrl);
  const container = document.getElementById("c");
  if (!container) return;
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setClearColor(0, 0);
  container.appendChild(renderer.domElement);
  scene = new THREE.Scene();
  scene.background = new THREE.Color(14477557);
  scene.add(new THREE.AmbientLight(16777215, 1.2));
  const dl = new THREE.DirectionalLight(16777215, 1);
  dl.position.set(2, 5, 3);
  scene.add(dl);
  const dl2 = new THREE.DirectionalLight(16777215, 0.6);
  dl2.position.set(-1, 2, -1);
  scene.add(dl2);
  camera = new THREE.PerspectiveCamera(
    45,
    container.clientWidth / container.clientHeight,
    0.1,
    100
  );
  camera.position.set(0, 0.65, 1.5);
  camera.lookAt(0, 0.5, 0);
  const loader = new GLTFLoader();
  loader.load(
    modelUrl,
    async (gltf) => {
      console.log("[SB] Model loaded");
      let primaryMesh = null;
      gltf.scene.traverse((child) => {
        if (child.isSkinnedMesh && !primaryMesh) {
          primaryMesh = child;
          console.log(
            "[SB] Mesh:",
            child.name,
            "tri:",
            child.geometry?.index?.count || "?"
          );
        }
      });
      const boneCount = primaryMesh?.skeleton?.bones.length || 0;
      console.log("[SB] Bones:", boneCount);
      rig = createHumanoidRig(gltf.scene);
      motionPlayer = createMotionPlayer(rig);
      console.log(
        "[SB] Humanoid profile:",
        rig.profile.id,
        `${Object.keys(rig.bones).length} mapped`
      );
      if (!rig.isSigningReady) {
        console.error("[SB] Missing signing bones:", rig.missing);
        modelLoading = false;
        notify("ERROR", {
          message: `Missing signing bones: ${rig.missing.join(", ")}`
        });
        return;
      }
      scene.add(gltf.scene);
      gltf.scene.scale.set(0.984, 0.984, 0.984);
      gltf.scene.position.y = -0.65;
      modelRoot = gltf.scene;
      baseModelY = gltf.scene.position.y;
      console.log("[SB] REST saved for", Object.keys(rig.rest).length, "bones");
      modelReady = true;
      modelLoading = false;
      await loadMotionLibrary();
      if (!modelReady) return;
      startIdleAnimations();
      setupMouseControls();
      notify("READY", {});
      console.log("[SB] \u2705 Ready");
    },
    void 0,
    (err) => {
      modelLoading = false;
      console.error("[SB] Load error:", err);
      notify("ERROR", { message: err.message || String(err) });
    }
  );
  if (!renderFrameId) animate();
}
function animate() {
  renderFrameId = requestAnimationFrame(animate);
  try {
    if (scene) scene.updateMatrixWorld(true);
    if (renderer && scene && camera) renderer.render(scene, camera);
  } catch {
  }
}
function notify(type, data) {
  try {
    parent.postMessage(
      { source: "signbridge-iframe", type, ...data || {} },
      "*"
    );
  } catch {
  }
}
function startIdleAnimations() {
  function scheduleBlink() {
    const delay = 2e3 + Math.random() * 3e3;
    blinkTimerId = setTimeout(() => {
      if (!modelReady || motionPlayer?.isPlaying) {
        scheduleBlink();
        return;
      }
      blink();
      scheduleBlink();
    }, delay);
  }
  scheduleBlink();
  let breathTime = 0;
  baseModelY = modelRoot?.position.y ?? -0.65;
  function breathingLoop() {
    if (!modelReady || !modelRoot) {
      breathingFrameId = requestAnimationFrame(breathingLoop);
      return;
    }
    breathTime += 0.016;
    const breathe = Math.sin(breathTime * 0.8) * 3e-3;
    if (modelRoot && !motionPlayer?.isPlaying) {
      modelRoot.position.y = baseModelY + breathe;
    }
    breathingFrameId = requestAnimationFrame(breathingLoop);
  }
  breathingFrameId = requestAnimationFrame(breathingLoop);
}
function blink() {
  const le = rig?.bones.leftUpperEyelid, re = rig?.bones.rightUpperEyelid;
  if (!le || !re) return;
  const startY = le.rotation.x;
  const dur = 150;
  let start;
  function step(ts) {
    if (!start) start = ts;
    const t = (ts - start) / dur;
    if (t < 0.4) {
      const v = t / 0.4;
      le.rotation.x = startY + v * 0.3;
      re.rotation.x = startY + v * 0.3;
    } else if (t < 0.6) {
      le.rotation.x = startY + 0.3;
      re.rotation.x = startY + 0.3;
    } else if (t < 1) {
      const v = 1 - (t - 0.6) / 0.4;
      le.rotation.x = startY + v * 0.3;
      re.rotation.x = startY + v * 0.3;
    } else {
      le.rotation.x = startY;
      re.rotation.x = startY;
      rig?.update();
      return;
    }
    rig?.update();
    requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
function setupMouseControls() {
  const canvas = renderer.domElement;
  if (!canvas) return;
  let isDragging = false, lastX = 0, lastY = 0, shiftKey = false;
  canvas.style.cursor = "grab";
  canvas.addEventListener("pointerdown", (e) => {
    isDragging = true;
    shiftKey = e.shiftKey;
    lastX = e.clientX;
    lastY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
    canvas.style.cursor = shiftKey ? "grabbing" : "grabbing";
    e.preventDefault();
    e.stopPropagation();
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!isDragging || !modelRoot) return;
    const dx = e.clientX - lastX;
    const dy = e.clientY - lastY;
    if (!shiftKey) modelRoot.rotation.y += dx * 0.01;
    modelRoot.position.y -= dy * 8e-3;
    baseModelY = modelRoot.position.y;
    lastX = e.clientX;
    lastY = e.clientY;
  });
  canvas.addEventListener("pointerup", () => {
    isDragging = false;
    canvas.style.cursor = "grab";
  });
  canvas.addEventListener("pointerleave", () => {
    if (!isDragging) canvas.style.cursor = "grab";
  });
  canvas.addEventListener(
    "wheel",
    (e) => {
      if (!modelRoot) return;
      e.preventDefault();
      const s = modelRoot.scale.x;
      const ns = Math.max(
        0.2,
        Math.min(2.5, s * (e.deltaY > 0 ? 0.985 : 1.015))
      );
      modelRoot.scale.set(ns, ns, ns);
    },
    { passive: false }
  );
  window.addEventListener("keydown", (e) => {
    if (e.key === "Shift") shiftKey = true;
  });
  window.addEventListener("keyup", (e) => {
    if (e.key === "Shift") shiftKey = false;
  });
}
notify("LOADED", {});
window.addEventListener("message", (ev) => {
  if (ev.source !== parent || !ev.data || ev.data.source !== "signbridge-page")
    return;
  if (ev.data.type !== "SUBTITLE_TEXT") {
    console.log("[SB] iframe rx:", ev.data.type);
  }
  switch (ev.data.type) {
    case "INIT":
      init(ev.data.modelUrl);
      break;
    case "SUBTITLE_TEXT":
      if (modelReady && ev.data.text) {
        textToAnimation(ev.data.text, ev.data.manual === true);
      }
      break;
    case "PLAYBACK_RESET":
      motionPlayer?.stop({ reset: true });
      break;
    case "RESIZE":
      if (renderer) {
        renderer.setSize(ev.data.width, ev.data.height);
        camera.aspect = ev.data.width / ev.data.height;
        camera.updateProjectionMatrix();
      }
      break;
  }
});
window.addEventListener("pagehide", disposeAvatar, { once: true });
function disposeAvatar() {
  modelReady = false;
  motionLibraryVersion += 1;
  unsubscribeMotions?.();
  motionPlayer?.stop();
  if (renderFrameId) cancelAnimationFrame(renderFrameId);
  if (breathingFrameId) cancelAnimationFrame(breathingFrameId);
  if (blinkTimerId) clearTimeout(blinkTimerId);
  modelRoot?.traverse((object) => {
    object.geometry?.dispose?.();
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) {
      if (!material) continue;
      for (const value of Object.values(material)) {
        if (value?.isTexture) value.dispose();
      }
      material.dispose?.();
    }
  });
  motionPlayer = null;
  rig = null;
  modelRoot = null;
  renderer?.dispose();
}
console.log("[SB] v17 \u2014 multi-site + structured gestures + eased blending");
