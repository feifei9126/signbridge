function lt(i,e,t){let n=Math.PI/180;return{x:(i||0)*n,y:(e||0)*n,z:(t||0)*n}}function se(i,e){return{value:i,duration:e||.8}}function Uc(i,e,t={}){if(!i||!Array.isArray(e)||e.length===0)throw new TypeError("A motion clip requires an id and at least one frame.");return{id:i,version:1,space:"humanoid-local-v1",frames:e,metadata:t}}var Ts=["Index","Middle","Ring","Little"];function vi(i,e,t,[n,s,r]){i[`${e}${t}Proximal`]=lt(n,0,0),i[`${e}${t}Intermediate`]=lt(s,0,0),i[`${e}${t}Distal`]=lt(r,0,0)}function Fi(i,e,t){let[n,s,r]=t;i[`${e}ThumbMetacarpal`]=n,i[`${e}ThumbProximal`]=s,i[`${e}ThumbDistal`]=r}function Fc(i,e="right"){if(i==="relax")return{};let t={},n=e==="left"?-1:1,s=[-25,-55,-30],r=[8,14,8],o=[lt(-10,0,0),lt(-20,0,0),lt(-10,0,0)],a=[lt(8,0,0),lt(14,0,0),lt(8,0,0)];if(i==="fist"){for(let l of Ts)vi(t,e,l,s);Fi(t,e,o)}else if(i==="flat"){for(let l of Ts)vi(t,e,l,r);Fi(t,e,a)}else if(i==="point"){for(let l of Ts)vi(t,e,l,l==="Index"?r:s);Fi(t,e,o)}else if(i==="thumbUp"){for(let l of Ts)vi(t,e,l,s);Fi(t,e,[lt(0,63*n,63*n),lt(0,0,0),lt(0,0,0)])}else if(i==="peace"){for(let l of Ts)vi(t,e,l,l==="Index"||l==="Middle"?r:s);Fi(t,e,o)}else if(i==="ok"){vi(t,e,"Index",[-20,-45,-25]);for(let l of["Middle","Ring","Little"])vi(t,e,l,[-15,-35,-20]);Fi(t,e,[lt(-10,30*n,0),lt(-10,0,0),lt(0,0,0)])}return t}function ce(i,e,t,n){let s={};if(s.rightShoulder=lt(i[0]||0,i[1]||0,i[2]||0),s.rightUpperArm=lt(i[3]||0,i[4]||0,i[5]||0),s.rightLowerArm=lt(i[6]||0,i[7]||0,i[8]||0),s.rightHand=lt(i[9]||0,i[10]||0,i[11]||0),t&&(s.leftShoulder=lt(t[0]||0,t[1]||0,t[2]||0),s.leftUpperArm=lt(t[3]||0,t[4]||0,t[5]||0),s.leftLowerArm=lt(t[6]||0,t[7]||0,t[8]||0),s.leftHand=lt(t[9]||0,t[10]||0,t[11]||0)),e){let r=Fc(e,"right");for(let o in r)s[o]=r[o]}if(n){let r=Fc(n,"left");for(let o in r)s[o]=r[o]}return s}var je=[0,0,0,35,50,-15,15,0,0,0,0,0],Kn=[0,0,0,30,50,-10,10,0,0,0,0,0],kc=[0,0,0,55,5,-10,20,0,0,0,10,10],Uo=[10,20,0,35,20,0,15,5,0,10,0,0],cr=[10,-20,0,35,-5,0,15,-5,0,10,0,0],Oc=[0,0,0,35,40,-10,20,0,0,0,-5,0],Do=[0,0,0,40,50,-15,20,0,0,5,0,0],Bc=[15,20,0,50,40,-15,25,5,0,5,0,0],An={csl_hello:{id:"csl_hello",gloss:"\u4F60\u597D",texts:["\u4F60\u597D","\u60A8\u597D","\u55E8","hello","hi"],tags:["greeting"],frames:[se(ce(je,"point"),.6),se(ce(je,"thumbUp"),.7)],meta:{handshape:"point+thumbUp",location:"chest",movement:"none"}},csl_thanks:{id:"csl_thanks",gloss:"\u8C22\u8C22",texts:["\u8C22\u8C22","\u591A\u8C22","\u611F\u8C22","thanks"],tags:["polite"],frames:[se(ce(kc,"fist"),.8)],meta:{handshape:"fist",location:"chest",movement:"nod"}},csl_yes:{id:"csl_yes",gloss:"\u662F",texts:["\u662F","\u5BF9","\u6B63\u786E","yes","ok"],tags:["confirm"],frames:[se(ce(je,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"nod"}},csl_no:{id:"csl_no",gloss:"\u4E0D",texts:["\u4E0D","\u6CA1","\u6CA1\u6709","\u522B","no","not"],tags:["negation"],frames:[se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"point"),.5)],meta:{handshape:"point",location:"chest",movement:"sway"}},csl_good:{id:"csl_good",gloss:"\u597D",texts:["\u597D","\u68D2","\u4F18\u79C0","good","great"],tags:["positive"],frames:[se(ce(je,"thumbUp"),.7)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_me:{id:"csl_me",gloss:"\u6211",texts:["\u6211","\u81EA\u5DF1","me","I"],tags:["pronoun"],frames:[se(ce([0,0,0,35,50,-15,25,0,0,5,0,0],"point"),.6)],meta:{handshape:"point",location:"chest",movement:"self"}},csl_you:{id:"csl_you",gloss:"\u4F60",texts:["\u4F60","\u60A8","you"],tags:["pronoun"],frames:[se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"point"),.6)],meta:{handshape:"point",location:"forward",movement:"none"}},csl_help:{id:"csl_help",gloss:"\u5E2E\u52A9",texts:["\u5E2E\u52A9","\u5E2E\u5FD9","\u5E2E","help"],tags:["action"],frames:[se(ce([0,0,0,40,40,-10,25,0,0,-5,5,0],"flat"),.7)],meta:{handshape:"flat",location:"chest",movement:"support"}},csl_welcome:{id:"csl_welcome",gloss:"\u6B22\u8FCE",texts:["\u6B22\u8FCE","welcome"],tags:["greeting"],frames:[se(ce(Uo,"flat",cr,"flat"),.8)],meta:{handshape:"flat",location:"side",movement:"open"}},csl_love:{id:"csl_love",gloss:"\u7231",texts:["\u7231","\u559C\u6B22","love","like"],tags:["emotion"],frames:[se(ce(Kn,"fist",Kn,"fist"),.8)],meta:{handshape:"fist",location:"heart",movement:"none"}},csl_goodbye:{id:"csl_goodbye",gloss:"\u518D\u89C1",texts:["\u518D\u89C1","\u62DC\u62DC","bye","goodbye"],tags:["greeting"],frames:[se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.6),se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.4),se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.4)],meta:{handshape:"flat",location:"side",movement:"wave"}},csl_happy:{id:"csl_happy",gloss:"\u5F00\u5FC3",texts:["\u5F00\u5FC3","\u9AD8\u5174","\u5FEB\u4E50","happy"],tags:["emotion"],frames:[se(ce([0,0,0,40,50,-15,25,0,0,0,0,0],"flat"),.6)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_true:{id:"csl_true",gloss:"\u771F",texts:["\u771F","\u771F\u7684","\u786E\u5B9E","true","really"],tags:["confirm"],frames:[se(ce(je,"point"),.5)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_too:{id:"csl_too",gloss:"\u592A",texts:["\u592A","\u5F88","\u975E\u5E38","very","too"],tags:["degree"],frames:[se(ce(je,"thumbUp"),.5)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_what:{id:"csl_what",gloss:"\u4EC0\u4E48",texts:["\u4EC0\u4E48","\u5565","what"],tags:["question"],frames:[se(ce(je,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_he:{id:"csl_he",gloss:"\u4ED6",texts:["\u4ED6","\u5979","\u5B83","he","she"],tags:["pronoun"],frames:[se(ce([0,0,0,40,60,-15,20,0,0,5,0,0],"point"),.6)],meta:{handshape:"point",location:"side",movement:"none"}},csl_we:{id:"csl_we",gloss:"\u6211\u4EEC",texts:["\u6211\u4EEC","\u54B1\u4EEC","we","us"],tags:["pronoun"],frames:[se(ce([0,0,0,30,40,-10,20,0,0,5,0,0],"point"),.7)],meta:{handshape:"point",location:"chest",movement:"arc"}},csl_this:{id:"csl_this",gloss:"\u8FD9",texts:["\u8FD9","\u8FD9\u4E2A","this"],tags:["demonstrative"],frames:[se(ce(Oc,"point"),.5)],meta:{handshape:"point",location:"down",movement:"none"}},csl_that:{id:"csl_that",gloss:"\u90A3",texts:["\u90A3","\u90A3\u4E2A","that"],tags:["demonstrative"],frames:[se(ce([0,0,0,40,60,-15,20,0,0,5,0,0],"point"),.5)],meta:{handshape:"point",location:"forward",movement:"none"}},csl_who:{id:"csl_who",gloss:"\u8C01",texts:["\u8C01","who"],tags:["question"],frames:[se(ce(je,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_how:{id:"csl_how",gloss:"\u600E\u4E48",texts:["\u600E\u4E48","\u600E\u6837","how"],tags:["question"],frames:[se(ce(je,"flat"),.6)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_where:{id:"csl_where",gloss:"\u54EA",texts:["\u54EA","\u54EA\u91CC","where"],tags:["question"],frames:[se(ce(je,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_have:{id:"csl_have",gloss:"\u6709",texts:["\u6709","have","has"],tags:["state"],frames:[se(ce(je,"thumbUp"),.6)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_can:{id:"csl_can",gloss:"\u53EF\u4EE5",texts:["\u53EF\u4EE5","\u80FD","can","may"],tags:["modal"],frames:[se(ce(je,"ok"),.6)],meta:{handshape:"ok",location:"chest",movement:"nod"}},csl_want:{id:"csl_want",gloss:"\u8981",texts:["\u8981","\u60F3","want","need"],tags:["modal"],frames:[se(ce(je,"flat"),.6)],meta:{handshape:"flat",location:"chest",movement:"pull"}},csl_come:{id:"csl_come",gloss:"\u6765",texts:["\u6765","\u8FC7\u6765","come"],tags:["action"],frames:[se(ce(Do,"flat"),.6)],meta:{handshape:"flat",location:"side",movement:"beckon"}},csl_go:{id:"csl_go",gloss:"\u53BB",texts:["\u53BB","\u8D70","go"],tags:["action"],frames:[se(ce([0,0,0,40,50,-15,25,0,0,0,0,0],"flat"),.5)],meta:{handshape:"flat",location:"forward",movement:"push"}},csl_say:{id:"csl_say",gloss:"\u8BF4",texts:["\u8BF4","\u8BB2","say","speak"],tags:["action"],frames:[se(ce([0,0,0,35,40,-15,20,0,0,-5,0,0],"flat"),.6)],meta:{handshape:"flat",location:"mouth",movement:"none"}},csl_see:{id:"csl_see",gloss:"\u770B",texts:["\u770B","\u89C1","see","look"],tags:["action"],frames:[se(ce([0,0,0,35,35,-10,20,0,0,0,0,0],"point"),.6)],meta:{handshape:"point",location:"eyes",movement:"none"}},csl_know:{id:"csl_know",gloss:"\u77E5\u9053",texts:["\u77E5\u9053","\u61C2","know","understand"],tags:["cognition"],frames:[se(ce(je,"point"),.6)],meta:{handshape:"point",location:"temple",movement:"none"}},csl_big:{id:"csl_big",gloss:"\u5927",texts:["\u5927","big","large"],tags:["size"],frames:[se(ce(Bc,"flat"),.6)],meta:{handshape:"flat",location:"side",movement:"spread"}},csl_small:{id:"csl_small",gloss:"\u5C0F",texts:["\u5C0F","small","little"],tags:["size"],frames:[se(ce([0,0,0,35,30,-10,20,0,0,0,0,0],"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"close"}},csl_many:{id:"csl_many",gloss:"\u591A",texts:["\u591A","\u5F88\u591A","many","much"],tags:["quantity"],frames:[se(ce(je,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_up:{id:"csl_up",gloss:"\u4E0A",texts:["\u4E0A","up","above"],tags:["direction"],frames:[se(ce([0,0,0,40,40,-15,15,0,0,10,0,0],"point"),.5)],meta:{handshape:"point",location:"up",movement:"none"}},csl_down:{id:"csl_down",gloss:"\u4E0B",texts:["\u4E0B","down","below"],tags:["direction"],frames:[se(ce([0,0,0,35,40,-15,25,0,0,-5,0,0],"point"),.5)],meta:{handshape:"point",location:"down",movement:"none"}},csl_now:{id:"csl_now",gloss:"\u73B0\u5728",texts:["\u73B0\u5728","now"],tags:["time"],frames:[se(ce(je,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_today:{id:"csl_today",gloss:"\u4ECA\u5929",texts:["\u4ECA\u5929","today"],tags:["time"],frames:[se(ce(je,"point"),.5)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_also:{id:"csl_also",gloss:"\u4E5F",texts:["\u4E5F","also","too"],tags:["conjunction"],frames:[se(ce(je,"point"),.5)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_all:{id:"csl_all",gloss:"\u90FD",texts:["\u90FD","\u5168\u90E8","all"],tags:["quantity"],frames:[se(ce(Bc,"flat",cr,"flat"),.6)],meta:{handshape:"flat",location:"side",movement:"arc"}},csl_but:{id:"csl_but",gloss:"\u4F46\u662F",texts:["\u4F46\u662F","\u4F46","but"],tags:["conjunction"],frames:[se(ce(je,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_if:{id:"csl_if",gloss:"\u5982\u679C",texts:["\u5982\u679C","\u8981\u662F","if"],tags:["conjunction"],frames:[se(ce(je,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_very:{id:"csl_very",gloss:"\u5F88",texts:["\u5F88","\u975E\u5E38","very","quite"],tags:["degree"],frames:[se(ce(je,"thumbUp"),.5)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_and:{id:"csl_and",gloss:"\u548C",texts:["\u548C","\u8DDF","\u4E0E","and"],tags:["conjunction"],frames:[se(ce([0,0,0,35,40,-15,20,0,0,5,0,0],"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_new:{id:"csl_new",gloss:"\u65B0",texts:["\u65B0","new"],tags:["quality"],frames:[se(ce(Do,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_old:{id:"csl_old",gloss:"\u8001",texts:["\u8001","\u65E7","old"],tags:["quality"],frames:[se(ce(Oc,"fist"),.5)],meta:{handshape:"fist",location:"chest",movement:"none"}},csl_one:{id:"csl_one",gloss:"\u4E00",texts:["\u4E00","one"],tags:["number"],frames:[se(ce(je,"point"),.4)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_two:{id:"csl_two",gloss:"\u4E8C",texts:["\u4E8C","\u4E24","two"],tags:["number"],frames:[se(ce(je,"peace"),.4)],meta:{handshape:"peace",location:"chest",movement:"none"}},csl_three:{id:"csl_three",gloss:"\u4E09",texts:["\u4E09","three"],tags:["number"],frames:[se(ce(je,"ok"),.4)],meta:{handshape:"ok",location:"chest",movement:"none"}},csl_please:{id:"csl_please",gloss:"\u8BF7",texts:["\u8BF7","please"],tags:["polite"],frames:[se(ce(Do,"flat"),.7)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_do:{id:"csl_do",gloss:"\u505A",texts:["\u505A","\u5E72","do"],tags:["action"],frames:[se(ce(je,"fist"),.5)],meta:{handshape:"fist",location:"chest",movement:"none"}},csl_people:{id:"csl_people",gloss:"\u4EBA",texts:["\u4EBA","person","people"],tags:["noun"],frames:[se(ce([0,0,0,35,50,-15,25,0,0,0,0,0],"point"),.6)],meta:{handshape:"point",location:"side",movement:"none"}},csl_self:{id:"csl_self",gloss:"\u81EA\u5DF1",texts:["\u81EA\u5DF1","self"],tags:["pronoun"],frames:[se(ce(Kn,"fist",Kn,"fist"),.6)],meta:{handshape:"fist",location:"chest",movement:"self"}}};for(let i of Object.values(An))i.motion=Uc(i.id,i.frames,{gloss:i.gloss,tags:i.tags,...i.meta});var Md={};function At(i,e){Md[i]=e}At("\u4F60",[se(ce(je,"point"),.6)]);At("\u597D",[se(ce(je,"thumbUp"),.7)]);At("\u8C22",[se(ce(kc,"fist"),.8)]);At("\u6211",[se(ce([0,0,0,35,50,-15,25,0,0,5,0,0],"point"),.6)]);At("\u7231",[se(ce(Kn,"fist",Kn,"fist"),.8)]);At("\u662F",[se(ce(je,"point"),.6)]);At("\u5BF9",[se(ce(je,"point"),.6)]);At("\u4E0D",[se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"point"),.5)]);At("\u5E2E",[se(ce([0,0,0,40,40,-10,25,0,0,-5,5,0],"flat"),.6)]);At("\u52A9",[se(ce([0,0,0,40,40,-10,25,0,0,-5,5,0],"flat"),.6)]);At("\u518D",[se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.6)]);At("\u89C1",[se(ce([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.6)]);At("\u6B22",[se(ce(Uo,"flat",cr,"flat"),.6)]);At("\u8FCE",[se(ce(Uo,"flat",cr,"flat"),.6)]);At("\u559C",[se(ce(Kn,"fist",Kn,"fist"),.7)]);At(" ",[se({},.3)]);function Sd(){let i={};for(let e of Object.values(An))for(let t of e.texts)i[t]||(i[t]=e.frames);return i}function No(i){return i?i.replace(/[，。！？、；："“”（）【】《》\s]+/g," ").replace(/[^\u4e00-\u9fff\u3400-\u4dbf a-zA-Z0-9'’-]/g," ").replace(/\s+/g," ").trim():""}var bd=new Intl.Segmenter("zh",{granularity:"word"});function zc(i){return[...bd.segment(i)].filter(e=>e.isWordLike)}function Es(i){let e=zc(No(i).toLowerCase()).map(t=>t.segment);return e.length?JSON.stringify(e):""}function wd(i=[]){return[...Object.values(An),...i].flatMap(e=>e.texts.map(t=>({id:e.id,sign:e,text:No(t).toLowerCase(),tokens:zc(No(t).toLowerCase()).map(n=>n.segment)}))).filter(e=>e.text&&e.tokens.length).sort((e,t)=>t.text.length-e.text.length)}var vv=wd();var xv=Sd();var Hc=Object.freeze(["root","body","hips","spine","chest","upperChest","neck","neck2","neck3","head","rightShoulder","rightUpperArm","rightLowerArm","rightHand","leftShoulder","leftUpperArm","leftLowerArm","leftHand","rightThumbMetacarpal","rightThumbProximal","rightThumbDistal","rightIndexProximal","rightIndexIntermediate","rightIndexDistal","rightMiddleProximal","rightMiddleIntermediate","rightMiddleDistal","rightRingProximal","rightRingIntermediate","rightRingDistal","rightLittleProximal","rightLittleIntermediate","rightLittleDistal","leftThumbMetacarpal","leftThumbProximal","leftThumbDistal","leftIndexProximal","leftIndexIntermediate","leftIndexDistal","leftMiddleProximal","leftMiddleIntermediate","leftMiddleDistal","leftRingProximal","leftRingIntermediate","leftRingDistal","leftLittleProximal","leftLittleIntermediate","leftLittleDistal","jaw","leftUpperEyelid","rightUpperEyelid","leftLowerEyelid","rightLowerEyelid"]),Ad=Object.freeze(["rightUpperArm","rightLowerArm","rightHand","leftUpperArm","leftLowerArm","leftHand","rightThumbMetacarpal","rightThumbProximal","rightThumbDistal","rightIndexProximal","rightIndexIntermediate","rightIndexDistal","rightMiddleProximal","rightMiddleIntermediate","rightMiddleDistal","rightRingProximal","rightRingIntermediate","rightRingDistal","rightLittleProximal","rightLittleIntermediate","rightLittleDistal","leftThumbMetacarpal","leftThumbProximal","leftThumbDistal","leftIndexProximal","leftIndexIntermediate","leftIndexDistal","leftMiddleProximal","leftMiddleIntermediate","leftMiddleDistal","leftRingProximal","leftRingIntermediate","leftRingDistal","leftLittleProximal","leftLittleIntermediate","leftLittleDistal"]),Vc=Object.freeze({id:"godette-v1",motionSpace:"humanoid-local-v1",bones:Object.freeze({root:["Root_225"],body:["Body_220"],hips:["Hip_218"],spine:["Spine_1_199"],chest:["Spine_2_198"],upperChest:["Ribcage_197"],neck:["Neck_1_132"],neck2:["Neck_2_131"],neck3:["Neck_3_130"],head:["Head_129"],rightShoulder:["ClavicR_192","Clavic.R_192"],rightUpperArm:["Arm_Upper_1R_187","Arm_Upper_1.R_187"],rightLowerArm:["Arm_Lower_1R_185","Arm_Lower_1.R_185"],rightHand:["HandR_184","Hand.R_184"],leftShoulder:["ClavicL_162","Clavic.L_162"],leftUpperArm:["Arm_Upper_1L_157","Arm_Upper_1.L_157"],leftLowerArm:["Arm_Lower_1L_155","Arm_Lower_1.L_155"],leftHand:["HandL_154","Hand.L_154"],rightThumbMetacarpal:["ThumbR_178","Thumb.R_178"],rightThumbProximal:["ThumbR002_177","Thumb.R.002_177"],rightThumbDistal:["ThumbR001_176","Thumb.R.001_176"],rightIndexProximal:["Finger_1R_166","Finger_1.R_166"],rightIndexIntermediate:["Finger_1R002_165","Finger_1.R.002_165"],rightIndexDistal:["Finger_1R001_164","Finger_1.R.001_164"],rightMiddleProximal:["Finger_2R_169","Finger_2.R_169"],rightMiddleIntermediate:["Finger_2R002_168","Finger_2.R.002_168"],rightMiddleDistal:["Finger_2R001_167","Finger_2.R.001_167"],rightRingProximal:["Finger_3R_172","Finger_3.R_172"],rightRingIntermediate:["Finger_3R002_171","Finger_3.R.002_171"],rightRingDistal:["Finger_3R001_170","Finger_3.R.001_170"],rightLittleProximal:["Finger_4R_175","Finger_4.R_175"],rightLittleIntermediate:["Finger_4R002_174","Finger_4.R.002_174"],rightLittleDistal:["Finger_4R001_173","Finger_4.R.001_173"],leftThumbMetacarpal:["ThumbL_148","Thumb.L_148"],leftThumbProximal:["ThumbL002_147","Thumb.L.002_147"],leftThumbDistal:["ThumbL001_146","Thumb.L.001_146"],leftIndexProximal:["Finger_1L_136","Finger_1.L_136"],leftIndexIntermediate:["Finger_1L002_135","Finger_1.L.002_135"],leftIndexDistal:["Finger_1L001_134","Finger_1.L.001_134"],leftMiddleProximal:["Finger_2L_139","Finger_2.L_139"],leftMiddleIntermediate:["Finger_2L002_138","Finger_2.L.002_138"],leftMiddleDistal:["Finger_2L001_137","Finger_2.L.001_137"],leftRingProximal:["Finger_3L_142","Finger_3.L_142"],leftRingIntermediate:["Finger_3L002_141","Finger_3.L.002_141"],leftRingDistal:["Finger_3L001_140","Finger_3.L.001_140"],leftLittleProximal:["Finger_4L_145","Finger_4.L_145"],leftLittleIntermediate:["Finger_4L002_144","Finger_4.L.002_144"],leftLittleDistal:["Finger_4L001_143","Finger_4.L.001_143"],jaw:["Jaw_4"],leftUpperEyelid:["Eyelid_Control_UpperL_14"],rightUpperEyelid:["Eyelid_Control_UpperR_15"],leftLowerEyelid:["Eyelid_Control_LowerL_16"],rightLowerEyelid:["Eyelid_Control_LowerR_17"]})}),Td=Object.freeze({hip:"hips",ribcage:"upperChest",rShoulder:"rightShoulder",rUpperArm:"rightUpperArm",rForearm:"rightLowerArm",rHand:"rightHand",lShoulder:"leftShoulder",lUpperArm:"leftUpperArm",lForearm:"leftLowerArm",lHand:"leftHand",rthumb:"rightThumbMetacarpal",rindex:"rightIndexIntermediate",rmiddle:"rightMiddleIntermediate",rring:"rightRingIntermediate",rpinky:"rightLittleIntermediate",lthumb:"leftThumbMetacarpal",lindex:"leftIndexIntermediate",lmiddle:"leftMiddleIntermediate",lring:"leftRingIntermediate",lpinky:"leftLittleIntermediate",lUpperEyelid:"leftUpperEyelid",rUpperEyelid:"rightUpperEyelid",lLowerEyelid:"leftLowerEyelid",rLowerEyelid:"rightLowerEyelid"});function Gc(i){return String(i||"").replace(/[._\s-]/g,"").toLowerCase()}function hr(i={}){let e={};for(let[t,n]of Object.entries(i))e[Td[t]||t]=n;return e}function Ed(i){let e=new Map,t=new Map,n=new Set;return i?.traverse?.(s=>{s.isBone&&(e.set(s.name,s),t.set(Gc(s.name),s)),s.isSkinnedMesh&&s.skeleton&&n.add(s.skeleton)}),{exact:e,normalized:t,skeletons:[...n]}}function Rd(i,e=Vc){let t=Ed(i),n={};for(let[s,r]of Object.entries(e.bones))for(let o of r){let a=t.exact.get(o)||t.normalized.get(Gc(o));if(a){n[s]=a;break}}return{bones:n,skeletons:t.skeletons}}function Wc(i,e=Vc){let{bones:t,skeletons:n}=Rd(i,e),s={};for(let[f,g]of Object.entries(t))s[f]={quaternion:g.quaternion.clone(),rotation:{x:g.rotation.x,y:g.rotation.y,z:g.rotation.z,order:g.rotation.order}};function r(){for(let f of n)f.update()}function o(f={}){let g=hr(f),_={};for(let[m,p]of Object.entries(t)){let w=s[m],S=g[m];if(!S){_[m]=w.quaternion.clone();continue}let y=p.rotation.clone();y.set(w.rotation.x+(S.x||0),w.rotation.y+(S.y||0),w.rotation.z+(S.z||0),w.rotation.order),_[m]=p.quaternion.clone().setFromEuler(y)}return _}function a(){let f={};for(let[g,_]of Object.entries(t))f[g]=_.quaternion.clone();return f}function l(){let f={};for(let[g,_]of Object.entries(t)){let m=s[g].rotation;f[g]={x:_.rotation.x-m.x,y:_.rotation.y-m.y,z:_.rotation.z-m.z}}return f}function c(f,g,_){for(let[m,p]of Object.entries(t)){let w=f[m]||s[m].quaternion,S=g[m]||s[m].quaternion;p.quaternion.copy(w).slerp(S,_)}r()}function h(f){let g=o(f);for(let[_,m]of Object.entries(t))m.quaternion.copy(g[_]);r()}function u(){for(let[f,g]of Object.entries(t))g.quaternion.copy(s[f].quaternion);r()}let d=Ad.filter(f=>!t[f]);return{profile:e,bones:t,rest:s,missing:d,isSigningReady:d.length===0,createTargets:o,capture:a,capturePose:l,interpolate:c,applyPose:h,reset:u,update:r}}var qc=2*1024*1024,Cd=240,Id=new Set(Hc);function nn(i,e="motionInvalidData"){let t=new Error(e);throw t.detail=i,t}function ur(i){return i!==null&&typeof i=="object"&&!Array.isArray(i)}function Fo(i,e,t=100){return(typeof i!="string"||!i.trim()||i.length>t)&&nn(e),i.trim()}function Xc(i,e,t=20){return(!Array.isArray(i)||i.length>t)&&nn(e),[...new Set(i.map(n=>Fo(n,e)))]}function dr(i){(!i?.rest||!i?.profile)&&nn("rig","motionModelNotReady");let e=Object.keys(i.rest).sort().map(t=>{let n=i.bones[t],s=i.rest[t].rotation;return[t,n.name,n.parent?.name||"",s.order,...[s.x,s.y,s.z,...n.position.toArray(),...n.scale.toArray()].map(r=>Number(r.toFixed(9)))]});return{profile:i.profile.id,rest:JSON.stringify(e)}}function Tn(i,e){(!ur(i)||i.type!=="signbridge-motion"||i.version!==1||i.space!=="humanoid-local-v1"||i.unit!=="radians")&&nn("type/version/space/unit");let t=Fo(i.id,"id",90);/^custom_[a-zA-Z0-9_-]+$/.test(t)||nn("id");let n=dr(e);(i.rig?.profile!==n.profile||i.rig?.rest!==n.rest)&&nn("rig","motionRigMismatch"),(!Array.isArray(i.frames)||!i.frames.length||i.frames.length>Cd)&&nn("frames");let s=0,r=i.frames.map((o,a)=>{(!ur(o?.value)||!Number.isFinite(o.duration)||o.duration<.05||o.duration>10)&&nn(`frames[${a}]`),s+=o.duration;let l={};for(let[c,h]of Object.entries(o.value)){(!Id.has(c)||!e.bones[c]||!ur(h))&&nn(`frames[${a}].${c}`);for(let u of["x","y","z"])(!Number.isFinite(h[u])||Math.abs(h[u])>Math.PI*2)&&nn(`${c}.${u}`);l[c]={x:h.x,y:h.y,z:h.z}}return{value:l,duration:o.duration}});return s>120&&nn("duration > 120s"),{type:"signbridge-motion",version:1,id:t,gloss:Fo(i.gloss,"gloss"),texts:Xc(i.texts,"texts"),tags:Xc(i.tags,"tags"),space:"humanoid-local-v1",unit:"radians",rig:n,frames:r}}function Yc(i,e,t){return Tn({...t,type:"signbridge-motion",version:1,space:"humanoid-local-v1",unit:"radians",rig:dr(i),frames:e},i)}function sn(i,e=!1){return JSON.stringify(i,(t,n)=>e&&typeof n=="number"?Number(n.toFixed(8)):ur(n)?Object.fromEntries(Object.keys(n).sort().map(s=>[s,n[s]])):n)}function Oo(i){return sn(i,!0)}var Pd=8*1024*1024,Ld=500;function Oi(i="motionPackInvalid"){throw new Error(i)}function Rs(i,e){(i?.type!=="signbridge-motion-pack"||i.version!==1||typeof i.createdAt!="string"||!Number.isFinite(Date.parse(i.createdAt))||!Array.isArray(i.motions))&&Oi(),i.motions.length||Oi("motionPackEmpty"),i.motions.length>Ld&&Oi("motionPackTooLarge");let t=new Set,n=i.motions.map(r=>{let o=Tn(r?.asset,e);return t.has(o.id)&&Oi("motionPackDuplicateId"),t.add(o.id),new Blob([sn(o)]).size>qc&&Oi("motionPackTooLarge"),{asset:o,wasEnabled:r.wasEnabled===!0}}),s={type:"signbridge-motion-pack",version:1,createdAt:i.createdAt,motions:n};return new Blob([JSON.stringify(s,null,2)]).size>Pd&&Oi("motionPackTooLarge"),s}function Zc(i,e){return Rs({type:"signbridge-motion-pack",version:1,createdAt:new Date().toISOString(),motions:i.map(t=>({asset:t.asset,wasEnabled:t.enabled===!0}))},e)}function Bo(i,e,t){let n=Rs(i,t),s=new Map;function r(c){for(let h of c.texts){let u=Es(h);s.has(u)||s.set(u,new Set),s.get(u).add(c.id)}}Object.values(An).forEach(r);let o=new Map;for(let[c,h]of Object.entries(e))try{let u=Tn(h?.asset,t);if(u.id!==c)continue;o.set(c,u),r(u)}catch{continue}n.motions.forEach(c=>r(c.asset));let a={new:0,existing:0,conflict:0},l=n.motions.map(({asset:c,wasEnabled:h})=>{let u="new";return Object.hasOwn(e,c.id)&&(u=o.has(c.id)&&sn(o.get(c.id))===sn(c)?"existing":"conflict"),a[u]+=1,{id:c.id,gloss:c.gloss,state:u,wasEnabled:h,aliasConflicts:c.texts.filter(d=>{let f=Es(d);return!f||[...s.get(f)].some(g=>g!==c.id)}),emptyTexts:c.texts.length===0}});return{pack:n,items:l,counts:a,revision:sn(e)}}var En="signbridge.motion.v1.",fr=Es,Dd=new Set(Object.values(An).flatMap(i=>i.texts.map(fr)));function Rn(i,e=""){let t=new Error(i);return t.detail=e,t}function Jc(i){return i.enabled===!0&&typeof i.review?.confirmedAt=="string"&&i.review.assetJson===sn(i.asset)}function Nd(i,e){return i.texts.length?i.texts.find(t=>!fr(t)||e.has(fr(t)))??null:"texts"}function Kc(i,e=globalThis.chrome?.storage,t=globalThis.navigator?.locks){if(!e?.local)throw Rn("motionStorageUnavailable");let n=e.local,s=f=>t?t.request(En,f):f();async function r(){let f=await n.get(null),g=[],_=0;for(let[m,p]of Object.entries(f))if(m.startsWith(En))try{let w=Tn(p.asset,i);if(m!==En+w.id)throw Rn("motionInvalidData");g.push({asset:w,enabled:Jc({...p,asset:w}),review:p.review})}catch{_+=1}return{entries:g,invalidCount:_}}async function o(f){let g=Tn(f,i),_={asset:g,enabled:!1,review:null};return await s(()=>n.set({[En+g.id]:_})),_}async function a(f,g,_){return s(async()=>{let{entries:m}=await r(),p=m.find(w=>w.asset.id===f);if(!p)throw Rn("motionSelectFirst");if(g){if(Oo(p.asset)!==Oo(_))throw Rn("motionSaveFirst");let w=new Set(Dd);for(let y of m)y.asset.id!==f&&Jc(y)&&y.asset.texts.forEach(U=>w.add(fr(U)));let S=Nd(p.asset,w);if(S!==null)throw Rn("motionAliasConflict",S)}await n.set({[En+f]:{asset:p.asset,enabled:g,review:g?{confirmedAt:new Date().toISOString(),assetJson:sn(p.asset)}:null}})})}async function l(){let f=await n.get(null);return Object.fromEntries(Object.entries(f).filter(([g])=>g.startsWith(En)).map(([g,_])=>[g.slice(En.length),_]))}async function c(){let{entries:f,invalidCount:g}=await r();if(g)throw Rn("motionPackInvalidStored");return Zc(f,i)}async function h(f){let g=Rs(f,i);return Bo(g,await l(),i)}async function u(f,g){if(!t?.request)throw Rn("motionPackLockUnavailable");let _=Rs(f,i);return s(async()=>{let m=Bo(_,await l(),i);if(m.revision!==g)throw Rn("motionPackStale");if(m.counts.conflict)throw Rn("motionPackConflict");let p=new Set(m.items.filter(S=>S.state==="new").map(S=>S.id)),w=Object.fromEntries(_.motions.filter(({asset:S})=>p.has(S.id)).map(({asset:S})=>[En+S.id,{asset:S,enabled:!1,review:null}]));return p.size&&await n.set(w),{imported:p.size,skipped:m.counts.existing}})}function d(f){let g=(_,m)=>{m==="local"&&Object.keys(_).some(p=>p.startsWith(En))&&f()};return e.onChanged.addListener(g),()=>e.onChanged.removeListener(g)}return{list:r,saveDraft:o,setEnabled:a,subscribe:d,exportPack:c,previewPack:h,importPack:u}}var xi="signbridge-visual-review-v1",pr=8,$c=12,Yt=Object.freeze({width:320,height:360}),Bi=Object.freeze(["front","right","left"]);function jc(i,e){if(!i?.motion?.id||!["custom","builtin"].includes(i.source))throw new Error("motionInvalidData");if(i.source==="builtin"&&(!Array.isArray(i.motion.frames)||i.motion.frames.some(n=>!n?.value||typeof n.value!="object"||Array.isArray(n.value))))throw new Error("motionInvalidData");let t=i.source==="custom"?Tn(i.motion,e):Yc(e,i.motion.frames?.map(n=>({value:hr(n.value),duration:n.duration})),{id:"custom_visual_review",gloss:i.motion.gloss,texts:i.motion.texts||[],tags:i.motion.tags||[]});return{key:`${i.source}:${i.motion.id}`,id:i.motion.id,source:i.source,enabled:i.enabled===!0,asset:t,totalDuration:t.frames.reduce((n,s)=>n+s.duration,0),usedBones:[...new Set(t.frames.flatMap(n=>Object.keys(n.value)))].sort()}}function Qc(i,e=$c){if(!Number.isInteger(i)||i<1||i>240||!Number.isInteger(e)||e<2||e>$c)throw new Error("reviewInvalidSamples");return i<=e?Array.from({length:i},(t,n)=>n):Array.from({length:e},(t,n)=>Math.round(n*(i-1)/(e-1)))}async function $n(i){let e=i instanceof ArrayBuffer||ArrayBuffer.isView(i)?i:new globalThis.TextEncoder().encode(sn(i)),t=await globalThis.crypto.subtle.digest("SHA-256",e);return Array.from(new Uint8Array(t),n=>n.toString(16).padStart(2,"0")).join("")}function eh(i,e,t=16){if(i.length!==e.length||!i.length||i.length%4)throw new Error("reviewImageMismatch");let n=0,s=0;for(let o=0;o<i.length;o+=4){let a=0;for(let l=0;l<3;l++){let c=Math.abs(i[o+l]-e[o+l]);s+=c,a=Math.max(a,c)}a>t&&(n+=1)}let r=i.length/4;return{changedPixels:n,changedRatio:n/r,meanDifference:s/(r*3),channelTolerance:t}}function th(i,e){return e?e.protocol!==xi||e.environmentHash!==i.environmentHash?"incompatible":e.motionHash!==i.motionHash?"motionChanged":"comparable":"missing"}async function nh(i=globalThis.indexedDB){if(!i)throw new Error("reviewStorageError");let e=await new Promise((s,r)=>{let o=!1,a=i.open("signbridge-visual-review",1);a.onupgradeneeded=()=>a.result.createObjectStore("baselines",{keyPath:"key"}),a.onsuccess=()=>{o?a.result.close():s(a.result)},a.onerror=()=>r(new Error("reviewStorageError")),a.onblocked=()=>{o=!0,r(new Error("reviewStorageError"))}});e.onversionchange=()=>e.close();function t(s){return new Promise((r,o)=>{let a=e.transaction("baselines","readonly"),l=a.objectStore("baselines").get(s);a.oncomplete=()=>r(l.result||null),a.onabort=a.onerror=()=>o(new Error("reviewStorageError"))})}function n(s,r,o,a){return new Promise((l,c)=>{a?.throwIfAborted();let h=e.transaction("baselines","readwrite"),u=()=>h.abort();a?.addEventListener("abort",u,{once:!0});let d=h.objectStore("baselines"),f="reviewStorageError",g=d.getAll();g.onsuccess=()=>{if((g.result.find(m=>m.key===s)?.token||null)!==r){f="reviewBaselineChanged",h.abort();return}if(o){let m=g.result.filter(w=>w.key!==s);if(!(o.image instanceof Blob)||m.some(w=>!(w.image instanceof Blob))){f="reviewImageMismatch",h.abort();return}let p=m.reduce((w,S)=>w+S.image.size,o.image.size);if(m.length>=100||p>67108864){f="reviewStorageFull",h.abort();return}d.put(o)}else d.delete(s)},h.oncomplete=()=>{a?.removeEventListener("abort",u),l()},h.onabort=h.onerror=()=>{a?.removeEventListener("abort",u),c(a?.aborted?a.reason:new Error(f))}})}return{read:t,update:n,close:()=>e.close()}}var Ud=0,ih=1,Fd=2;var Su=1,Od=2,Un=3,vn=0,Ot=1,ln=2,oi=0,ns=1,sh=2,rh=3,oh=4,Bd=5,Ei=100,kd=101,zd=102,Hd=103,Vd=104,Gd=200,Wd=201,Xd=202,qd=203,_a=204,va=205,Yd=206,Zd=207,Jd=208,Kd=209,$d=210,jd=211,Qd=212,ef=213,tf=214,xa=0,ya=1,Ma=2,os=3,Sa=4,ba=5,wa=6,Aa=7,bu=0,nf=1,sf=2,ai=0,rf=1,of=2,af=3,lf=4,cf=5,hf=6,uf=7,ah="attached",df="detached",wu=300,as=301,ls=302,Ta=303,Ea=304,bo=306,Ii=1e3,On=1001,Gs=1002,It=1003,Cl=1004;var es=1005;var Ft=1006,ks=1007;var gn=1008;var zn=1009,Au=1010,Tu=1011,Ws=1012,Il=1013,Pi=1014,hn=1015,tr=1016,Pl=1017,Ll=1018,cs=1020,Eu=35902,Ru=1021,Cu=1022,Jt=1023,Iu=1024,Pu=1025,is=1026,hs=1027,Dl=1028,Nl=1029,Lu=1030,Ul=1031;var Fl=1033,Vr=33776,Gr=33777,Wr=33778,Xr=33779,Ra=35840,Ca=35841,Ia=35842,Pa=35843,La=36196,Da=37492,Na=37496,Ua=37808,Fa=37809,Oa=37810,Ba=37811,ka=37812,za=37813,Ha=37814,Va=37815,Ga=37816,Wa=37817,Xa=37818,qa=37819,Ya=37820,Za=37821,qr=36492,Ja=36494,Ka=36495,Du=36283,$a=36284,ja=36285,Qa=36286;var us=2300,ds=2301,ko=2302,lh=2400,ch=2401,hh=2402,ff=2500;var Nu=0,wo=1,nr=2,pf=3200,mf=3201;var Uu=0,gf=1,si="",pt="srgb",Pt="srgb-linear",Ao="linear",et="srgb";var ki=7680;var uh=519,_f=512,vf=513,xf=514,Fu=515,yf=516,Mf=517,Sf=518,bf=519,el=35044;var dh="300 es",Bn=2e3,Yr=2001,li=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let s=this._listeners[e];if(s!==void 0){let r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let n=this._listeners[e.type];if(n!==void 0){e.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}},Tt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],fh=1234567,zs=Math.PI/180,fs=180/Math.PI;function un(){let i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Tt[i&255]+Tt[i>>8&255]+Tt[i>>16&255]+Tt[i>>24&255]+"-"+Tt[e&255]+Tt[e>>8&255]+"-"+Tt[e>>16&15|64]+Tt[e>>24&255]+"-"+Tt[t&63|128]+Tt[t>>8&255]+"-"+Tt[t>>16&255]+Tt[t>>24&255]+Tt[n&255]+Tt[n>>8&255]+Tt[n>>16&255]+Tt[n>>24&255]).toLowerCase()}function Rt(i,e,t){return Math.max(e,Math.min(t,i))}function Ol(i,e){return(i%e+e)%e}function wf(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function Af(i,e,t){return i!==e?(t-i)/(e-i):0}function Hs(i,e,t){return(1-t)*i+t*e}function Tf(i,e,t,n){return Hs(i,e,1-Math.exp(-t*n))}function Ef(i,e=1){return e-Math.abs(Ol(i,e*2)-e)}function Rf(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function Cf(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function If(i,e){return i+Math.floor(Math.random()*(e-i+1))}function Pf(i,e){return i+Math.random()*(e-i)}function Lf(i){return i*(.5-Math.random())}function Df(i){i!==void 0&&(fh=i);let e=fh+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Nf(i){return i*zs}function Uf(i){return i*fs}function Ff(i){return(i&i-1)===0&&i!==0}function Of(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Bf(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function kf(i,e,t,n,s){let r=Math.cos,o=Math.sin,a=r(t/2),l=o(t/2),c=r((e+n)/2),h=o((e+n)/2),u=r((e-n)/2),d=o((e-n)/2),f=r((n-e)/2),g=o((n-e)/2);switch(s){case"XYX":i.set(a*h,l*u,l*d,a*c);break;case"YZY":i.set(l*d,a*h,l*u,a*c);break;case"ZXZ":i.set(l*u,l*d,a*h,a*c);break;case"XZX":i.set(a*h,l*g,l*f,a*c);break;case"YXY":i.set(l*f,a*h,l*g,a*c);break;case"ZYZ":i.set(l*g,l*f,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function cn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function Qe(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}var Ou={DEG2RAD:zs,RAD2DEG:fs,generateUUID:un,clamp:Rt,euclideanModulo:Ol,mapLinear:wf,inverseLerp:Af,lerp:Hs,damp:Tf,pingpong:Ef,smoothstep:Rf,smootherstep:Cf,randInt:If,randFloat:Pf,randFloatSpread:Lf,seededRandom:Df,degToRad:Nf,radToDeg:Uf,isPowerOfTwo:Ff,ceilPowerOfTwo:Of,floorPowerOfTwo:Bf,setQuaternionFromProperEuler:kf,normalize:Qe,denormalize:cn},ze=class i{constructor(e=0,t=0){i.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Rt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*n-o*s+e.x,this.y=r*s+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Le=class i{constructor(e,t,n,s,r,o,a,l,c){i.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c)}set(e,t,n,s,r,o,a,l,c){let h=this.elements;return h[0]=e,h[1]=s,h[2]=a,h[3]=t,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],_=s[0],m=s[3],p=s[6],w=s[1],S=s[4],y=s[7],U=s[2],E=s[5],T=s[8];return r[0]=o*_+a*w+l*U,r[3]=o*m+a*S+l*E,r[6]=o*p+a*y+l*T,r[1]=c*_+h*w+u*U,r[4]=c*m+h*S+u*E,r[7]=c*p+h*y+u*T,r[2]=d*_+f*w+g*U,r[5]=d*m+f*S+g*E,r[8]=d*p+f*y+g*T,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8];return t*o*h-t*a*c-n*r*h+n*a*l+s*r*c-s*o*l}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=h*o-a*c,d=a*l-h*r,f=c*r-o*l,g=t*u+n*d+s*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let _=1/g;return e[0]=u*_,e[1]=(s*c-h*n)*_,e[2]=(a*n-s*o)*_,e[3]=d*_,e[4]=(h*t-s*l)*_,e[5]=(s*r-a*t)*_,e[6]=f*_,e[7]=(n*l-c*t)*_,e[8]=(o*t-n*r)*_,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+e,-s*c,s*l,-s*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(zo.makeScale(e,t)),this}rotate(e){return this.premultiply(zo.makeRotation(-e)),this}translate(e,t){return this.premultiply(zo.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},zo=new Le;function Bu(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Xs(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function zf(){let i=Xs("canvas");return i.style.display="block",i}var ph={};function Os(i){i in ph||(ph[i]=!0,console.warn(i))}function Hf(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}function Vf(i){let e=i.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function Gf(i){let e=i.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}var ke={enabled:!0,workingColorSpace:Pt,spaces:{},convert:function(i,e,t){return this.enabled===!1||e===t||!e||!t||(this.spaces[e].transfer===et&&(i.r=kn(i.r),i.g=kn(i.g),i.b=kn(i.b)),this.spaces[e].primaries!==this.spaces[t].primaries&&(i.applyMatrix3(this.spaces[e].toXYZ),i.applyMatrix3(this.spaces[t].fromXYZ)),this.spaces[t].transfer===et&&(i.r=ss(i.r),i.g=ss(i.g),i.b=ss(i.b))),i},fromWorkingColorSpace:function(i,e){return this.convert(i,this.workingColorSpace,e)},toWorkingColorSpace:function(i,e){return this.convert(i,e,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===si?Ao:this.spaces[i].transfer},getLuminanceCoefficients:function(i,e=this.workingColorSpace){return i.fromArray(this.spaces[e].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,e,t){return i.copy(this.spaces[e].toXYZ).multiply(this.spaces[t].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function kn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function ss(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var mh=[.64,.33,.3,.6,.15,.06],gh=[.2126,.7152,.0722],_h=[.3127,.329],vh=new Le().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),xh=new Le().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);ke.define({[Pt]:{primaries:mh,whitePoint:_h,transfer:Ao,toXYZ:vh,fromXYZ:xh,luminanceCoefficients:gh,workingColorSpaceConfig:{unpackColorSpace:pt},outputColorSpaceConfig:{drawingBufferColorSpace:pt}},[pt]:{primaries:mh,whitePoint:_h,transfer:et,toXYZ:vh,fromXYZ:xh,luminanceCoefficients:gh,outputColorSpaceConfig:{drawingBufferColorSpace:pt}}});var zi,tl=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{zi===void 0&&(zi=Xs("canvas")),zi.width=e.width,zi.height=e.height;let n=zi.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=zi}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=Xs("canvas");t.width=e.width,t.height=e.height;let n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);let s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=kn(r[o]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){let t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(kn(t[n]/255)*255):t[n]=kn(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},Wf=0,Zr=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Wf++}),this.uuid=un(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(Ho(s[o].image)):r.push(Ho(s[o]))}else r=Ho(s);n.url=r}return t||(e.images[this.uuid]=n),n}};function Ho(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?tl.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Xf=0,St=class i extends li{constructor(e=i.DEFAULT_IMAGE,t=i.DEFAULT_MAPPING,n=On,s=On,r=Ft,o=gn,a=Jt,l=zn,c=i.DEFAULT_ANISOTROPY,h=si){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Xf++}),this.uuid=un(),this.name="",this.source=new Zr(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new ze(0,0),this.repeat=new ze(1,1),this.center=new ze(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Le,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==wu)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Ii:e.x=e.x-Math.floor(e.x);break;case On:e.x=e.x<0?0:1;break;case Gs:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Ii:e.y=e.y-Math.floor(e.y);break;case On:e.y=e.y<0?0:1;break;case Gs:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};St.DEFAULT_IMAGE=null;St.DEFAULT_MAPPING=wu;St.DEFAULT_ANISOTROPY=1;var Ye=class i{constructor(e=0,t=0,n=0,s=1){i.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*n+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r,l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],_=l[2],m=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-_)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+_)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let S=(c+1)/2,y=(f+1)/2,U=(p+1)/2,E=(h+d)/4,T=(u+_)/4,N=(g+m)/4;return S>y&&S>U?S<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(S),s=E/n,r=T/n):y>U?y<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),n=E/s,r=N/s):U<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(U),n=T/r,s=N/r),this.set(n,s,r,t),this}let w=Math.sqrt((m-g)*(m-g)+(u-_)*(u-_)+(d-h)*(d-h));return Math.abs(w)<.001&&(w=1),this.x=(m-g)/w,this.y=(u-_)/w,this.z=(d-h)/w,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},nl=class extends li{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new Ye(0,0,e,t),this.scissorTest=!1,this.viewport=new Ye(0,0,e,t);let s={width:e,height:t,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ft,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);let r=new St(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];let o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,s=e.textures.length;n<s;n++)this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new Zr(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Hn=class extends nl{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},Jr=class extends St{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=It,this.minFilter=It,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}};var il=class extends St{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=It,this.minFilter=It,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var dn=class{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,o,a){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3],d=r[o+0],f=r[o+1],g=r[o+2],_=r[o+3];if(a===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u;return}if(a===1){e[t+0]=d,e[t+1]=f,e[t+2]=g,e[t+3]=_;return}if(u!==_||l!==d||c!==f||h!==g){let m=1-a,p=l*d+c*f+h*g+u*_,w=p>=0?1:-1,S=1-p*p;if(S>Number.EPSILON){let U=Math.sqrt(S),E=Math.atan2(U,p*w);m=Math.sin(m*E)/U,a=Math.sin(a*E)/U}let y=a*w;if(l=l*m+d*y,c=c*m+f*y,h=h*m+g*y,u=u*m+_*y,m===1-a){let U=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=U,c*=U,h*=U,u*=U}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[o],d=r[o+1],f=r[o+2],g=r[o+3];return e[t]=a*g+h*u+l*f-c*d,e[t+1]=l*g+h*d+c*u-a*f,e[t+2]=c*g+h*f+a*d-l*u,e[t+3]=h*g-a*u-l*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,s=e._y,r=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(s/2),u=a(r/2),d=l(n/2),f=l(s/2),g=l(r/2);switch(o){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],s=t[4],r=t[8],o=t[1],a=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+a+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(o-s)*f}else if(n>a&&n>u){let f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+c)/f}else if(a>u){let f=2*Math.sqrt(1+a-n-u);this._w=(r-c)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-a);this._w=(o-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Rt(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,s=e._y,r=e._z,o=e._w,a=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-s*a,this._w=o*h-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let n=this._x,s=this._y,r=this._z,o=this._w,a=o*e._w+n*e._x+s*e._y+r*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*s+t*this._y,this._z=f*r+t*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=s*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},P=class i{constructor(e=0,t=0,n=0){i.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(yh.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(yh.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(e){let t=this.x,n=this.y,s=this.z,r=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*s-a*n),h=2*(a*t-r*s),u=2*(r*n-o*t);return this.x=t+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=s+l*u+r*h-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,s=e.y,r=e.z,o=t.x,a=t.y,l=t.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Vo.copy(this).projectOnVector(e),this.sub(Vo)}reflect(e){return this.sub(Vo.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(Rt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Vo=new P,yh=new dn,Bt=class{constructor(e=new P(1/0,1/0,1/0),t=new P(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(rn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(rn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=rn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,rn):rn.fromBufferAttribute(r,o),rn.applyMatrix4(e.matrixWorld),this.expandByPoint(rn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),mr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),mr.copy(n.boundingBox)),mr.applyMatrix4(e.matrixWorld),this.union(mr)}let s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,rn),rn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Cs),gr.subVectors(this.max,Cs),Hi.subVectors(e.a,Cs),Vi.subVectors(e.b,Cs),Gi.subVectors(e.c,Cs),jn.subVectors(Vi,Hi),Qn.subVectors(Gi,Vi),yi.subVectors(Hi,Gi);let t=[0,-jn.z,jn.y,0,-Qn.z,Qn.y,0,-yi.z,yi.y,jn.z,0,-jn.x,Qn.z,0,-Qn.x,yi.z,0,-yi.x,-jn.y,jn.x,0,-Qn.y,Qn.x,0,-yi.y,yi.x,0];return!Go(t,Hi,Vi,Gi,gr)||(t=[1,0,0,0,1,0,0,0,1],!Go(t,Hi,Vi,Gi,gr))?!1:(_r.crossVectors(jn,Qn),t=[_r.x,_r.y,_r.z],Go(t,Hi,Vi,Gi,gr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,rn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(rn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Cn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Cn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Cn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Cn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Cn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Cn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Cn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Cn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Cn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},Cn=[new P,new P,new P,new P,new P,new P,new P,new P],rn=new P,mr=new Bt,Hi=new P,Vi=new P,Gi=new P,jn=new P,Qn=new P,yi=new P,Cs=new P,gr=new P,_r=new P,Mi=new P;function Go(i,e,t,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){Mi.fromArray(i,r);let a=s.x*Math.abs(Mi.x)+s.y*Math.abs(Mi.y)+s.z*Math.abs(Mi.z),l=e.dot(Mi),c=t.dot(Mi),h=n.dot(Mi);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var qf=new Bt,Is=new P,Wo=new P,Vt=class{constructor(e=new P,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t!==void 0?n.copy(t):qf.setFromPoints(e).getCenter(n);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Is.subVectors(e,this.center);let t=Is.lengthSq();if(t>this.radius*this.radius){let n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(Is,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Wo.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Is.copy(e.center).add(Wo)),this.expandByPoint(Is.copy(e.center).sub(Wo))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},In=new P,Xo=new P,vr=new P,ei=new P,qo=new P,xr=new P,Yo=new P,ps=class{constructor(e=new P,t=new P(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,In)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=In.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(In.copy(this.origin).addScaledVector(this.direction,t),In.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){Xo.copy(e).add(t).multiplyScalar(.5),vr.copy(t).sub(e).normalize(),ei.copy(this.origin).sub(Xo);let r=e.distanceTo(t)*.5,o=-this.direction.dot(vr),a=ei.dot(this.direction),l=-ei.dot(vr),c=ei.lengthSq(),h=Math.abs(1-o*o),u,d,f,g;if(h>0)if(u=o*l-a,d=o*a-l,g=r*h,u>=0)if(d>=-g)if(d<=g){let _=1/h;u*=_,d*=_,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Xo).addScaledVector(vr,d),f}intersectSphere(e,t){In.subVectors(e.center,this.origin);let n=In.dot(this.direction),s=In.dot(In)-n*n,r=e.radius*e.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,s=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,s=(e.min.x-d.x)*c),h>=0?(r=(e.min.y-d.y)*h,o=(e.max.y-d.y)*h):(r=(e.max.y-d.y)*h,o=(e.min.y-d.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(a=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,In)!==null}intersectTriangle(e,t,n,s,r){qo.subVectors(t,e),xr.subVectors(n,e),Yo.crossVectors(qo,xr);let o=this.direction.dot(Yo),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;ei.subVectors(this.origin,e);let l=a*this.direction.dot(xr.crossVectors(ei,xr));if(l<0)return null;let c=a*this.direction.dot(qo.cross(ei));if(c<0||l+c>o)return null;let h=-a*ei.dot(Yo);return h<0?null:this.at(h/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},De=class i{constructor(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m){i.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m)}set(e,t,n,s,r,o,a,l,c,h,u,d,f,g,_,m){let p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=s,p[1]=r,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=_,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new i().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,n=e.elements,s=1/Wi.setFromMatrixColumn(e,0).length(),r=1/Wi.setFromMatrixColumn(e,1).length(),o=1/Wi.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,s=e.y,r=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(e.order==="XYZ"){let d=o*h,f=o*u,g=a*h,_=a*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=f+g*c,t[5]=d-_*c,t[9]=-a*l,t[2]=_-d*c,t[6]=g+f*c,t[10]=o*l}else if(e.order==="YXZ"){let d=l*h,f=l*u,g=c*h,_=c*u;t[0]=d+_*a,t[4]=g*a-f,t[8]=o*c,t[1]=o*u,t[5]=o*h,t[9]=-a,t[2]=f*a-g,t[6]=_+d*a,t[10]=o*l}else if(e.order==="ZXY"){let d=l*h,f=l*u,g=c*h,_=c*u;t[0]=d-_*a,t[4]=-o*u,t[8]=g+f*a,t[1]=f+g*a,t[5]=o*h,t[9]=_-d*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){let d=o*h,f=o*u,g=a*h,_=a*u;t[0]=l*h,t[4]=g*c-f,t[8]=d*c+_,t[1]=l*u,t[5]=_*c+d,t[9]=f*c-g,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){let d=o*l,f=o*c,g=a*l,_=a*c;t[0]=l*h,t[4]=_-d*u,t[8]=g*u+f,t[1]=u,t[5]=o*h,t[9]=-a*h,t[2]=-c*h,t[6]=f*u+g,t[10]=d-_*u}else if(e.order==="XZY"){let d=o*l,f=o*c,g=a*l,_=a*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+_,t[5]=o*h,t[9]=f*u-g,t[2]=g*u-f,t[6]=a*h,t[10]=_*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Yf,e,Zf)}lookAt(e,t,n){let s=this.elements;return zt.subVectors(e,t),zt.lengthSq()===0&&(zt.z=1),zt.normalize(),ti.crossVectors(n,zt),ti.lengthSq()===0&&(Math.abs(n.z)===1?zt.x+=1e-4:zt.z+=1e-4,zt.normalize(),ti.crossVectors(n,zt)),ti.normalize(),yr.crossVectors(zt,ti),s[0]=ti.x,s[4]=yr.x,s[8]=zt.x,s[1]=ti.y,s[5]=yr.y,s[9]=zt.y,s[2]=ti.z,s[6]=yr.z,s[10]=zt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],_=n[6],m=n[10],p=n[14],w=n[3],S=n[7],y=n[11],U=n[15],E=s[0],T=s[4],N=s[8],b=s[12],M=s[1],R=s[5],W=s[9],k=s[13],V=s[2],K=s[6],G=s[10],$=s[14],z=s[3],ne=s[7],ue=s[11],xe=s[15];return r[0]=o*E+a*M+l*V+c*z,r[4]=o*T+a*R+l*K+c*ne,r[8]=o*N+a*W+l*G+c*ue,r[12]=o*b+a*k+l*$+c*xe,r[1]=h*E+u*M+d*V+f*z,r[5]=h*T+u*R+d*K+f*ne,r[9]=h*N+u*W+d*G+f*ue,r[13]=h*b+u*k+d*$+f*xe,r[2]=g*E+_*M+m*V+p*z,r[6]=g*T+_*R+m*K+p*ne,r[10]=g*N+_*W+m*G+p*ue,r[14]=g*b+_*k+m*$+p*xe,r[3]=w*E+S*M+y*V+U*z,r[7]=w*T+S*R+y*K+U*ne,r[11]=w*N+S*W+y*G+U*ue,r[15]=w*b+S*k+y*$+U*xe,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],o=e[1],a=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],f=e[14],g=e[3],_=e[7],m=e[11],p=e[15];return g*(+r*l*u-s*c*u-r*a*d+n*c*d+s*a*f-n*l*f)+_*(+t*l*f-t*c*d+r*o*d-s*o*f+s*c*h-r*l*h)+m*(+t*c*u-t*a*f-r*o*u+n*o*f+r*a*h-n*c*h)+p*(-s*a*h-t*l*u+t*a*d+s*o*u-n*o*d+n*l*h)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],f=e[11],g=e[12],_=e[13],m=e[14],p=e[15],w=u*m*c-_*d*c+_*l*f-a*m*f-u*l*p+a*d*p,S=g*d*c-h*m*c-g*l*f+o*m*f+h*l*p-o*d*p,y=h*_*c-g*u*c+g*a*f-o*_*f-h*a*p+o*u*p,U=g*u*l-h*_*l-g*a*d+o*_*d+h*a*m-o*u*m,E=t*w+n*S+s*y+r*U;if(E===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let T=1/E;return e[0]=w*T,e[1]=(_*d*r-u*m*r-_*s*f+n*m*f+u*s*p-n*d*p)*T,e[2]=(a*m*r-_*l*r+_*s*c-n*m*c-a*s*p+n*l*p)*T,e[3]=(u*l*r-a*d*r-u*s*c+n*d*c+a*s*f-n*l*f)*T,e[4]=S*T,e[5]=(h*m*r-g*d*r+g*s*f-t*m*f-h*s*p+t*d*p)*T,e[6]=(g*l*r-o*m*r-g*s*c+t*m*c+o*s*p-t*l*p)*T,e[7]=(o*d*r-h*l*r+h*s*c-t*d*c-o*s*f+t*l*f)*T,e[8]=y*T,e[9]=(g*u*r-h*_*r-g*n*f+t*_*f+h*n*p-t*u*p)*T,e[10]=(o*_*r-g*a*r+g*n*c-t*_*c-o*n*p+t*a*p)*T,e[11]=(h*a*r-o*u*r-h*n*c+t*u*c+o*n*f-t*a*f)*T,e[12]=U*T,e[13]=(h*_*s-g*u*s+g*n*d-t*_*d-h*n*m+t*u*m)*T,e[14]=(g*a*s-o*_*s-g*n*l+t*_*l+o*n*m-t*a*m)*T,e[15]=(o*u*s-h*a*s+h*n*l-t*u*l-o*n*d+t*a*d)*T,this}scale(e){let t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),s=Math.sin(t),r=1-n,o=e.x,a=e.y,l=e.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+n,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,o){return this.set(1,n,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){let s=this.elements,r=t._x,o=t._y,a=t._z,l=t._w,c=r+r,h=o+o,u=a+a,d=r*c,f=r*h,g=r*u,_=o*h,m=o*u,p=a*u,w=l*c,S=l*h,y=l*u,U=n.x,E=n.y,T=n.z;return s[0]=(1-(_+p))*U,s[1]=(f+y)*U,s[2]=(g-S)*U,s[3]=0,s[4]=(f-y)*E,s[5]=(1-(d+p))*E,s[6]=(m+w)*E,s[7]=0,s[8]=(g+S)*T,s[9]=(m-w)*T,s[10]=(1-(d+_))*T,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){let s=this.elements,r=Wi.set(s[0],s[1],s[2]).length(),o=Wi.set(s[4],s[5],s[6]).length(),a=Wi.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],on.copy(this);let c=1/r,h=1/o,u=1/a;return on.elements[0]*=c,on.elements[1]*=c,on.elements[2]*=c,on.elements[4]*=h,on.elements[5]*=h,on.elements[6]*=h,on.elements[8]*=u,on.elements[9]*=u,on.elements[10]*=u,t.setFromRotationMatrix(on),n.x=r,n.y=o,n.z=a,this}makePerspective(e,t,n,s,r,o,a=Bn){let l=this.elements,c=2*r/(t-e),h=2*r/(n-s),u=(t+e)/(t-e),d=(n+s)/(n-s),f,g;if(a===Bn)f=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===Yr)f=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,s,r,o,a=Bn){let l=this.elements,c=1/(t-e),h=1/(n-s),u=1/(o-r),d=(t+e)*c,f=(n+s)*h,g,_;if(a===Bn)g=(o+r)*u,_=-2*u;else if(a===Yr)g=r*u,_=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=_,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Wi=new P,on=new De,Yf=new P(0,0,0),Zf=new P(1,1,1),ti=new P,yr=new P,zt=new P,Mh=new De,Sh=new dn,xn=class i{constructor(e=0,t=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let s=e.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(Rt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Rt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Rt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Rt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Rt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-Rt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Mh.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Mh,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Sh.setFromEuler(this),this.setFromQuaternion(Sh,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};xn.DEFAULT_ORDER="XYZ";var Kr=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},Jf=0,bh=new P,Xi=new dn,Pn=new De,Mr=new P,Ps=new P,Kf=new P,$f=new dn,wh=new P(1,0,0),Ah=new P(0,1,0),Th=new P(0,0,1),Eh={type:"added"},jf={type:"removed"},qi={type:"childadded",child:null},Zo={type:"childremoved",child:null},ht=class i extends li{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Jf++}),this.uuid=un(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let e=new P,t=new xn,n=new dn,s=new P(1,1,1);function r(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new De},normalMatrix:{value:new Le}}),this.matrix=new De,this.matrixWorld=new De,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Kr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Xi.setFromAxisAngle(e,t),this.quaternion.multiply(Xi),this}rotateOnWorldAxis(e,t){return Xi.setFromAxisAngle(e,t),this.quaternion.premultiply(Xi),this}rotateX(e){return this.rotateOnAxis(wh,e)}rotateY(e){return this.rotateOnAxis(Ah,e)}rotateZ(e){return this.rotateOnAxis(Th,e)}translateOnAxis(e,t){return bh.copy(e).applyQuaternion(this.quaternion),this.position.add(bh.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(wh,e)}translateY(e){return this.translateOnAxis(Ah,e)}translateZ(e){return this.translateOnAxis(Th,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Pn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Mr.copy(e):Mr.set(e,t,n);let s=this.parent;this.updateWorldMatrix(!0,!1),Ps.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Pn.lookAt(Ps,Mr,this.up):Pn.lookAt(Mr,Ps,this.up),this.quaternion.setFromRotationMatrix(Pn),s&&(Pn.extractRotation(s.matrixWorld),Xi.setFromRotationMatrix(Pn),this.quaternion.premultiply(Xi.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Eh),qi.child=e,this.dispatchEvent(qi),qi.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(jf),Zo.child=e,this.dispatchEvent(Zo),Zo.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Pn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Pn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Pn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Eh),qi.child=e,this.dispatchEvent(qi),qi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ps,e,Kf),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ps,$f,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){let n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){let t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(e.shapes,u)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(e.materials,this.material[l]));s.material=a}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(e.animations,l))}}if(t){let a=o(e.geometries),l=o(e.materials),c=o(e.textures),h=o(e.images),u=o(e.shapes),d=o(e.skeletons),f=o(e.animations),g=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=s,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){let s=e.children[n];this.add(s.clone())}return this}};ht.DEFAULT_UP=new P(0,1,0);ht.DEFAULT_MATRIX_AUTO_UPDATE=!0;ht.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var an=new P,Ln=new P,Jo=new P,Dn=new P,Yi=new P,Zi=new P,Rh=new P,Ko=new P,$o=new P,jo=new P,Qo=new Ye,ea=new Ye,ta=new Ye,Ri=class i{constructor(e=new P,t=new P,n=new P){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),an.subVectors(e,t),s.cross(an);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){an.subVectors(s,t),Ln.subVectors(n,t),Jo.subVectors(e,t);let o=an.dot(an),a=an.dot(Ln),l=an.dot(Jo),c=Ln.dot(Ln),h=Ln.dot(Jo),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-a*h)*d,g=(o*h-a*l)*d;return r.set(1-f-g,g,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,Dn)===null?!1:Dn.x>=0&&Dn.y>=0&&Dn.x+Dn.y<=1}static getInterpolation(e,t,n,s,r,o,a,l){return this.getBarycoord(e,t,n,s,Dn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Dn.x),l.addScaledVector(o,Dn.y),l.addScaledVector(a,Dn.z),l)}static getInterpolatedAttribute(e,t,n,s,r,o){return Qo.setScalar(0),ea.setScalar(0),ta.setScalar(0),Qo.fromBufferAttribute(e,t),ea.fromBufferAttribute(e,n),ta.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(Qo,r.x),o.addScaledVector(ea,r.y),o.addScaledVector(ta,r.z),o}static isFrontFacing(e,t,n,s){return an.subVectors(n,t),Ln.subVectors(e,t),an.cross(Ln).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return an.subVectors(this.c,this.b),Ln.subVectors(this.a,this.b),an.cross(Ln).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return i.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return i.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return i.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return i.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return i.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,s=this.b,r=this.c,o,a;Yi.subVectors(s,n),Zi.subVectors(r,n),Ko.subVectors(e,n);let l=Yi.dot(Ko),c=Zi.dot(Ko);if(l<=0&&c<=0)return t.copy(n);$o.subVectors(e,s);let h=Yi.dot($o),u=Zi.dot($o);if(h>=0&&u<=h)return t.copy(s);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),t.copy(n).addScaledVector(Yi,o);jo.subVectors(e,r);let f=Yi.dot(jo),g=Zi.dot(jo);if(g>=0&&f<=g)return t.copy(r);let _=f*c-l*g;if(_<=0&&c>=0&&g<=0)return a=c/(c-g),t.copy(n).addScaledVector(Zi,a);let m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return Rh.subVectors(r,s),a=(u-h)/(u-h+(f-g)),t.copy(s).addScaledVector(Rh,a);let p=1/(m+_+d);return o=_*p,a=d*p,t.copy(n).addScaledVector(Yi,o).addScaledVector(Zi,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},ku={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ni={h:0,s:0,l:0},Sr={h:0,s:0,l:0};function na(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}var we=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=pt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,ke.toWorkingColorSpace(this,t),this}setRGB(e,t,n,s=ke.workingColorSpace){return this.r=e,this.g=t,this.b=n,ke.toWorkingColorSpace(this,s),this}setHSL(e,t,n,s=ke.workingColorSpace){if(e=Ol(e,1),t=Rt(t,0,1),n=Rt(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,o=2*n-r;this.r=na(o,r,e+1/3),this.g=na(o,r,e),this.b=na(o,r,e-1/3)}return ke.toWorkingColorSpace(this,s),this}setStyle(e,t=pt){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=pt){let n=ku[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=kn(e.r),this.g=kn(e.g),this.b=kn(e.b),this}copyLinearToSRGB(e){return this.r=ss(e.r),this.g=ss(e.g),this.b=ss(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=pt){return ke.fromWorkingColorSpace(Et.copy(this),e),Math.round(Rt(Et.r*255,0,255))*65536+Math.round(Rt(Et.g*255,0,255))*256+Math.round(Rt(Et.b*255,0,255))}getHexString(e=pt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=ke.workingColorSpace){ke.fromWorkingColorSpace(Et.copy(this),t);let n=Et.r,s=Et.g,r=Et.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=ke.workingColorSpace){return ke.fromWorkingColorSpace(Et.copy(this),t),e.r=Et.r,e.g=Et.g,e.b=Et.b,e}getStyle(e=pt){ke.fromWorkingColorSpace(Et.copy(this),e);let t=Et.r,n=Et.g,s=Et.b;return e!==pt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(ni),this.setHSL(ni.h+e,ni.s+t,ni.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(ni),e.getHSL(Sr);let n=Hs(ni.h,Sr.h,t),s=Hs(ni.s,Sr.s,t),r=Hs(ni.l,Sr.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Et=new we;we.NAMES=ku;var Qf=0,Gt=class extends li{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Qf++}),this.uuid=un(),this.name="",this.blending=ns,this.side=vn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=_a,this.blendDst=va,this.blendEquation=Ei,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new we(0,0,0),this.blendAlpha=0,this.depthFunc=os,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=uh,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ki,this.stencilZFail=ki,this.stencilZPass=ki,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==ns&&(n.blending=this.blending),this.side!==vn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==_a&&(n.blendSrc=this.blendSrc),this.blendDst!==va&&(n.blendDst=this.blendDst),this.blendEquation!==Ei&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==os&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==uh&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==ki&&(n.stencilFail=this.stencilFail),this.stencilZFail!==ki&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==ki&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(t){let r=s(e.textures),o=s(e.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},yn=class extends Gt{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new we(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.combine=bu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}};var ft=new P,br=new ze,mt=class{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=el,this.updateRanges=[],this.gpuType=hn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)br.fromBufferAttribute(this,t),br.applyMatrix3(e),this.setXY(t,br.x,br.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)ft.fromBufferAttribute(this,t),ft.applyMatrix3(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)ft.fromBufferAttribute(this,t),ft.applyMatrix4(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)ft.fromBufferAttribute(this,t),ft.applyNormalMatrix(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)ft.fromBufferAttribute(this,t),ft.transformDirection(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=cn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Qe(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=cn(t,this.array)),t}setX(e,t){return this.normalized&&(t=Qe(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=cn(t,this.array)),t}setY(e,t){return this.normalized&&(t=Qe(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=cn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Qe(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=cn(t,this.array)),t}setW(e,t){return this.normalized&&(t=Qe(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=Qe(t,this.array),n=Qe(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=Qe(t,this.array),n=Qe(n,this.array),s=Qe(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=Qe(t,this.array),n=Qe(n,this.array),s=Qe(s,this.array),r=Qe(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==el&&(e.usage=this.usage),e}};var $r=class extends mt{constructor(e,t,n){super(new Uint16Array(e),t,n)}};var jr=class extends mt{constructor(e,t,n){super(new Uint32Array(e),t,n)}};var Kt=class extends mt{constructor(e,t,n){super(new Float32Array(e),t,n)}},ep=0,Zt=new De,ia=new ht,Ji=new P,Ht=new Bt,Ls=new Bt,xt=new P,$t=class i extends li{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:ep++}),this.uuid=un(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Bu(e)?jr:$r)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Le().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Zt.makeRotationFromQuaternion(e),this.applyMatrix4(Zt),this}rotateX(e){return Zt.makeRotationX(e),this.applyMatrix4(Zt),this}rotateY(e){return Zt.makeRotationY(e),this.applyMatrix4(Zt),this}rotateZ(e){return Zt.makeRotationZ(e),this.applyMatrix4(Zt),this}translate(e,t,n){return Zt.makeTranslation(e,t,n),this.applyMatrix4(Zt),this}scale(e,t,n){return Zt.makeScale(e,t,n),this.applyMatrix4(Zt),this}lookAt(e){return ia.lookAt(e),ia.updateMatrix(),this.applyMatrix4(ia.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ji).negate(),this.translate(Ji.x,Ji.y,Ji.z),this}setFromPoints(e){let t=this.getAttribute("position");if(t===void 0){let n=[];for(let s=0,r=e.length;s<r;s++){let o=e[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Kt(n,3))}else{for(let n=0,s=t.count;n<s;n++){let r=e[n];t.setXYZ(n,r.x,r.y,r.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Bt);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new P(-1/0,-1/0,-1/0),new P(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){let r=t[n];Ht.setFromBufferAttribute(r),this.morphTargetsRelative?(xt.addVectors(this.boundingBox.min,Ht.min),this.boundingBox.expandByPoint(xt),xt.addVectors(this.boundingBox.max,Ht.max),this.boundingBox.expandByPoint(xt)):(this.boundingBox.expandByPoint(Ht.min),this.boundingBox.expandByPoint(Ht.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Vt);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new P,1/0);return}if(e){let n=this.boundingSphere.center;if(Ht.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){let a=t[r];Ls.setFromBufferAttribute(a),this.morphTargetsRelative?(xt.addVectors(Ht.min,Ls.min),Ht.expandByPoint(xt),xt.addVectors(Ht.max,Ls.max),Ht.expandByPoint(xt)):(Ht.expandByPoint(Ls.min),Ht.expandByPoint(Ls.max))}Ht.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)xt.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(xt));if(t)for(let r=0,o=t.length;r<o;r++){let a=t[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)xt.fromBufferAttribute(a,c),l&&(Ji.fromBufferAttribute(e,c),xt.add(Ji)),s=Math.max(s,n.distanceToSquared(xt))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new mt(new Float32Array(4*n.count),4));let o=this.getAttribute("tangent"),a=[],l=[];for(let N=0;N<n.count;N++)a[N]=new P,l[N]=new P;let c=new P,h=new P,u=new P,d=new ze,f=new ze,g=new ze,_=new P,m=new P;function p(N,b,M){c.fromBufferAttribute(n,N),h.fromBufferAttribute(n,b),u.fromBufferAttribute(n,M),d.fromBufferAttribute(r,N),f.fromBufferAttribute(r,b),g.fromBufferAttribute(r,M),h.sub(c),u.sub(c),f.sub(d),g.sub(d);let R=1/(f.x*g.y-g.x*f.y);isFinite(R)&&(_.copy(h).multiplyScalar(g.y).addScaledVector(u,-f.y).multiplyScalar(R),m.copy(u).multiplyScalar(f.x).addScaledVector(h,-g.x).multiplyScalar(R),a[N].add(_),a[b].add(_),a[M].add(_),l[N].add(m),l[b].add(m),l[M].add(m))}let w=this.groups;w.length===0&&(w=[{start:0,count:e.count}]);for(let N=0,b=w.length;N<b;++N){let M=w[N],R=M.start,W=M.count;for(let k=R,V=R+W;k<V;k+=3)p(e.getX(k+0),e.getX(k+1),e.getX(k+2))}let S=new P,y=new P,U=new P,E=new P;function T(N){U.fromBufferAttribute(s,N),E.copy(U);let b=a[N];S.copy(b),S.sub(U.multiplyScalar(U.dot(b))).normalize(),y.crossVectors(E,b);let R=y.dot(l[N])<0?-1:1;o.setXYZW(N,S.x,S.y,S.z,R)}for(let N=0,b=w.length;N<b;++N){let M=w[N],R=M.start,W=M.count;for(let k=R,V=R+W;k<V;k+=3)T(e.getX(k+0)),T(e.getX(k+1)),T(e.getX(k+2))}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new mt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let s=new P,r=new P,o=new P,a=new P,l=new P,c=new P,h=new P,u=new P;if(e)for(let d=0,f=e.count;d<f;d+=3){let g=e.getX(d+0),_=e.getX(d+1),m=e.getX(d+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,_),o.fromBufferAttribute(t,m),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,g),l.fromBufferAttribute(n,_),c.fromBufferAttribute(n,m),a.add(h),l.add(h),c.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(_,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=t.count;d<f;d+=3)s.fromBufferAttribute(t,d+0),r.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)xt.fromBufferAttribute(e,t),xt.normalize(),e.setXYZ(t,xt.x,xt.y,xt.z)}toNonIndexed(){function e(a,l){let c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h),f=0,g=0;for(let _=0,m=l.length;_<m;_++){a.isInterleavedBufferAttribute?f=l[_]*a.data.stride+a.offset:f=l[_]*h;for(let p=0;p<h;p++)d[g++]=c[f++]}return new mt(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=e(l,n);t.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=e(d,n);l.push(f)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let l in n){let c=n[l];e.data.attributes[l]=c.toJSON(e.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(e.data))}h.length>0&&(s[l]=h,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone(t));let s=e.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(t))}let r=e.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;let o=e.groups;for(let c=0,h=o.length;c<h;c++){let u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}let a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Ch=new De,Si=new ps,wr=new Vt,Ih=new P,Ar=new P,Tr=new P,Er=new P,sa=new P,Rr=new P,Ph=new P,Cr=new P,Ct=class extends ht{constructor(e=new $t,t=new yn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(e,t){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(s,e);let a=this.morphTargetInfluences;if(r&&a){Rr.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],u=r[l];h!==0&&(sa.fromBufferAttribute(u,e),o?Rr.addScaledVector(sa,h):Rr.addScaledVector(sa.sub(t),h))}t.add(Rr)}return t}raycast(e,t){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),wr.copy(n.boundingSphere),wr.applyMatrix4(r),Si.copy(e.ray).recast(e.near),!(wr.containsPoint(Si.origin)===!1&&(Si.intersectSphere(wr,Ih)===null||Si.origin.distanceToSquared(Ih)>(e.far-e.near)**2))&&(Ch.copy(r).invert(),Si.copy(e.ray).applyMatrix4(Ch),!(n.boundingBox!==null&&Si.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Si)))}_computeIntersections(e,t,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){let m=d[g],p=o[m.materialIndex],w=Math.max(m.start,f.start),S=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let y=w,U=S;y<U;y+=3){let E=a.getX(y),T=a.getX(y+1),N=a.getX(y+2);s=Ir(this,p,e,n,c,h,u,E,T,N),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{let g=Math.max(0,f.start),_=Math.min(a.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){let w=a.getX(m),S=a.getX(m+1),y=a.getX(m+2);s=Ir(this,o,e,n,c,h,u,w,S,y),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,_=d.length;g<_;g++){let m=d[g],p=o[m.materialIndex],w=Math.max(m.start,f.start),S=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let y=w,U=S;y<U;y+=3){let E=y,T=y+1,N=y+2;s=Ir(this,p,e,n,c,h,u,E,T,N),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{let g=Math.max(0,f.start),_=Math.min(l.count,f.start+f.count);for(let m=g,p=_;m<p;m+=3){let w=m,S=m+1,y=m+2;s=Ir(this,o,e,n,c,h,u,w,S,y),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}};function tp(i,e,t,n,s,r,o,a){let l;if(e.side===Ot?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,e.side===vn,a),l===null)return null;Cr.copy(a),Cr.applyMatrix4(i.matrixWorld);let c=t.ray.origin.distanceTo(Cr);return c<t.near||c>t.far?null:{distance:c,point:Cr.clone(),object:i}}function Ir(i,e,t,n,s,r,o,a,l,c){i.getVertexPosition(a,Ar),i.getVertexPosition(l,Tr),i.getVertexPosition(c,Er);let h=tp(i,e,t,n,Ar,Tr,Er,Ph);if(h){let u=new P;Ri.getBarycoord(Ph,Ar,Tr,Er,u),s&&(h.uv=Ri.getInterpolatedAttribute(s,a,l,c,u,new ze)),r&&(h.uv1=Ri.getInterpolatedAttribute(r,a,l,c,u,new ze)),o&&(h.normal=Ri.getInterpolatedAttribute(o,a,l,c,u,new P),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let d={a,b:l,c,normal:new P,materialIndex:0};Ri.getNormal(Ar,Tr,Er,d.normal),h.face=d,h.barycoord=u}return h}var qs=class i extends $t{constructor(e=1,t=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],u=[],d=0,f=0;g("z","y","x",-1,-1,n,t,e,o,r,0),g("z","y","x",1,-1,n,t,-e,o,r,1),g("x","z","y",1,1,e,n,t,s,o,2),g("x","z","y",1,-1,e,n,-t,s,o,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new Kt(c,3)),this.setAttribute("normal",new Kt(h,3)),this.setAttribute("uv",new Kt(u,2));function g(_,m,p,w,S,y,U,E,T,N,b){let M=y/T,R=U/N,W=y/2,k=U/2,V=E/2,K=T+1,G=N+1,$=0,z=0,ne=new P;for(let ue=0;ue<G;ue++){let xe=ue*R-k;for(let Fe=0;Fe<K;Fe++){let tt=Fe*M-W;ne[_]=tt*w,ne[m]=xe*S,ne[p]=V,c.push(ne.x,ne.y,ne.z),ne[_]=0,ne[m]=0,ne[p]=E>0?1:-1,h.push(ne.x,ne.y,ne.z),u.push(Fe/T),u.push(1-ue/N),$+=1}}for(let ue=0;ue<N;ue++)for(let xe=0;xe<T;xe++){let Fe=d+xe+K*ue,tt=d+xe+K*(ue+1),q=d+(xe+1)+K*(ue+1),ee=d+(xe+1)+K*ue;l.push(Fe,tt,ee),l.push(tt,q,ee),z+=6}a.addGroup(f,z,b),f+=z,d+=$}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function ms(i){let e={};for(let t in i){e[t]={};for(let n in i[t]){let s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function Nt(i){let e={};for(let t=0;t<i.length;t++){let n=ms(i[t]);for(let s in n)e[s]=n[s]}return e}function np(i){let e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function zu(i){let e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:ke.workingColorSpace}var ip={clone:ms,merge:Nt},sp=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,rp=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Mn=class extends Gt{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=sp,this.fragmentShader=rp,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=ms(e.uniforms),this.uniformsGroups=np(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}},Qr=class extends ht{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new De,this.projectionMatrix=new De,this.projectionMatrixInverse=new De,this.coordinateSystem=Bn}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},ii=new P,Lh=new ze,Dh=new ze,Mt=class extends Qr{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=fs*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(zs*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return fs*2*Math.atan(Math.tan(zs*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){ii.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(ii.x,ii.y).multiplyScalar(-e/ii.z),ii.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ii.x,ii.y).multiplyScalar(-e/ii.z)}getViewSize(e,t){return this.getViewBounds(e,Lh,Dh),t.subVectors(Dh,Lh)}setViewOffset(e,t,n,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(zs*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,t-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Ki=-90,$i=1,sl=class extends ht{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new Mt(Ki,$i,e,t);s.layers=this.layers,this.add(s);let r=new Mt(Ki,$i,e,t);r.layers=this.layers,this.add(r);let o=new Mt(Ki,$i,e,t);o.layers=this.layers,this.add(o);let a=new Mt(Ki,$i,e,t);a.layers=this.layers,this.add(a);let l=new Mt(Ki,$i,e,t);l.layers=this.layers,this.add(l);let c=new Mt(Ki,$i,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,s,r,o,a,l]=t;for(let c of t)this.remove(c);if(e===Bn)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Yr)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(let c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;let _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,r),e.setRenderTarget(n,1,s),e.render(t,o),e.setRenderTarget(n,2,s),e.render(t,a),e.setRenderTarget(n,3,s),e.render(t,l),e.setRenderTarget(n,4,s),e.render(t,c),n.texture.generateMipmaps=_,e.setRenderTarget(n,5,s),e.render(t,h),e.setRenderTarget(u,d,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}},eo=class extends St{constructor(e,t,n,s,r,o,a,l,c,h){e=e!==void 0?e:[],t=t!==void 0?t:as,super(e,t,n,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},rl=class extends Hn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new eo(s,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Ft}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new qs(5,5,5),r=new Mn({name:"CubemapFromEquirect",uniforms:ms(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ot,blending:oi});r.uniforms.tEquirect.value=t;let o=new Ct(s,r),a=t.minFilter;return t.minFilter===gn&&(t.minFilter=Ft),new sl(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,n,s){let r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,s);e.setRenderTarget(r)}},ra=new P,op=new P,ap=new Le,Fn=class{constructor(e=new P(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let s=ra.subVectors(n,t).cross(op.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let n=e.delta(ra),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(n,r)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||ap.getNormalMatrix(e),s=this.coplanarPoint(ra).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},bi=new Vt,Pr=new P,Ys=class{constructor(e=new Fn,t=new Fn,n=new Fn,s=new Fn,r=new Fn,o=new Fn){this.planes=[e,t,n,s,r,o]}set(e,t,n,s,r,o){let a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Bn){let n=this.planes,s=e.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],h=s[5],u=s[6],d=s[7],f=s[8],g=s[9],_=s[10],m=s[11],p=s[12],w=s[13],S=s[14],y=s[15];if(n[0].setComponents(l-r,d-c,m-f,y-p).normalize(),n[1].setComponents(l+r,d+c,m+f,y+p).normalize(),n[2].setComponents(l+o,d+h,m+g,y+w).normalize(),n[3].setComponents(l-o,d-h,m-g,y-w).normalize(),n[4].setComponents(l-a,d-u,m-_,y-S).normalize(),t===Bn)n[5].setComponents(l+a,d+u,m+_,y+S).normalize();else if(t===Yr)n[5].setComponents(a,u,_,S).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),bi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),bi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(bi)}intersectsSprite(e){return bi.center.set(0,0,0),bi.radius=.7071067811865476,bi.applyMatrix4(e.matrixWorld),this.intersectsSphere(bi)}intersectsSphere(e){let t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let s=t[n];if(Pr.x=s.normal.x>0?e.max.x:e.min.x,Pr.y=s.normal.y>0?e.max.y:e.min.y,Pr.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Pr)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function Hu(){let i=null,e=!1,t=null,n=null;function s(r,o){t(r,o),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function lp(i){let e=new WeakMap;function t(a,l){let c=a.array,h=a.usage,u=c.byteLength,d=i.createBuffer();i.bindBuffer(l,d),i.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){let h=l.array,u=l.updateRanges;if(i.bindBuffer(c,a),u.length===0)i.bufferSubData(c,0,h);else{u.sort((f,g)=>f.start-g.start);let d=0;for(let f=1;f<u.length;f++){let g=u[d],_=u[f];_.start<=g.start+g.count+1?g.count=Math.max(g.count,_.start+_.count-g.start):(++d,u[d]=_)}u.length=d+1;for(let f=0,g=u.length;f<g;f++){let _=u[f];i.bufferSubData(c,_.start*h.BYTES_PER_ELEMENT,h,_.start,_.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);let l=e.get(a);l&&(i.deleteBuffer(l.buffer),e.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let h=e.get(a);(!h||h.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=e.get(a);if(c===void 0)e.set(a,t(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:s,remove:r,update:o}}var to=class i extends $t{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};let r=e/2,o=t/2,a=Math.floor(n),l=Math.floor(s),c=a+1,h=l+1,u=e/a,d=t/l,f=[],g=[],_=[],m=[];for(let p=0;p<h;p++){let w=p*d-o;for(let S=0;S<c;S++){let y=S*u-r;g.push(y,-w,0),_.push(0,0,1),m.push(S/a),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let w=0;w<a;w++){let S=w+c*p,y=w+c*(p+1),U=w+1+c*(p+1),E=w+1+c*p;f.push(S,y,E),f.push(y,U,E)}this.setIndex(f),this.setAttribute("position",new Kt(g,3)),this.setAttribute("normal",new Kt(_,3)),this.setAttribute("uv",new Kt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.widthSegments,e.heightSegments)}},cp=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,hp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,up=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,dp=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,fp=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,pp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,mp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,gp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,_p=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,vp=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,xp=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,yp=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Mp=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Sp=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bp=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,wp=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Ap=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Tp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Ep=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Rp=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Cp=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Ip=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Pp=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Lp=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Dp=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Np=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Up=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Fp=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Op=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Bp=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,kp="gl_FragColor = linearToOutputTexel( gl_FragColor );",zp=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Hp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Vp=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Gp=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Wp=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Xp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,qp=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Yp=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Zp=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Jp=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Kp=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,$p=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,jp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Qp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,em=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,tm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,nm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,im=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,sm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,rm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,om=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,am=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,cm=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,hm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,um=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,dm=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,fm=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,pm=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,mm=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,gm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,_m=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,vm=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xm=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,ym=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Mm=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Sm=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,bm=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,wm=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Am=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Tm=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Em=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Rm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Cm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Im=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Pm=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Lm=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Dm=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Nm=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Um=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Fm=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Om=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Bm=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,km=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,zm=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Hm=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Vm=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Gm=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Wm=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Xm=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,qm=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Ym=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Zm=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Jm=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Km=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,$m=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,jm=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Qm=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,eg=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,ng=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,ig=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,sg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,rg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,og=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,ag=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,lg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ug=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,mg=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,_g=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,vg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,xg=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,yg=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Mg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Sg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,bg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ag=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Eg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Cg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Ig=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Pg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Dg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ng=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ug=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Og=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Bg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,kg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,zg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Hg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ue={alphahash_fragment:cp,alphahash_pars_fragment:hp,alphamap_fragment:up,alphamap_pars_fragment:dp,alphatest_fragment:fp,alphatest_pars_fragment:pp,aomap_fragment:mp,aomap_pars_fragment:gp,batching_pars_vertex:_p,batching_vertex:vp,begin_vertex:xp,beginnormal_vertex:yp,bsdfs:Mp,iridescence_fragment:Sp,bumpmap_pars_fragment:bp,clipping_planes_fragment:wp,clipping_planes_pars_fragment:Ap,clipping_planes_pars_vertex:Tp,clipping_planes_vertex:Ep,color_fragment:Rp,color_pars_fragment:Cp,color_pars_vertex:Ip,color_vertex:Pp,common:Lp,cube_uv_reflection_fragment:Dp,defaultnormal_vertex:Np,displacementmap_pars_vertex:Up,displacementmap_vertex:Fp,emissivemap_fragment:Op,emissivemap_pars_fragment:Bp,colorspace_fragment:kp,colorspace_pars_fragment:zp,envmap_fragment:Hp,envmap_common_pars_fragment:Vp,envmap_pars_fragment:Gp,envmap_pars_vertex:Wp,envmap_physical_pars_fragment:tm,envmap_vertex:Xp,fog_vertex:qp,fog_pars_vertex:Yp,fog_fragment:Zp,fog_pars_fragment:Jp,gradientmap_pars_fragment:Kp,lightmap_pars_fragment:$p,lights_lambert_fragment:jp,lights_lambert_pars_fragment:Qp,lights_pars_begin:em,lights_toon_fragment:nm,lights_toon_pars_fragment:im,lights_phong_fragment:sm,lights_phong_pars_fragment:rm,lights_physical_fragment:om,lights_physical_pars_fragment:am,lights_fragment_begin:lm,lights_fragment_maps:cm,lights_fragment_end:hm,logdepthbuf_fragment:um,logdepthbuf_pars_fragment:dm,logdepthbuf_pars_vertex:fm,logdepthbuf_vertex:pm,map_fragment:mm,map_pars_fragment:gm,map_particle_fragment:_m,map_particle_pars_fragment:vm,metalnessmap_fragment:xm,metalnessmap_pars_fragment:ym,morphinstance_vertex:Mm,morphcolor_vertex:Sm,morphnormal_vertex:bm,morphtarget_pars_vertex:wm,morphtarget_vertex:Am,normal_fragment_begin:Tm,normal_fragment_maps:Em,normal_pars_fragment:Rm,normal_pars_vertex:Cm,normal_vertex:Im,normalmap_pars_fragment:Pm,clearcoat_normal_fragment_begin:Lm,clearcoat_normal_fragment_maps:Dm,clearcoat_pars_fragment:Nm,iridescence_pars_fragment:Um,opaque_fragment:Fm,packing:Om,premultiplied_alpha_fragment:Bm,project_vertex:km,dithering_fragment:zm,dithering_pars_fragment:Hm,roughnessmap_fragment:Vm,roughnessmap_pars_fragment:Gm,shadowmap_pars_fragment:Wm,shadowmap_pars_vertex:Xm,shadowmap_vertex:qm,shadowmask_pars_fragment:Ym,skinbase_vertex:Zm,skinning_pars_vertex:Jm,skinning_vertex:Km,skinnormal_vertex:$m,specularmap_fragment:jm,specularmap_pars_fragment:Qm,tonemapping_fragment:eg,tonemapping_pars_fragment:tg,transmission_fragment:ng,transmission_pars_fragment:ig,uv_pars_fragment:sg,uv_pars_vertex:rg,uv_vertex:og,worldpos_vertex:ag,background_vert:lg,background_frag:cg,backgroundCube_vert:hg,backgroundCube_frag:ug,cube_vert:dg,cube_frag:fg,depth_vert:pg,depth_frag:mg,distanceRGBA_vert:gg,distanceRGBA_frag:_g,equirect_vert:vg,equirect_frag:xg,linedashed_vert:yg,linedashed_frag:Mg,meshbasic_vert:Sg,meshbasic_frag:bg,meshlambert_vert:wg,meshlambert_frag:Ag,meshmatcap_vert:Tg,meshmatcap_frag:Eg,meshnormal_vert:Rg,meshnormal_frag:Cg,meshphong_vert:Ig,meshphong_frag:Pg,meshphysical_vert:Lg,meshphysical_frag:Dg,meshtoon_vert:Ng,meshtoon_frag:Ug,points_vert:Fg,points_frag:Og,shadow_vert:Bg,shadow_frag:kg,sprite_vert:zg,sprite_frag:Hg},te={common:{diffuse:{value:new we(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Le},alphaMap:{value:null},alphaMapTransform:{value:new Le},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Le}},envmap:{envMap:{value:null},envMapRotation:{value:new Le},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Le}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Le}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Le},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Le},normalScale:{value:new ze(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Le},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Le}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Le}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Le}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new we(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new we(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Le},alphaTest:{value:0},uvTransform:{value:new Le}},sprite:{diffuse:{value:new we(16777215)},opacity:{value:1},center:{value:new ze(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Le},alphaMap:{value:null},alphaMapTransform:{value:new Le},alphaTest:{value:0}}},mn={basic:{uniforms:Nt([te.common,te.specularmap,te.envmap,te.aomap,te.lightmap,te.fog]),vertexShader:Ue.meshbasic_vert,fragmentShader:Ue.meshbasic_frag},lambert:{uniforms:Nt([te.common,te.specularmap,te.envmap,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.fog,te.lights,{emissive:{value:new we(0)}}]),vertexShader:Ue.meshlambert_vert,fragmentShader:Ue.meshlambert_frag},phong:{uniforms:Nt([te.common,te.specularmap,te.envmap,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.fog,te.lights,{emissive:{value:new we(0)},specular:{value:new we(1118481)},shininess:{value:30}}]),vertexShader:Ue.meshphong_vert,fragmentShader:Ue.meshphong_frag},standard:{uniforms:Nt([te.common,te.envmap,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.roughnessmap,te.metalnessmap,te.fog,te.lights,{emissive:{value:new we(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ue.meshphysical_vert,fragmentShader:Ue.meshphysical_frag},toon:{uniforms:Nt([te.common,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.gradientmap,te.fog,te.lights,{emissive:{value:new we(0)}}]),vertexShader:Ue.meshtoon_vert,fragmentShader:Ue.meshtoon_frag},matcap:{uniforms:Nt([te.common,te.bumpmap,te.normalmap,te.displacementmap,te.fog,{matcap:{value:null}}]),vertexShader:Ue.meshmatcap_vert,fragmentShader:Ue.meshmatcap_frag},points:{uniforms:Nt([te.points,te.fog]),vertexShader:Ue.points_vert,fragmentShader:Ue.points_frag},dashed:{uniforms:Nt([te.common,te.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ue.linedashed_vert,fragmentShader:Ue.linedashed_frag},depth:{uniforms:Nt([te.common,te.displacementmap]),vertexShader:Ue.depth_vert,fragmentShader:Ue.depth_frag},normal:{uniforms:Nt([te.common,te.bumpmap,te.normalmap,te.displacementmap,{opacity:{value:1}}]),vertexShader:Ue.meshnormal_vert,fragmentShader:Ue.meshnormal_frag},sprite:{uniforms:Nt([te.sprite,te.fog]),vertexShader:Ue.sprite_vert,fragmentShader:Ue.sprite_frag},background:{uniforms:{uvTransform:{value:new Le},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ue.background_vert,fragmentShader:Ue.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Le}},vertexShader:Ue.backgroundCube_vert,fragmentShader:Ue.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ue.cube_vert,fragmentShader:Ue.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ue.equirect_vert,fragmentShader:Ue.equirect_frag},distanceRGBA:{uniforms:Nt([te.common,te.displacementmap,{referencePosition:{value:new P},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ue.distanceRGBA_vert,fragmentShader:Ue.distanceRGBA_frag},shadow:{uniforms:Nt([te.lights,te.fog,{color:{value:new we(0)},opacity:{value:1}}]),vertexShader:Ue.shadow_vert,fragmentShader:Ue.shadow_frag}};mn.physical={uniforms:Nt([mn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Le},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Le},clearcoatNormalScale:{value:new ze(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Le},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Le},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Le},sheen:{value:0},sheenColor:{value:new we(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Le},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Le},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Le},transmissionSamplerSize:{value:new ze},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Le},attenuationDistance:{value:0},attenuationColor:{value:new we(0)},specularColor:{value:new we(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Le},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Le},anisotropyVector:{value:new ze},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Le}}]),vertexShader:Ue.meshphysical_vert,fragmentShader:Ue.meshphysical_frag};var Lr={r:0,b:0,g:0},wi=new xn,Vg=new De;function Gg(i,e,t,n,s,r,o){let a=new we(0),l=r===!0?0:1,c,h,u=null,d=0,f=null;function g(w){let S=w.isScene===!0?w.background:null;return S&&S.isTexture&&(S=(w.backgroundBlurriness>0?t:e).get(S)),S}function _(w){let S=!1,y=g(w);y===null?p(a,l):y&&y.isColor&&(p(y,1),S=!0);let U=i.xr.getEnvironmentBlendMode();U==="additive"?n.buffers.color.setClear(0,0,0,1,o):U==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||S)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(w,S){let y=g(S);y&&(y.isCubeTexture||y.mapping===bo)?(h===void 0&&(h=new Ct(new qs(1,1,1),new Mn({name:"BackgroundCubeMaterial",uniforms:ms(mn.backgroundCube.uniforms),vertexShader:mn.backgroundCube.vertexShader,fragmentShader:mn.backgroundCube.fragmentShader,side:Ot,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(U,E,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),wi.copy(S.backgroundRotation),wi.x*=-1,wi.y*=-1,wi.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(wi.y*=-1,wi.z*=-1),h.material.uniforms.envMap.value=y,h.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=S.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(Vg.makeRotationFromEuler(wi)),h.material.toneMapped=ke.getTransfer(y.colorSpace)!==et,(u!==y||d!==y.version||f!==i.toneMapping)&&(h.material.needsUpdate=!0,u=y,d=y.version,f=i.toneMapping),h.layers.enableAll(),w.unshift(h,h.geometry,h.material,0,0,null)):y&&y.isTexture&&(c===void 0&&(c=new Ct(new to(2,2),new Mn({name:"BackgroundMaterial",uniforms:ms(mn.background.uniforms),vertexShader:mn.background.vertexShader,fragmentShader:mn.background.fragmentShader,side:vn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=y,c.material.uniforms.backgroundIntensity.value=S.backgroundIntensity,c.material.toneMapped=ke.getTransfer(y.colorSpace)!==et,y.matrixAutoUpdate===!0&&y.updateMatrix(),c.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||d!==y.version||f!==i.toneMapping)&&(c.material.needsUpdate=!0,u=y,d=y.version,f=i.toneMapping),c.layers.enableAll(),w.unshift(c,c.geometry,c.material,0,0,null))}function p(w,S){w.getRGB(Lr,zu(i)),n.buffers.color.setClear(Lr.r,Lr.g,Lr.b,S,o)}return{getClearColor:function(){return a},setClearColor:function(w,S=1){a.set(w),l=S,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(w){l=w,p(a,l)},render:_,addToRenderList:m}}function Wg(i,e){let t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null),r=s,o=!1;function a(M,R,W,k,V){let K=!1,G=u(k,W,R);r!==G&&(r=G,c(r.object)),K=f(M,k,W,V),K&&g(M,k,W,V),V!==null&&e.update(V,i.ELEMENT_ARRAY_BUFFER),(K||o)&&(o=!1,y(M,R,W,k),V!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(V).buffer))}function l(){return i.createVertexArray()}function c(M){return i.bindVertexArray(M)}function h(M){return i.deleteVertexArray(M)}function u(M,R,W){let k=W.wireframe===!0,V=n[M.id];V===void 0&&(V={},n[M.id]=V);let K=V[R.id];K===void 0&&(K={},V[R.id]=K);let G=K[k];return G===void 0&&(G=d(l()),K[k]=G),G}function d(M){let R=[],W=[],k=[];for(let V=0;V<t;V++)R[V]=0,W[V]=0,k[V]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:R,enabledAttributes:W,attributeDivisors:k,object:M,attributes:{},index:null}}function f(M,R,W,k){let V=r.attributes,K=R.attributes,G=0,$=W.getAttributes();for(let z in $)if($[z].location>=0){let ue=V[z],xe=K[z];if(xe===void 0&&(z==="instanceMatrix"&&M.instanceMatrix&&(xe=M.instanceMatrix),z==="instanceColor"&&M.instanceColor&&(xe=M.instanceColor)),ue===void 0||ue.attribute!==xe||xe&&ue.data!==xe.data)return!0;G++}return r.attributesNum!==G||r.index!==k}function g(M,R,W,k){let V={},K=R.attributes,G=0,$=W.getAttributes();for(let z in $)if($[z].location>=0){let ue=K[z];ue===void 0&&(z==="instanceMatrix"&&M.instanceMatrix&&(ue=M.instanceMatrix),z==="instanceColor"&&M.instanceColor&&(ue=M.instanceColor));let xe={};xe.attribute=ue,ue&&ue.data&&(xe.data=ue.data),V[z]=xe,G++}r.attributes=V,r.attributesNum=G,r.index=k}function _(){let M=r.newAttributes;for(let R=0,W=M.length;R<W;R++)M[R]=0}function m(M){p(M,0)}function p(M,R){let W=r.newAttributes,k=r.enabledAttributes,V=r.attributeDivisors;W[M]=1,k[M]===0&&(i.enableVertexAttribArray(M),k[M]=1),V[M]!==R&&(i.vertexAttribDivisor(M,R),V[M]=R)}function w(){let M=r.newAttributes,R=r.enabledAttributes;for(let W=0,k=R.length;W<k;W++)R[W]!==M[W]&&(i.disableVertexAttribArray(W),R[W]=0)}function S(M,R,W,k,V,K,G){G===!0?i.vertexAttribIPointer(M,R,W,V,K):i.vertexAttribPointer(M,R,W,k,V,K)}function y(M,R,W,k){_();let V=k.attributes,K=W.getAttributes(),G=R.defaultAttributeValues;for(let $ in K){let z=K[$];if(z.location>=0){let ne=V[$];if(ne===void 0&&($==="instanceMatrix"&&M.instanceMatrix&&(ne=M.instanceMatrix),$==="instanceColor"&&M.instanceColor&&(ne=M.instanceColor)),ne!==void 0){let ue=ne.normalized,xe=ne.itemSize,Fe=e.get(ne);if(Fe===void 0)continue;let tt=Fe.buffer,q=Fe.type,ee=Fe.bytesPerElement,ve=q===i.INT||q===i.UNSIGNED_INT||ne.gpuType===Il;if(ne.isInterleavedBufferAttribute){let re=ne.data,Te=re.stride,Ce=ne.offset;if(re.isInstancedInterleavedBuffer){for(let Oe=0;Oe<z.locationSize;Oe++)p(z.location+Oe,re.meshPerAttribute);M.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=re.meshPerAttribute*re.count)}else for(let Oe=0;Oe<z.locationSize;Oe++)m(z.location+Oe);i.bindBuffer(i.ARRAY_BUFFER,tt);for(let Oe=0;Oe<z.locationSize;Oe++)S(z.location+Oe,xe/z.locationSize,q,ue,Te*ee,(Ce+xe/z.locationSize*Oe)*ee,ve)}else{if(ne.isInstancedBufferAttribute){for(let re=0;re<z.locationSize;re++)p(z.location+re,ne.meshPerAttribute);M.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=ne.meshPerAttribute*ne.count)}else for(let re=0;re<z.locationSize;re++)m(z.location+re);i.bindBuffer(i.ARRAY_BUFFER,tt);for(let re=0;re<z.locationSize;re++)S(z.location+re,xe/z.locationSize,q,ue,xe*ee,xe/z.locationSize*re*ee,ve)}}else if(G!==void 0){let ue=G[$];if(ue!==void 0)switch(ue.length){case 2:i.vertexAttrib2fv(z.location,ue);break;case 3:i.vertexAttrib3fv(z.location,ue);break;case 4:i.vertexAttrib4fv(z.location,ue);break;default:i.vertexAttrib1fv(z.location,ue)}}}}w()}function U(){N();for(let M in n){let R=n[M];for(let W in R){let k=R[W];for(let V in k)h(k[V].object),delete k[V];delete R[W]}delete n[M]}}function E(M){if(n[M.id]===void 0)return;let R=n[M.id];for(let W in R){let k=R[W];for(let V in k)h(k[V].object),delete k[V];delete R[W]}delete n[M.id]}function T(M){for(let R in n){let W=n[R];if(W[M.id]===void 0)continue;let k=W[M.id];for(let V in k)h(k[V].object),delete k[V];delete W[M.id]}}function N(){b(),o=!0,r!==s&&(r=s,c(r.object))}function b(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:N,resetDefaultState:b,dispose:U,releaseStatesOfGeometry:E,releaseStatesOfProgram:T,initAttributes:_,enableAttribute:m,disableUnusedAttributes:w}}function Xg(i,e,t){let n;function s(c){n=c}function r(c,h){i.drawArrays(n,c,h),t.update(h,n,1)}function o(c,h,u){u!==0&&(i.drawArraysInstanced(n,c,h,u),t.update(h,n,u))}function a(c,h,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let g=0;g<u;g++)f+=h[g];t.update(f,n,1)}function l(c,h,u,d){if(u===0)return;let f=e.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<c.length;g++)o(c[g],h[g],d[g]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let g=0;for(let _=0;_<u;_++)g+=h[_]*d[_];t.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function qg(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){let T=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(T){return!(T!==Jt&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){let N=T===tr&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(T!==zn&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==hn&&!N)}function l(T){if(T==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let u=t.logarithmicDepthBuffer===!0,d=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),p=i.getParameter(i.MAX_VERTEX_ATTRIBS),w=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),S=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),U=g>0,E=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:_,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:w,maxVaryings:S,maxFragmentUniforms:y,vertexTextures:U,maxSamples:E}}function Yg(i){let e=this,t=null,n=0,s=!1,r=!1,o=new Fn,a=new Le,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||s;return s=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,f){let g=u.clippingPlanes,_=u.clipIntersection,m=u.clipShadows,p=i.get(u);if(!s||g===null||g.length===0||r&&!m)r?h(null):c();else{let w=r?0:n,S=w*4,y=p.clippingState||null;l.value=y,y=h(g,d,S,f);for(let U=0;U!==S;++U)y[U]=t[U];p.clippingState=y,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=w}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,f,g){let _=u!==null?u.length:0,m=null;if(_!==0){if(m=l.value,g!==!0||m===null){let p=f+_*4,w=d.matrixWorldInverse;a.getNormalMatrix(w),(m===null||m.length<p)&&(m=new Float32Array(p));for(let S=0,y=f;S!==_;++S,y+=4)o.copy(u[S]).applyMatrix4(w,a),o.normal.toArray(m,y),m[y+3]=o.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,m}}function Zg(i){let e=new WeakMap;function t(o,a){return a===Ta?o.mapping=as:a===Ea&&(o.mapping=ls),o}function n(o){if(o&&o.isTexture){let a=o.mapping;if(a===Ta||a===Ea)if(e.has(o)){let l=e.get(o).texture;return t(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new rl(l.height);return c.fromEquirectangularTexture(i,o),e.set(o,c),o.addEventListener("dispose",s),t(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function r(){e=new WeakMap}return{get:n,dispose:r}}var ci=class extends Qr{constructor(e=-1,t=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-e,o=n+e,a=s+t,l=s-t;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},ts=4,Nh=[.125,.215,.35,.446,.526,.582],Ci=20,oa=new ci,Uh=new we,aa=null,la=0,ca=0,ha=!1,Ti=(1+Math.sqrt(5))/2,ji=1/Ti,Fh=[new P(-Ti,ji,0),new P(Ti,ji,0),new P(-ji,0,Ti),new P(ji,0,Ti),new P(0,Ti,-ji),new P(0,Ti,ji),new P(-1,1,-1),new P(1,1,-1),new P(-1,1,1),new P(1,1,1)],no=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100){aa=this._renderer.getRenderTarget(),la=this._renderer.getActiveCubeFace(),ca=this._renderer.getActiveMipmapLevel(),ha=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(e,n,s,r),t>0&&this._blur(r,0,0,t),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=kh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Bh(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(aa,la,ca),this._renderer.xr.enabled=ha,e.scissorTest=!1,Dr(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===as||e.mapping===ls?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),aa=this._renderer.getRenderTarget(),la=this._renderer.getActiveCubeFace(),ca=this._renderer.getActiveMipmapLevel(),ha=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Ft,minFilter:Ft,generateMipmaps:!1,type:tr,format:Jt,colorSpace:Pt,depthBuffer:!1},s=Oh(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Oh(e,t,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Jg(r)),this._blurMaterial=Kg(r,e,t)}return s}_compileMaterial(e){let t=new Ct(this._lodPlanes[0],e);this._renderer.compile(t,oa)}_sceneToCubeUV(e,t,n,s){let a=new Mt(90,1,t,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(Uh),h.toneMapping=ai,h.autoClear=!1;let f=new yn({name:"PMREM.Background",side:Ot,depthWrite:!1,depthTest:!1}),g=new Ct(new qs,f),_=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,_=!0):(f.color.copy(Uh),_=!0);for(let p=0;p<6;p++){let w=p%3;w===0?(a.up.set(0,l[p],0),a.lookAt(c[p],0,0)):w===1?(a.up.set(0,0,l[p]),a.lookAt(0,c[p],0)):(a.up.set(0,l[p],0),a.lookAt(0,0,c[p]));let S=this._cubeSize;Dr(s,w*S,p>2?S:0,S,S),h.setRenderTarget(s),_&&h.render(g,a),h.render(e,a)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=d,h.autoClear=u,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,s=e.mapping===as||e.mapping===ls;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=kh()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Bh());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new Ct(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=e;let l=this._cubeSize;Dr(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,oa)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let s=this._lodPlanes.length;for(let r=1;r<s;r++){let o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=Fh[(s-r-1)%Fh.length];this._blur(e,r-1,r,o,a)}t.autoClear=n}_blur(e,t,n,s,r){let o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,s,"latitudinal",r),this._halfBlur(o,e,n,n,s,"longitudinal",r)}_halfBlur(e,t,n,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new Ct(this._lodPlanes[s],c),d=c.uniforms,f=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*Ci-1),_=r/g,m=isFinite(r)?1+Math.floor(h*_):Ci;m>Ci&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Ci}`);let p=[],w=0;for(let T=0;T<Ci;++T){let N=T/_,b=Math.exp(-N*N/2);p.push(b),T===0?w+=b:T<m&&(w+=2*b)}for(let T=0;T<p.length;T++)p[T]=p[T]/w;d.envMap.value=e.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);let{_lodMax:S}=this;d.dTheta.value=g,d.mipInt.value=S-n;let y=this._sizeLods[s],U=3*y*(s>S-ts?s-S+ts:0),E=4*(this._cubeSize-y);Dr(t,U,E,3*y,2*y),l.setRenderTarget(t),l.render(u,oa)}};function Jg(i){let e=[],t=[],n=[],s=i,r=i-ts+1+Nh.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);t.push(a);let l=1/a;o>i-ts?l=Nh[o-i+ts-1]:o===0&&(l=0),n.push(l);let c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,_=3,m=2,p=1,w=new Float32Array(_*g*f),S=new Float32Array(m*g*f),y=new Float32Array(p*g*f);for(let E=0;E<f;E++){let T=E%3*2/3-1,N=E>2?0:-1,b=[T,N,0,T+2/3,N,0,T+2/3,N+1,0,T,N,0,T+2/3,N+1,0,T,N+1,0];w.set(b,_*g*E),S.set(d,m*g*E);let M=[E,E,E,E,E,E];y.set(M,p*g*E)}let U=new $t;U.setAttribute("position",new mt(w,_)),U.setAttribute("uv",new mt(S,m)),U.setAttribute("faceIndex",new mt(y,p)),e.push(U),s>ts&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function Oh(i,e,t){let n=new Hn(i,e,t);return n.texture.mapping=bo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Dr(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function Kg(i,e,t){let n=new Float32Array(Ci),s=new P(0,1,0);return new Mn({name:"SphericalGaussianBlur",defines:{n:Ci,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function Bh(){return new Mn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function kh(){return new Mn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function Bl(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function $g(i){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){let l=a.mapping,c=l===Ta||l===Ea,h=l===as||l===ls;if(c||h){let u=e.get(a),d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return t===null&&(t=new no(i)),u=c?t.fromEquirectangular(a,u):t.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),u.texture;if(u!==void 0)return u.texture;{let f=a.image;return c&&f&&f.height>0||h&&f&&s(f)?(t===null&&(t=new no(i)),u=c?t.fromEquirectangular(a):t.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function s(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function jg(i){let e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){let s=t(n);return s===null&&Os("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function Qg(i,e,t,n){let s={},r=new WeakMap;function o(u){let d=u.target;d.index!==null&&e.remove(d.index);for(let g in d.attributes)e.remove(d.attributes[g]);for(let g in d.morphAttributes){let _=d.morphAttributes[g];for(let m=0,p=_.length;m<p;m++)e.remove(_[m])}d.removeEventListener("dispose",o),delete s[d.id];let f=r.get(d);f&&(e.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(u,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,t.memory.geometries++),d}function l(u){let d=u.attributes;for(let g in d)e.update(d[g],i.ARRAY_BUFFER);let f=u.morphAttributes;for(let g in f){let _=f[g];for(let m=0,p=_.length;m<p;m++)e.update(_[m],i.ARRAY_BUFFER)}}function c(u){let d=[],f=u.index,g=u.attributes.position,_=0;if(f!==null){let w=f.array;_=f.version;for(let S=0,y=w.length;S<y;S+=3){let U=w[S+0],E=w[S+1],T=w[S+2];d.push(U,E,E,T,T,U)}}else if(g!==void 0){let w=g.array;_=g.version;for(let S=0,y=w.length/3-1;S<y;S+=3){let U=S+0,E=S+1,T=S+2;d.push(U,E,E,T,T,U)}}else return;let m=new(Bu(d)?jr:$r)(d,1);m.version=_;let p=r.get(u);p&&e.remove(p),r.set(u,m)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function e_(i,e,t){let n;function s(d){n=d}let r,o;function a(d){r=d.type,o=d.bytesPerElement}function l(d,f){i.drawElements(n,f,r,d*o),t.update(f,n,1)}function c(d,f,g){g!==0&&(i.drawElementsInstanced(n,f,r,d*o,g),t.update(f,n,g))}function h(d,f,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];t.update(m,n,1)}function u(d,f,g,_){if(g===0)return;let m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<d.length;p++)c(d[p]/o,f[p],_[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,_,0,g);let p=0;for(let w=0;w<g;w++)p+=f[w]*_[w];t.update(p,n,1)}}this.setMode=s,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function t_(i){let e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=a*(r/3);break;case i.LINES:t.lines+=a*(r/2);break;case i.LINE_STRIP:t.lines+=a*(r-1);break;case i.LINE_LOOP:t.lines+=a*r;break;case i.POINTS:t.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function n_(i,e,t){let n=new WeakMap,s=new Ye;function r(o,a,l){let c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0,d=n.get(a);if(d===void 0||d.count!==u){let b=function(){T.dispose(),n.delete(a),a.removeEventListener("dispose",b)};d!==void 0&&d.texture.dispose();let f=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,_=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],w=a.morphAttributes.color||[],S=0;f===!0&&(S=1),g===!0&&(S=2),_===!0&&(S=3);let y=a.attributes.position.count*S,U=1;y>e.maxTextureSize&&(U=Math.ceil(y/e.maxTextureSize),y=e.maxTextureSize);let E=new Float32Array(y*U*4*u),T=new Jr(E,y,U,u);T.type=hn,T.needsUpdate=!0;let N=S*4;for(let M=0;M<u;M++){let R=m[M],W=p[M],k=w[M],V=y*U*4*M;for(let K=0;K<R.count;K++){let G=K*N;f===!0&&(s.fromBufferAttribute(R,K),E[V+G+0]=s.x,E[V+G+1]=s.y,E[V+G+2]=s.z,E[V+G+3]=0),g===!0&&(s.fromBufferAttribute(W,K),E[V+G+4]=s.x,E[V+G+5]=s.y,E[V+G+6]=s.z,E[V+G+7]=0),_===!0&&(s.fromBufferAttribute(k,K),E[V+G+8]=s.x,E[V+G+9]=s.y,E[V+G+10]=s.z,E[V+G+11]=k.itemSize===4?s.w:1)}}d={count:u,texture:T,size:new ze(y,U)},n.set(a,d),a.addEventListener("dispose",b)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let f=0;for(let _=0;_<c.length;_++)f+=c[_];let g=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(i,"morphTargetBaseInfluence",g),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",d.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function i_(i,e,t,n){let s=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=e.get(l,h);if(s.get(u)!==c&&(e.update(u),s.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;s.get(d)!==c&&(d.update(),s.set(d,c))}return u}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:r,dispose:o}}var io=class extends St{constructor(e,t,n,s,r,o,a,l,c,h=is){if(h!==is&&h!==hs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===is&&(n=Pi),n===void 0&&h===hs&&(n=cs),super(null,s,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:It,this.minFilter=l!==void 0?l:It,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},Vu=new St,zh=new io(1,1),Gu=new Jr,Wu=new il,Xu=new eo,Hh=[],Vh=[],Gh=new Float32Array(16),Wh=new Float32Array(9),Xh=new Float32Array(4);function ys(i,e,t){let n=i[0];if(n<=0||n>0)return i;let s=e*t,r=Hh[s];if(r===void 0&&(r=new Float32Array(s),Hh[s]=r),e!==0){n.toArray(r,0);for(let o=1,a=0;o!==e;++o)a+=t,i[o].toArray(r,a)}return r}function gt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function _t(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function To(i,e){let t=Vh[e];t===void 0&&(t=new Int32Array(e),Vh[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function s_(i,e){let t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function r_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(gt(t,e))return;i.uniform2fv(this.addr,e),_t(t,e)}}function o_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(gt(t,e))return;i.uniform3fv(this.addr,e),_t(t,e)}}function a_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(gt(t,e))return;i.uniform4fv(this.addr,e),_t(t,e)}}function l_(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(gt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),_t(t,e)}else{if(gt(t,n))return;Xh.set(n),i.uniformMatrix2fv(this.addr,!1,Xh),_t(t,n)}}function c_(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(gt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),_t(t,e)}else{if(gt(t,n))return;Wh.set(n),i.uniformMatrix3fv(this.addr,!1,Wh),_t(t,n)}}function h_(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(gt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),_t(t,e)}else{if(gt(t,n))return;Gh.set(n),i.uniformMatrix4fv(this.addr,!1,Gh),_t(t,n)}}function u_(i,e){let t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function d_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(gt(t,e))return;i.uniform2iv(this.addr,e),_t(t,e)}}function f_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(gt(t,e))return;i.uniform3iv(this.addr,e),_t(t,e)}}function p_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(gt(t,e))return;i.uniform4iv(this.addr,e),_t(t,e)}}function m_(i,e){let t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function g_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(gt(t,e))return;i.uniform2uiv(this.addr,e),_t(t,e)}}function __(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(gt(t,e))return;i.uniform3uiv(this.addr,e),_t(t,e)}}function v_(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(gt(t,e))return;i.uniform4uiv(this.addr,e),_t(t,e)}}function x_(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(zh.compareFunction=Fu,r=zh):r=Vu,t.setTexture2D(e||r,s)}function y_(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||Wu,s)}function M_(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||Xu,s)}function S_(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||Gu,s)}function b_(i){switch(i){case 5126:return s_;case 35664:return r_;case 35665:return o_;case 35666:return a_;case 35674:return l_;case 35675:return c_;case 35676:return h_;case 5124:case 35670:return u_;case 35667:case 35671:return d_;case 35668:case 35672:return f_;case 35669:case 35673:return p_;case 5125:return m_;case 36294:return g_;case 36295:return __;case 36296:return v_;case 35678:case 36198:case 36298:case 36306:case 35682:return x_;case 35679:case 36299:case 36307:return y_;case 35680:case 36300:case 36308:case 36293:return M_;case 36289:case 36303:case 36311:case 36292:return S_}}function w_(i,e){i.uniform1fv(this.addr,e)}function A_(i,e){let t=ys(e,this.size,2);i.uniform2fv(this.addr,t)}function T_(i,e){let t=ys(e,this.size,3);i.uniform3fv(this.addr,t)}function E_(i,e){let t=ys(e,this.size,4);i.uniform4fv(this.addr,t)}function R_(i,e){let t=ys(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function C_(i,e){let t=ys(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function I_(i,e){let t=ys(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function P_(i,e){i.uniform1iv(this.addr,e)}function L_(i,e){i.uniform2iv(this.addr,e)}function D_(i,e){i.uniform3iv(this.addr,e)}function N_(i,e){i.uniform4iv(this.addr,e)}function U_(i,e){i.uniform1uiv(this.addr,e)}function F_(i,e){i.uniform2uiv(this.addr,e)}function O_(i,e){i.uniform3uiv(this.addr,e)}function B_(i,e){i.uniform4uiv(this.addr,e)}function k_(i,e,t){let n=this.cache,s=e.length,r=To(t,s);gt(n,r)||(i.uniform1iv(this.addr,r),_t(n,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||Vu,r[o])}function z_(i,e,t){let n=this.cache,s=e.length,r=To(t,s);gt(n,r)||(i.uniform1iv(this.addr,r),_t(n,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||Wu,r[o])}function H_(i,e,t){let n=this.cache,s=e.length,r=To(t,s);gt(n,r)||(i.uniform1iv(this.addr,r),_t(n,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||Xu,r[o])}function V_(i,e,t){let n=this.cache,s=e.length,r=To(t,s);gt(n,r)||(i.uniform1iv(this.addr,r),_t(n,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||Gu,r[o])}function G_(i){switch(i){case 5126:return w_;case 35664:return A_;case 35665:return T_;case 35666:return E_;case 35674:return R_;case 35675:return C_;case 35676:return I_;case 5124:case 35670:return P_;case 35667:case 35671:return L_;case 35668:case 35672:return D_;case 35669:case 35673:return N_;case 5125:return U_;case 36294:return F_;case 36295:return O_;case 36296:return B_;case 35678:case 36198:case 36298:case 36306:case 35682:return k_;case 35679:case 36299:case 36307:return z_;case 35680:case 36300:case 36308:case 36293:return H_;case 36289:case 36303:case 36311:case 36292:return V_}}var ol=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=b_(t.type)}},al=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=G_(t.type)}},ll=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(e,t[a.id],n)}}},ua=/(\w+)(\])?(\[|\.)?/g;function qh(i,e){i.seq.push(e),i.map[e.id]=e}function W_(i,e,t){let n=i.name,s=n.length;for(ua.lastIndex=0;;){let r=ua.exec(n),o=ua.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){qh(t,c===void 0?new ol(a,i,e):new al(a,i,e));break}else{let u=t.map[a];u===void 0&&(u=new ll(a),qh(t,u)),t=u}}}var rs=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){let r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);W_(r,o,this)}}setValue(e,t,n,s){let r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){let s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,o=t.length;r!==o;++r){let a=t[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,s)}}static seqWithValue(e,t){let n=[];for(let s=0,r=e.length;s!==r;++s){let o=e[s];o.id in t&&n.push(o)}return n}};function Yh(i,e,t){let n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}var X_=37297,q_=0;function Y_(i,e){let t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}var Zh=new Le;function Z_(i){ke._getMatrix(Zh,ke.workingColorSpace,i);let e=`mat3( ${Zh.elements.map(t=>t.toFixed(4))} )`;switch(ke.getTransfer(i)){case Ao:return[e,"LinearTransferOETF"];case et:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function Jh(i,e,t){let n=i.getShaderParameter(e,i.COMPILE_STATUS),s=i.getShaderInfoLog(e).trim();if(n&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return t.toUpperCase()+`

`+s+`

`+Y_(i.getShaderSource(e),o)}else return s}function J_(i,e){let t=Z_(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function K_(i,e){let t;switch(e){case rf:t="Linear";break;case of:t="Reinhard";break;case af:t="Cineon";break;case lf:t="ACESFilmic";break;case hf:t="AgX";break;case uf:t="Neutral";break;case cf:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}var Nr=new P;function $_(){ke.getLuminanceCoefficients(Nr);let i=Nr.x.toFixed(4),e=Nr.y.toFixed(4),t=Nr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function j_(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Bs).join(`
`)}function Q_(i){let e=[];for(let t in i){let n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function e0(i,e){let t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(e,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),t[o]={type:r.type,location:i.getAttribLocation(e,o),locationSize:a}}return t}function Bs(i){return i!==""}function Kh(i,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function $h(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var t0=/^[ \t]*#include +<([\w\d./]+)>/gm;function cl(i){return i.replace(t0,i0)}var n0=new Map;function i0(i,e){let t=Ue[e];if(t===void 0){let n=n0.get(e);if(n!==void 0)t=Ue[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return cl(t)}var s0=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function jh(i){return i.replace(s0,r0)}function r0(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Qh(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function o0(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Su?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===Od?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===Un&&(e="SHADOWMAP_TYPE_VSM"),e}function a0(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case as:case ls:e="ENVMAP_TYPE_CUBE";break;case bo:e="ENVMAP_TYPE_CUBE_UV";break}return e}function l0(i){let e="ENVMAP_MODE_REFLECTION";return i.envMap&&i.envMapMode===ls&&(e="ENVMAP_MODE_REFRACTION"),e}function c0(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case bu:e="ENVMAP_BLENDING_MULTIPLY";break;case nf:e="ENVMAP_BLENDING_MIX";break;case sf:e="ENVMAP_BLENDING_ADD";break}return e}function h0(i){let e=i.envMapCubeUVHeight;if(e===null)return null;let t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function u0(i,e,t,n){let s=i.getContext(),r=t.defines,o=t.vertexShader,a=t.fragmentShader,l=o0(t),c=a0(t),h=l0(t),u=c0(t),d=h0(t),f=j_(t),g=Q_(r),_=s.createProgram(),m,p,w=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Bs).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Bs).join(`
`),p.length>0&&(p+=`
`)):(m=[Qh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Bs).join(`
`),p=[Qh(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==ai?"#define TONE_MAPPING":"",t.toneMapping!==ai?Ue.tonemapping_pars_fragment:"",t.toneMapping!==ai?K_("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ue.colorspace_pars_fragment,J_("linearToOutputTexel",t.outputColorSpace),$_(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Bs).join(`
`)),o=cl(o),o=Kh(o,t),o=$h(o,t),a=cl(a),a=Kh(a,t),a=$h(a,t),o=jh(o),a=jh(a),t.isRawShaderMaterial!==!0&&(w=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",t.glslVersion===dh?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===dh?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let S=w+m+o,y=w+p+a,U=Yh(s,s.VERTEX_SHADER,S),E=Yh(s,s.FRAGMENT_SHADER,y);s.attachShader(_,U),s.attachShader(_,E),t.index0AttributeName!==void 0?s.bindAttribLocation(_,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function T(R){if(i.debug.checkShaderErrors){let W=s.getProgramInfoLog(_).trim(),k=s.getShaderInfoLog(U).trim(),V=s.getShaderInfoLog(E).trim(),K=!0,G=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(K=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,U,E);else{let $=Jh(s,U,"vertex"),z=Jh(s,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+W+`
`+$+`
`+z)}else W!==""?console.warn("THREE.WebGLProgram: Program Info Log:",W):(k===""||V==="")&&(G=!1);G&&(R.diagnostics={runnable:K,programLog:W,vertexShader:{log:k,prefix:m},fragmentShader:{log:V,prefix:p}})}s.deleteShader(U),s.deleteShader(E),N=new rs(s,_),b=e0(s,_)}let N;this.getUniforms=function(){return N===void 0&&T(this),N};let b;this.getAttributes=function(){return b===void 0&&T(this),b};let M=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return M===!1&&(M=s.getProgramParameter(_,X_)),M},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=q_++,this.cacheKey=e,this.usedTimes=1,this.program=_,this.vertexShader=U,this.fragmentShader=E,this}var d0=0,hl=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new ul(e),t.set(e,n)),n}},ul=class{constructor(e){this.id=d0++,this.code=e,this.usedTimes=0}};function f0(i,e,t,n,s,r,o){let a=new Kr,l=new hl,c=new Set,h=[],u=s.logarithmicDepthBuffer,d=s.vertexTextures,f=s.precision,g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(b){return c.add(b),b===0?"uv":`uv${b}`}function m(b,M,R,W,k){let V=W.fog,K=k.geometry,G=b.isMeshStandardMaterial?W.environment:null,$=(b.isMeshStandardMaterial?t:e).get(b.envMap||G),z=$&&$.mapping===bo?$.image.height:null,ne=g[b.type];b.precision!==null&&(f=s.getMaxPrecision(b.precision),f!==b.precision&&console.warn("THREE.WebGLProgram.getParameters:",b.precision,"not supported, using",f,"instead."));let ue=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,xe=ue!==void 0?ue.length:0,Fe=0;K.morphAttributes.position!==void 0&&(Fe=1),K.morphAttributes.normal!==void 0&&(Fe=2),K.morphAttributes.color!==void 0&&(Fe=3);let tt,q,ee,ve;if(ne){let $e=mn[ne];tt=$e.vertexShader,q=$e.fragmentShader}else tt=b.vertexShader,q=b.fragmentShader,l.update(b),ee=l.getVertexShaderID(b),ve=l.getFragmentShaderID(b);let re=i.getRenderTarget(),Te=i.state.buffers.depth.getReversed(),Ce=k.isInstancedMesh===!0,Oe=k.isBatchedMesh===!0,ct=!!b.map,We=!!b.matcap,dt=!!$,D=!!b.aoMap,Xt=!!b.lightMap,He=!!b.bumpMap,Ve=!!b.normalMap,be=!!b.displacementMap,rt=!!b.emissiveMap,Se=!!b.metalnessMap,A=!!b.roughnessMap,v=b.anisotropy>0,F=b.clearcoat>0,Y=b.dispersion>0,J=b.iridescence>0,X=b.sheen>0,ye=b.transmission>0,oe=v&&!!b.anisotropyMap,de=F&&!!b.clearcoatMap,Xe=F&&!!b.clearcoatNormalMap,j=F&&!!b.clearcoatRoughnessMap,fe=J&&!!b.iridescenceMap,Ae=J&&!!b.iridescenceThicknessMap,Ee=X&&!!b.sheenColorMap,pe=X&&!!b.sheenRoughnessMap,Ge=!!b.specularMap,Ne=!!b.specularColorMap,nt=!!b.specularIntensityMap,C=ye&&!!b.transmissionMap,ie=ye&&!!b.thicknessMap,H=!!b.gradientMap,Z=!!b.alphaMap,he=b.alphaTest>0,ae=!!b.alphaHash,Ie=!!b.extensions,ut=ai;b.toneMapped&&(re===null||re.isXRRenderTarget===!0)&&(ut=i.toneMapping);let wt={shaderID:ne,shaderType:b.type,shaderName:b.name,vertexShader:tt,fragmentShader:q,defines:b.defines,customVertexShaderID:ee,customFragmentShaderID:ve,isRawShaderMaterial:b.isRawShaderMaterial===!0,glslVersion:b.glslVersion,precision:f,batching:Oe,batchingColor:Oe&&k._colorsTexture!==null,instancing:Ce,instancingColor:Ce&&k.instanceColor!==null,instancingMorph:Ce&&k.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:re===null?i.outputColorSpace:re.isXRRenderTarget===!0?re.texture.colorSpace:Pt,alphaToCoverage:!!b.alphaToCoverage,map:ct,matcap:We,envMap:dt,envMapMode:dt&&$.mapping,envMapCubeUVHeight:z,aoMap:D,lightMap:Xt,bumpMap:He,normalMap:Ve,displacementMap:d&&be,emissiveMap:rt,normalMapObjectSpace:Ve&&b.normalMapType===gf,normalMapTangentSpace:Ve&&b.normalMapType===Uu,metalnessMap:Se,roughnessMap:A,anisotropy:v,anisotropyMap:oe,clearcoat:F,clearcoatMap:de,clearcoatNormalMap:Xe,clearcoatRoughnessMap:j,dispersion:Y,iridescence:J,iridescenceMap:fe,iridescenceThicknessMap:Ae,sheen:X,sheenColorMap:Ee,sheenRoughnessMap:pe,specularMap:Ge,specularColorMap:Ne,specularIntensityMap:nt,transmission:ye,transmissionMap:C,thicknessMap:ie,gradientMap:H,opaque:b.transparent===!1&&b.blending===ns&&b.alphaToCoverage===!1,alphaMap:Z,alphaTest:he,alphaHash:ae,combine:b.combine,mapUv:ct&&_(b.map.channel),aoMapUv:D&&_(b.aoMap.channel),lightMapUv:Xt&&_(b.lightMap.channel),bumpMapUv:He&&_(b.bumpMap.channel),normalMapUv:Ve&&_(b.normalMap.channel),displacementMapUv:be&&_(b.displacementMap.channel),emissiveMapUv:rt&&_(b.emissiveMap.channel),metalnessMapUv:Se&&_(b.metalnessMap.channel),roughnessMapUv:A&&_(b.roughnessMap.channel),anisotropyMapUv:oe&&_(b.anisotropyMap.channel),clearcoatMapUv:de&&_(b.clearcoatMap.channel),clearcoatNormalMapUv:Xe&&_(b.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:j&&_(b.clearcoatRoughnessMap.channel),iridescenceMapUv:fe&&_(b.iridescenceMap.channel),iridescenceThicknessMapUv:Ae&&_(b.iridescenceThicknessMap.channel),sheenColorMapUv:Ee&&_(b.sheenColorMap.channel),sheenRoughnessMapUv:pe&&_(b.sheenRoughnessMap.channel),specularMapUv:Ge&&_(b.specularMap.channel),specularColorMapUv:Ne&&_(b.specularColorMap.channel),specularIntensityMapUv:nt&&_(b.specularIntensityMap.channel),transmissionMapUv:C&&_(b.transmissionMap.channel),thicknessMapUv:ie&&_(b.thicknessMap.channel),alphaMapUv:Z&&_(b.alphaMap.channel),vertexTangents:!!K.attributes.tangent&&(Ve||v),vertexColors:b.vertexColors,vertexAlphas:b.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!K.attributes.uv&&(ct||Z),fog:!!V,useFog:b.fog===!0,fogExp2:!!V&&V.isFogExp2,flatShading:b.flatShading===!0,sizeAttenuation:b.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:Te,skinning:k.isSkinnedMesh===!0,morphTargets:K.morphAttributes.position!==void 0,morphNormals:K.morphAttributes.normal!==void 0,morphColors:K.morphAttributes.color!==void 0,morphTargetsCount:xe,morphTextureStride:Fe,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:b.dithering,shadowMapEnabled:i.shadowMap.enabled&&R.length>0,shadowMapType:i.shadowMap.type,toneMapping:ut,decodeVideoTexture:ct&&b.map.isVideoTexture===!0&&ke.getTransfer(b.map.colorSpace)===et,decodeVideoTextureEmissive:rt&&b.emissiveMap.isVideoTexture===!0&&ke.getTransfer(b.emissiveMap.colorSpace)===et,premultipliedAlpha:b.premultipliedAlpha,doubleSided:b.side===ln,flipSided:b.side===Ot,useDepthPacking:b.depthPacking>=0,depthPacking:b.depthPacking||0,index0AttributeName:b.index0AttributeName,extensionClipCullDistance:Ie&&b.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ie&&b.extensions.multiDraw===!0||Oe)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:b.customProgramCacheKey()};return wt.vertexUv1s=c.has(1),wt.vertexUv2s=c.has(2),wt.vertexUv3s=c.has(3),c.clear(),wt}function p(b){let M=[];if(b.shaderID?M.push(b.shaderID):(M.push(b.customVertexShaderID),M.push(b.customFragmentShaderID)),b.defines!==void 0)for(let R in b.defines)M.push(R),M.push(b.defines[R]);return b.isRawShaderMaterial===!1&&(w(M,b),S(M,b),M.push(i.outputColorSpace)),M.push(b.customProgramCacheKey),M.join()}function w(b,M){b.push(M.precision),b.push(M.outputColorSpace),b.push(M.envMapMode),b.push(M.envMapCubeUVHeight),b.push(M.mapUv),b.push(M.alphaMapUv),b.push(M.lightMapUv),b.push(M.aoMapUv),b.push(M.bumpMapUv),b.push(M.normalMapUv),b.push(M.displacementMapUv),b.push(M.emissiveMapUv),b.push(M.metalnessMapUv),b.push(M.roughnessMapUv),b.push(M.anisotropyMapUv),b.push(M.clearcoatMapUv),b.push(M.clearcoatNormalMapUv),b.push(M.clearcoatRoughnessMapUv),b.push(M.iridescenceMapUv),b.push(M.iridescenceThicknessMapUv),b.push(M.sheenColorMapUv),b.push(M.sheenRoughnessMapUv),b.push(M.specularMapUv),b.push(M.specularColorMapUv),b.push(M.specularIntensityMapUv),b.push(M.transmissionMapUv),b.push(M.thicknessMapUv),b.push(M.combine),b.push(M.fogExp2),b.push(M.sizeAttenuation),b.push(M.morphTargetsCount),b.push(M.morphAttributeCount),b.push(M.numDirLights),b.push(M.numPointLights),b.push(M.numSpotLights),b.push(M.numSpotLightMaps),b.push(M.numHemiLights),b.push(M.numRectAreaLights),b.push(M.numDirLightShadows),b.push(M.numPointLightShadows),b.push(M.numSpotLightShadows),b.push(M.numSpotLightShadowsWithMaps),b.push(M.numLightProbes),b.push(M.shadowMapType),b.push(M.toneMapping),b.push(M.numClippingPlanes),b.push(M.numClipIntersection),b.push(M.depthPacking)}function S(b,M){a.disableAll(),M.supportsVertexTextures&&a.enable(0),M.instancing&&a.enable(1),M.instancingColor&&a.enable(2),M.instancingMorph&&a.enable(3),M.matcap&&a.enable(4),M.envMap&&a.enable(5),M.normalMapObjectSpace&&a.enable(6),M.normalMapTangentSpace&&a.enable(7),M.clearcoat&&a.enable(8),M.iridescence&&a.enable(9),M.alphaTest&&a.enable(10),M.vertexColors&&a.enable(11),M.vertexAlphas&&a.enable(12),M.vertexUv1s&&a.enable(13),M.vertexUv2s&&a.enable(14),M.vertexUv3s&&a.enable(15),M.vertexTangents&&a.enable(16),M.anisotropy&&a.enable(17),M.alphaHash&&a.enable(18),M.batching&&a.enable(19),M.dispersion&&a.enable(20),M.batchingColor&&a.enable(21),b.push(a.mask),a.disableAll(),M.fog&&a.enable(0),M.useFog&&a.enable(1),M.flatShading&&a.enable(2),M.logarithmicDepthBuffer&&a.enable(3),M.reverseDepthBuffer&&a.enable(4),M.skinning&&a.enable(5),M.morphTargets&&a.enable(6),M.morphNormals&&a.enable(7),M.morphColors&&a.enable(8),M.premultipliedAlpha&&a.enable(9),M.shadowMapEnabled&&a.enable(10),M.doubleSided&&a.enable(11),M.flipSided&&a.enable(12),M.useDepthPacking&&a.enable(13),M.dithering&&a.enable(14),M.transmission&&a.enable(15),M.sheen&&a.enable(16),M.opaque&&a.enable(17),M.pointsUvs&&a.enable(18),M.decodeVideoTexture&&a.enable(19),M.decodeVideoTextureEmissive&&a.enable(20),M.alphaToCoverage&&a.enable(21),b.push(a.mask)}function y(b){let M=g[b.type],R;if(M){let W=mn[M];R=ip.clone(W.uniforms)}else R=b.uniforms;return R}function U(b,M){let R;for(let W=0,k=h.length;W<k;W++){let V=h[W];if(V.cacheKey===M){R=V,++R.usedTimes;break}}return R===void 0&&(R=new u0(i,M,b,r),h.push(R)),R}function E(b){if(--b.usedTimes===0){let M=h.indexOf(b);h[M]=h[h.length-1],h.pop(),b.destroy()}}function T(b){l.remove(b)}function N(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:y,acquireProgram:U,releaseProgram:E,releaseShaderCache:T,programs:h,dispose:N}}function p0(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function s(o,a,l){i.get(o)[a]=l}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function m0(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function eu(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function tu(){let i=[],e=0,t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function o(u,d,f,g,_,m){let p=i[e];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:_,group:m},i[e]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=_,p.group=m),e++,p}function a(u,d,f,g,_,m){let p=o(u,d,f,g,_,m);f.transmission>0?n.push(p):f.transparent===!0?s.push(p):t.push(p)}function l(u,d,f,g,_,m){let p=o(u,d,f,g,_,m);f.transmission>0?n.unshift(p):f.transparent===!0?s.unshift(p):t.unshift(p)}function c(u,d){t.length>1&&t.sort(u||m0),n.length>1&&n.sort(d||eu),s.length>1&&s.sort(d||eu)}function h(){for(let u=e,d=i.length;u<d;u++){let f=i[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:a,unshift:l,finish:h,sort:c}}function g0(){let i=new WeakMap;function e(n,s){let r=i.get(n),o;return r===void 0?(o=new tu,i.set(n,[o])):s>=r.length?(o=new tu,r.push(o)):o=r[s],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function _0(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new P,color:new we};break;case"SpotLight":t={position:new P,direction:new P,color:new we,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new P,color:new we,distance:0,decay:0};break;case"HemisphereLight":t={direction:new P,skyColor:new we,groundColor:new we};break;case"RectAreaLight":t={color:new we,position:new P,halfWidth:new P,halfHeight:new P};break}return i[e.id]=t,t}}}function v0(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ze};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ze};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ze,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}var x0=0;function y0(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function M0(i){let e=new _0,t=v0(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new P);let s=new P,r=new De,o=new De;function a(c){let h=0,u=0,d=0;for(let b=0;b<9;b++)n.probe[b].set(0,0,0);let f=0,g=0,_=0,m=0,p=0,w=0,S=0,y=0,U=0,E=0,T=0;c.sort(y0);for(let b=0,M=c.length;b<M;b++){let R=c[b],W=R.color,k=R.intensity,V=R.distance,K=R.shadow&&R.shadow.map?R.shadow.map.texture:null;if(R.isAmbientLight)h+=W.r*k,u+=W.g*k,d+=W.b*k;else if(R.isLightProbe){for(let G=0;G<9;G++)n.probe[G].addScaledVector(R.sh.coefficients[G],k);T++}else if(R.isDirectionalLight){let G=e.get(R);if(G.color.copy(R.color).multiplyScalar(R.intensity),R.castShadow){let $=R.shadow,z=t.get(R);z.shadowIntensity=$.intensity,z.shadowBias=$.bias,z.shadowNormalBias=$.normalBias,z.shadowRadius=$.radius,z.shadowMapSize=$.mapSize,n.directionalShadow[f]=z,n.directionalShadowMap[f]=K,n.directionalShadowMatrix[f]=R.shadow.matrix,w++}n.directional[f]=G,f++}else if(R.isSpotLight){let G=e.get(R);G.position.setFromMatrixPosition(R.matrixWorld),G.color.copy(W).multiplyScalar(k),G.distance=V,G.coneCos=Math.cos(R.angle),G.penumbraCos=Math.cos(R.angle*(1-R.penumbra)),G.decay=R.decay,n.spot[_]=G;let $=R.shadow;if(R.map&&(n.spotLightMap[U]=R.map,U++,$.updateMatrices(R),R.castShadow&&E++),n.spotLightMatrix[_]=$.matrix,R.castShadow){let z=t.get(R);z.shadowIntensity=$.intensity,z.shadowBias=$.bias,z.shadowNormalBias=$.normalBias,z.shadowRadius=$.radius,z.shadowMapSize=$.mapSize,n.spotShadow[_]=z,n.spotShadowMap[_]=K,y++}_++}else if(R.isRectAreaLight){let G=e.get(R);G.color.copy(W).multiplyScalar(k),G.halfWidth.set(R.width*.5,0,0),G.halfHeight.set(0,R.height*.5,0),n.rectArea[m]=G,m++}else if(R.isPointLight){let G=e.get(R);if(G.color.copy(R.color).multiplyScalar(R.intensity),G.distance=R.distance,G.decay=R.decay,R.castShadow){let $=R.shadow,z=t.get(R);z.shadowIntensity=$.intensity,z.shadowBias=$.bias,z.shadowNormalBias=$.normalBias,z.shadowRadius=$.radius,z.shadowMapSize=$.mapSize,z.shadowCameraNear=$.camera.near,z.shadowCameraFar=$.camera.far,n.pointShadow[g]=z,n.pointShadowMap[g]=K,n.pointShadowMatrix[g]=R.shadow.matrix,S++}n.point[g]=G,g++}else if(R.isHemisphereLight){let G=e.get(R);G.skyColor.copy(R.color).multiplyScalar(k),G.groundColor.copy(R.groundColor).multiplyScalar(k),n.hemi[p]=G,p++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=te.LTC_FLOAT_1,n.rectAreaLTC2=te.LTC_FLOAT_2):(n.rectAreaLTC1=te.LTC_HALF_1,n.rectAreaLTC2=te.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let N=n.hash;(N.directionalLength!==f||N.pointLength!==g||N.spotLength!==_||N.rectAreaLength!==m||N.hemiLength!==p||N.numDirectionalShadows!==w||N.numPointShadows!==S||N.numSpotShadows!==y||N.numSpotMaps!==U||N.numLightProbes!==T)&&(n.directional.length=f,n.spot.length=_,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=w,n.directionalShadowMap.length=w,n.pointShadow.length=S,n.pointShadowMap.length=S,n.spotShadow.length=y,n.spotShadowMap.length=y,n.directionalShadowMatrix.length=w,n.pointShadowMatrix.length=S,n.spotLightMatrix.length=y+U-E,n.spotLightMap.length=U,n.numSpotLightShadowsWithMaps=E,n.numLightProbes=T,N.directionalLength=f,N.pointLength=g,N.spotLength=_,N.rectAreaLength=m,N.hemiLength=p,N.numDirectionalShadows=w,N.numPointShadows=S,N.numSpotShadows=y,N.numSpotMaps=U,N.numLightProbes=T,n.version=x0++)}function l(c,h){let u=0,d=0,f=0,g=0,_=0,m=h.matrixWorldInverse;for(let p=0,w=c.length;p<w;p++){let S=c[p];if(S.isDirectionalLight){let y=n.directional[u];y.direction.setFromMatrixPosition(S.matrixWorld),s.setFromMatrixPosition(S.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(m),u++}else if(S.isSpotLight){let y=n.spot[f];y.position.setFromMatrixPosition(S.matrixWorld),y.position.applyMatrix4(m),y.direction.setFromMatrixPosition(S.matrixWorld),s.setFromMatrixPosition(S.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(m),f++}else if(S.isRectAreaLight){let y=n.rectArea[g];y.position.setFromMatrixPosition(S.matrixWorld),y.position.applyMatrix4(m),o.identity(),r.copy(S.matrixWorld),r.premultiply(m),o.extractRotation(r),y.halfWidth.set(S.width*.5,0,0),y.halfHeight.set(0,S.height*.5,0),y.halfWidth.applyMatrix4(o),y.halfHeight.applyMatrix4(o),g++}else if(S.isPointLight){let y=n.point[d];y.position.setFromMatrixPosition(S.matrixWorld),y.position.applyMatrix4(m),d++}else if(S.isHemisphereLight){let y=n.hemi[_];y.direction.setFromMatrixPosition(S.matrixWorld),y.direction.transformDirection(m),_++}}}return{setup:a,setupView:l,state:n}}function nu(i){let e=new M0(i),t=[],n=[];function s(h){c.camera=h,t.length=0,n.length=0}function r(h){t.push(h)}function o(h){n.push(h)}function a(){e.setup(t)}function l(h){e.setupView(t,h)}let c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:c,setupLights:a,setupLightsView:l,pushLight:r,pushShadow:o}}function S0(i){let e=new WeakMap;function t(s,r=0){let o=e.get(s),a;return o===void 0?(a=new nu(i),e.set(s,[a])):r>=o.length?(a=new nu(i),o.push(a)):a=o[r],a}function n(){e=new WeakMap}return{get:t,dispose:n}}var dl=class extends Gt{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=pf,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},fl=class extends Gt{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},b0=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,w0=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function A0(i,e,t){let n=new Ys,s=new ze,r=new ze,o=new Ye,a=new dl({depthPacking:mf}),l=new fl,c={},h=t.maxTextureSize,u={[vn]:Ot,[Ot]:vn,[ln]:ln},d=new Mn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ze},radius:{value:4}},vertexShader:b0,fragmentShader:w0}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let g=new $t;g.setAttribute("position",new mt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let _=new Ct(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Su;let p=this.type;this.render=function(E,T,N){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;let b=i.getRenderTarget(),M=i.getActiveCubeFace(),R=i.getActiveMipmapLevel(),W=i.state;W.setBlending(oi),W.buffers.color.setClear(1,1,1,1),W.buffers.depth.setTest(!0),W.setScissorTest(!1);let k=p!==Un&&this.type===Un,V=p===Un&&this.type!==Un;for(let K=0,G=E.length;K<G;K++){let $=E[K],z=$.shadow;if(z===void 0){console.warn("THREE.WebGLShadowMap:",$,"has no shadow.");continue}if(z.autoUpdate===!1&&z.needsUpdate===!1)continue;s.copy(z.mapSize);let ne=z.getFrameExtents();if(s.multiply(ne),r.copy(z.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/ne.x),s.x=r.x*ne.x,z.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/ne.y),s.y=r.y*ne.y,z.mapSize.y=r.y)),z.map===null||k===!0||V===!0){let xe=this.type!==Un?{minFilter:It,magFilter:It}:{};z.map!==null&&z.map.dispose(),z.map=new Hn(s.x,s.y,xe),z.map.texture.name=$.name+".shadowMap",z.camera.updateProjectionMatrix()}i.setRenderTarget(z.map),i.clear();let ue=z.getViewportCount();for(let xe=0;xe<ue;xe++){let Fe=z.getViewport(xe);o.set(r.x*Fe.x,r.y*Fe.y,r.x*Fe.z,r.y*Fe.w),W.viewport(o),z.updateMatrices($,xe),n=z.getFrustum(),y(T,N,z.camera,$,this.type)}z.isPointLightShadow!==!0&&this.type===Un&&w(z,N),z.needsUpdate=!1}p=this.type,m.needsUpdate=!1,i.setRenderTarget(b,M,R)};function w(E,T){let N=e.update(_);d.defines.VSM_SAMPLES!==E.blurSamples&&(d.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new Hn(s.x,s.y)),d.uniforms.shadow_pass.value=E.map.texture,d.uniforms.resolution.value=E.mapSize,d.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(T,null,N,d,_,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value=E.mapSize,f.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(T,null,N,f,_,null)}function S(E,T,N,b){let M=null,R=N.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(R!==void 0)M=R;else if(M=N.isPointLight===!0?l:a,i.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0){let W=M.uuid,k=T.uuid,V=c[W];V===void 0&&(V={},c[W]=V);let K=V[k];K===void 0&&(K=M.clone(),V[k]=K,T.addEventListener("dispose",U)),M=K}if(M.visible=T.visible,M.wireframe=T.wireframe,b===Un?M.side=T.shadowSide!==null?T.shadowSide:T.side:M.side=T.shadowSide!==null?T.shadowSide:u[T.side],M.alphaMap=T.alphaMap,M.alphaTest=T.alphaTest,M.map=T.map,M.clipShadows=T.clipShadows,M.clippingPlanes=T.clippingPlanes,M.clipIntersection=T.clipIntersection,M.displacementMap=T.displacementMap,M.displacementScale=T.displacementScale,M.displacementBias=T.displacementBias,M.wireframeLinewidth=T.wireframeLinewidth,M.linewidth=T.linewidth,N.isPointLight===!0&&M.isMeshDistanceMaterial===!0){let W=i.properties.get(M);W.light=N}return M}function y(E,T,N,b,M){if(E.visible===!1)return;if(E.layers.test(T.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&M===Un)&&(!E.frustumCulled||n.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(N.matrixWorldInverse,E.matrixWorld);let k=e.update(E),V=E.material;if(Array.isArray(V)){let K=k.groups;for(let G=0,$=K.length;G<$;G++){let z=K[G],ne=V[z.materialIndex];if(ne&&ne.visible){let ue=S(E,ne,b,M);E.onBeforeShadow(i,E,T,N,k,ue,z),i.renderBufferDirect(N,null,k,ue,E,z),E.onAfterShadow(i,E,T,N,k,ue,z)}}}else if(V.visible){let K=S(E,V,b,M);E.onBeforeShadow(i,E,T,N,k,K,null),i.renderBufferDirect(N,null,k,K,E,null),E.onAfterShadow(i,E,T,N,k,K,null)}}let W=E.children;for(let k=0,V=W.length;k<V;k++)y(W[k],T,N,b,M)}function U(E){E.target.removeEventListener("dispose",U);for(let N in c){let b=c[N],M=E.target.uuid;M in b&&(b[M].dispose(),delete b[M])}}}var T0={[xa]:ya,[Ma]:wa,[Sa]:Aa,[os]:ba,[ya]:xa,[wa]:Ma,[Aa]:Sa,[ba]:os};function E0(i,e){function t(){let C=!1,ie=new Ye,H=null,Z=new Ye(0,0,0,0);return{setMask:function(he){H!==he&&!C&&(i.colorMask(he,he,he,he),H=he)},setLocked:function(he){C=he},setClear:function(he,ae,Ie,ut,wt){wt===!0&&(he*=ut,ae*=ut,Ie*=ut),ie.set(he,ae,Ie,ut),Z.equals(ie)===!1&&(i.clearColor(he,ae,Ie,ut),Z.copy(ie))},reset:function(){C=!1,H=null,Z.set(-1,0,0,0)}}}function n(){let C=!1,ie=!1,H=null,Z=null,he=null;return{setReversed:function(ae){if(ie!==ae){let Ie=e.get("EXT_clip_control");ie?Ie.clipControlEXT(Ie.LOWER_LEFT_EXT,Ie.ZERO_TO_ONE_EXT):Ie.clipControlEXT(Ie.LOWER_LEFT_EXT,Ie.NEGATIVE_ONE_TO_ONE_EXT);let ut=he;he=null,this.setClear(ut)}ie=ae},getReversed:function(){return ie},setTest:function(ae){ae?re(i.DEPTH_TEST):Te(i.DEPTH_TEST)},setMask:function(ae){H!==ae&&!C&&(i.depthMask(ae),H=ae)},setFunc:function(ae){if(ie&&(ae=T0[ae]),Z!==ae){switch(ae){case xa:i.depthFunc(i.NEVER);break;case ya:i.depthFunc(i.ALWAYS);break;case Ma:i.depthFunc(i.LESS);break;case os:i.depthFunc(i.LEQUAL);break;case Sa:i.depthFunc(i.EQUAL);break;case ba:i.depthFunc(i.GEQUAL);break;case wa:i.depthFunc(i.GREATER);break;case Aa:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Z=ae}},setLocked:function(ae){C=ae},setClear:function(ae){he!==ae&&(ie&&(ae=1-ae),i.clearDepth(ae),he=ae)},reset:function(){C=!1,H=null,Z=null,he=null,ie=!1}}}function s(){let C=!1,ie=null,H=null,Z=null,he=null,ae=null,Ie=null,ut=null,wt=null;return{setTest:function($e){C||($e?re(i.STENCIL_TEST):Te(i.STENCIL_TEST))},setMask:function($e){ie!==$e&&!C&&(i.stencilMask($e),ie=$e)},setFunc:function($e,en,bn){(H!==$e||Z!==en||he!==bn)&&(i.stencilFunc($e,en,bn),H=$e,Z=en,he=bn)},setOp:function($e,en,bn){(ae!==$e||Ie!==en||ut!==bn)&&(i.stencilOp($e,en,bn),ae=$e,Ie=en,ut=bn)},setLocked:function($e){C=$e},setClear:function($e){wt!==$e&&(i.clearStencil($e),wt=$e)},reset:function(){C=!1,ie=null,H=null,Z=null,he=null,ae=null,Ie=null,ut=null,wt=null}}}let r=new t,o=new n,a=new s,l=new WeakMap,c=new WeakMap,h={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,w=null,S=null,y=null,U=null,E=null,T=new we(0,0,0),N=0,b=!1,M=null,R=null,W=null,k=null,V=null,K=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),G=!1,$=0,z=i.getParameter(i.VERSION);z.indexOf("WebGL")!==-1?($=parseFloat(/^WebGL (\d)/.exec(z)[1]),G=$>=1):z.indexOf("OpenGL ES")!==-1&&($=parseFloat(/^OpenGL ES (\d)/.exec(z)[1]),G=$>=2);let ne=null,ue={},xe=i.getParameter(i.SCISSOR_BOX),Fe=i.getParameter(i.VIEWPORT),tt=new Ye().fromArray(xe),q=new Ye().fromArray(Fe);function ee(C,ie,H,Z){let he=new Uint8Array(4),ae=i.createTexture();i.bindTexture(C,ae),i.texParameteri(C,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(C,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ie=0;Ie<H;Ie++)C===i.TEXTURE_3D||C===i.TEXTURE_2D_ARRAY?i.texImage3D(ie,0,i.RGBA,1,1,Z,0,i.RGBA,i.UNSIGNED_BYTE,he):i.texImage2D(ie+Ie,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,he);return ae}let ve={};ve[i.TEXTURE_2D]=ee(i.TEXTURE_2D,i.TEXTURE_2D,1),ve[i.TEXTURE_CUBE_MAP]=ee(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),ve[i.TEXTURE_2D_ARRAY]=ee(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),ve[i.TEXTURE_3D]=ee(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),re(i.DEPTH_TEST),o.setFunc(os),He(!1),Ve(ih),re(i.CULL_FACE),D(oi);function re(C){h[C]!==!0&&(i.enable(C),h[C]=!0)}function Te(C){h[C]!==!1&&(i.disable(C),h[C]=!1)}function Ce(C,ie){return u[C]!==ie?(i.bindFramebuffer(C,ie),u[C]=ie,C===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=ie),C===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=ie),!0):!1}function Oe(C,ie){let H=f,Z=!1;if(C){H=d.get(ie),H===void 0&&(H=[],d.set(ie,H));let he=C.textures;if(H.length!==he.length||H[0]!==i.COLOR_ATTACHMENT0){for(let ae=0,Ie=he.length;ae<Ie;ae++)H[ae]=i.COLOR_ATTACHMENT0+ae;H.length=he.length,Z=!0}}else H[0]!==i.BACK&&(H[0]=i.BACK,Z=!0);Z&&i.drawBuffers(H)}function ct(C){return g!==C?(i.useProgram(C),g=C,!0):!1}let We={[Ei]:i.FUNC_ADD,[kd]:i.FUNC_SUBTRACT,[zd]:i.FUNC_REVERSE_SUBTRACT};We[Hd]=i.MIN,We[Vd]=i.MAX;let dt={[Gd]:i.ZERO,[Wd]:i.ONE,[Xd]:i.SRC_COLOR,[_a]:i.SRC_ALPHA,[$d]:i.SRC_ALPHA_SATURATE,[Jd]:i.DST_COLOR,[Yd]:i.DST_ALPHA,[qd]:i.ONE_MINUS_SRC_COLOR,[va]:i.ONE_MINUS_SRC_ALPHA,[Kd]:i.ONE_MINUS_DST_COLOR,[Zd]:i.ONE_MINUS_DST_ALPHA,[jd]:i.CONSTANT_COLOR,[Qd]:i.ONE_MINUS_CONSTANT_COLOR,[ef]:i.CONSTANT_ALPHA,[tf]:i.ONE_MINUS_CONSTANT_ALPHA};function D(C,ie,H,Z,he,ae,Ie,ut,wt,$e){if(C===oi){_===!0&&(Te(i.BLEND),_=!1);return}if(_===!1&&(re(i.BLEND),_=!0),C!==Bd){if(C!==m||$e!==b){if((p!==Ei||y!==Ei)&&(i.blendEquation(i.FUNC_ADD),p=Ei,y=Ei),$e)switch(C){case ns:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case sh:i.blendFunc(i.ONE,i.ONE);break;case rh:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case oh:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",C);break}else switch(C){case ns:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case sh:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case rh:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case oh:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",C);break}w=null,S=null,U=null,E=null,T.set(0,0,0),N=0,m=C,b=$e}return}he=he||ie,ae=ae||H,Ie=Ie||Z,(ie!==p||he!==y)&&(i.blendEquationSeparate(We[ie],We[he]),p=ie,y=he),(H!==w||Z!==S||ae!==U||Ie!==E)&&(i.blendFuncSeparate(dt[H],dt[Z],dt[ae],dt[Ie]),w=H,S=Z,U=ae,E=Ie),(ut.equals(T)===!1||wt!==N)&&(i.blendColor(ut.r,ut.g,ut.b,wt),T.copy(ut),N=wt),m=C,b=!1}function Xt(C,ie){C.side===ln?Te(i.CULL_FACE):re(i.CULL_FACE);let H=C.side===Ot;ie&&(H=!H),He(H),C.blending===ns&&C.transparent===!1?D(oi):D(C.blending,C.blendEquation,C.blendSrc,C.blendDst,C.blendEquationAlpha,C.blendSrcAlpha,C.blendDstAlpha,C.blendColor,C.blendAlpha,C.premultipliedAlpha),o.setFunc(C.depthFunc),o.setTest(C.depthTest),o.setMask(C.depthWrite),r.setMask(C.colorWrite);let Z=C.stencilWrite;a.setTest(Z),Z&&(a.setMask(C.stencilWriteMask),a.setFunc(C.stencilFunc,C.stencilRef,C.stencilFuncMask),a.setOp(C.stencilFail,C.stencilZFail,C.stencilZPass)),rt(C.polygonOffset,C.polygonOffsetFactor,C.polygonOffsetUnits),C.alphaToCoverage===!0?re(i.SAMPLE_ALPHA_TO_COVERAGE):Te(i.SAMPLE_ALPHA_TO_COVERAGE)}function He(C){M!==C&&(C?i.frontFace(i.CW):i.frontFace(i.CCW),M=C)}function Ve(C){C!==Ud?(re(i.CULL_FACE),C!==R&&(C===ih?i.cullFace(i.BACK):C===Fd?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Te(i.CULL_FACE),R=C}function be(C){C!==W&&(G&&i.lineWidth(C),W=C)}function rt(C,ie,H){C?(re(i.POLYGON_OFFSET_FILL),(k!==ie||V!==H)&&(i.polygonOffset(ie,H),k=ie,V=H)):Te(i.POLYGON_OFFSET_FILL)}function Se(C){C?re(i.SCISSOR_TEST):Te(i.SCISSOR_TEST)}function A(C){C===void 0&&(C=i.TEXTURE0+K-1),ne!==C&&(i.activeTexture(C),ne=C)}function v(C,ie,H){H===void 0&&(ne===null?H=i.TEXTURE0+K-1:H=ne);let Z=ue[H];Z===void 0&&(Z={type:void 0,texture:void 0},ue[H]=Z),(Z.type!==C||Z.texture!==ie)&&(ne!==H&&(i.activeTexture(H),ne=H),i.bindTexture(C,ie||ve[C]),Z.type=C,Z.texture=ie)}function F(){let C=ue[ne];C!==void 0&&C.type!==void 0&&(i.bindTexture(C.type,null),C.type=void 0,C.texture=void 0)}function Y(){try{i.compressedTexImage2D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function J(){try{i.compressedTexImage3D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function X(){try{i.texSubImage2D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function ye(){try{i.texSubImage3D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function oe(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function de(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function Xe(){try{i.texStorage2D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function j(){try{i.texStorage3D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function fe(){try{i.texImage2D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function Ae(){try{i.texImage3D.apply(i,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function Ee(C){tt.equals(C)===!1&&(i.scissor(C.x,C.y,C.z,C.w),tt.copy(C))}function pe(C){q.equals(C)===!1&&(i.viewport(C.x,C.y,C.z,C.w),q.copy(C))}function Ge(C,ie){let H=c.get(ie);H===void 0&&(H=new WeakMap,c.set(ie,H));let Z=H.get(C);Z===void 0&&(Z=i.getUniformBlockIndex(ie,C.name),H.set(C,Z))}function Ne(C,ie){let Z=c.get(ie).get(C);l.get(ie)!==Z&&(i.uniformBlockBinding(ie,Z,C.__bindingPointIndex),l.set(ie,Z))}function nt(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},ne=null,ue={},u={},d=new WeakMap,f=[],g=null,_=!1,m=null,p=null,w=null,S=null,y=null,U=null,E=null,T=new we(0,0,0),N=0,b=!1,M=null,R=null,W=null,k=null,V=null,tt.set(0,0,i.canvas.width,i.canvas.height),q.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:re,disable:Te,bindFramebuffer:Ce,drawBuffers:Oe,useProgram:ct,setBlending:D,setMaterial:Xt,setFlipSided:He,setCullFace:Ve,setLineWidth:be,setPolygonOffset:rt,setScissorTest:Se,activeTexture:A,bindTexture:v,unbindTexture:F,compressedTexImage2D:Y,compressedTexImage3D:J,texImage2D:fe,texImage3D:Ae,updateUBOMapping:Ge,uniformBlockBinding:Ne,texStorage2D:Xe,texStorage3D:j,texSubImage2D:X,texSubImage3D:ye,compressedTexSubImage2D:oe,compressedTexSubImage3D:de,scissor:Ee,viewport:pe,reset:nt}}function iu(i,e,t,n){let s=R0(n);switch(t){case Ru:return i*e;case Iu:return i*e;case Pu:return i*e*2;case Dl:return i*e/s.components*s.byteLength;case Nl:return i*e/s.components*s.byteLength;case Lu:return i*e*2/s.components*s.byteLength;case Ul:return i*e*2/s.components*s.byteLength;case Cu:return i*e*3/s.components*s.byteLength;case Jt:return i*e*4/s.components*s.byteLength;case Fl:return i*e*4/s.components*s.byteLength;case Vr:case Gr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Wr:case Xr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Ca:case Pa:return Math.max(i,16)*Math.max(e,8)/4;case Ra:case Ia:return Math.max(i,8)*Math.max(e,8)/2;case La:case Da:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Na:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Ua:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Fa:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Oa:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Ba:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case ka:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case za:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Ha:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Va:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Ga:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Wa:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Xa:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case qa:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Ya:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Za:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case qr:case Ja:case Ka:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Du:case $a:return Math.ceil(i/4)*Math.ceil(e/4)*8;case ja:case Qa:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function R0(i){switch(i){case zn:case Au:return{byteLength:1,components:1};case Ws:case Tu:case tr:return{byteLength:2,components:1};case Pl:case Ll:return{byteLength:2,components:4};case Pi:case Il:case hn:return{byteLength:4,components:1};case Eu:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function C0(i,e,t,n,s,r,o){let a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new ze,h=new WeakMap,u,d=new WeakMap,f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(A,v){return f?new OffscreenCanvas(A,v):Xs("canvas")}function _(A,v,F){let Y=1,J=Se(A);if((J.width>F||J.height>F)&&(Y=F/Math.max(J.width,J.height)),Y<1)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap||typeof VideoFrame<"u"&&A instanceof VideoFrame){let X=Math.floor(Y*J.width),ye=Math.floor(Y*J.height);u===void 0&&(u=g(X,ye));let oe=v?g(X,ye):u;return oe.width=X,oe.height=ye,oe.getContext("2d").drawImage(A,0,0,X,ye),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+J.width+"x"+J.height+") to ("+X+"x"+ye+")."),oe}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+J.width+"x"+J.height+")."),A;return A}function m(A){return A.generateMipmaps}function p(A){i.generateMipmap(A)}function w(A){return A.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?i.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function S(A,v,F,Y,J=!1){if(A!==null){if(i[A]!==void 0)return i[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let X=v;if(v===i.RED&&(F===i.FLOAT&&(X=i.R32F),F===i.HALF_FLOAT&&(X=i.R16F),F===i.UNSIGNED_BYTE&&(X=i.R8)),v===i.RED_INTEGER&&(F===i.UNSIGNED_BYTE&&(X=i.R8UI),F===i.UNSIGNED_SHORT&&(X=i.R16UI),F===i.UNSIGNED_INT&&(X=i.R32UI),F===i.BYTE&&(X=i.R8I),F===i.SHORT&&(X=i.R16I),F===i.INT&&(X=i.R32I)),v===i.RG&&(F===i.FLOAT&&(X=i.RG32F),F===i.HALF_FLOAT&&(X=i.RG16F),F===i.UNSIGNED_BYTE&&(X=i.RG8)),v===i.RG_INTEGER&&(F===i.UNSIGNED_BYTE&&(X=i.RG8UI),F===i.UNSIGNED_SHORT&&(X=i.RG16UI),F===i.UNSIGNED_INT&&(X=i.RG32UI),F===i.BYTE&&(X=i.RG8I),F===i.SHORT&&(X=i.RG16I),F===i.INT&&(X=i.RG32I)),v===i.RGB_INTEGER&&(F===i.UNSIGNED_BYTE&&(X=i.RGB8UI),F===i.UNSIGNED_SHORT&&(X=i.RGB16UI),F===i.UNSIGNED_INT&&(X=i.RGB32UI),F===i.BYTE&&(X=i.RGB8I),F===i.SHORT&&(X=i.RGB16I),F===i.INT&&(X=i.RGB32I)),v===i.RGBA_INTEGER&&(F===i.UNSIGNED_BYTE&&(X=i.RGBA8UI),F===i.UNSIGNED_SHORT&&(X=i.RGBA16UI),F===i.UNSIGNED_INT&&(X=i.RGBA32UI),F===i.BYTE&&(X=i.RGBA8I),F===i.SHORT&&(X=i.RGBA16I),F===i.INT&&(X=i.RGBA32I)),v===i.RGB&&F===i.UNSIGNED_INT_5_9_9_9_REV&&(X=i.RGB9_E5),v===i.RGBA){let ye=J?Ao:ke.getTransfer(Y);F===i.FLOAT&&(X=i.RGBA32F),F===i.HALF_FLOAT&&(X=i.RGBA16F),F===i.UNSIGNED_BYTE&&(X=ye===et?i.SRGB8_ALPHA8:i.RGBA8),F===i.UNSIGNED_SHORT_4_4_4_4&&(X=i.RGBA4),F===i.UNSIGNED_SHORT_5_5_5_1&&(X=i.RGB5_A1)}return(X===i.R16F||X===i.R32F||X===i.RG16F||X===i.RG32F||X===i.RGBA16F||X===i.RGBA32F)&&e.get("EXT_color_buffer_float"),X}function y(A,v){let F;return A?v===null||v===Pi||v===cs?F=i.DEPTH24_STENCIL8:v===hn?F=i.DEPTH32F_STENCIL8:v===Ws&&(F=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):v===null||v===Pi||v===cs?F=i.DEPTH_COMPONENT24:v===hn?F=i.DEPTH_COMPONENT32F:v===Ws&&(F=i.DEPTH_COMPONENT16),F}function U(A,v){return m(A)===!0||A.isFramebufferTexture&&A.minFilter!==It&&A.minFilter!==Ft?Math.log2(Math.max(v.width,v.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?v.mipmaps.length:1}function E(A){let v=A.target;v.removeEventListener("dispose",E),N(v),v.isVideoTexture&&h.delete(v)}function T(A){let v=A.target;v.removeEventListener("dispose",T),M(v)}function N(A){let v=n.get(A);if(v.__webglInit===void 0)return;let F=A.source,Y=d.get(F);if(Y){let J=Y[v.__cacheKey];J.usedTimes--,J.usedTimes===0&&b(A),Object.keys(Y).length===0&&d.delete(F)}n.remove(A)}function b(A){let v=n.get(A);i.deleteTexture(v.__webglTexture);let F=A.source,Y=d.get(F);delete Y[v.__cacheKey],o.memory.textures--}function M(A){let v=n.get(A);if(A.depthTexture&&(A.depthTexture.dispose(),n.remove(A.depthTexture)),A.isWebGLCubeRenderTarget)for(let Y=0;Y<6;Y++){if(Array.isArray(v.__webglFramebuffer[Y]))for(let J=0;J<v.__webglFramebuffer[Y].length;J++)i.deleteFramebuffer(v.__webglFramebuffer[Y][J]);else i.deleteFramebuffer(v.__webglFramebuffer[Y]);v.__webglDepthbuffer&&i.deleteRenderbuffer(v.__webglDepthbuffer[Y])}else{if(Array.isArray(v.__webglFramebuffer))for(let Y=0;Y<v.__webglFramebuffer.length;Y++)i.deleteFramebuffer(v.__webglFramebuffer[Y]);else i.deleteFramebuffer(v.__webglFramebuffer);if(v.__webglDepthbuffer&&i.deleteRenderbuffer(v.__webglDepthbuffer),v.__webglMultisampledFramebuffer&&i.deleteFramebuffer(v.__webglMultisampledFramebuffer),v.__webglColorRenderbuffer)for(let Y=0;Y<v.__webglColorRenderbuffer.length;Y++)v.__webglColorRenderbuffer[Y]&&i.deleteRenderbuffer(v.__webglColorRenderbuffer[Y]);v.__webglDepthRenderbuffer&&i.deleteRenderbuffer(v.__webglDepthRenderbuffer)}let F=A.textures;for(let Y=0,J=F.length;Y<J;Y++){let X=n.get(F[Y]);X.__webglTexture&&(i.deleteTexture(X.__webglTexture),o.memory.textures--),n.remove(F[Y])}n.remove(A)}let R=0;function W(){R=0}function k(){let A=R;return A>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+s.maxTextures),R+=1,A}function V(A){let v=[];return v.push(A.wrapS),v.push(A.wrapT),v.push(A.wrapR||0),v.push(A.magFilter),v.push(A.minFilter),v.push(A.anisotropy),v.push(A.internalFormat),v.push(A.format),v.push(A.type),v.push(A.generateMipmaps),v.push(A.premultiplyAlpha),v.push(A.flipY),v.push(A.unpackAlignment),v.push(A.colorSpace),v.join()}function K(A,v){let F=n.get(A);if(A.isVideoTexture&&be(A),A.isRenderTargetTexture===!1&&A.version>0&&F.__version!==A.version){let Y=A.image;if(Y===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Y.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{q(F,A,v);return}}t.bindTexture(i.TEXTURE_2D,F.__webglTexture,i.TEXTURE0+v)}function G(A,v){let F=n.get(A);if(A.version>0&&F.__version!==A.version){q(F,A,v);return}t.bindTexture(i.TEXTURE_2D_ARRAY,F.__webglTexture,i.TEXTURE0+v)}function $(A,v){let F=n.get(A);if(A.version>0&&F.__version!==A.version){q(F,A,v);return}t.bindTexture(i.TEXTURE_3D,F.__webglTexture,i.TEXTURE0+v)}function z(A,v){let F=n.get(A);if(A.version>0&&F.__version!==A.version){ee(F,A,v);return}t.bindTexture(i.TEXTURE_CUBE_MAP,F.__webglTexture,i.TEXTURE0+v)}let ne={[Ii]:i.REPEAT,[On]:i.CLAMP_TO_EDGE,[Gs]:i.MIRRORED_REPEAT},ue={[It]:i.NEAREST,[Cl]:i.NEAREST_MIPMAP_NEAREST,[es]:i.NEAREST_MIPMAP_LINEAR,[Ft]:i.LINEAR,[ks]:i.LINEAR_MIPMAP_NEAREST,[gn]:i.LINEAR_MIPMAP_LINEAR},xe={[_f]:i.NEVER,[bf]:i.ALWAYS,[vf]:i.LESS,[Fu]:i.LEQUAL,[xf]:i.EQUAL,[Sf]:i.GEQUAL,[yf]:i.GREATER,[Mf]:i.NOTEQUAL};function Fe(A,v){if(v.type===hn&&e.has("OES_texture_float_linear")===!1&&(v.magFilter===Ft||v.magFilter===ks||v.magFilter===es||v.magFilter===gn||v.minFilter===Ft||v.minFilter===ks||v.minFilter===es||v.minFilter===gn)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(A,i.TEXTURE_WRAP_S,ne[v.wrapS]),i.texParameteri(A,i.TEXTURE_WRAP_T,ne[v.wrapT]),(A===i.TEXTURE_3D||A===i.TEXTURE_2D_ARRAY)&&i.texParameteri(A,i.TEXTURE_WRAP_R,ne[v.wrapR]),i.texParameteri(A,i.TEXTURE_MAG_FILTER,ue[v.magFilter]),i.texParameteri(A,i.TEXTURE_MIN_FILTER,ue[v.minFilter]),v.compareFunction&&(i.texParameteri(A,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(A,i.TEXTURE_COMPARE_FUNC,xe[v.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(v.magFilter===It||v.minFilter!==es&&v.minFilter!==gn||v.type===hn&&e.has("OES_texture_float_linear")===!1)return;if(v.anisotropy>1||n.get(v).__currentAnisotropy){let F=e.get("EXT_texture_filter_anisotropic");i.texParameterf(A,F.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(v.anisotropy,s.getMaxAnisotropy())),n.get(v).__currentAnisotropy=v.anisotropy}}}function tt(A,v){let F=!1;A.__webglInit===void 0&&(A.__webglInit=!0,v.addEventListener("dispose",E));let Y=v.source,J=d.get(Y);J===void 0&&(J={},d.set(Y,J));let X=V(v);if(X!==A.__cacheKey){J[X]===void 0&&(J[X]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,F=!0),J[X].usedTimes++;let ye=J[A.__cacheKey];ye!==void 0&&(J[A.__cacheKey].usedTimes--,ye.usedTimes===0&&b(v)),A.__cacheKey=X,A.__webglTexture=J[X].texture}return F}function q(A,v,F){let Y=i.TEXTURE_2D;(v.isDataArrayTexture||v.isCompressedArrayTexture)&&(Y=i.TEXTURE_2D_ARRAY),v.isData3DTexture&&(Y=i.TEXTURE_3D);let J=tt(A,v),X=v.source;t.bindTexture(Y,A.__webglTexture,i.TEXTURE0+F);let ye=n.get(X);if(X.version!==ye.__version||J===!0){t.activeTexture(i.TEXTURE0+F);let oe=ke.getPrimaries(ke.workingColorSpace),de=v.colorSpace===si?null:ke.getPrimaries(v.colorSpace),Xe=v.colorSpace===si||oe===de?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,v.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,v.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,v.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Xe);let j=_(v.image,!1,s.maxTextureSize);j=rt(v,j);let fe=r.convert(v.format,v.colorSpace),Ae=r.convert(v.type),Ee=S(v.internalFormat,fe,Ae,v.colorSpace,v.isVideoTexture);Fe(Y,v);let pe,Ge=v.mipmaps,Ne=v.isVideoTexture!==!0,nt=ye.__version===void 0||J===!0,C=X.dataReady,ie=U(v,j);if(v.isDepthTexture)Ee=y(v.format===hs,v.type),nt&&(Ne?t.texStorage2D(i.TEXTURE_2D,1,Ee,j.width,j.height):t.texImage2D(i.TEXTURE_2D,0,Ee,j.width,j.height,0,fe,Ae,null));else if(v.isDataTexture)if(Ge.length>0){Ne&&nt&&t.texStorage2D(i.TEXTURE_2D,ie,Ee,Ge[0].width,Ge[0].height);for(let H=0,Z=Ge.length;H<Z;H++)pe=Ge[H],Ne?C&&t.texSubImage2D(i.TEXTURE_2D,H,0,0,pe.width,pe.height,fe,Ae,pe.data):t.texImage2D(i.TEXTURE_2D,H,Ee,pe.width,pe.height,0,fe,Ae,pe.data);v.generateMipmaps=!1}else Ne?(nt&&t.texStorage2D(i.TEXTURE_2D,ie,Ee,j.width,j.height),C&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,j.width,j.height,fe,Ae,j.data)):t.texImage2D(i.TEXTURE_2D,0,Ee,j.width,j.height,0,fe,Ae,j.data);else if(v.isCompressedTexture)if(v.isCompressedArrayTexture){Ne&&nt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ie,Ee,Ge[0].width,Ge[0].height,j.depth);for(let H=0,Z=Ge.length;H<Z;H++)if(pe=Ge[H],v.format!==Jt)if(fe!==null)if(Ne){if(C)if(v.layerUpdates.size>0){let he=iu(pe.width,pe.height,v.format,v.type);for(let ae of v.layerUpdates){let Ie=pe.data.subarray(ae*he/pe.data.BYTES_PER_ELEMENT,(ae+1)*he/pe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,H,0,0,ae,pe.width,pe.height,1,fe,Ie)}v.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,H,0,0,0,pe.width,pe.height,j.depth,fe,pe.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,H,Ee,pe.width,pe.height,j.depth,0,pe.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Ne?C&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,H,0,0,0,pe.width,pe.height,j.depth,fe,Ae,pe.data):t.texImage3D(i.TEXTURE_2D_ARRAY,H,Ee,pe.width,pe.height,j.depth,0,fe,Ae,pe.data)}else{Ne&&nt&&t.texStorage2D(i.TEXTURE_2D,ie,Ee,Ge[0].width,Ge[0].height);for(let H=0,Z=Ge.length;H<Z;H++)pe=Ge[H],v.format!==Jt?fe!==null?Ne?C&&t.compressedTexSubImage2D(i.TEXTURE_2D,H,0,0,pe.width,pe.height,fe,pe.data):t.compressedTexImage2D(i.TEXTURE_2D,H,Ee,pe.width,pe.height,0,pe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Ne?C&&t.texSubImage2D(i.TEXTURE_2D,H,0,0,pe.width,pe.height,fe,Ae,pe.data):t.texImage2D(i.TEXTURE_2D,H,Ee,pe.width,pe.height,0,fe,Ae,pe.data)}else if(v.isDataArrayTexture)if(Ne){if(nt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ie,Ee,j.width,j.height,j.depth),C)if(v.layerUpdates.size>0){let H=iu(j.width,j.height,v.format,v.type);for(let Z of v.layerUpdates){let he=j.data.subarray(Z*H/j.data.BYTES_PER_ELEMENT,(Z+1)*H/j.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Z,j.width,j.height,1,fe,Ae,he)}v.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,j.width,j.height,j.depth,fe,Ae,j.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Ee,j.width,j.height,j.depth,0,fe,Ae,j.data);else if(v.isData3DTexture)Ne?(nt&&t.texStorage3D(i.TEXTURE_3D,ie,Ee,j.width,j.height,j.depth),C&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,j.width,j.height,j.depth,fe,Ae,j.data)):t.texImage3D(i.TEXTURE_3D,0,Ee,j.width,j.height,j.depth,0,fe,Ae,j.data);else if(v.isFramebufferTexture){if(nt)if(Ne)t.texStorage2D(i.TEXTURE_2D,ie,Ee,j.width,j.height);else{let H=j.width,Z=j.height;for(let he=0;he<ie;he++)t.texImage2D(i.TEXTURE_2D,he,Ee,H,Z,0,fe,Ae,null),H>>=1,Z>>=1}}else if(Ge.length>0){if(Ne&&nt){let H=Se(Ge[0]);t.texStorage2D(i.TEXTURE_2D,ie,Ee,H.width,H.height)}for(let H=0,Z=Ge.length;H<Z;H++)pe=Ge[H],Ne?C&&t.texSubImage2D(i.TEXTURE_2D,H,0,0,fe,Ae,pe):t.texImage2D(i.TEXTURE_2D,H,Ee,fe,Ae,pe);v.generateMipmaps=!1}else if(Ne){if(nt){let H=Se(j);t.texStorage2D(i.TEXTURE_2D,ie,Ee,H.width,H.height)}C&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,fe,Ae,j)}else t.texImage2D(i.TEXTURE_2D,0,Ee,fe,Ae,j);m(v)&&p(Y),ye.__version=X.version,v.onUpdate&&v.onUpdate(v)}A.__version=v.version}function ee(A,v,F){if(v.image.length!==6)return;let Y=tt(A,v),J=v.source;t.bindTexture(i.TEXTURE_CUBE_MAP,A.__webglTexture,i.TEXTURE0+F);let X=n.get(J);if(J.version!==X.__version||Y===!0){t.activeTexture(i.TEXTURE0+F);let ye=ke.getPrimaries(ke.workingColorSpace),oe=v.colorSpace===si?null:ke.getPrimaries(v.colorSpace),de=v.colorSpace===si||ye===oe?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,v.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,v.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,v.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,de);let Xe=v.isCompressedTexture||v.image[0].isCompressedTexture,j=v.image[0]&&v.image[0].isDataTexture,fe=[];for(let Z=0;Z<6;Z++)!Xe&&!j?fe[Z]=_(v.image[Z],!0,s.maxCubemapSize):fe[Z]=j?v.image[Z].image:v.image[Z],fe[Z]=rt(v,fe[Z]);let Ae=fe[0],Ee=r.convert(v.format,v.colorSpace),pe=r.convert(v.type),Ge=S(v.internalFormat,Ee,pe,v.colorSpace),Ne=v.isVideoTexture!==!0,nt=X.__version===void 0||Y===!0,C=J.dataReady,ie=U(v,Ae);Fe(i.TEXTURE_CUBE_MAP,v);let H;if(Xe){Ne&&nt&&t.texStorage2D(i.TEXTURE_CUBE_MAP,ie,Ge,Ae.width,Ae.height);for(let Z=0;Z<6;Z++){H=fe[Z].mipmaps;for(let he=0;he<H.length;he++){let ae=H[he];v.format!==Jt?Ee!==null?Ne?C&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he,0,0,ae.width,ae.height,Ee,ae.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he,Ge,ae.width,ae.height,0,ae.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ne?C&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he,0,0,ae.width,ae.height,Ee,pe,ae.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he,Ge,ae.width,ae.height,0,Ee,pe,ae.data)}}}else{if(H=v.mipmaps,Ne&&nt){H.length>0&&ie++;let Z=Se(fe[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,ie,Ge,Z.width,Z.height)}for(let Z=0;Z<6;Z++)if(j){Ne?C&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,fe[Z].width,fe[Z].height,Ee,pe,fe[Z].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Ge,fe[Z].width,fe[Z].height,0,Ee,pe,fe[Z].data);for(let he=0;he<H.length;he++){let Ie=H[he].image[Z].image;Ne?C&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he+1,0,0,Ie.width,Ie.height,Ee,pe,Ie.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he+1,Ge,Ie.width,Ie.height,0,Ee,pe,Ie.data)}}else{Ne?C&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,Ee,pe,fe[Z]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Ge,Ee,pe,fe[Z]);for(let he=0;he<H.length;he++){let ae=H[he];Ne?C&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he+1,0,0,Ee,pe,ae.image[Z]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Z,he+1,Ge,Ee,pe,ae.image[Z])}}}m(v)&&p(i.TEXTURE_CUBE_MAP),X.__version=J.version,v.onUpdate&&v.onUpdate(v)}A.__version=v.version}function ve(A,v,F,Y,J,X){let ye=r.convert(F.format,F.colorSpace),oe=r.convert(F.type),de=S(F.internalFormat,ye,oe,F.colorSpace),Xe=n.get(v),j=n.get(F);if(j.__renderTarget=v,!Xe.__hasExternalTextures){let fe=Math.max(1,v.width>>X),Ae=Math.max(1,v.height>>X);J===i.TEXTURE_3D||J===i.TEXTURE_2D_ARRAY?t.texImage3D(J,X,de,fe,Ae,v.depth,0,ye,oe,null):t.texImage2D(J,X,de,fe,Ae,0,ye,oe,null)}t.bindFramebuffer(i.FRAMEBUFFER,A),Ve(v)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,Y,J,j.__webglTexture,0,He(v)):(J===i.TEXTURE_2D||J>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&J<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,Y,J,j.__webglTexture,X),t.bindFramebuffer(i.FRAMEBUFFER,null)}function re(A,v,F){if(i.bindRenderbuffer(i.RENDERBUFFER,A),v.depthBuffer){let Y=v.depthTexture,J=Y&&Y.isDepthTexture?Y.type:null,X=y(v.stencilBuffer,J),ye=v.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,oe=He(v);Ve(v)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,oe,X,v.width,v.height):F?i.renderbufferStorageMultisample(i.RENDERBUFFER,oe,X,v.width,v.height):i.renderbufferStorage(i.RENDERBUFFER,X,v.width,v.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,ye,i.RENDERBUFFER,A)}else{let Y=v.textures;for(let J=0;J<Y.length;J++){let X=Y[J],ye=r.convert(X.format,X.colorSpace),oe=r.convert(X.type),de=S(X.internalFormat,ye,oe,X.colorSpace),Xe=He(v);F&&Ve(v)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Xe,de,v.width,v.height):Ve(v)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Xe,de,v.width,v.height):i.renderbufferStorage(i.RENDERBUFFER,de,v.width,v.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Te(A,v){if(v&&v.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,A),!(v.depthTexture&&v.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let Y=n.get(v.depthTexture);Y.__renderTarget=v,(!Y.__webglTexture||v.depthTexture.image.width!==v.width||v.depthTexture.image.height!==v.height)&&(v.depthTexture.image.width=v.width,v.depthTexture.image.height=v.height,v.depthTexture.needsUpdate=!0),K(v.depthTexture,0);let J=Y.__webglTexture,X=He(v);if(v.depthTexture.format===is)Ve(v)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,J,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,J,0);else if(v.depthTexture.format===hs)Ve(v)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,J,0,X):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,J,0);else throw new Error("Unknown depthTexture format")}function Ce(A){let v=n.get(A),F=A.isWebGLCubeRenderTarget===!0;if(v.__boundDepthTexture!==A.depthTexture){let Y=A.depthTexture;if(v.__depthDisposeCallback&&v.__depthDisposeCallback(),Y){let J=()=>{delete v.__boundDepthTexture,delete v.__depthDisposeCallback,Y.removeEventListener("dispose",J)};Y.addEventListener("dispose",J),v.__depthDisposeCallback=J}v.__boundDepthTexture=Y}if(A.depthTexture&&!v.__autoAllocateDepthBuffer){if(F)throw new Error("target.depthTexture not supported in Cube render targets");Te(v.__webglFramebuffer,A)}else if(F){v.__webglDepthbuffer=[];for(let Y=0;Y<6;Y++)if(t.bindFramebuffer(i.FRAMEBUFFER,v.__webglFramebuffer[Y]),v.__webglDepthbuffer[Y]===void 0)v.__webglDepthbuffer[Y]=i.createRenderbuffer(),re(v.__webglDepthbuffer[Y],A,!1);else{let J=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,X=v.__webglDepthbuffer[Y];i.bindRenderbuffer(i.RENDERBUFFER,X),i.framebufferRenderbuffer(i.FRAMEBUFFER,J,i.RENDERBUFFER,X)}}else if(t.bindFramebuffer(i.FRAMEBUFFER,v.__webglFramebuffer),v.__webglDepthbuffer===void 0)v.__webglDepthbuffer=i.createRenderbuffer(),re(v.__webglDepthbuffer,A,!1);else{let Y=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,J=v.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,J),i.framebufferRenderbuffer(i.FRAMEBUFFER,Y,i.RENDERBUFFER,J)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function Oe(A,v,F){let Y=n.get(A);v!==void 0&&ve(Y.__webglFramebuffer,A,A.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),F!==void 0&&Ce(A)}function ct(A){let v=A.texture,F=n.get(A),Y=n.get(v);A.addEventListener("dispose",T);let J=A.textures,X=A.isWebGLCubeRenderTarget===!0,ye=J.length>1;if(ye||(Y.__webglTexture===void 0&&(Y.__webglTexture=i.createTexture()),Y.__version=v.version,o.memory.textures++),X){F.__webglFramebuffer=[];for(let oe=0;oe<6;oe++)if(v.mipmaps&&v.mipmaps.length>0){F.__webglFramebuffer[oe]=[];for(let de=0;de<v.mipmaps.length;de++)F.__webglFramebuffer[oe][de]=i.createFramebuffer()}else F.__webglFramebuffer[oe]=i.createFramebuffer()}else{if(v.mipmaps&&v.mipmaps.length>0){F.__webglFramebuffer=[];for(let oe=0;oe<v.mipmaps.length;oe++)F.__webglFramebuffer[oe]=i.createFramebuffer()}else F.__webglFramebuffer=i.createFramebuffer();if(ye)for(let oe=0,de=J.length;oe<de;oe++){let Xe=n.get(J[oe]);Xe.__webglTexture===void 0&&(Xe.__webglTexture=i.createTexture(),o.memory.textures++)}if(A.samples>0&&Ve(A)===!1){F.__webglMultisampledFramebuffer=i.createFramebuffer(),F.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,F.__webglMultisampledFramebuffer);for(let oe=0;oe<J.length;oe++){let de=J[oe];F.__webglColorRenderbuffer[oe]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,F.__webglColorRenderbuffer[oe]);let Xe=r.convert(de.format,de.colorSpace),j=r.convert(de.type),fe=S(de.internalFormat,Xe,j,de.colorSpace,A.isXRRenderTarget===!0),Ae=He(A);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ae,fe,A.width,A.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+oe,i.RENDERBUFFER,F.__webglColorRenderbuffer[oe])}i.bindRenderbuffer(i.RENDERBUFFER,null),A.depthBuffer&&(F.__webglDepthRenderbuffer=i.createRenderbuffer(),re(F.__webglDepthRenderbuffer,A,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(X){t.bindTexture(i.TEXTURE_CUBE_MAP,Y.__webglTexture),Fe(i.TEXTURE_CUBE_MAP,v);for(let oe=0;oe<6;oe++)if(v.mipmaps&&v.mipmaps.length>0)for(let de=0;de<v.mipmaps.length;de++)ve(F.__webglFramebuffer[oe][de],A,v,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+oe,de);else ve(F.__webglFramebuffer[oe],A,v,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+oe,0);m(v)&&p(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ye){for(let oe=0,de=J.length;oe<de;oe++){let Xe=J[oe],j=n.get(Xe);t.bindTexture(i.TEXTURE_2D,j.__webglTexture),Fe(i.TEXTURE_2D,Xe),ve(F.__webglFramebuffer,A,Xe,i.COLOR_ATTACHMENT0+oe,i.TEXTURE_2D,0),m(Xe)&&p(i.TEXTURE_2D)}t.unbindTexture()}else{let oe=i.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(oe=A.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(oe,Y.__webglTexture),Fe(oe,v),v.mipmaps&&v.mipmaps.length>0)for(let de=0;de<v.mipmaps.length;de++)ve(F.__webglFramebuffer[de],A,v,i.COLOR_ATTACHMENT0,oe,de);else ve(F.__webglFramebuffer,A,v,i.COLOR_ATTACHMENT0,oe,0);m(v)&&p(oe),t.unbindTexture()}A.depthBuffer&&Ce(A)}function We(A){let v=A.textures;for(let F=0,Y=v.length;F<Y;F++){let J=v[F];if(m(J)){let X=w(A),ye=n.get(J).__webglTexture;t.bindTexture(X,ye),p(X),t.unbindTexture()}}}let dt=[],D=[];function Xt(A){if(A.samples>0){if(Ve(A)===!1){let v=A.textures,F=A.width,Y=A.height,J=i.COLOR_BUFFER_BIT,X=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ye=n.get(A),oe=v.length>1;if(oe)for(let de=0;de<v.length;de++)t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,ye.__webglMultisampledFramebuffer),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglFramebuffer);for(let de=0;de<v.length;de++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(J|=i.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(J|=i.STENCIL_BUFFER_BIT)),oe){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,ye.__webglColorRenderbuffer[de]);let Xe=n.get(v[de]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,Xe,0)}i.blitFramebuffer(0,0,F,Y,0,0,F,Y,J,i.NEAREST),l===!0&&(dt.length=0,D.length=0,dt.push(i.COLOR_ATTACHMENT0+de),A.depthBuffer&&A.resolveDepthBuffer===!1&&(dt.push(X),D.push(X),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,D)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,dt))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),oe)for(let de=0;de<v.length;de++){t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.RENDERBUFFER,ye.__webglColorRenderbuffer[de]);let Xe=n.get(v[de]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+de,i.TEXTURE_2D,Xe,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.resolveDepthBuffer===!1&&l){let v=A.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[v])}}}function He(A){return Math.min(s.maxSamples,A.samples)}function Ve(A){let v=n.get(A);return A.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&v.__useRenderToTexture!==!1}function be(A){let v=o.render.frame;h.get(A)!==v&&(h.set(A,v),A.update())}function rt(A,v){let F=A.colorSpace,Y=A.format,J=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||F!==Pt&&F!==si&&(ke.getTransfer(F)===et?(Y!==Jt||J!==zn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",F)),v}function Se(A){return typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement?(c.width=A.naturalWidth||A.width,c.height=A.naturalHeight||A.height):typeof VideoFrame<"u"&&A instanceof VideoFrame?(c.width=A.displayWidth,c.height=A.displayHeight):(c.width=A.width,c.height=A.height),c}this.allocateTextureUnit=k,this.resetTextureUnits=W,this.setTexture2D=K,this.setTexture2DArray=G,this.setTexture3D=$,this.setTextureCube=z,this.rebindTextures=Oe,this.setupRenderTarget=ct,this.updateRenderTargetMipmap=We,this.updateMultisampleRenderTarget=Xt,this.setupDepthRenderbuffer=Ce,this.setupFrameBufferTexture=ve,this.useMultisampledRTT=Ve}function I0(i,e){function t(n,s=si){let r,o=ke.getTransfer(s);if(n===zn)return i.UNSIGNED_BYTE;if(n===Pl)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Ll)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Eu)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Au)return i.BYTE;if(n===Tu)return i.SHORT;if(n===Ws)return i.UNSIGNED_SHORT;if(n===Il)return i.INT;if(n===Pi)return i.UNSIGNED_INT;if(n===hn)return i.FLOAT;if(n===tr)return i.HALF_FLOAT;if(n===Ru)return i.ALPHA;if(n===Cu)return i.RGB;if(n===Jt)return i.RGBA;if(n===Iu)return i.LUMINANCE;if(n===Pu)return i.LUMINANCE_ALPHA;if(n===is)return i.DEPTH_COMPONENT;if(n===hs)return i.DEPTH_STENCIL;if(n===Dl)return i.RED;if(n===Nl)return i.RED_INTEGER;if(n===Lu)return i.RG;if(n===Ul)return i.RG_INTEGER;if(n===Fl)return i.RGBA_INTEGER;if(n===Vr||n===Gr||n===Wr||n===Xr)if(o===et)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Vr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Gr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Wr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Xr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Vr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Gr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Wr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Xr)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Ra||n===Ca||n===Ia||n===Pa)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Ra)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Ca)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Ia)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Pa)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===La||n===Da||n===Na)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===La||n===Da)return o===et?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Na)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Ua||n===Fa||n===Oa||n===Ba||n===ka||n===za||n===Ha||n===Va||n===Ga||n===Wa||n===Xa||n===qa||n===Ya||n===Za)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Ua)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Fa)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Oa)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Ba)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===ka)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===za)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ha)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Va)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Ga)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Wa)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Xa)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===qa)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Ya)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Za)return o===et?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===qr||n===Ja||n===Ka)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===qr)return o===et?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Ja)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Ka)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Du||n===$a||n===ja||n===Qa)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===qr)return r.COMPRESSED_RED_RGTC1_EXT;if(n===$a)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===ja)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Qa)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===cs?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}var pl=class extends Mt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},_n=class extends ht{constructor(){super(),this.isGroup=!0,this.type="Group"}},P0={type:"move"},Vs=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new _n,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new _n,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new P,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new P),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new _n,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new P,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new P),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(let _ of e.hand.values()){let m=t.getJointPose(_,n),p=this._getHandJoint(c,_);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(P0)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new _n;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},L0=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,D0=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,ml=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,n){if(this.texture===null){let s=new St,r=e.properties.get(s);r.__webglTexture=t.texture,(t.depthNear!=n.depthNear||t.depthFar!=n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=s}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new Mn({vertexShader:L0,fragmentShader:D0,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Ct(new to(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},gl=class extends li{constructor(e,t){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null,_=new ml,m=t.getContextAttributes(),p=null,w=null,S=[],y=[],U=new ze,E=null,T=new Mt;T.viewport=new Ye;let N=new Mt;N.viewport=new Ye;let b=[T,N],M=new pl,R=null,W=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(q){let ee=S[q];return ee===void 0&&(ee=new Vs,S[q]=ee),ee.getTargetRaySpace()},this.getControllerGrip=function(q){let ee=S[q];return ee===void 0&&(ee=new Vs,S[q]=ee),ee.getGripSpace()},this.getHand=function(q){let ee=S[q];return ee===void 0&&(ee=new Vs,S[q]=ee),ee.getHandSpace()};function k(q){let ee=y.indexOf(q.inputSource);if(ee===-1)return;let ve=S[ee];ve!==void 0&&(ve.update(q.inputSource,q.frame,c||o),ve.dispatchEvent({type:q.type,data:q.inputSource}))}function V(){s.removeEventListener("select",k),s.removeEventListener("selectstart",k),s.removeEventListener("selectend",k),s.removeEventListener("squeeze",k),s.removeEventListener("squeezestart",k),s.removeEventListener("squeezeend",k),s.removeEventListener("end",V),s.removeEventListener("inputsourceschange",K);for(let q=0;q<S.length;q++){let ee=y[q];ee!==null&&(y[q]=null,S[q].disconnect(ee))}R=null,W=null,_.reset(),e.setRenderTarget(p),f=null,d=null,u=null,s=null,w=null,tt.stop(),n.isPresenting=!1,e.setPixelRatio(E),e.setSize(U.width,U.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(q){r=q,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(q){a=q,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(q){c=q},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(q){if(s=q,s!==null){if(p=e.getRenderTarget(),s.addEventListener("select",k),s.addEventListener("selectstart",k),s.addEventListener("selectend",k),s.addEventListener("squeeze",k),s.addEventListener("squeezestart",k),s.addEventListener("squeezeend",k),s.addEventListener("end",V),s.addEventListener("inputsourceschange",K),m.xrCompatible!==!0&&await t.makeXRCompatible(),E=e.getPixelRatio(),e.getSize(U),s.renderState.layers===void 0){let ee={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,ee),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),w=new Hn(f.framebufferWidth,f.framebufferHeight,{format:Jt,type:zn,colorSpace:e.outputColorSpace,stencilBuffer:m.stencil})}else{let ee=null,ve=null,re=null;m.depth&&(re=m.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ee=m.stencil?hs:is,ve=m.stencil?cs:Pi);let Te={colorFormat:t.RGBA8,depthFormat:re,scaleFactor:r};u=new XRWebGLBinding(s,t),d=u.createProjectionLayer(Te),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),w=new Hn(d.textureWidth,d.textureHeight,{format:Jt,type:zn,depthTexture:new io(d.textureWidth,d.textureHeight,ve,void 0,void 0,void 0,void 0,void 0,void 0,ee),stencilBuffer:m.stencil,colorSpace:e.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1})}w.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),tt.setContext(s),tt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function K(q){for(let ee=0;ee<q.removed.length;ee++){let ve=q.removed[ee],re=y.indexOf(ve);re>=0&&(y[re]=null,S[re].disconnect(ve))}for(let ee=0;ee<q.added.length;ee++){let ve=q.added[ee],re=y.indexOf(ve);if(re===-1){for(let Ce=0;Ce<S.length;Ce++)if(Ce>=y.length){y.push(ve),re=Ce;break}else if(y[Ce]===null){y[Ce]=ve,re=Ce;break}if(re===-1)break}let Te=S[re];Te&&Te.connect(ve)}}let G=new P,$=new P;function z(q,ee,ve){G.setFromMatrixPosition(ee.matrixWorld),$.setFromMatrixPosition(ve.matrixWorld);let re=G.distanceTo($),Te=ee.projectionMatrix.elements,Ce=ve.projectionMatrix.elements,Oe=Te[14]/(Te[10]-1),ct=Te[14]/(Te[10]+1),We=(Te[9]+1)/Te[5],dt=(Te[9]-1)/Te[5],D=(Te[8]-1)/Te[0],Xt=(Ce[8]+1)/Ce[0],He=Oe*D,Ve=Oe*Xt,be=re/(-D+Xt),rt=be*-D;if(ee.matrixWorld.decompose(q.position,q.quaternion,q.scale),q.translateX(rt),q.translateZ(be),q.matrixWorld.compose(q.position,q.quaternion,q.scale),q.matrixWorldInverse.copy(q.matrixWorld).invert(),Te[10]===-1)q.projectionMatrix.copy(ee.projectionMatrix),q.projectionMatrixInverse.copy(ee.projectionMatrixInverse);else{let Se=Oe+be,A=ct+be,v=He-rt,F=Ve+(re-rt),Y=We*ct/A*Se,J=dt*ct/A*Se;q.projectionMatrix.makePerspective(v,F,Y,J,Se,A),q.projectionMatrixInverse.copy(q.projectionMatrix).invert()}}function ne(q,ee){ee===null?q.matrixWorld.copy(q.matrix):q.matrixWorld.multiplyMatrices(ee.matrixWorld,q.matrix),q.matrixWorldInverse.copy(q.matrixWorld).invert()}this.updateCamera=function(q){if(s===null)return;let ee=q.near,ve=q.far;_.texture!==null&&(_.depthNear>0&&(ee=_.depthNear),_.depthFar>0&&(ve=_.depthFar)),M.near=N.near=T.near=ee,M.far=N.far=T.far=ve,(R!==M.near||W!==M.far)&&(s.updateRenderState({depthNear:M.near,depthFar:M.far}),R=M.near,W=M.far),T.layers.mask=q.layers.mask|2,N.layers.mask=q.layers.mask|4,M.layers.mask=T.layers.mask|N.layers.mask;let re=q.parent,Te=M.cameras;ne(M,re);for(let Ce=0;Ce<Te.length;Ce++)ne(Te[Ce],re);Te.length===2?z(M,T,N):M.projectionMatrix.copy(T.projectionMatrix),ue(q,M,re)};function ue(q,ee,ve){ve===null?q.matrix.copy(ee.matrixWorld):(q.matrix.copy(ve.matrixWorld),q.matrix.invert(),q.matrix.multiply(ee.matrixWorld)),q.matrix.decompose(q.position,q.quaternion,q.scale),q.updateMatrixWorld(!0),q.projectionMatrix.copy(ee.projectionMatrix),q.projectionMatrixInverse.copy(ee.projectionMatrixInverse),q.isPerspectiveCamera&&(q.fov=fs*2*Math.atan(1/q.projectionMatrix.elements[5]),q.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(q){l=q,d!==null&&(d.fixedFoveation=q),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=q)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(M)};let xe=null;function Fe(q,ee){if(h=ee.getViewerPose(c||o),g=ee,h!==null){let ve=h.views;f!==null&&(e.setRenderTargetFramebuffer(w,f.framebuffer),e.setRenderTarget(w));let re=!1;ve.length!==M.cameras.length&&(M.cameras.length=0,re=!0);for(let Ce=0;Ce<ve.length;Ce++){let Oe=ve[Ce],ct=null;if(f!==null)ct=f.getViewport(Oe);else{let dt=u.getViewSubImage(d,Oe);ct=dt.viewport,Ce===0&&(e.setRenderTargetTextures(w,dt.colorTexture,d.ignoreDepthValues?void 0:dt.depthStencilTexture),e.setRenderTarget(w))}let We=b[Ce];We===void 0&&(We=new Mt,We.layers.enable(Ce),We.viewport=new Ye,b[Ce]=We),We.matrix.fromArray(Oe.transform.matrix),We.matrix.decompose(We.position,We.quaternion,We.scale),We.projectionMatrix.fromArray(Oe.projectionMatrix),We.projectionMatrixInverse.copy(We.projectionMatrix).invert(),We.viewport.set(ct.x,ct.y,ct.width,ct.height),Ce===0&&(M.matrix.copy(We.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),re===!0&&M.cameras.push(We)}let Te=s.enabledFeatures;if(Te&&Te.includes("depth-sensing")){let Ce=u.getDepthInformation(ve[0]);Ce&&Ce.isValid&&Ce.texture&&_.init(e,Ce,s.renderState)}}for(let ve=0;ve<S.length;ve++){let re=y[ve],Te=S[ve];re!==null&&Te!==void 0&&Te.update(re,ee,c||o)}xe&&xe(q,ee),ee.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ee}),g=null}let tt=new Hu;tt.setAnimationLoop(Fe),this.setAnimationLoop=function(q){xe=q},this.dispose=function(){}}},Ai=new xn,N0=new De;function U0(i,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,zu(i)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function s(m,p,w,S,y){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(m,p):p.isMeshToonMaterial?(r(m,p),u(m,p)):p.isMeshPhongMaterial?(r(m,p),h(m,p)):p.isMeshStandardMaterial?(r(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,y)):p.isMeshMatcapMaterial?(r(m,p),g(m,p)):p.isMeshDepthMaterial?r(m,p):p.isMeshDistanceMaterial?(r(m,p),_(m,p)):p.isMeshNormalMaterial?r(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?l(m,p,w,S):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Ot&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Ot&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);let w=e.get(p),S=w.envMap,y=w.envMapRotation;S&&(m.envMap.value=S,Ai.copy(y),Ai.x*=-1,Ai.y*=-1,Ai.z*=-1,S.isCubeTexture&&S.isRenderTargetTexture===!1&&(Ai.y*=-1,Ai.z*=-1),m.envMapRotation.value.setFromMatrix4(N0.makeRotationFromEuler(Ai)),m.flipEnvMap.value=S.isCubeTexture&&S.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,w,S){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*w,m.scale.value=S*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,w){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Ot&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=w.texture,m.transmissionSamplerSize.value.set(w.width,w.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function _(m,p){let w=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(w.matrixWorld),m.nearDistance.value=w.shadow.camera.near,m.farDistance.value=w.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function F0(i,e,t,n){let s={},r={},o=[],a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(w,S){let y=S.program;n.uniformBlockBinding(w,y)}function c(w,S){let y=s[w.id];y===void 0&&(g(w),y=h(w),s[w.id]=y,w.addEventListener("dispose",m));let U=S.program;n.updateUBOMapping(w,U);let E=e.render.frame;r[w.id]!==E&&(d(w),r[w.id]=E)}function h(w){let S=u();w.__bindingPointIndex=S;let y=i.createBuffer(),U=w.__size,E=w.usage;return i.bindBuffer(i.UNIFORM_BUFFER,y),i.bufferData(i.UNIFORM_BUFFER,U,E),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,S,y),y}function u(){for(let w=0;w<a;w++)if(o.indexOf(w)===-1)return o.push(w),w;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(w){let S=s[w.id],y=w.uniforms,U=w.__cache;i.bindBuffer(i.UNIFORM_BUFFER,S);for(let E=0,T=y.length;E<T;E++){let N=Array.isArray(y[E])?y[E]:[y[E]];for(let b=0,M=N.length;b<M;b++){let R=N[b];if(f(R,E,b,U)===!0){let W=R.__offset,k=Array.isArray(R.value)?R.value:[R.value],V=0;for(let K=0;K<k.length;K++){let G=k[K],$=_(G);typeof G=="number"||typeof G=="boolean"?(R.__data[0]=G,i.bufferSubData(i.UNIFORM_BUFFER,W+V,R.__data)):G.isMatrix3?(R.__data[0]=G.elements[0],R.__data[1]=G.elements[1],R.__data[2]=G.elements[2],R.__data[3]=0,R.__data[4]=G.elements[3],R.__data[5]=G.elements[4],R.__data[6]=G.elements[5],R.__data[7]=0,R.__data[8]=G.elements[6],R.__data[9]=G.elements[7],R.__data[10]=G.elements[8],R.__data[11]=0):(G.toArray(R.__data,V),V+=$.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,W,R.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(w,S,y,U){let E=w.value,T=S+"_"+y;if(U[T]===void 0)return typeof E=="number"||typeof E=="boolean"?U[T]=E:U[T]=E.clone(),!0;{let N=U[T];if(typeof E=="number"||typeof E=="boolean"){if(N!==E)return U[T]=E,!0}else if(N.equals(E)===!1)return N.copy(E),!0}return!1}function g(w){let S=w.uniforms,y=0,U=16;for(let T=0,N=S.length;T<N;T++){let b=Array.isArray(S[T])?S[T]:[S[T]];for(let M=0,R=b.length;M<R;M++){let W=b[M],k=Array.isArray(W.value)?W.value:[W.value];for(let V=0,K=k.length;V<K;V++){let G=k[V],$=_(G),z=y%U,ne=z%$.boundary,ue=z+ne;y+=ne,ue!==0&&U-ue<$.storage&&(y+=U-ue),W.__data=new Float32Array($.storage/Float32Array.BYTES_PER_ELEMENT),W.__offset=y,y+=$.storage}}}let E=y%U;return E>0&&(y+=U-E),w.__size=y,w.__cache={},this}function _(w){let S={boundary:0,storage:0};return typeof w=="number"||typeof w=="boolean"?(S.boundary=4,S.storage=4):w.isVector2?(S.boundary=8,S.storage=8):w.isVector3||w.isColor?(S.boundary=16,S.storage=12):w.isVector4?(S.boundary=16,S.storage=16):w.isMatrix3?(S.boundary=48,S.storage=48):w.isMatrix4?(S.boundary=64,S.storage=64):w.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",w),S}function m(w){let S=w.target;S.removeEventListener("dispose",m);let y=o.indexOf(S.__bindingPointIndex);o.splice(y,1),i.deleteBuffer(s[S.id]),delete s[S.id],delete r[S.id]}function p(){for(let w in s)i.deleteBuffer(s[w]);o=[],s={},r={}}return{bind:l,update:c,dispose:p}}var so=class{constructor(e={}){let{canvas:t=zf(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:d=!1}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;let g=new Uint32Array(4),_=new Int32Array(4),m=null,p=null,w=[],S=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=pt,this.toneMapping=ai,this.toneMappingExposure=1;let y=this,U=!1,E=0,T=0,N=null,b=-1,M=null,R=new Ye,W=new Ye,k=null,V=new we(0),K=0,G=t.width,$=t.height,z=1,ne=null,ue=null,xe=new Ye(0,0,G,$),Fe=new Ye(0,0,G,$),tt=!1,q=new Ys,ee=!1,ve=!1,re=new De,Te=new De,Ce=new P,Oe=new Ye,ct={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},We=!1;function dt(){return N===null?z:1}let D=n;function Xt(x,I){return t.getContext(x,I)}try{let x={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine","three.js r170"),t.addEventListener("webglcontextlost",Z,!1),t.addEventListener("webglcontextrestored",he,!1),t.addEventListener("webglcontextcreationerror",ae,!1),D===null){let I="webgl2";if(D=Xt(I,x),D===null)throw Xt(I)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(x){throw console.error("THREE.WebGLRenderer: "+x.message),x}let He,Ve,be,rt,Se,A,v,F,Y,J,X,ye,oe,de,Xe,j,fe,Ae,Ee,pe,Ge,Ne,nt,C;function ie(){He=new jg(D),He.init(),Ne=new I0(D,He),Ve=new qg(D,He,e,Ne),be=new E0(D,He),Ve.reverseDepthBuffer&&d&&be.buffers.depth.setReversed(!0),rt=new t_(D),Se=new p0,A=new C0(D,He,be,Se,Ve,Ne,rt),v=new Zg(y),F=new $g(y),Y=new lp(D),nt=new Wg(D,Y),J=new Qg(D,Y,rt,nt),X=new i_(D,J,Y,rt),Ee=new n_(D,Ve,A),j=new Yg(Se),ye=new f0(y,v,F,He,Ve,nt,j),oe=new U0(y,Se),de=new g0,Xe=new S0(He),Ae=new Gg(y,v,F,be,X,f,l),fe=new A0(y,X,Ve),C=new F0(D,rt,Ve,be),pe=new Xg(D,He,rt),Ge=new e_(D,He,rt),rt.programs=ye.programs,y.capabilities=Ve,y.extensions=He,y.properties=Se,y.renderLists=de,y.shadowMap=fe,y.state=be,y.info=rt}ie();let H=new gl(y,D);this.xr=H,this.getContext=function(){return D},this.getContextAttributes=function(){return D.getContextAttributes()},this.forceContextLoss=function(){let x=He.get("WEBGL_lose_context");x&&x.loseContext()},this.forceContextRestore=function(){let x=He.get("WEBGL_lose_context");x&&x.restoreContext()},this.getPixelRatio=function(){return z},this.setPixelRatio=function(x){x!==void 0&&(z=x,this.setSize(G,$,!1))},this.getSize=function(x){return x.set(G,$)},this.setSize=function(x,I,O=!0){if(H.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}G=x,$=I,t.width=Math.floor(x*z),t.height=Math.floor(I*z),O===!0&&(t.style.width=x+"px",t.style.height=I+"px"),this.setViewport(0,0,x,I)},this.getDrawingBufferSize=function(x){return x.set(G*z,$*z).floor()},this.setDrawingBufferSize=function(x,I,O){G=x,$=I,z=O,t.width=Math.floor(x*O),t.height=Math.floor(I*O),this.setViewport(0,0,x,I)},this.getCurrentViewport=function(x){return x.copy(R)},this.getViewport=function(x){return x.copy(xe)},this.setViewport=function(x,I,O,B){x.isVector4?xe.set(x.x,x.y,x.z,x.w):xe.set(x,I,O,B),be.viewport(R.copy(xe).multiplyScalar(z).round())},this.getScissor=function(x){return x.copy(Fe)},this.setScissor=function(x,I,O,B){x.isVector4?Fe.set(x.x,x.y,x.z,x.w):Fe.set(x,I,O,B),be.scissor(W.copy(Fe).multiplyScalar(z).round())},this.getScissorTest=function(){return tt},this.setScissorTest=function(x){be.setScissorTest(tt=x)},this.setOpaqueSort=function(x){ne=x},this.setTransparentSort=function(x){ue=x},this.getClearColor=function(x){return x.copy(Ae.getClearColor())},this.setClearColor=function(){Ae.setClearColor.apply(Ae,arguments)},this.getClearAlpha=function(){return Ae.getClearAlpha()},this.setClearAlpha=function(){Ae.setClearAlpha.apply(Ae,arguments)},this.clear=function(x=!0,I=!0,O=!0){let B=0;if(x){let L=!1;if(N!==null){let Q=N.texture.format;L=Q===Fl||Q===Ul||Q===Nl}if(L){let Q=N.texture.type,le=Q===zn||Q===Pi||Q===Ws||Q===cs||Q===Pl||Q===Ll,me=Ae.getClearColor(),ge=Ae.getClearAlpha(),Re=me.r,Pe=me.g,_e=me.b;le?(g[0]=Re,g[1]=Pe,g[2]=_e,g[3]=ge,D.clearBufferuiv(D.COLOR,0,g)):(_[0]=Re,_[1]=Pe,_[2]=_e,_[3]=ge,D.clearBufferiv(D.COLOR,0,_))}else B|=D.COLOR_BUFFER_BIT}I&&(B|=D.DEPTH_BUFFER_BIT),O&&(B|=D.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),D.clear(B)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Z,!1),t.removeEventListener("webglcontextrestored",he,!1),t.removeEventListener("webglcontextcreationerror",ae,!1),de.dispose(),Xe.dispose(),Se.dispose(),v.dispose(),F.dispose(),X.dispose(),nt.dispose(),C.dispose(),ye.dispose(),H.dispose(),H.removeEventListener("sessionstart",Ec),H.removeEventListener("sessionend",Rc),_i.stop()};function Z(x){x.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),U=!0}function he(){console.log("THREE.WebGLRenderer: Context Restored."),U=!1;let x=rt.autoReset,I=fe.enabled,O=fe.autoUpdate,B=fe.needsUpdate,L=fe.type;ie(),rt.autoReset=x,fe.enabled=I,fe.autoUpdate=O,fe.needsUpdate=B,fe.type=L}function ae(x){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",x.statusMessage)}function Ie(x){let I=x.target;I.removeEventListener("dispose",Ie),ut(I)}function ut(x){wt(x),Se.remove(x)}function wt(x){let I=Se.get(x).programs;I!==void 0&&(I.forEach(function(O){ye.releaseProgram(O)}),x.isShaderMaterial&&ye.releaseShaderCache(x))}this.renderBufferDirect=function(x,I,O,B,L,Q){I===null&&(I=ct);let le=L.isMesh&&L.matrixWorld.determinant()<0,me=vd(x,I,O,B,L);be.setMaterial(B,le);let ge=O.index,Re=1;if(B.wireframe===!0){if(ge=J.getWireframeAttribute(O),ge===void 0)return;Re=2}let Pe=O.drawRange,_e=O.attributes.position,qe=Pe.start*Re,it=(Pe.start+Pe.count)*Re;Q!==null&&(qe=Math.max(qe,Q.start*Re),it=Math.min(it,(Q.start+Q.count)*Re)),ge!==null?(qe=Math.max(qe,0),it=Math.min(it,ge.count)):_e!=null&&(qe=Math.max(qe,0),it=Math.min(it,_e.count));let ot=it-qe;if(ot<0||ot===1/0)return;nt.setup(L,B,me,O,ge);let Ut,Je=pe;if(ge!==null&&(Ut=Y.get(ge),Je=Ge,Je.setIndex(Ut)),L.isMesh)B.wireframe===!0?(be.setLineWidth(B.wireframeLinewidth*dt()),Je.setMode(D.LINES)):Je.setMode(D.TRIANGLES);else if(L.isLine){let Me=B.linewidth;Me===void 0&&(Me=1),be.setLineWidth(Me*dt()),L.isLineSegments?Je.setMode(D.LINES):L.isLineLoop?Je.setMode(D.LINE_LOOP):Je.setMode(D.LINE_STRIP)}else L.isPoints?Je.setMode(D.POINTS):L.isSprite&&Je.setMode(D.TRIANGLES);if(L.isBatchedMesh)if(L._multiDrawInstances!==null)Je.renderMultiDrawInstances(L._multiDrawStarts,L._multiDrawCounts,L._multiDrawCount,L._multiDrawInstances);else if(He.get("WEBGL_multi_draw"))Je.renderMultiDraw(L._multiDrawStarts,L._multiDrawCounts,L._multiDrawCount);else{let Me=L._multiDrawStarts,wn=L._multiDrawCounts,Ke=L._multiDrawCount,tn=ge?Y.get(ge).bytesPerElement:1,Ui=Se.get(B).currentProgram.getUniforms();for(let kt=0;kt<Ke;kt++)Ui.setValue(D,"_gl_DrawID",kt),Je.render(Me[kt]/tn,wn[kt])}else if(L.isInstancedMesh)Je.renderInstances(qe,ot,L.count);else if(O.isInstancedBufferGeometry){let Me=O._maxInstanceCount!==void 0?O._maxInstanceCount:1/0,wn=Math.min(O.instanceCount,Me);Je.renderInstances(qe,ot,wn)}else Je.render(qe,ot)};function $e(x,I,O){x.transparent===!0&&x.side===ln&&x.forceSinglePass===!1?(x.side=Ot,x.needsUpdate=!0,lr(x,I,O),x.side=vn,x.needsUpdate=!0,lr(x,I,O),x.side=ln):lr(x,I,O)}this.compile=function(x,I,O=null){O===null&&(O=x),p=Xe.get(O),p.init(I),S.push(p),O.traverseVisible(function(L){L.isLight&&L.layers.test(I.layers)&&(p.pushLight(L),L.castShadow&&p.pushShadow(L))}),x!==O&&x.traverseVisible(function(L){L.isLight&&L.layers.test(I.layers)&&(p.pushLight(L),L.castShadow&&p.pushShadow(L))}),p.setupLights();let B=new Set;return x.traverse(function(L){if(!(L.isMesh||L.isPoints||L.isLine||L.isSprite))return;let Q=L.material;if(Q)if(Array.isArray(Q))for(let le=0;le<Q.length;le++){let me=Q[le];$e(me,O,L),B.add(me)}else $e(Q,O,L),B.add(Q)}),S.pop(),p=null,B},this.compileAsync=function(x,I,O=null){let B=this.compile(x,I,O);return new Promise(L=>{function Q(){if(B.forEach(function(le){Se.get(le).currentProgram.isReady()&&B.delete(le)}),B.size===0){L(x);return}setTimeout(Q,10)}He.get("KHR_parallel_shader_compile")!==null?Q():setTimeout(Q,10)})};let en=null;function bn(x){en&&en(x)}function Ec(){_i.stop()}function Rc(){_i.start()}let _i=new Hu;_i.setAnimationLoop(bn),typeof self<"u"&&_i.setContext(self),this.setAnimationLoop=function(x){en=x,H.setAnimationLoop(x),x===null?_i.stop():_i.start()},H.addEventListener("sessionstart",Ec),H.addEventListener("sessionend",Rc),this.render=function(x,I){if(I!==void 0&&I.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(U===!0)return;if(x.matrixWorldAutoUpdate===!0&&x.updateMatrixWorld(),I.parent===null&&I.matrixWorldAutoUpdate===!0&&I.updateMatrixWorld(),H.enabled===!0&&H.isPresenting===!0&&(H.cameraAutoUpdate===!0&&H.updateCamera(I),I=H.getCamera()),x.isScene===!0&&x.onBeforeRender(y,x,I,N),p=Xe.get(x,S.length),p.init(I),S.push(p),Te.multiplyMatrices(I.projectionMatrix,I.matrixWorldInverse),q.setFromProjectionMatrix(Te),ve=this.localClippingEnabled,ee=j.init(this.clippingPlanes,ve),m=de.get(x,w.length),m.init(),w.push(m),H.enabled===!0&&H.isPresenting===!0){let Q=y.xr.getDepthSensingMesh();Q!==null&&Lo(Q,I,-1/0,y.sortObjects)}Lo(x,I,0,y.sortObjects),m.finish(),y.sortObjects===!0&&m.sort(ne,ue),We=H.enabled===!1||H.isPresenting===!1||H.hasDepthSensing()===!1,We&&Ae.addToRenderList(m,x),this.info.render.frame++,ee===!0&&j.beginShadows();let O=p.state.shadowsArray;fe.render(O,x,I),ee===!0&&j.endShadows(),this.info.autoReset===!0&&this.info.reset();let B=m.opaque,L=m.transmissive;if(p.setupLights(),I.isArrayCamera){let Q=I.cameras;if(L.length>0)for(let le=0,me=Q.length;le<me;le++){let ge=Q[le];Ic(B,L,x,ge)}We&&Ae.render(x);for(let le=0,me=Q.length;le<me;le++){let ge=Q[le];Cc(m,x,ge,ge.viewport)}}else L.length>0&&Ic(B,L,x,I),We&&Ae.render(x),Cc(m,x,I);N!==null&&(A.updateMultisampleRenderTarget(N),A.updateRenderTargetMipmap(N)),x.isScene===!0&&x.onAfterRender(y,x,I),nt.resetDefaultState(),b=-1,M=null,S.pop(),S.length>0?(p=S[S.length-1],ee===!0&&j.setGlobalState(y.clippingPlanes,p.state.camera)):p=null,w.pop(),w.length>0?m=w[w.length-1]:m=null};function Lo(x,I,O,B){if(x.visible===!1)return;if(x.layers.test(I.layers)){if(x.isGroup)O=x.renderOrder;else if(x.isLOD)x.autoUpdate===!0&&x.update(I);else if(x.isLight)p.pushLight(x),x.castShadow&&p.pushShadow(x);else if(x.isSprite){if(!x.frustumCulled||q.intersectsSprite(x)){B&&Oe.setFromMatrixPosition(x.matrixWorld).applyMatrix4(Te);let le=X.update(x),me=x.material;me.visible&&m.push(x,le,me,O,Oe.z,null)}}else if((x.isMesh||x.isLine||x.isPoints)&&(!x.frustumCulled||q.intersectsObject(x))){let le=X.update(x),me=x.material;if(B&&(x.boundingSphere!==void 0?(x.boundingSphere===null&&x.computeBoundingSphere(),Oe.copy(x.boundingSphere.center)):(le.boundingSphere===null&&le.computeBoundingSphere(),Oe.copy(le.boundingSphere.center)),Oe.applyMatrix4(x.matrixWorld).applyMatrix4(Te)),Array.isArray(me)){let ge=le.groups;for(let Re=0,Pe=ge.length;Re<Pe;Re++){let _e=ge[Re],qe=me[_e.materialIndex];qe&&qe.visible&&m.push(x,le,qe,O,Oe.z,_e)}}else me.visible&&m.push(x,le,me,O,Oe.z,null)}}let Q=x.children;for(let le=0,me=Q.length;le<me;le++)Lo(Q[le],I,O,B)}function Cc(x,I,O,B){let L=x.opaque,Q=x.transmissive,le=x.transparent;p.setupLightsView(O),ee===!0&&j.setGlobalState(y.clippingPlanes,O),B&&be.viewport(R.copy(B)),L.length>0&&ar(L,I,O),Q.length>0&&ar(Q,I,O),le.length>0&&ar(le,I,O),be.buffers.depth.setTest(!0),be.buffers.depth.setMask(!0),be.buffers.color.setMask(!0),be.setPolygonOffset(!1)}function Ic(x,I,O,B){if((O.isScene===!0?O.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[B.id]===void 0&&(p.state.transmissionRenderTarget[B.id]=new Hn(1,1,{generateMipmaps:!0,type:He.has("EXT_color_buffer_half_float")||He.has("EXT_color_buffer_float")?tr:zn,minFilter:gn,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:ke.workingColorSpace}));let Q=p.state.transmissionRenderTarget[B.id],le=B.viewport||R;Q.setSize(le.z,le.w);let me=y.getRenderTarget();y.setRenderTarget(Q),y.getClearColor(V),K=y.getClearAlpha(),K<1&&y.setClearColor(16777215,.5),y.clear(),We&&Ae.render(O);let ge=y.toneMapping;y.toneMapping=ai;let Re=B.viewport;if(B.viewport!==void 0&&(B.viewport=void 0),p.setupLightsView(B),ee===!0&&j.setGlobalState(y.clippingPlanes,B),ar(x,O,B),A.updateMultisampleRenderTarget(Q),A.updateRenderTargetMipmap(Q),He.has("WEBGL_multisampled_render_to_texture")===!1){let Pe=!1;for(let _e=0,qe=I.length;_e<qe;_e++){let it=I[_e],ot=it.object,Ut=it.geometry,Je=it.material,Me=it.group;if(Je.side===ln&&ot.layers.test(B.layers)){let wn=Je.side;Je.side=Ot,Je.needsUpdate=!0,Pc(ot,O,B,Ut,Je,Me),Je.side=wn,Je.needsUpdate=!0,Pe=!0}}Pe===!0&&(A.updateMultisampleRenderTarget(Q),A.updateRenderTargetMipmap(Q))}y.setRenderTarget(me),y.setClearColor(V,K),Re!==void 0&&(B.viewport=Re),y.toneMapping=ge}function ar(x,I,O){let B=I.isScene===!0?I.overrideMaterial:null;for(let L=0,Q=x.length;L<Q;L++){let le=x[L],me=le.object,ge=le.geometry,Re=B===null?le.material:B,Pe=le.group;me.layers.test(O.layers)&&Pc(me,I,O,ge,Re,Pe)}}function Pc(x,I,O,B,L,Q){x.onBeforeRender(y,I,O,B,L,Q),x.modelViewMatrix.multiplyMatrices(O.matrixWorldInverse,x.matrixWorld),x.normalMatrix.getNormalMatrix(x.modelViewMatrix),L.onBeforeRender(y,I,O,B,x,Q),L.transparent===!0&&L.side===ln&&L.forceSinglePass===!1?(L.side=Ot,L.needsUpdate=!0,y.renderBufferDirect(O,I,B,L,x,Q),L.side=vn,L.needsUpdate=!0,y.renderBufferDirect(O,I,B,L,x,Q),L.side=ln):y.renderBufferDirect(O,I,B,L,x,Q),x.onAfterRender(y,I,O,B,L,Q)}function lr(x,I,O){I.isScene!==!0&&(I=ct);let B=Se.get(x),L=p.state.lights,Q=p.state.shadowsArray,le=L.state.version,me=ye.getParameters(x,L.state,Q,I,O),ge=ye.getProgramCacheKey(me),Re=B.programs;B.environment=x.isMeshStandardMaterial?I.environment:null,B.fog=I.fog,B.envMap=(x.isMeshStandardMaterial?F:v).get(x.envMap||B.environment),B.envMapRotation=B.environment!==null&&x.envMap===null?I.environmentRotation:x.envMapRotation,Re===void 0&&(x.addEventListener("dispose",Ie),Re=new Map,B.programs=Re);let Pe=Re.get(ge);if(Pe!==void 0){if(B.currentProgram===Pe&&B.lightsStateVersion===le)return Dc(x,me),Pe}else me.uniforms=ye.getUniforms(x),x.onBeforeCompile(me,y),Pe=ye.acquireProgram(me,ge),Re.set(ge,Pe),B.uniforms=me.uniforms;let _e=B.uniforms;return(!x.isShaderMaterial&&!x.isRawShaderMaterial||x.clipping===!0)&&(_e.clippingPlanes=j.uniform),Dc(x,me),B.needsLights=yd(x),B.lightsStateVersion=le,B.needsLights&&(_e.ambientLightColor.value=L.state.ambient,_e.lightProbe.value=L.state.probe,_e.directionalLights.value=L.state.directional,_e.directionalLightShadows.value=L.state.directionalShadow,_e.spotLights.value=L.state.spot,_e.spotLightShadows.value=L.state.spotShadow,_e.rectAreaLights.value=L.state.rectArea,_e.ltc_1.value=L.state.rectAreaLTC1,_e.ltc_2.value=L.state.rectAreaLTC2,_e.pointLights.value=L.state.point,_e.pointLightShadows.value=L.state.pointShadow,_e.hemisphereLights.value=L.state.hemi,_e.directionalShadowMap.value=L.state.directionalShadowMap,_e.directionalShadowMatrix.value=L.state.directionalShadowMatrix,_e.spotShadowMap.value=L.state.spotShadowMap,_e.spotLightMatrix.value=L.state.spotLightMatrix,_e.spotLightMap.value=L.state.spotLightMap,_e.pointShadowMap.value=L.state.pointShadowMap,_e.pointShadowMatrix.value=L.state.pointShadowMatrix),B.currentProgram=Pe,B.uniformsList=null,Pe}function Lc(x){if(x.uniformsList===null){let I=x.currentProgram.getUniforms();x.uniformsList=rs.seqWithValue(I.seq,x.uniforms)}return x.uniformsList}function Dc(x,I){let O=Se.get(x);O.outputColorSpace=I.outputColorSpace,O.batching=I.batching,O.batchingColor=I.batchingColor,O.instancing=I.instancing,O.instancingColor=I.instancingColor,O.instancingMorph=I.instancingMorph,O.skinning=I.skinning,O.morphTargets=I.morphTargets,O.morphNormals=I.morphNormals,O.morphColors=I.morphColors,O.morphTargetsCount=I.morphTargetsCount,O.numClippingPlanes=I.numClippingPlanes,O.numIntersection=I.numClipIntersection,O.vertexAlphas=I.vertexAlphas,O.vertexTangents=I.vertexTangents,O.toneMapping=I.toneMapping}function vd(x,I,O,B,L){I.isScene!==!0&&(I=ct),A.resetTextureUnits();let Q=I.fog,le=B.isMeshStandardMaterial?I.environment:null,me=N===null?y.outputColorSpace:N.isXRRenderTarget===!0?N.texture.colorSpace:Pt,ge=(B.isMeshStandardMaterial?F:v).get(B.envMap||le),Re=B.vertexColors===!0&&!!O.attributes.color&&O.attributes.color.itemSize===4,Pe=!!O.attributes.tangent&&(!!B.normalMap||B.anisotropy>0),_e=!!O.morphAttributes.position,qe=!!O.morphAttributes.normal,it=!!O.morphAttributes.color,ot=ai;B.toneMapped&&(N===null||N.isXRRenderTarget===!0)&&(ot=y.toneMapping);let Ut=O.morphAttributes.position||O.morphAttributes.normal||O.morphAttributes.color,Je=Ut!==void 0?Ut.length:0,Me=Se.get(B),wn=p.state.lights;if(ee===!0&&(ve===!0||x!==M)){let qt=x===M&&B.id===b;j.setState(B,x,qt)}let Ke=!1;B.version===Me.__version?(Me.needsLights&&Me.lightsStateVersion!==wn.state.version||Me.outputColorSpace!==me||L.isBatchedMesh&&Me.batching===!1||!L.isBatchedMesh&&Me.batching===!0||L.isBatchedMesh&&Me.batchingColor===!0&&L.colorTexture===null||L.isBatchedMesh&&Me.batchingColor===!1&&L.colorTexture!==null||L.isInstancedMesh&&Me.instancing===!1||!L.isInstancedMesh&&Me.instancing===!0||L.isSkinnedMesh&&Me.skinning===!1||!L.isSkinnedMesh&&Me.skinning===!0||L.isInstancedMesh&&Me.instancingColor===!0&&L.instanceColor===null||L.isInstancedMesh&&Me.instancingColor===!1&&L.instanceColor!==null||L.isInstancedMesh&&Me.instancingMorph===!0&&L.morphTexture===null||L.isInstancedMesh&&Me.instancingMorph===!1&&L.morphTexture!==null||Me.envMap!==ge||B.fog===!0&&Me.fog!==Q||Me.numClippingPlanes!==void 0&&(Me.numClippingPlanes!==j.numPlanes||Me.numIntersection!==j.numIntersection)||Me.vertexAlphas!==Re||Me.vertexTangents!==Pe||Me.morphTargets!==_e||Me.morphNormals!==qe||Me.morphColors!==it||Me.toneMapping!==ot||Me.morphTargetsCount!==Je)&&(Ke=!0):(Ke=!0,Me.__version=B.version);let tn=Me.currentProgram;Ke===!0&&(tn=lr(B,I,L));let Ui=!1,kt=!1,ws=!1,at=tn.getUniforms(),pn=Me.uniforms;if(be.useProgram(tn.program)&&(Ui=!0,kt=!0,ws=!0),B.id!==b&&(b=B.id,kt=!0),Ui||M!==x){be.buffers.depth.getReversed()?(re.copy(x.projectionMatrix),Vf(re),Gf(re),at.setValue(D,"projectionMatrix",re)):at.setValue(D,"projectionMatrix",x.projectionMatrix),at.setValue(D,"viewMatrix",x.matrixWorldInverse);let Zn=at.map.cameraPosition;Zn!==void 0&&Zn.setValue(D,Ce.setFromMatrixPosition(x.matrixWorld)),Ve.logarithmicDepthBuffer&&at.setValue(D,"logDepthBufFC",2/(Math.log(x.far+1)/Math.LN2)),(B.isMeshPhongMaterial||B.isMeshToonMaterial||B.isMeshLambertMaterial||B.isMeshBasicMaterial||B.isMeshStandardMaterial||B.isShaderMaterial)&&at.setValue(D,"isOrthographic",x.isOrthographicCamera===!0),M!==x&&(M=x,kt=!0,ws=!0)}if(L.isSkinnedMesh){at.setOptional(D,L,"bindMatrix"),at.setOptional(D,L,"bindMatrixInverse");let qt=L.skeleton;qt&&(qt.boneTexture===null&&qt.computeBoneTexture(),at.setValue(D,"boneTexture",qt.boneTexture,A))}L.isBatchedMesh&&(at.setOptional(D,L,"batchingTexture"),at.setValue(D,"batchingTexture",L._matricesTexture,A),at.setOptional(D,L,"batchingIdTexture"),at.setValue(D,"batchingIdTexture",L._indirectTexture,A),at.setOptional(D,L,"batchingColorTexture"),L._colorsTexture!==null&&at.setValue(D,"batchingColorTexture",L._colorsTexture,A));let As=O.morphAttributes;if((As.position!==void 0||As.normal!==void 0||As.color!==void 0)&&Ee.update(L,O,tn),(kt||Me.receiveShadow!==L.receiveShadow)&&(Me.receiveShadow=L.receiveShadow,at.setValue(D,"receiveShadow",L.receiveShadow)),B.isMeshGouraudMaterial&&B.envMap!==null&&(pn.envMap.value=ge,pn.flipEnvMap.value=ge.isCubeTexture&&ge.isRenderTargetTexture===!1?-1:1),B.isMeshStandardMaterial&&B.envMap===null&&I.environment!==null&&(pn.envMapIntensity.value=I.environmentIntensity),kt&&(at.setValue(D,"toneMappingExposure",y.toneMappingExposure),Me.needsLights&&xd(pn,ws),Q&&B.fog===!0&&oe.refreshFogUniforms(pn,Q),oe.refreshMaterialUniforms(pn,B,z,$,p.state.transmissionRenderTarget[x.id]),rs.upload(D,Lc(Me),pn,A)),B.isShaderMaterial&&B.uniformsNeedUpdate===!0&&(rs.upload(D,Lc(Me),pn,A),B.uniformsNeedUpdate=!1),B.isSpriteMaterial&&at.setValue(D,"center",L.center),at.setValue(D,"modelViewMatrix",L.modelViewMatrix),at.setValue(D,"normalMatrix",L.normalMatrix),at.setValue(D,"modelMatrix",L.matrixWorld),B.isShaderMaterial||B.isRawShaderMaterial){let qt=B.uniformsGroups;for(let Zn=0,Jn=qt.length;Zn<Jn;Zn++){let Nc=qt[Zn];C.update(Nc,tn),C.bind(Nc,tn)}}return tn}function xd(x,I){x.ambientLightColor.needsUpdate=I,x.lightProbe.needsUpdate=I,x.directionalLights.needsUpdate=I,x.directionalLightShadows.needsUpdate=I,x.pointLights.needsUpdate=I,x.pointLightShadows.needsUpdate=I,x.spotLights.needsUpdate=I,x.spotLightShadows.needsUpdate=I,x.rectAreaLights.needsUpdate=I,x.hemisphereLights.needsUpdate=I}function yd(x){return x.isMeshLambertMaterial||x.isMeshToonMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isShadowMaterial||x.isShaderMaterial&&x.lights===!0}this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return N},this.setRenderTargetTextures=function(x,I,O){Se.get(x.texture).__webglTexture=I,Se.get(x.depthTexture).__webglTexture=O;let B=Se.get(x);B.__hasExternalTextures=!0,B.__autoAllocateDepthBuffer=O===void 0,B.__autoAllocateDepthBuffer||He.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),B.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(x,I){let O=Se.get(x);O.__webglFramebuffer=I,O.__useDefaultFramebuffer=I===void 0},this.setRenderTarget=function(x,I=0,O=0){N=x,E=I,T=O;let B=!0,L=null,Q=!1,le=!1;if(x){let ge=Se.get(x);if(ge.__useDefaultFramebuffer!==void 0)be.bindFramebuffer(D.FRAMEBUFFER,null),B=!1;else if(ge.__webglFramebuffer===void 0)A.setupRenderTarget(x);else if(ge.__hasExternalTextures)A.rebindTextures(x,Se.get(x.texture).__webglTexture,Se.get(x.depthTexture).__webglTexture);else if(x.depthBuffer){let _e=x.depthTexture;if(ge.__boundDepthTexture!==_e){if(_e!==null&&Se.has(_e)&&(x.width!==_e.image.width||x.height!==_e.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");A.setupDepthRenderbuffer(x)}}let Re=x.texture;(Re.isData3DTexture||Re.isDataArrayTexture||Re.isCompressedArrayTexture)&&(le=!0);let Pe=Se.get(x).__webglFramebuffer;x.isWebGLCubeRenderTarget?(Array.isArray(Pe[I])?L=Pe[I][O]:L=Pe[I],Q=!0):x.samples>0&&A.useMultisampledRTT(x)===!1?L=Se.get(x).__webglMultisampledFramebuffer:Array.isArray(Pe)?L=Pe[O]:L=Pe,R.copy(x.viewport),W.copy(x.scissor),k=x.scissorTest}else R.copy(xe).multiplyScalar(z).floor(),W.copy(Fe).multiplyScalar(z).floor(),k=tt;if(be.bindFramebuffer(D.FRAMEBUFFER,L)&&B&&be.drawBuffers(x,L),be.viewport(R),be.scissor(W),be.setScissorTest(k),Q){let ge=Se.get(x.texture);D.framebufferTexture2D(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,D.TEXTURE_CUBE_MAP_POSITIVE_X+I,ge.__webglTexture,O)}else if(le){let ge=Se.get(x.texture),Re=I||0;D.framebufferTextureLayer(D.FRAMEBUFFER,D.COLOR_ATTACHMENT0,ge.__webglTexture,O||0,Re)}b=-1},this.readRenderTargetPixels=function(x,I,O,B,L,Q,le){if(!(x&&x.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let me=Se.get(x).__webglFramebuffer;if(x.isWebGLCubeRenderTarget&&le!==void 0&&(me=me[le]),me){be.bindFramebuffer(D.FRAMEBUFFER,me);try{let ge=x.texture,Re=ge.format,Pe=ge.type;if(!Ve.textureFormatReadable(Re)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Ve.textureTypeReadable(Pe)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}I>=0&&I<=x.width-B&&O>=0&&O<=x.height-L&&D.readPixels(I,O,B,L,Ne.convert(Re),Ne.convert(Pe),Q)}finally{let ge=N!==null?Se.get(N).__webglFramebuffer:null;be.bindFramebuffer(D.FRAMEBUFFER,ge)}}},this.readRenderTargetPixelsAsync=async function(x,I,O,B,L,Q,le){if(!(x&&x.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let me=Se.get(x).__webglFramebuffer;if(x.isWebGLCubeRenderTarget&&le!==void 0&&(me=me[le]),me){let ge=x.texture,Re=ge.format,Pe=ge.type;if(!Ve.textureFormatReadable(Re))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Ve.textureTypeReadable(Pe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(I>=0&&I<=x.width-B&&O>=0&&O<=x.height-L){be.bindFramebuffer(D.FRAMEBUFFER,me);let _e=D.createBuffer();D.bindBuffer(D.PIXEL_PACK_BUFFER,_e),D.bufferData(D.PIXEL_PACK_BUFFER,Q.byteLength,D.STREAM_READ),D.readPixels(I,O,B,L,Ne.convert(Re),Ne.convert(Pe),0);let qe=N!==null?Se.get(N).__webglFramebuffer:null;be.bindFramebuffer(D.FRAMEBUFFER,qe);let it=D.fenceSync(D.SYNC_GPU_COMMANDS_COMPLETE,0);return D.flush(),await Hf(D,it,4),D.bindBuffer(D.PIXEL_PACK_BUFFER,_e),D.getBufferSubData(D.PIXEL_PACK_BUFFER,0,Q),D.deleteBuffer(_e),D.deleteSync(it),Q}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(x,I=null,O=0){x.isTexture!==!0&&(Os("WebGLRenderer: copyFramebufferToTexture function signature has changed."),I=arguments[0]||null,x=arguments[1]);let B=Math.pow(2,-O),L=Math.floor(x.image.width*B),Q=Math.floor(x.image.height*B),le=I!==null?I.x:0,me=I!==null?I.y:0;A.setTexture2D(x,0),D.copyTexSubImage2D(D.TEXTURE_2D,O,0,0,le,me,L,Q),be.unbindTexture()},this.copyTextureToTexture=function(x,I,O=null,B=null,L=0){x.isTexture!==!0&&(Os("WebGLRenderer: copyTextureToTexture function signature has changed."),B=arguments[0]||null,x=arguments[1],I=arguments[2],L=arguments[3]||0,O=null);let Q,le,me,ge,Re,Pe,_e,qe,it,ot=x.isCompressedTexture?x.mipmaps[L]:x.image;O!==null?(Q=O.max.x-O.min.x,le=O.max.y-O.min.y,me=O.isBox3?O.max.z-O.min.z:1,ge=O.min.x,Re=O.min.y,Pe=O.isBox3?O.min.z:0):(Q=ot.width,le=ot.height,me=ot.depth||1,ge=0,Re=0,Pe=0),B!==null?(_e=B.x,qe=B.y,it=B.z):(_e=0,qe=0,it=0);let Ut=Ne.convert(I.format),Je=Ne.convert(I.type),Me;I.isData3DTexture?(A.setTexture3D(I,0),Me=D.TEXTURE_3D):I.isDataArrayTexture||I.isCompressedArrayTexture?(A.setTexture2DArray(I,0),Me=D.TEXTURE_2D_ARRAY):(A.setTexture2D(I,0),Me=D.TEXTURE_2D),D.pixelStorei(D.UNPACK_FLIP_Y_WEBGL,I.flipY),D.pixelStorei(D.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),D.pixelStorei(D.UNPACK_ALIGNMENT,I.unpackAlignment);let wn=D.getParameter(D.UNPACK_ROW_LENGTH),Ke=D.getParameter(D.UNPACK_IMAGE_HEIGHT),tn=D.getParameter(D.UNPACK_SKIP_PIXELS),Ui=D.getParameter(D.UNPACK_SKIP_ROWS),kt=D.getParameter(D.UNPACK_SKIP_IMAGES);D.pixelStorei(D.UNPACK_ROW_LENGTH,ot.width),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,ot.height),D.pixelStorei(D.UNPACK_SKIP_PIXELS,ge),D.pixelStorei(D.UNPACK_SKIP_ROWS,Re),D.pixelStorei(D.UNPACK_SKIP_IMAGES,Pe);let ws=x.isDataArrayTexture||x.isData3DTexture,at=I.isDataArrayTexture||I.isData3DTexture;if(x.isRenderTargetTexture||x.isDepthTexture){let pn=Se.get(x),As=Se.get(I),qt=Se.get(pn.__renderTarget),Zn=Se.get(As.__renderTarget);be.bindFramebuffer(D.READ_FRAMEBUFFER,qt.__webglFramebuffer),be.bindFramebuffer(D.DRAW_FRAMEBUFFER,Zn.__webglFramebuffer);for(let Jn=0;Jn<me;Jn++)ws&&D.framebufferTextureLayer(D.READ_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Se.get(x).__webglTexture,L,Pe+Jn),x.isDepthTexture?(at&&D.framebufferTextureLayer(D.DRAW_FRAMEBUFFER,D.COLOR_ATTACHMENT0,Se.get(I).__webglTexture,L,it+Jn),D.blitFramebuffer(ge,Re,Q,le,_e,qe,Q,le,D.DEPTH_BUFFER_BIT,D.NEAREST)):at?D.copyTexSubImage3D(Me,L,_e,qe,it+Jn,ge,Re,Q,le):D.copyTexSubImage2D(Me,L,_e,qe,it+Jn,ge,Re,Q,le);be.bindFramebuffer(D.READ_FRAMEBUFFER,null),be.bindFramebuffer(D.DRAW_FRAMEBUFFER,null)}else at?x.isDataTexture||x.isData3DTexture?D.texSubImage3D(Me,L,_e,qe,it,Q,le,me,Ut,Je,ot.data):I.isCompressedArrayTexture?D.compressedTexSubImage3D(Me,L,_e,qe,it,Q,le,me,Ut,ot.data):D.texSubImage3D(Me,L,_e,qe,it,Q,le,me,Ut,Je,ot):x.isDataTexture?D.texSubImage2D(D.TEXTURE_2D,L,_e,qe,Q,le,Ut,Je,ot.data):x.isCompressedTexture?D.compressedTexSubImage2D(D.TEXTURE_2D,L,_e,qe,ot.width,ot.height,Ut,ot.data):D.texSubImage2D(D.TEXTURE_2D,L,_e,qe,Q,le,Ut,Je,ot);D.pixelStorei(D.UNPACK_ROW_LENGTH,wn),D.pixelStorei(D.UNPACK_IMAGE_HEIGHT,Ke),D.pixelStorei(D.UNPACK_SKIP_PIXELS,tn),D.pixelStorei(D.UNPACK_SKIP_ROWS,Ui),D.pixelStorei(D.UNPACK_SKIP_IMAGES,kt),L===0&&I.generateMipmaps&&D.generateMipmap(Me),be.unbindTexture()},this.copyTextureToTexture3D=function(x,I,O=null,B=null,L=0){return x.isTexture!==!0&&(Os("WebGLRenderer: copyTextureToTexture3D function signature has changed."),O=arguments[0]||null,B=arguments[1]||null,x=arguments[2],I=arguments[3],L=arguments[4]||0),Os('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(x,I,O,B,L)},this.initRenderTarget=function(x){Se.get(x).__webglFramebuffer===void 0&&A.setupRenderTarget(x)},this.initTexture=function(x){x.isCubeTexture?A.setTextureCube(x,0):x.isData3DTexture?A.setTexture3D(x,0):x.isDataArrayTexture||x.isCompressedArrayTexture?A.setTexture2DArray(x,0):A.setTexture2D(x,0),be.unbindTexture()},this.resetState=function(){E=0,T=0,N=null,be.reset(),nt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Bn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorspace=ke._getDrawingBufferColorSpace(e),t.unpackColorSpace=ke._getUnpackColorSpace()}};var ro=class extends ht{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new xn,this.environmentIntensity=1,this.environmentRotation=new xn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}},Zs=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=el,this.updateRanges=[],this.version=0,this.uuid=un()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=un()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=un()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},Dt=new P,Js=class i{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)Dt.fromBufferAttribute(this,t),Dt.applyMatrix4(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Dt.fromBufferAttribute(this,t),Dt.applyNormalMatrix(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Dt.fromBufferAttribute(this,t),Dt.transformDirection(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=cn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Qe(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=Qe(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=Qe(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=Qe(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=Qe(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=cn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=cn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=cn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=cn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=Qe(t,this.array),n=Qe(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=Qe(t,this.array),n=Qe(n,this.array),s=Qe(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=Qe(t,this.array),n=Qe(n,this.array),s=Qe(s,this.array),r=Qe(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new mt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new i(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}};var su=new P,ru=new Ye,ou=new Ye,O0=new P,au=new De,Ur=new P,da=new Vt,lu=new De,fa=new ps,oo=class extends Ct{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=ah,this.bindMatrix=new De,this.bindMatrixInverse=new De,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;this.boundingBox===null&&(this.boundingBox=new Bt),this.boundingBox.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Ur),this.boundingBox.expandByPoint(Ur)}computeBoundingSphere(){let e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new Vt),this.boundingSphere.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Ur),this.boundingSphere.expandByPoint(Ur)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){let n=this.material,s=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),da.copy(this.boundingSphere),da.applyMatrix4(s),e.ray.intersectsSphere(da)!==!1&&(lu.copy(s).invert(),fa.copy(e.ray).applyMatrix4(lu),!(this.boundingBox!==null&&fa.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,fa)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new Ye,t=this.geometry.attributes.skinWeight;for(let n=0,s=t.count;n<s;n++){e.fromBufferAttribute(t,n);let r=1/e.manhattanLength();r!==1/0?e.multiplyScalar(r):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===ah?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===df?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){let n=this.skeleton,s=this.geometry;ru.fromBufferAttribute(s.attributes.skinIndex,e),ou.fromBufferAttribute(s.attributes.skinWeight,e),su.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let r=0;r<4;r++){let o=ou.getComponent(r);if(o!==0){let a=ru.getComponent(r);au.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(O0.copy(su).applyMatrix4(au),o)}}return t.applyMatrix4(this.bindMatrixInverse)}},Ks=class extends ht{constructor(){super(),this.isBone=!0,this.type="Bone"}},ao=class extends St{constructor(e=null,t=1,n=1,s,r,o,a,l,c=It,h=It,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},cu=new De,B0=new De,lo=class i{constructor(e=[],t=[]){this.uuid=un(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){let e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,s=this.bones.length;n<s;n++)this.boneInverses.push(new De)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){let n=new De;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){let e=this.bones,t=this.boneInverses,n=this.boneMatrices,s=this.boneTexture;for(let r=0,o=e.length;r<o;r++){let a=e[r]?e[r].matrixWorld:B0;cu.multiplyMatrices(a,t[r]),cu.toArray(n,r*16)}s!==null&&(s.needsUpdate=!0)}clone(){return new i(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4);t.set(this.boneMatrices);let n=new ao(t,e,e,Jt,hn);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){let s=this.bones[t];if(s.name===e)return s}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,s=e.bones.length;n<s;n++){let r=e.bones[n],o=t[r];o===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",r),o=new Ks),this.bones.push(o),this.boneInverses.push(new De().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){let e={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;let t=this.bones,n=this.boneInverses;for(let s=0,r=t.length;s<r;s++){let o=t[s];e.bones.push(o.uuid);let a=n[s];e.boneInverses.push(a.toArray())}return e}},Li=class extends mt{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Qi=new De,hu=new De,Fr=[],uu=new Bt,k0=new De,Ds=new Ct,Ns=new Vt,co=class extends Ct{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Li(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,k0)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Bt),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Qi),uu.copy(e.boundingBox).applyMatrix4(Qi),this.boundingBox.union(uu)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Vt),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Qi),Ns.copy(e.boundingSphere).applyMatrix4(Qi),this.boundingSphere.union(Ns)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=e*r+1;for(let a=0;a<n.length;a++)n[a]=s[o+a]}raycast(e,t){let n=this.matrixWorld,s=this.count;if(Ds.geometry=this.geometry,Ds.material=this.material,Ds.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ns.copy(this.boundingSphere),Ns.applyMatrix4(n),e.ray.intersectsSphere(Ns)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Qi),hu.multiplyMatrices(n,Qi),Ds.matrixWorld=hu,Ds.raycast(e,Fr);for(let o=0,a=Fr.length;o<a;o++){let l=Fr[o];l.instanceId=r,l.object=this,t.push(l)}Fr.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Li(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){let n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new ao(new Float32Array(s*this.count),s,this.count,Dl,hn));let r=this.morphTexture.source.data.data,o=0;for(let c=0;c<n.length;c++)o+=n[c];let a=this.geometry.morphTargetsRelative?1:1-o,l=s*e;r[l]=a,r.set(n,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var $s=class extends Gt{static get type(){return"LineBasicMaterial"}constructor(e){super(),this.isLineBasicMaterial=!0,this.color=new we(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},ho=new P,uo=new P,du=new De,Us=new ps,Or=new Vt,pa=new P,fu=new P,gs=class extends ht{constructor(e=new $t,t=new $s){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)ho.fromBufferAttribute(t,s-1),uo.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=ho.distanceTo(uo);e.setAttribute("lineDistance",new Kt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Or.copy(n.boundingSphere),Or.applyMatrix4(s),Or.radius+=r,e.ray.intersectsSphere(Or)===!1)return;du.copy(s).invert(),Us.copy(e.ray).applyMatrix4(du);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){let f=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=c){let p=h.getX(_),w=h.getX(_+1),S=Br(this,e,Us,l,p,w);S&&t.push(S)}if(this.isLineLoop){let _=h.getX(g-1),m=h.getX(f),p=Br(this,e,Us,l,_,m);p&&t.push(p)}}else{let f=Math.max(0,o.start),g=Math.min(d.count,o.start+o.count);for(let _=f,m=g-1;_<m;_+=c){let p=Br(this,e,Us,l,_,_+1);p&&t.push(p)}if(this.isLineLoop){let _=Br(this,e,Us,l,g-1,f);_&&t.push(_)}}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Br(i,e,t,n,s,r){let o=i.geometry.attributes.position;if(ho.fromBufferAttribute(o,s),uo.fromBufferAttribute(o,r),t.distanceSqToSegment(ho,uo,pa,fu)>n)return;pa.applyMatrix4(i.matrixWorld);let l=e.ray.origin.distanceTo(pa);if(!(l<e.near||l>e.far))return{distance:l,point:fu.clone().applyMatrix4(i.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:i}}var pu=new P,mu=new P,fo=class extends gs{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)pu.fromBufferAttribute(t,s),mu.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+pu.distanceTo(mu);e.setAttribute("lineDistance",new Kt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}},po=class extends gs{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}},js=class extends Gt{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new we(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},gu=new De,_l=new ps,kr=new Vt,zr=new P,mo=class extends ht{constructor(e=new $t,t=new js){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),kr.copy(n.boundingSphere),kr.applyMatrix4(s),kr.radius+=r,e.ray.intersectsSphere(kr)===!1)return;gu.copy(s).invert(),_l.copy(e.ray).applyMatrix4(gu);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,o.start),f=Math.min(c.count,o.start+o.count);for(let g=d,_=f;g<_;g++){let m=c.getX(g);zr.fromBufferAttribute(u,m),_u(zr,m,l,s,e,t,this)}}else{let d=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let g=d,_=f;g<_;g++)zr.fromBufferAttribute(u,g),_u(zr,g,l,s,e,t,this)}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function _u(i,e,t,n,s,r,o){let a=_l.distanceSqToPoint(i);if(a<t){let l=new P;_l.closestPointToPoint(i,l),l.applyMatrix4(n);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}var _s=class extends Gt{static get type(){return"MeshStandardMaterial"}constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new we(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new we(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Uu,this.normalScale=new ze(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Wt=class extends _s{static get type(){return"MeshPhysicalMaterial"}constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new ze(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Rt(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new we(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new we(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new we(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}};function Hr(i,e,t){return!i||!t&&i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function z0(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function H0(i){function e(s,r){return i[s]-i[r]}let t=i.length,n=new Array(t);for(let s=0;s!==t;++s)n[s]=s;return n.sort(e),n}function vu(i,e,t){let n=i.length,s=new i.constructor(n);for(let r=0,o=0;o!==n;++r){let a=t[r]*e;for(let l=0;l!==e;++l)s[o++]=i[a+l]}return s}function qu(i,e,t,n){let s=1,r=i[0];for(;r!==void 0&&r[n]===void 0;)r=i[s++];if(r===void 0)return;let o=r[n];if(o!==void 0)if(Array.isArray(o))do o=r[n],o!==void 0&&(e.push(r.time),t.push.apply(t,o)),r=i[s++];while(r!==void 0);else if(o.toArray!==void 0)do o=r[n],o!==void 0&&(e.push(r.time),o.toArray(t,t.length)),r=i[s++];while(r!==void 0);else do o=r[n],o!==void 0&&(e.push(r.time),t.push(o)),r=i[s++];while(r!==void 0)}var hi=class{constructor(e,t,n,s){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,s=t[n],r=t[n-1];n:{e:{let o;t:{i:if(!(e<s)){for(let a=n+2;;){if(s===void 0){if(e<r)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=t[++n],e<s)break e}o=t.length;break t}if(!(e>=r)){let a=t[1];e<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=t[--n-1],e>=r)break e}o=n,n=0;break t}break n}for(;n<o;){let a=n+o>>>1;e<t[a]?o=a:n=a+1}if(s=t[n],r=t[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,e,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s;for(let o=0;o!==s;++o)t[o]=n[r+o];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},vl=class extends hi{constructor(e,t,n,s){super(e,t,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:lh,endingEnd:lh}}intervalChanged_(e,t,n){let s=this.parameterPositions,r=e-2,o=e+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case ch:r=e,a=2*t-n;break;case hh:r=s.length-2,a=t+s[r]-s[r+1];break;default:r=e,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case ch:o=e,l=2*n-t;break;case hh:o=1,l=n+s[1]-s[0];break;default:o=e-1,l=t}let c=(n-t)*.5,h=this.valueSize;this._weightPrev=c/(t-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,g=(n-t)/(s-t),_=g*g,m=_*g,p=-d*m+2*d*_-d*g,w=(1+d)*m+(-1.5-2*d)*_+(-.5+d)*g+1,S=(-1-f)*m+(1.5+f)*_+.5*g,y=f*m-f*_;for(let U=0;U!==a;++U)r[U]=p*o[h+U]+w*o[c+U]+S*o[l+U]+y*o[u+U];return r}},xl=class extends hi{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=(n-t)/(s-t),u=1-h;for(let d=0;d!==a;++d)r[d]=o[c+d]*u+o[l+d]*h;return r}},yl=class extends hi{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e){return this.copySampleValue_(e-1)}},jt=class{constructor(e,t,n,s){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Hr(t,this.TimeBufferType),this.values=Hr(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Hr(e.times,Array),values:Hr(e.values,Array)};let s=e.getInterpolation();s!==e.DefaultInterpolation&&(n.interpolation=s)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new yl(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new xl(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new vl(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case us:t=this.InterpolantFactoryMethodDiscrete;break;case ds:t=this.InterpolantFactoryMethodLinear;break;case ko:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return us;case this.InterpolantFactoryMethodLinear:return ds;case this.InterpolantFactoryMethodSmooth:return ko}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]*=e}return this}trim(e,t){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<e;)++r;for(;o!==-1&&n[o]>t;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),e=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),e=!1;break}o=l}if(s!==void 0&&z0(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===ko,r=e.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=e[a],h=e[a+1];if(c!==h&&(a!==1||c!==e[0]))if(s)l=!0;else{let u=a*n,d=u-n,f=u+n;for(let g=0;g!==n;++g){let _=t[u+g];if(_!==t[d+g]||_!==t[f+g]){l=!0;break}}}if(l){if(a!==o){e[o]=e[a];let u=a*n,d=o*n;for(let f=0;f!==n;++f)t[d+f]=t[u+f]}++o}}if(r>0){e[o]=e[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)t[l+c]=t[a+c];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*n)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,s=new n(this.name,e,t);return s.createInterpolant=this.createInterpolant,s}};jt.prototype.TimeBufferType=Float32Array;jt.prototype.ValueBufferType=Float32Array;jt.prototype.DefaultInterpolation=ds;var ui=class extends jt{constructor(e,t,n){super(e,t,n)}};ui.prototype.ValueTypeName="bool";ui.prototype.ValueBufferType=Array;ui.prototype.DefaultInterpolation=us;ui.prototype.InterpolantFactoryMethodLinear=void 0;ui.prototype.InterpolantFactoryMethodSmooth=void 0;var go=class extends jt{};go.prototype.ValueTypeName="color";var Vn=class extends jt{};Vn.prototype.ValueTypeName="number";var Ml=class extends hi{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-t)/(s-t),c=e*a;for(let h=c+a;c!==h;c+=4)dn.slerpFlat(r,0,o,c-a,o,c,l);return r}},Gn=class extends jt{InterpolantFactoryMethodLinear(e){return new Ml(this.times,this.values,this.getValueSize(),e)}};Gn.prototype.ValueTypeName="quaternion";Gn.prototype.InterpolantFactoryMethodSmooth=void 0;var di=class extends jt{constructor(e,t,n){super(e,t,n)}};di.prototype.ValueTypeName="string";di.prototype.ValueBufferType=Array;di.prototype.DefaultInterpolation=us;di.prototype.InterpolantFactoryMethodLinear=void 0;di.prototype.InterpolantFactoryMethodSmooth=void 0;var Wn=class extends jt{};Wn.prototype.ValueTypeName="vector";var _o=class{constructor(e="",t=-1,n=[],s=ff){this.name=e,this.tracks=n,this.duration=t,this.blendMode=s,this.uuid=un(),this.duration<0&&this.resetDuration()}static parse(e){let t=[],n=e.tracks,s=1/(e.fps||1);for(let o=0,a=n.length;o!==a;++o)t.push(G0(n[o]).scale(s));let r=new this(e.name,e.duration,t,e.blendMode);return r.uuid=e.uuid,r}static toJSON(e){let t=[],n=e.tracks,s={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let r=0,o=n.length;r!==o;++r)t.push(jt.toJSON(n[r]));return s}static CreateFromMorphTargetSequence(e,t,n,s){let r=t.length,o=[];for(let a=0;a<r;a++){let l=[],c=[];l.push((a+r-1)%r,a,(a+1)%r),c.push(0,1,0);let h=H0(l);l=vu(l,1,h),c=vu(c,1,h),!s&&l[0]===0&&(l.push(r),c.push(c[0])),o.push(new Vn(".morphTargetInfluences["+t[a].name+"]",l,c).scale(1/n))}return new this(e,-1,o)}static findByName(e,t){let n=e;if(!Array.isArray(e)){let s=e;n=s.geometry&&s.geometry.animations||s.animations}for(let s=0;s<n.length;s++)if(n[s].name===t)return n[s];return null}static CreateClipsFromMorphTargetSequences(e,t,n){let s={},r=/^([\w-]*?)([\d]+)$/;for(let a=0,l=e.length;a<l;a++){let c=e[a],h=c.name.match(r);if(h&&h.length>1){let u=h[1],d=s[u];d||(s[u]=d=[]),d.push(c)}}let o=[];for(let a in s)o.push(this.CreateFromMorphTargetSequence(a,s[a],t,n));return o}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;let n=function(u,d,f,g,_){if(f.length!==0){let m=[],p=[];qu(f,m,p,g),m.length!==0&&_.push(new u(d,m,p))}},s=[],r=e.name||"default",o=e.fps||30,a=e.blendMode,l=e.length||-1,c=e.hierarchy||[];for(let u=0;u<c.length;u++){let d=c[u].keys;if(!(!d||d.length===0))if(d[0].morphTargets){let f={},g;for(g=0;g<d.length;g++)if(d[g].morphTargets)for(let _=0;_<d[g].morphTargets.length;_++)f[d[g].morphTargets[_]]=-1;for(let _ in f){let m=[],p=[];for(let w=0;w!==d[g].morphTargets.length;++w){let S=d[g];m.push(S.time),p.push(S.morphTarget===_?1:0)}s.push(new Vn(".morphTargetInfluence["+_+"]",m,p))}l=f.length*o}else{let f=".bones["+t[u].name+"]";n(Wn,f+".position",d,"pos",s),n(Gn,f+".quaternion",d,"rot",s),n(Wn,f+".scale",d,"scl",s)}}return s.length===0?null:new this(r,l,s,a)}resetDuration(){let e=this.tracks,t=0;for(let n=0,s=e.length;n!==s;++n){let r=this.tracks[n];t=Math.max(t,r.times[r.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}};function V0(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Vn;case"vector":case"vector2":case"vector3":case"vector4":return Wn;case"color":return go;case"quaternion":return Gn;case"bool":case"boolean":return ui;case"string":return di}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function G0(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");let e=V0(i.type);if(i.times===void 0){let t=[],n=[];qu(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}var ri={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}},Sl=class{constructor(e,t,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],g=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return g}return null}}},W0=new Sl,Xn=class{constructor(e){this.manager=e!==void 0?e:W0,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};Xn.DEFAULT_MATERIAL_NAME="__DEFAULT";var Nn={},bl=class extends Error{constructor(e,t){super(e),this.response=t}},Qs=class extends Xn{constructor(e){super(e)}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=ri.get(e);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(Nn[e]!==void 0){Nn[e].push({onLoad:t,onProgress:n,onError:s});return}Nn[e]=[],Nn[e].push({onLoad:t,onProgress:n,onError:s});let o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),a=this.mimeType,l=this.responseType;fetch(o).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;let h=Nn[e],u=c.body.getReader(),d=c.headers.get("X-File-Size")||c.headers.get("Content-Length"),f=d?parseInt(d):0,g=f!==0,_=0,m=new ReadableStream({start(p){w();function w(){u.read().then(({done:S,value:y})=>{if(S)p.close();else{_+=y.byteLength;let U=new ProgressEvent("progress",{lengthComputable:g,loaded:_,total:f});for(let E=0,T=h.length;E<T;E++){let N=h[E];N.onProgress&&N.onProgress(U)}p.enqueue(y),w()}},S=>{p.error(S)})}}});return new Response(m)}else throw new bl(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(h=>new DOMParser().parseFromString(h,a));case"json":return c.json();default:if(a===void 0)return c.text();{let u=/charset="?([^;"\s]*)"?/i.exec(a),d=u&&u[1]?u[1].toLowerCase():void 0,f=new TextDecoder(d);return c.arrayBuffer().then(g=>f.decode(g))}}}).then(c=>{ri.add(e,c);let h=Nn[e];delete Nn[e];for(let u=0,d=h.length;u<d;u++){let f=h[u];f.onLoad&&f.onLoad(c)}}).catch(c=>{let h=Nn[e];if(h===void 0)throw this.manager.itemError(e),c;delete Nn[e];for(let u=0,d=h.length;u<d;u++){let f=h[u];f.onError&&f.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}};var wl=class extends Xn{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=ri.get(e);if(o!==void 0)return r.manager.itemStart(e),setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o;let a=Xs("img");function l(){h(),ri.add(e,this),t&&t(this),r.manager.itemEnd(e)}function c(u){h(),s&&s(u),r.manager.itemError(e),r.manager.itemEnd(e)}function h(){a.removeEventListener("load",l,!1),a.removeEventListener("error",c,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),r.manager.itemStart(e),a.src=e,a}};var vo=class extends Xn{constructor(e){super(e)}load(e,t,n,s){let r=new St,o=new wl(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){r.image=a,r.needsUpdate=!0,t!==void 0&&t(r)},n,s),r}},vs=class extends ht{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new we(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}},xo=class extends vs{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ht.DEFAULT_UP),this.updateMatrix(),this.groundColor=new we(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},ma=new De,xu=new P,yu=new P,er=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ze(512,512),this.map=null,this.mapPass=null,this.matrix=new De,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ys,this._frameExtents=new ze(1,1),this._viewportCount=1,this._viewports=[new Ye(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,n=this.matrix;xu.setFromMatrixPosition(e.matrixWorld),t.position.copy(xu),yu.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(yu),t.updateMatrixWorld(),ma.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ma),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(ma)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},Al=class extends er{constructor(){super(new Mt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,n=fs*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height,r=e.distance||t.far;(n!==t.fov||s!==t.aspect||r!==t.far)&&(t.fov=n,t.aspect=s,t.far=r,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},yo=class extends vs{constructor(e,t,n=0,s=Math.PI/3,r=0,o=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(ht.DEFAULT_UP),this.updateMatrix(),this.target=new ht,this.distance=n,this.angle=s,this.penumbra=r,this.decay=o,this.map=null,this.shadow=new Al}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},Mu=new De,Fs=new P,ga=new P,Tl=class extends er{constructor(){super(new Mt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new ze(4,2),this._viewportCount=6,this._viewports=[new Ye(2,1,1,1),new Ye(0,1,1,1),new Ye(3,1,1,1),new Ye(1,1,1,1),new Ye(3,0,1,1),new Ye(1,0,1,1)],this._cubeDirections=[new P(1,0,0),new P(-1,0,0),new P(0,0,1),new P(0,0,-1),new P(0,1,0),new P(0,-1,0)],this._cubeUps=[new P(0,1,0),new P(0,1,0),new P(0,1,0),new P(0,1,0),new P(0,0,1),new P(0,0,-1)]}updateMatrices(e,t=0){let n=this.camera,s=this.matrix,r=e.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),Fs.setFromMatrixPosition(e.matrixWorld),n.position.copy(Fs),ga.copy(n.position),ga.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(ga),n.updateMatrixWorld(),s.makeTranslation(-Fs.x,-Fs.y,-Fs.z),Mu.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Mu)}},Mo=class extends vs{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new Tl}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},El=class extends er{constructor(){super(new ci(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},xs=class extends vs{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ht.DEFAULT_UP),this.updateMatrix(),this.target=new ht,this.shadow=new El}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var fi=class{static decodeText(e){if(console.warn("THREE.LoaderUtils: decodeText() has been deprecated with r165 and will be removed with r175. Use TextDecoder instead."),typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let n=0,s=e.length;n<s;n++)t+=String.fromCharCode(e[n]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){let t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}};var So=class extends Xn{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"}}setOptions(e){return this.options=e,this}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=ri.get(e);if(o!==void 0){if(r.manager.itemStart(e),o.then){o.then(c=>{t&&t(c),r.manager.itemEnd(e)}).catch(c=>{s&&s(c)});return}return setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0),o}let a={};a.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",a.headers=this.requestHeader;let l=fetch(e,a).then(function(c){return c.blob()}).then(function(c){return createImageBitmap(c,Object.assign(r.options,{colorSpaceConversion:"none"}))}).then(function(c){return ri.add(e,c),t&&t(c),r.manager.itemEnd(e),c}).catch(function(c){s&&s(c),ri.remove(e),r.manager.itemError(e),r.manager.itemEnd(e)});ri.add(e,l),r.manager.itemStart(e)}};var kl="\\[\\]\\.:\\/",X0=new RegExp("["+kl+"]","g"),zl="[^"+kl+"]",q0="[^"+kl.replace("\\.","")+"]",Y0=/((?:WC+[\/:])*)/.source.replace("WC",zl),Z0=/(WCOD+)?/.source.replace("WCOD",q0),J0=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",zl),K0=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",zl),$0=new RegExp("^"+Y0+Z0+J0+K0+"$"),j0=["material","materials","bones","map"],Rl=class{constructor(e,t,n){let s=n||st.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,s)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},st=class i{constructor(e,t,n){this.path=t,this.parsedPath=n||i.parseTrackName(t),this.node=i.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new i.Composite(e,t,n):new i(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(X0,"")}static parseTrackName(e){let t=$0.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);j0.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===t||a.uuid===t)return a;let l=n(a.children);if(l)return l}return null},s=n(e.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)e[t++]=n[s]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,n=t.objectName,s=t.propertyName,r=t.propertyIndex;if(e||(e=i.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}let o=e[s];if(o===void 0){let c=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[r]!==void 0&&(r=e.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};st.Composite=Rl;st.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};st.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};st.prototype.GetterByBindingType=[st.prototype._getValue_direct,st.prototype._getValue_array,st.prototype._getValue_arrayElement,st.prototype._getValue_toArray];st.prototype.SetterByBindingTypeAndVersioning=[[st.prototype._setValue_direct,st.prototype._setValue_direct_setNeedsUpdate,st.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[st.prototype._setValue_array,st.prototype._setValue_array_setNeedsUpdate,st.prototype._setValue_array_setMatrixWorldNeedsUpdate],[st.prototype._setValue_arrayElement,st.prototype._setValue_arrayElement_setNeedsUpdate,st.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[st.prototype._setValue_fromArray,st.prototype._setValue_fromArray_setNeedsUpdate,st.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Uv=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"170"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="170");function Hl(i,e){if(e===Nu)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===nr||e===wo){let t=i.getIndex();if(t===null){let o=[],a=i.getAttribute("position");if(a!==void 0){for(let l=0;l<a.count;l++)o.push(l);i.setIndex(o),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}let n=t.count-2,s=[];if(e===nr)for(let o=1;o<=n;o++)s.push(t.getX(0)),s.push(t.getX(o)),s.push(t.getX(o+1));else for(let o=0;o<n;o++)o%2===0?(s.push(t.getX(o)),s.push(t.getX(o+1)),s.push(t.getX(o+2))):(s.push(t.getX(o+2)),s.push(t.getX(o+1)),s.push(t.getX(o)));s.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");let r=i.clone();return r.setIndex(s),r.clearGroups(),r}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}var Eo=class extends Xn{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new Zl(t)}),this.register(function(t){return new Jl(t)}),this.register(function(t){return new sc(t)}),this.register(function(t){return new rc(t)}),this.register(function(t){return new oc(t)}),this.register(function(t){return new $l(t)}),this.register(function(t){return new jl(t)}),this.register(function(t){return new Ql(t)}),this.register(function(t){return new ec(t)}),this.register(function(t){return new Yl(t)}),this.register(function(t){return new tc(t)}),this.register(function(t){return new Kl(t)}),this.register(function(t){return new ic(t)}),this.register(function(t){return new nc(t)}),this.register(function(t){return new Xl(t)}),this.register(function(t){return new ac(t)}),this.register(function(t){return new lc(t)})}load(e,t,n,s){let r=this,o;if(this.resourcePath!=="")o=this.resourcePath;else if(this.path!==""){let c=fi.extractUrlBase(e);o=fi.resolveURL(c,this.path)}else o=fi.extractUrlBase(e);this.manager.itemStart(e);let a=function(c){s?s(c):console.error(c),r.manager.itemError(e),r.manager.itemEnd(e)},l=new Qs(this.manager);l.setPath(this.path),l.setResponseType("arraybuffer"),l.setRequestHeader(this.requestHeader),l.setWithCredentials(this.withCredentials),l.load(e,function(c){try{r.parse(c,o,function(h){t(h),r.manager.itemEnd(e)},a)}catch(h){a(h)}},n,a)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,s){let r,o={},a={},l=new TextDecoder;if(typeof e=="string")r=JSON.parse(e);else if(e instanceof ArrayBuffer)if(l.decode(new Uint8Array(e,0,4))===$u){try{o[Be.KHR_BINARY_GLTF]=new cc(e)}catch(u){s&&s(u);return}r=JSON.parse(o[Be.KHR_BINARY_GLTF].content)}else r=JSON.parse(l.decode(e));else r=e;if(r.asset===void 0||r.asset.version[0]<2){s&&s(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}let c=new gc(r,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});c.fileLoader.setRequestHeader(this.requestHeader);for(let h=0;h<this.pluginCallbacks.length;h++){let u=this.pluginCallbacks[h](c);u.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),a[u.name]=u,o[u.name]=!0}if(r.extensionsUsed)for(let h=0;h<r.extensionsUsed.length;++h){let u=r.extensionsUsed[h],d=r.extensionsRequired||[];switch(u){case Be.KHR_MATERIALS_UNLIT:o[u]=new ql;break;case Be.KHR_DRACO_MESH_COMPRESSION:o[u]=new hc(r,this.dracoLoader);break;case Be.KHR_TEXTURE_TRANSFORM:o[u]=new uc;break;case Be.KHR_MESH_QUANTIZATION:o[u]=new dc;break;default:d.indexOf(u)>=0&&a[u]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}c.setExtensions(o),c.setPlugins(a),c.parse(n,s)}parseAsync(e,t){let n=this;return new Promise(function(s,r){n.parse(e,t,s,r)})}};function ev(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}var Be={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"},Xl=class{constructor(e){this.parser=e,this.name=Be.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let n=0,s=t.length;n<s;n++){let r=t[n];r.extensions&&r.extensions[this.name]&&r.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,r.extensions[this.name].light)}}_loadLight(e){let t=this.parser,n="light:"+e,s=t.cache.get(n);if(s)return s;let r=t.json,l=((r.extensions&&r.extensions[this.name]||{}).lights||[])[e],c,h=new we(16777215);l.color!==void 0&&h.setRGB(l.color[0],l.color[1],l.color[2],Pt);let u=l.range!==void 0?l.range:0;switch(l.type){case"directional":c=new xs(h),c.target.position.set(0,0,-1),c.add(c.target);break;case"point":c=new Mo(h),c.distance=u;break;case"spot":c=new yo(h),c.distance=u,l.spot=l.spot||{},l.spot.innerConeAngle=l.spot.innerConeAngle!==void 0?l.spot.innerConeAngle:0,l.spot.outerConeAngle=l.spot.outerConeAngle!==void 0?l.spot.outerConeAngle:Math.PI/4,c.angle=l.spot.outerConeAngle,c.penumbra=1-l.spot.innerConeAngle/l.spot.outerConeAngle,c.target.position.set(0,0,-1),c.add(c.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+l.type)}return c.position.set(0,0,0),c.decay=2,qn(c,l),l.intensity!==void 0&&(c.intensity=l.intensity),c.name=t.createUniqueName(l.name||"light_"+e),s=Promise.resolve(c),t.cache.add(n,s),s}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){let t=this,n=this.parser,r=n.json.nodes[e],a=(r.extensions&&r.extensions[this.name]||{}).light;return a===void 0?null:this._loadLight(a).then(function(l){return n._getNodeRef(t.cache,a,l)})}},ql=class{constructor(){this.name=Be.KHR_MATERIALS_UNLIT}getMaterialType(){return yn}extendParams(e,t,n){let s=[];e.color=new we(1,1,1),e.opacity=1;let r=t.pbrMetallicRoughness;if(r){if(Array.isArray(r.baseColorFactor)){let o=r.baseColorFactor;e.color.setRGB(o[0],o[1],o[2],Pt),e.opacity=o[3]}r.baseColorTexture!==void 0&&s.push(n.assignTexture(e,"map",r.baseColorTexture,pt))}return Promise.all(s)}},Yl=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=s.extensions[this.name].emissiveStrength;return r!==void 0&&(t.emissiveIntensity=r),Promise.resolve()}},Zl=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];if(o.clearcoatFactor!==void 0&&(t.clearcoat=o.clearcoatFactor),o.clearcoatTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatMap",o.clearcoatTexture)),o.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=o.clearcoatRoughnessFactor),o.clearcoatRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatRoughnessMap",o.clearcoatRoughnessTexture)),o.clearcoatNormalTexture!==void 0&&(r.push(n.assignTexture(t,"clearcoatNormalMap",o.clearcoatNormalTexture)),o.clearcoatNormalTexture.scale!==void 0)){let a=o.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new ze(a,a)}return Promise.all(r)}},Jl=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_DISPERSION}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=s.extensions[this.name];return t.dispersion=r.dispersion!==void 0?r.dispersion:0,Promise.resolve()}},Kl=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.iridescenceFactor!==void 0&&(t.iridescence=o.iridescenceFactor),o.iridescenceTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceMap",o.iridescenceTexture)),o.iridescenceIor!==void 0&&(t.iridescenceIOR=o.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),o.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=o.iridescenceThicknessMinimum),o.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=o.iridescenceThicknessMaximum),o.iridescenceThicknessTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceThicknessMap",o.iridescenceThicknessTexture)),Promise.all(r)}},$l=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_SHEEN}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[];t.sheenColor=new we(0,0,0),t.sheenRoughness=0,t.sheen=1;let o=s.extensions[this.name];if(o.sheenColorFactor!==void 0){let a=o.sheenColorFactor;t.sheenColor.setRGB(a[0],a[1],a[2],Pt)}return o.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=o.sheenRoughnessFactor),o.sheenColorTexture!==void 0&&r.push(n.assignTexture(t,"sheenColorMap",o.sheenColorTexture,pt)),o.sheenRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"sheenRoughnessMap",o.sheenRoughnessTexture)),Promise.all(r)}},jl=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.transmissionFactor!==void 0&&(t.transmission=o.transmissionFactor),o.transmissionTexture!==void 0&&r.push(n.assignTexture(t,"transmissionMap",o.transmissionTexture)),Promise.all(r)}},Ql=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_VOLUME}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];t.thickness=o.thicknessFactor!==void 0?o.thicknessFactor:0,o.thicknessTexture!==void 0&&r.push(n.assignTexture(t,"thicknessMap",o.thicknessTexture)),t.attenuationDistance=o.attenuationDistance||1/0;let a=o.attenuationColor||[1,1,1];return t.attenuationColor=new we().setRGB(a[0],a[1],a[2],Pt),Promise.all(r)}},ec=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_IOR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=s.extensions[this.name];return t.ior=r.ior!==void 0?r.ior:1.5,Promise.resolve()}},tc=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_SPECULAR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];t.specularIntensity=o.specularFactor!==void 0?o.specularFactor:1,o.specularTexture!==void 0&&r.push(n.assignTexture(t,"specularIntensityMap",o.specularTexture));let a=o.specularColorFactor||[1,1,1];return t.specularColor=new we().setRGB(a[0],a[1],a[2],Pt),o.specularColorTexture!==void 0&&r.push(n.assignTexture(t,"specularColorMap",o.specularColorTexture,pt)),Promise.all(r)}},nc=class{constructor(e){this.parser=e,this.name=Be.EXT_MATERIALS_BUMP}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return t.bumpScale=o.bumpFactor!==void 0?o.bumpFactor:1,o.bumpTexture!==void 0&&r.push(n.assignTexture(t,"bumpMap",o.bumpTexture)),Promise.all(r)}},ic=class{constructor(e){this.parser=e,this.name=Be.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Wt}extendMaterialParams(e,t){let n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();let r=[],o=s.extensions[this.name];return o.anisotropyStrength!==void 0&&(t.anisotropy=o.anisotropyStrength),o.anisotropyRotation!==void 0&&(t.anisotropyRotation=o.anisotropyRotation),o.anisotropyTexture!==void 0&&r.push(n.assignTexture(t,"anisotropyMap",o.anisotropyTexture)),Promise.all(r)}},sc=class{constructor(e){this.parser=e,this.name=Be.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,n=t.json,s=n.textures[e];if(!s.extensions||!s.extensions[this.name])return null;let r=s.extensions[this.name],o=t.options.ktx2Loader;if(!o){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,r.source,o)}},rc=class{constructor(e){this.parser=e,this.name=Be.EXT_TEXTURE_WEBP,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],a=s.images[o.source],l=n.textureLoader;if(a.uri){let c=n.options.manager.getHandler(a.uri);c!==null&&(l=c)}return this.detectSupport().then(function(c){if(c)return n.loadTextureImage(e,o.source,l);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},oc=class{constructor(e){this.parser=e,this.name=Be.EXT_TEXTURE_AVIF,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;let o=r.extensions[t],a=s.images[o.source],l=n.textureLoader;if(a.uri){let c=n.options.manager.getHandler(a.uri);c!==null&&(l=c)}return this.detectSupport().then(function(c){if(c)return n.loadTextureImage(e,o.source,l);if(s.extensionsRequired&&s.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},ac=class{constructor(e){this.name=Be.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){let t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){let s=n.extensions[this.name],r=this.parser.getDependency("buffer",s.buffer),o=this.parser.options.meshoptDecoder;if(!o||!o.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return r.then(function(a){let l=s.byteOffset||0,c=s.byteLength||0,h=s.count,u=s.byteStride,d=new Uint8Array(a,l,c);return o.decodeGltfBufferAsync?o.decodeGltfBufferAsync(h,u,d,s.mode,s.filter).then(function(f){return f.buffer}):o.ready.then(function(){let f=new ArrayBuffer(h*u);return o.decodeGltfBuffer(new Uint8Array(f),h,u,d,s.mode,s.filter),f})})}else return null}},lc=class{constructor(e){this.name=Be.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;let s=t.meshes[n.mesh];for(let c of s.primitives)if(c.mode!==Qt.TRIANGLES&&c.mode!==Qt.TRIANGLE_STRIP&&c.mode!==Qt.TRIANGLE_FAN&&c.mode!==void 0)return null;let o=n.extensions[this.name].attributes,a=[],l={};for(let c in o)a.push(this.parser.getDependency("accessor",o[c]).then(h=>(l[c]=h,l[c])));return a.length<1?null:(a.push(this.parser.createNodeMesh(e)),Promise.all(a).then(c=>{let h=c.pop(),u=h.isGroup?h.children:[h],d=c[0].count,f=[];for(let g of u){let _=new De,m=new P,p=new dn,w=new P(1,1,1),S=new co(g.geometry,g.material,d);for(let y=0;y<d;y++)l.TRANSLATION&&m.fromBufferAttribute(l.TRANSLATION,y),l.ROTATION&&p.fromBufferAttribute(l.ROTATION,y),l.SCALE&&w.fromBufferAttribute(l.SCALE,y),S.setMatrixAt(y,_.compose(m,p,w));for(let y in l)if(y==="_COLOR_0"){let U=l[y];S.instanceColor=new Li(U.array,U.itemSize,U.normalized)}else y!=="TRANSLATION"&&y!=="ROTATION"&&y!=="SCALE"&&g.geometry.setAttribute(y,l[y]);ht.prototype.copy.call(S,g),this.parser.assignFinalMaterial(S),f.push(S)}return h.isGroup?(h.clear(),h.add(...f),h):f[0]}))}},$u="glTF",ir=12,Yu={JSON:1313821514,BIN:5130562},cc=class{constructor(e){this.name=Be.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,ir),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==$u)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");let s=this.header.length-ir,r=new DataView(e,ir),o=0;for(;o<s;){let a=r.getUint32(o,!0);o+=4;let l=r.getUint32(o,!0);if(o+=4,l===Yu.JSON){let c=new Uint8Array(e,ir+o,a);this.content=n.decode(c)}else if(l===Yu.BIN){let c=ir+o;this.body=e.slice(c,c+a)}o+=a}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}},hc=class{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=Be.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let n=this.json,s=this.dracoLoader,r=e.extensions[this.name].bufferView,o=e.extensions[this.name].attributes,a={},l={},c={};for(let h in o){let u=pc[h]||h.toLowerCase();a[u]=o[h]}for(let h in e.attributes){let u=pc[h]||h.toLowerCase();if(o[h]!==void 0){let d=n.accessors[e.attributes[h]],f=Ms[d.componentType];c[u]=f.name,l[u]=d.normalized===!0}}return t.getDependency("bufferView",r).then(function(h){return new Promise(function(u,d){s.decodeDracoFile(h,function(f){for(let g in f.attributes){let _=f.attributes[g],m=l[g];m!==void 0&&(_.normalized=m)}u(f)},a,c,Pt,d)})})}},uc=class{constructor(){this.name=Be.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}},dc=class{constructor(){this.name=Be.KHR_MESH_QUANTIZATION}},Ro=class extends hi{constructor(e,t,n,s){super(e,t,n,s)}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s*3+s;for(let o=0;o!==s;o++)t[o]=n[r+o];return t}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=a*2,c=a*3,h=s-t,u=(n-t)/h,d=u*u,f=d*u,g=e*c,_=g-c,m=-2*f+3*d,p=f-d,w=1-m,S=p-d+u;for(let y=0;y!==a;y++){let U=o[_+y+a],E=o[_+y+l]*h,T=o[g+y+a],N=o[g+y]*h;r[y]=w*U+S*E+m*T+p*N}return r}},tv=new dn,fc=class extends Ro{interpolate_(e,t,n,s){let r=super.interpolate_(e,t,n,s);return tv.fromArray(r).normalize().toArray(r),r}},Qt={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},Ms={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Zu={9728:It,9729:Ft,9984:Cl,9985:ks,9986:es,9987:gn},Ju={33071:On,33648:Gs,10497:Ii},Vl={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},pc={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},pi={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},nv={CUBICSPLINE:void 0,LINEAR:ds,STEP:us},Gl={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function iv(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new _s({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:vn})),i.DefaultMaterial}function Di(i,e,t){for(let n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function qn(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function sv(i,e,t){let n=!1,s=!1,r=!1;for(let c=0,h=e.length;c<h;c++){let u=e[c];if(u.POSITION!==void 0&&(n=!0),u.NORMAL!==void 0&&(s=!0),u.COLOR_0!==void 0&&(r=!0),n&&s&&r)break}if(!n&&!s&&!r)return Promise.resolve(i);let o=[],a=[],l=[];for(let c=0,h=e.length;c<h;c++){let u=e[c];if(n){let d=u.POSITION!==void 0?t.getDependency("accessor",u.POSITION):i.attributes.position;o.push(d)}if(s){let d=u.NORMAL!==void 0?t.getDependency("accessor",u.NORMAL):i.attributes.normal;a.push(d)}if(r){let d=u.COLOR_0!==void 0?t.getDependency("accessor",u.COLOR_0):i.attributes.color;l.push(d)}}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(l)]).then(function(c){let h=c[0],u=c[1],d=c[2];return n&&(i.morphAttributes.position=h),s&&(i.morphAttributes.normal=u),r&&(i.morphAttributes.color=d),i.morphTargetsRelative=!0,i})}function rv(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){let t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,s=t.length;n<s;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function ov(i){let e,t=i.extensions&&i.extensions[Be.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+Wl(t.attributes):e=i.indices+":"+Wl(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,s=i.targets.length;n<s;n++)e+=":"+Wl(i.targets[n]);return e}function Wl(i){let e="",t=Object.keys(i).sort();for(let n=0,s=t.length;n<s;n++)e+=t[n]+":"+i[t[n]]+";";return e}function mc(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function av(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":i.search(/\.ktx2($|\?)/i)>0||i.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}var lv=new De,gc=class{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new ev,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,s=-1,r=!1,o=-1;if(typeof navigator<"u"){let a=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(a)===!0;let l=a.match(/Version\/(\d+)/);s=n&&l?parseInt(l[1],10):-1,r=a.indexOf("Firefox")>-1,o=r?a.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&s<17||r&&o<98?this.textureLoader=new vo(this.options.manager):this.textureLoader=new So(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new Qs(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let n=this,s=this.json,r=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(o){return o._markDefs&&o._markDefs()}),Promise.all(this._invokeAll(function(o){return o.beforeRoot&&o.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(o){let a={scene:o[0][s.scene||0],scenes:o[0],animations:o[1],cameras:o[2],asset:s.asset,parser:n,userData:{}};return Di(r,a,s),qn(a,s),Promise.all(n._invokeAll(function(l){return l.afterRoot&&l.afterRoot(a)})).then(function(){for(let l of a.scenes)l.updateMatrixWorld();e(a)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let s=0,r=t.length;s<r;s++){let o=t[s].joints;for(let a=0,l=o.length;a<l;a++)e[o[a]].isBone=!0}for(let s=0,r=e.length;s<r;s++){let o=e[s];o.mesh!==void 0&&(this._addNodeRef(this.meshCache,o.mesh),o.skin!==void 0&&(n[o.mesh].isSkinnedMesh=!0)),o.camera!==void 0&&this._addNodeRef(this.cameraCache,o.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;let s=n.clone(),r=(o,a)=>{let l=this.associations.get(o);l!=null&&this.associations.set(a,l);for(let[c,h]of o.children.entries())r(h,a.children[c])};return r(n,s),s.name+="_instance_"+e.uses[t]++,s}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){let s=e(t[n]);if(s)return s}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let n=[];for(let s=0;s<t.length;s++){let r=e(t[s]);r&&n.push(r)}return n}getDependency(e,t){let n=e+":"+t,s=this.cache.get(n);if(!s){switch(e){case"scene":s=this.loadScene(t);break;case"node":s=this._invokeOne(function(r){return r.loadNode&&r.loadNode(t)});break;case"mesh":s=this._invokeOne(function(r){return r.loadMesh&&r.loadMesh(t)});break;case"accessor":s=this.loadAccessor(t);break;case"bufferView":s=this._invokeOne(function(r){return r.loadBufferView&&r.loadBufferView(t)});break;case"buffer":s=this.loadBuffer(t);break;case"material":s=this._invokeOne(function(r){return r.loadMaterial&&r.loadMaterial(t)});break;case"texture":s=this._invokeOne(function(r){return r.loadTexture&&r.loadTexture(t)});break;case"skin":s=this.loadSkin(t);break;case"animation":s=this._invokeOne(function(r){return r.loadAnimation&&r.loadAnimation(t)});break;case"camera":s=this.loadCamera(t);break;default:if(s=this._invokeOne(function(r){return r!=this&&r.getDependency&&r.getDependency(e,t)}),!s)throw new Error("Unknown type: "+e);break}this.cache.add(n,s)}return s}getDependencies(e){let t=this.cache.get(e);if(!t){let n=this,s=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(s.map(function(r,o){return n.getDependency(e,o)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[Be.KHR_BINARY_GLTF].body);let s=this.options;return new Promise(function(r,o){n.load(fi.resolveURL(t.uri,s.path),r,void 0,function(){o(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){let s=t.byteLength||0,r=t.byteOffset||0;return n.slice(r,r+s)})}loadAccessor(e){let t=this,n=this.json,s=this.json.accessors[e];if(s.bufferView===void 0&&s.sparse===void 0){let o=Vl[s.type],a=Ms[s.componentType],l=s.normalized===!0,c=new a(s.count*o);return Promise.resolve(new mt(c,o,l))}let r=[];return s.bufferView!==void 0?r.push(this.getDependency("bufferView",s.bufferView)):r.push(null),s.sparse!==void 0&&(r.push(this.getDependency("bufferView",s.sparse.indices.bufferView)),r.push(this.getDependency("bufferView",s.sparse.values.bufferView))),Promise.all(r).then(function(o){let a=o[0],l=Vl[s.type],c=Ms[s.componentType],h=c.BYTES_PER_ELEMENT,u=h*l,d=s.byteOffset||0,f=s.bufferView!==void 0?n.bufferViews[s.bufferView].byteStride:void 0,g=s.normalized===!0,_,m;if(f&&f!==u){let p=Math.floor(d/f),w="InterleavedBuffer:"+s.bufferView+":"+s.componentType+":"+p+":"+s.count,S=t.cache.get(w);S||(_=new c(a,p*f,s.count*f/h),S=new Zs(_,f/h),t.cache.add(w,S)),m=new Js(S,l,d%f/h,g)}else a===null?_=new c(s.count*l):_=new c(a,d,s.count*l),m=new mt(_,l,g);if(s.sparse!==void 0){let p=Vl.SCALAR,w=Ms[s.sparse.indices.componentType],S=s.sparse.indices.byteOffset||0,y=s.sparse.values.byteOffset||0,U=new w(o[1],S,s.sparse.count*p),E=new c(o[2],y,s.sparse.count*l);a!==null&&(m=new mt(m.array.slice(),m.itemSize,m.normalized)),m.normalized=!1;for(let T=0,N=U.length;T<N;T++){let b=U[T];if(m.setX(b,E[T*l]),l>=2&&m.setY(b,E[T*l+1]),l>=3&&m.setZ(b,E[T*l+2]),l>=4&&m.setW(b,E[T*l+3]),l>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}m.normalized=g}return m})}loadTexture(e){let t=this.json,n=this.options,r=t.textures[e].source,o=t.images[r],a=this.textureLoader;if(o.uri){let l=n.manager.getHandler(o.uri);l!==null&&(a=l)}return this.loadTextureImage(e,r,a)}loadTextureImage(e,t,n){let s=this,r=this.json,o=r.textures[e],a=r.images[t],l=(a.uri||a.bufferView)+":"+o.sampler;if(this.textureCache[l])return this.textureCache[l];let c=this.loadImageSource(t,n).then(function(h){h.flipY=!1,h.name=o.name||a.name||"",h.name===""&&typeof a.uri=="string"&&a.uri.startsWith("data:image/")===!1&&(h.name=a.uri);let d=(r.samplers||{})[o.sampler]||{};return h.magFilter=Zu[d.magFilter]||Ft,h.minFilter=Zu[d.minFilter]||gn,h.wrapS=Ju[d.wrapS]||Ii,h.wrapT=Ju[d.wrapT]||Ii,h.generateMipmaps=!h.isCompressedTexture&&h.minFilter!==It&&h.minFilter!==Ft,s.associations.set(h,{textures:e}),h}).catch(function(){return null});return this.textureCache[l]=c,c}loadImageSource(e,t){let n=this,s=this.json,r=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(u=>u.clone());let o=s.images[e],a=self.URL||self.webkitURL,l=o.uri||"",c=!1;if(o.bufferView!==void 0)l=n.getDependency("bufferView",o.bufferView).then(function(u){c=!0;let d=new Blob([u],{type:o.mimeType});return l=a.createObjectURL(d),l});else if(o.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");let h=Promise.resolve(l).then(function(u){return new Promise(function(d,f){let g=d;t.isImageBitmapLoader===!0&&(g=function(_){let m=new St(_);m.needsUpdate=!0,d(m)}),t.load(fi.resolveURL(u,r.path),g,void 0,f)})}).then(function(u){return c===!0&&a.revokeObjectURL(l),qn(u,o),u.userData.mimeType=o.mimeType||av(o.uri),u}).catch(function(u){throw console.error("THREE.GLTFLoader: Couldn't load texture",l),u});return this.sourceCache[e]=h,h}assignTexture(e,t,n,s){let r=this;return this.getDependency("texture",n.index).then(function(o){if(!o)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(o=o.clone(),o.channel=n.texCoord),r.extensions[Be.KHR_TEXTURE_TRANSFORM]){let a=n.extensions!==void 0?n.extensions[Be.KHR_TEXTURE_TRANSFORM]:void 0;if(a){let l=r.associations.get(o);o=r.extensions[Be.KHR_TEXTURE_TRANSFORM].extendTexture(o,a),r.associations.set(o,l)}}return s!==void 0&&(o.colorSpace=s),e[t]=o,o})}assignFinalMaterial(e){let t=e.geometry,n=e.material,s=t.attributes.tangent===void 0,r=t.attributes.color!==void 0,o=t.attributes.normal===void 0;if(e.isPoints){let a="PointsMaterial:"+n.uuid,l=this.cache.get(a);l||(l=new js,Gt.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,l.sizeAttenuation=!1,this.cache.add(a,l)),n=l}else if(e.isLine){let a="LineBasicMaterial:"+n.uuid,l=this.cache.get(a);l||(l=new $s,Gt.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,this.cache.add(a,l)),n=l}if(s||r||o){let a="ClonedMaterial:"+n.uuid+":";s&&(a+="derivative-tangents:"),r&&(a+="vertex-colors:"),o&&(a+="flat-shading:");let l=this.cache.get(a);l||(l=n.clone(),r&&(l.vertexColors=!0),o&&(l.flatShading=!0),s&&(l.normalScale&&(l.normalScale.y*=-1),l.clearcoatNormalScale&&(l.clearcoatNormalScale.y*=-1)),this.cache.add(a,l),this.associations.set(l,this.associations.get(n))),n=l}e.material=n}getMaterialType(){return _s}loadMaterial(e){let t=this,n=this.json,s=this.extensions,r=n.materials[e],o,a={},l=r.extensions||{},c=[];if(l[Be.KHR_MATERIALS_UNLIT]){let u=s[Be.KHR_MATERIALS_UNLIT];o=u.getMaterialType(),c.push(u.extendParams(a,r,t))}else{let u=r.pbrMetallicRoughness||{};if(a.color=new we(1,1,1),a.opacity=1,Array.isArray(u.baseColorFactor)){let d=u.baseColorFactor;a.color.setRGB(d[0],d[1],d[2],Pt),a.opacity=d[3]}u.baseColorTexture!==void 0&&c.push(t.assignTexture(a,"map",u.baseColorTexture,pt)),a.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,a.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0&&(c.push(t.assignTexture(a,"metalnessMap",u.metallicRoughnessTexture)),c.push(t.assignTexture(a,"roughnessMap",u.metallicRoughnessTexture))),o=this._invokeOne(function(d){return d.getMaterialType&&d.getMaterialType(e)}),c.push(Promise.all(this._invokeAll(function(d){return d.extendMaterialParams&&d.extendMaterialParams(e,a)})))}r.doubleSided===!0&&(a.side=ln);let h=r.alphaMode||Gl.OPAQUE;if(h===Gl.BLEND?(a.transparent=!0,a.depthWrite=!1):(a.transparent=!1,h===Gl.MASK&&(a.alphaTest=r.alphaCutoff!==void 0?r.alphaCutoff:.5)),r.normalTexture!==void 0&&o!==yn&&(c.push(t.assignTexture(a,"normalMap",r.normalTexture)),a.normalScale=new ze(1,1),r.normalTexture.scale!==void 0)){let u=r.normalTexture.scale;a.normalScale.set(u,u)}if(r.occlusionTexture!==void 0&&o!==yn&&(c.push(t.assignTexture(a,"aoMap",r.occlusionTexture)),r.occlusionTexture.strength!==void 0&&(a.aoMapIntensity=r.occlusionTexture.strength)),r.emissiveFactor!==void 0&&o!==yn){let u=r.emissiveFactor;a.emissive=new we().setRGB(u[0],u[1],u[2],Pt)}return r.emissiveTexture!==void 0&&o!==yn&&c.push(t.assignTexture(a,"emissiveMap",r.emissiveTexture,pt)),Promise.all(c).then(function(){let u=new o(a);return r.name&&(u.name=r.name),qn(u,r),t.associations.set(u,{materials:e}),r.extensions&&Di(s,u,r),u})}createUniqueName(e){let t=st.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,n=this.extensions,s=this.primitiveCache;function r(a){return n[Be.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(a,t).then(function(l){return Ku(l,a,t)})}let o=[];for(let a=0,l=e.length;a<l;a++){let c=e[a],h=ov(c),u=s[h];if(u)o.push(u.promise);else{let d;c.extensions&&c.extensions[Be.KHR_DRACO_MESH_COMPRESSION]?d=r(c):d=Ku(new $t,c,t),s[h]={primitive:c,promise:d},o.push(d)}}return Promise.all(o)}loadMesh(e){let t=this,n=this.json,s=this.extensions,r=n.meshes[e],o=r.primitives,a=[];for(let l=0,c=o.length;l<c;l++){let h=o[l].material===void 0?iv(this.cache):this.getDependency("material",o[l].material);a.push(h)}return a.push(t.loadGeometries(o)),Promise.all(a).then(function(l){let c=l.slice(0,l.length-1),h=l[l.length-1],u=[];for(let f=0,g=h.length;f<g;f++){let _=h[f],m=o[f],p,w=c[f];if(m.mode===Qt.TRIANGLES||m.mode===Qt.TRIANGLE_STRIP||m.mode===Qt.TRIANGLE_FAN||m.mode===void 0)p=r.isSkinnedMesh===!0?new oo(_,w):new Ct(_,w),p.isSkinnedMesh===!0&&p.normalizeSkinWeights(),m.mode===Qt.TRIANGLE_STRIP?p.geometry=Hl(p.geometry,wo):m.mode===Qt.TRIANGLE_FAN&&(p.geometry=Hl(p.geometry,nr));else if(m.mode===Qt.LINES)p=new fo(_,w);else if(m.mode===Qt.LINE_STRIP)p=new gs(_,w);else if(m.mode===Qt.LINE_LOOP)p=new po(_,w);else if(m.mode===Qt.POINTS)p=new mo(_,w);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(p.geometry.morphAttributes).length>0&&rv(p,r),p.name=t.createUniqueName(r.name||"mesh_"+e),qn(p,r),m.extensions&&Di(s,p,m),t.assignFinalMaterial(p),u.push(p)}for(let f=0,g=u.length;f<g;f++)t.associations.set(u[f],{meshes:e,primitives:f});if(u.length===1)return r.extensions&&Di(s,u[0],r),u[0];let d=new _n;r.extensions&&Di(s,d,r),t.associations.set(d,{meshes:e});for(let f=0,g=u.length;f<g;f++)d.add(u[f]);return d})}loadCamera(e){let t,n=this.json.cameras[e],s=n[n.type];if(!s){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Mt(Ou.radToDeg(s.yfov),s.aspectRatio||1,s.znear||1,s.zfar||2e6):n.type==="orthographic"&&(t=new ci(-s.xmag,s.xmag,s.ymag,-s.ymag,s.znear,s.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),qn(t,n),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],n=[];for(let s=0,r=t.joints.length;s<r;s++)n.push(this._loadNodeShallow(t.joints[s]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(s){let r=s.pop(),o=s,a=[],l=[];for(let c=0,h=o.length;c<h;c++){let u=o[c];if(u){a.push(u);let d=new De;r!==null&&d.fromArray(r.array,c*16),l.push(d)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[c])}return new lo(a,l)})}loadAnimation(e){let t=this.json,n=this,s=t.animations[e],r=s.name?s.name:"animation_"+e,o=[],a=[],l=[],c=[],h=[];for(let u=0,d=s.channels.length;u<d;u++){let f=s.channels[u],g=s.samplers[f.sampler],_=f.target,m=_.node,p=s.parameters!==void 0?s.parameters[g.input]:g.input,w=s.parameters!==void 0?s.parameters[g.output]:g.output;_.node!==void 0&&(o.push(this.getDependency("node",m)),a.push(this.getDependency("accessor",p)),l.push(this.getDependency("accessor",w)),c.push(g),h.push(_))}return Promise.all([Promise.all(o),Promise.all(a),Promise.all(l),Promise.all(c),Promise.all(h)]).then(function(u){let d=u[0],f=u[1],g=u[2],_=u[3],m=u[4],p=[];for(let w=0,S=d.length;w<S;w++){let y=d[w],U=f[w],E=g[w],T=_[w],N=m[w];if(y===void 0)continue;y.updateMatrix&&y.updateMatrix();let b=n._createAnimationTracks(y,U,E,T,N);if(b)for(let M=0;M<b.length;M++)p.push(b[M])}return new _o(r,void 0,p)})}createNodeMesh(e){let t=this.json,n=this,s=t.nodes[e];return s.mesh===void 0?null:n.getDependency("mesh",s.mesh).then(function(r){let o=n._getNodeRef(n.meshCache,s.mesh,r);return s.weights!==void 0&&o.traverse(function(a){if(a.isMesh)for(let l=0,c=s.weights.length;l<c;l++)a.morphTargetInfluences[l]=s.weights[l]}),o})}loadNode(e){let t=this.json,n=this,s=t.nodes[e],r=n._loadNodeShallow(e),o=[],a=s.children||[];for(let c=0,h=a.length;c<h;c++)o.push(n.getDependency("node",a[c]));let l=s.skin===void 0?Promise.resolve(null):n.getDependency("skin",s.skin);return Promise.all([r,Promise.all(o),l]).then(function(c){let h=c[0],u=c[1],d=c[2];d!==null&&h.traverse(function(f){f.isSkinnedMesh&&f.bind(d,lv)});for(let f=0,g=u.length;f<g;f++)h.add(u[f]);return h})}_loadNodeShallow(e){let t=this.json,n=this.extensions,s=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let r=t.nodes[e],o=r.name?s.createUniqueName(r.name):"",a=[],l=s._invokeOne(function(c){return c.createNodeMesh&&c.createNodeMesh(e)});return l&&a.push(l),r.camera!==void 0&&a.push(s.getDependency("camera",r.camera).then(function(c){return s._getNodeRef(s.cameraCache,r.camera,c)})),s._invokeAll(function(c){return c.createNodeAttachment&&c.createNodeAttachment(e)}).forEach(function(c){a.push(c)}),this.nodeCache[e]=Promise.all(a).then(function(c){let h;if(r.isBone===!0?h=new Ks:c.length>1?h=new _n:c.length===1?h=c[0]:h=new ht,h!==c[0])for(let u=0,d=c.length;u<d;u++)h.add(c[u]);if(r.name&&(h.userData.name=r.name,h.name=o),qn(h,r),r.extensions&&Di(n,h,r),r.matrix!==void 0){let u=new De;u.fromArray(r.matrix),h.applyMatrix4(u)}else r.translation!==void 0&&h.position.fromArray(r.translation),r.rotation!==void 0&&h.quaternion.fromArray(r.rotation),r.scale!==void 0&&h.scale.fromArray(r.scale);return s.associations.has(h)||s.associations.set(h,{}),s.associations.get(h).nodes=e,h}),this.nodeCache[e]}loadScene(e){let t=this.extensions,n=this.json.scenes[e],s=this,r=new _n;n.name&&(r.name=s.createUniqueName(n.name)),qn(r,n),n.extensions&&Di(t,r,n);let o=n.nodes||[],a=[];for(let l=0,c=o.length;l<c;l++)a.push(s.getDependency("node",o[l]));return Promise.all(a).then(function(l){for(let h=0,u=l.length;h<u;h++)r.add(l[h]);let c=h=>{let u=new Map;for(let[d,f]of s.associations)(d instanceof Gt||d instanceof St)&&u.set(d,f);return h.traverse(d=>{let f=s.associations.get(d);f!=null&&u.set(d,f)}),u};return s.associations=c(r),r})}_createAnimationTracks(e,t,n,s,r){let o=[],a=e.name?e.name:e.uuid,l=[];pi[r.path]===pi.weights?e.traverse(function(d){d.morphTargetInfluences&&l.push(d.name?d.name:d.uuid)}):l.push(a);let c;switch(pi[r.path]){case pi.weights:c=Vn;break;case pi.rotation:c=Gn;break;case pi.position:case pi.scale:c=Wn;break;default:n.itemSize===1?c=Vn:c=Wn;break}let h=s.interpolation!==void 0?nv[s.interpolation]:ds,u=this._getArrayFromAccessor(n);for(let d=0,f=l.length;d<f;d++){let g=new c(l[d]+"."+pi[r.path],t.array,u,h);s.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(g),o.push(g)}return o}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let n=mc(t.constructor),s=new Float32Array(t.length);for(let r=0,o=t.length;r<o;r++)s[r]=t[r]*n;t=s}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){let s=this instanceof Gn?fc:Ro;return new s(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}};function cv(i,e,t){let n=e.attributes,s=new Bt;if(n.POSITION!==void 0){let a=t.json.accessors[n.POSITION],l=a.min,c=a.max;if(l!==void 0&&c!==void 0){if(s.set(new P(l[0],l[1],l[2]),new P(c[0],c[1],c[2])),a.normalized){let h=mc(Ms[a.componentType]);s.min.multiplyScalar(h),s.max.multiplyScalar(h)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;let r=e.targets;if(r!==void 0){let a=new P,l=new P;for(let c=0,h=r.length;c<h;c++){let u=r[c];if(u.POSITION!==void 0){let d=t.json.accessors[u.POSITION],f=d.min,g=d.max;if(f!==void 0&&g!==void 0){if(l.setX(Math.max(Math.abs(f[0]),Math.abs(g[0]))),l.setY(Math.max(Math.abs(f[1]),Math.abs(g[1]))),l.setZ(Math.max(Math.abs(f[2]),Math.abs(g[2]))),d.normalized){let _=mc(Ms[d.componentType]);l.multiplyScalar(_)}a.max(l)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}s.expandByVector(a)}i.boundingBox=s;let o=new Vt;s.getCenter(o.center),o.radius=s.min.distanceTo(s.max)/2,i.boundingSphere=o}function Ku(i,e,t){let n=e.attributes,s=[];function r(o,a){return t.getDependency("accessor",o).then(function(l){i.setAttribute(a,l)})}for(let o in n){let a=pc[o]||o.toLowerCase();a in i.attributes||s.push(r(n[o],a))}if(e.indices!==void 0&&!i.index){let o=t.getDependency("accessor",e.indices).then(function(a){i.setIndex(a)});s.push(o)}return ke.workingColorSpace!==Pt&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${ke.workingColorSpace}" not supported.`),qn(i,e),cv(i,e,t),Promise.all(s).then(function(){return e.targets!==void 0?sv(i,e.targets,t):i})}function hv(i){return i<.5?2*i*i:-1+(4-2*i)*i}function ju(i){let e=Array.isArray(i)?i:i?.frames;return!Array.isArray(e)||e.length===0?[]:e.map(t=>({value:t?.value&&typeof t.value=="object"?t.value:{},duration:Number.isFinite(t?.duration)&&t.duration>0?t.duration:.8}))}function Qu(i,{requestFrame:e=requestAnimationFrame,cancelFrame:t=cancelAnimationFrame,setTimer:n=setTimeout,clearTimer:s=clearTimeout,now:r=()=>performance.now(),maxPendingMotions:o=2,maxPendingAgeMs:a=6e3,onComplete:l=()=>{}}={}){let c=[],h=null,u=null,d=!1,f=[],g=null;function _({reset:S=!1}={}){d=!1,c=[],f=[],g=null,h!==null&&s(h),u!==null&&t(u),h=null,u=null,S&&i.reset()}function m(){if(u!==null&&t(u),u=null,h=null,d&&c.length===0){f=f.filter(R=>r()-R.receivedAt<=a);let M=f.shift();c=M?.frames||[],g=M?.key??null}if(!d||c.length===0){d=!1,l();return}let S=c.shift(),y=S.duration*1e3,U=Math.max(1,Math.min(y*.35,150)),E=i.capture(),T=i.createTargets(S.value),N=r();function b(){let M=r()-N,R=Math.min(M/U,1);i.interpolate(E,T,hv(R)),R<1&&d?u=e(b):u=null}b(),h=n(m,y)}function p(S){let y=ju(S);return y.length===0?!1:(_(),c=y,d=!0,m(),!0)}function w(S,{key:y=null}={}){let U=ju(S);if(U.length===0||y!==null&&(y===g||f.some(E=>E.key===y)))return!1;if(!d)c=U,g=y,d=!0,m();else for(f=f.filter(E=>r()-E.receivedAt<=a),f.push({frames:U,key:y,receivedAt:r()});f.length>o;)f.shift();return!0}return{play:p,enqueue:w,stop:_,get isPlaying(){return d}}}function Co(i){let e=new Set;function t(n){!n?.dispose||e.has(n)||(e.add(n),n.dispose())}i?.traverse(n=>{t(n.geometry),t(n.skeleton);let s=Array.isArray(n.material)?n.material:[n.material];for(let r of s)if(r){for(let o of Object.values(r))o?.isTexture&&t(o);t(r)}})}async function ed(i,e){let t=await fetch(chrome.runtime.getURL("avatar/model.glb"),{signal:e});if(!t.ok)throw new Error("reviewModelError");let n=await t.arrayBuffer(),s=await $n(n);e.throwIfAborted();let o=(await new Promise((l,c)=>{let h=()=>c(e.reason);e.addEventListener("abort",h,{once:!0}),new Eo().parseAsync(n,chrome.runtime.getURL("avatar/")).then(u=>{e.removeEventListener("abort",h),e.aborted?Co(u.scene):l(u)},u=>{e.removeEventListener("abort",h),c(u)})})).scene,a;try{let R=function($=T){if(M||S.isContextLost())throw new Error("reviewRenderError");T=$,w.position.copy(m),T==="front"?w.position.z+=f.y*3:w.position.x+=f.y*(T==="right"?-3:3),w.lookAt(m),a.render(h,w)},W=function($){b!==null&&cancelAnimationFrame(b),b=null;let z=N;N=null,$?z?.reject($):z?.resolve()},V=function(){k.stop({reset:!0}),W(new globalThis.DOMException("Aborted","AbortError"))},K=function($,z){return V(),z.throwIfAborted(),z.addEventListener("abort",V,{once:!0}),new Promise((ne,ue)=>{N={resolve:ne,reject:ue};function xe(){try{R(),k.isPlaying&&(b=requestAnimationFrame(xe))}catch(Fe){k.stop(),W(Fe)}}k.play($),xe()}).finally(()=>z.removeEventListener("abort",V))},G=function(){V(),M=!0,Co(o),a.dispose()};e.throwIfAborted();let l=Wc(o);if(!l.isSigningReady)throw new Error("reviewMissingBones");let c=dr(l),h=new ro;h.background=new we("#e9f2f8"),h.add(o),h.add(new xo(16777215,6713472,2.2));let u=new xs(16777215,2.5);u.position.set(3,5,4),h.add(u),o.updateMatrixWorld(!0);let d=new Bt().setFromObject(o),f=d.getSize(new P),g=d.getCenter(new P);if(!Number.isFinite(f.y)||f.y<=0)throw new Error("reviewModelError");let _=Math.max(f.y*.9,f.x*1.1*Yt.height/Yt.width),m=g.clone();m.y+=f.y*.17;let p=_*Yt.width/Yt.height/2,w=new ci(-p,p,_/2,-_/2,f.y*.01,f.y*20);a=new so({canvas:i,antialias:!0,preserveDrawingBuffer:!0}),a.setPixelRatio(1),a.setSize(Yt.width,Yt.height,!1),a.outputColorSpace=pt;let S=a.getContext(),y=S.getExtension("WEBGL_debug_renderer_info"),U={protocol:xi,modelHash:s,binding:c,threeRevision:"170",cell:Yt,views:Bi,camera:{span:_,target:m.toArray()},userAgent:navigator.userAgent,renderer:S.getParameter(y?y.UNMASKED_RENDERER_WEBGL:S.RENDERER),vendor:S.getParameter(y?y.UNMASKED_VENDOR_WEBGL:S.VENDOR)},E=await $n(U);e.throwIfAborted();let T="front",N=null,b=null,M=!1,k=Qu(l,{onComplete:()=>{try{R(),W()}catch($){W($)}}});return R(),{rig:l,environment:U,environmentHash:E,render:R,play:K,stop:V,dispose:G,canvas:i}}catch(l){throw Co(o),a?.dispose(),l}}async function td(i,e,t,n){let s=document.createElement("canvas");s.width=Yt.width*Bi.length,s.height=Yt.height*t.length;let r=s.getContext("2d",{willReadFrequently:!0});try{i.stop();for(let[a,l]of t.entries()){n.throwIfAborted(),i.rig.applyPose(e[l].value);for(let[c,h]of Bi.entries())i.render(h),r.drawImage(i.canvas,c*Yt.width,a*Yt.height);await new Promise(c=>{requestAnimationFrame(c)})}n.throwIfAborted();let o=await new Promise(a=>{s.toBlob(a,"image/png")});if(!o)throw new Error("reviewRenderError");return{image:o,width:s.width,height:s.height}}finally{s.width=s.height=0,i.rig.reset(),i.render("front")}}var nd={enabled:!0,sourceLanguage:"auto",targetSignLanguage:"csl",avatarStyle:"default",avatarSize:260,avatarPosition:"bottom-right",avatarOpacity:.9,enableAutoDetect:!0,enableSubtitles:!0,voiceVolume:"medium",speed:1,showAvatar:!0,uiLocale:"auto"},id="signbridge_config";async function sd(){try{if(typeof chrome<"u"&&chrome.storage){let i=await chrome.storage.sync.get(id);return{...nd,...i[id]}}}catch{}return{...nd}}var Io={"zh-CN":{batchTitle:"\u672C\u6279\u8865\u8BCD\u6E05\u5355 \xB7 \u6700\u591A 8 \u4E2A",batchManual:"\u624B\u52A8\u52A0\u5165\u5B8C\u6574\u8BCD\u7EC4\uFF08\u53EF\u9009\uFF0C\u907F\u514D\u5206\u8BCD\u8BEF\u62C6\uFF09",batchInvalidWord:"\u8BF7\u8F93\u5165 1\u2013100 \u4E2A\u5B57\u7B26\u7684\u6709\u6548\u8BCD\u8BED\u6216\u8BCD\u7EC4\uFF0C\u4E0D\u80FD\u53EA\u6709\u7A7A\u767D\u6216\u6807\u70B9\u3002",batchIntro:"\u5728\u5206\u6790\u7ED3\u679C\u4E2D\u6311\u9009\u9AD8\u9891\u7F3A\u8BCD\u52A0\u5165\u6E05\u5355\u3002\u5148\u5236\u4F5C\u5E76\u4FDD\u5B58\u8349\u7A3F\uFF0C\u518D\u53BB\u201C\u52A8\u4F5C\u9A8C\u6536\u201D\u68C0\u67E5\uFF0C\u6700\u540E\u5728\u7F16\u8F91\u5668\u6216\u5F55\u5236\u5DE5\u5177\u4E2D\u4EBA\u5DE5\u786E\u8BA4\u542F\u7528\u3002\u53EF\u5339\u914D\u53EA\u8868\u793A\u8BCD\u5E93\u6709\u5BF9\u5E94\u6570\u636E\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u542B\u4E49\u6B63\u786E\uFF1B\u6B64\u6E05\u5355\u4E0D\u4F1A\u751F\u6210\u3001\u4FEE\u6539\u6216\u81EA\u52A8\u542F\u7528\u52A8\u4F5C\u3002",batchAdd:"\u52A0\u5165\u672C\u6279",batchRefresh:"\u5237\u65B0\u8865\u8BCD\u72B6\u6001",batchExport:"\u4E0B\u8F7D\u8865\u8BCD\u8FDB\u5EA6 JSON",batchClear:"\u6E05\u7A7A\u672C\u6279\u6E05\u5355",batchClearConfirm:"\u53EA\u6E05\u7A7A\u8865\u8BCD\u6E05\u5355\uFF1F\u4E0D\u4F1A\u5220\u9664\u4EFB\u4F55\u52A8\u4F5C\u6216\u89C6\u89C9\u57FA\u51C6\u3002",batchRemove:"\u79FB\u51FA\u672C\u6279",batchState:"\u5B9E\u9645\u5339\u914D\u72B6\u6001 / \u52A8\u4F5C ID",batchLoading:"\u6B63\u5728\u6838\u5BF9\u5F53\u524D\u52A8\u4F5C\u5E93\u2026",batchEmpty:"\u6E05\u5355\u4E3A\u7A7A\u3002\u5206\u6790\u6750\u6599\u540E\uFF0C\u5728\u672A\u8986\u76D6\u8BCD\u65C1\u70B9\u51FB\u201C\u52A0\u5165\u672C\u6279\u201D\u3002",batchMissing:"\u5F85\u5236\u4F5C \xB7 \u5C1A\u672A\u5B8C\u5168\u5339\u914D",batchDraft:"\u5DF2\u4FDD\u5B58\u5019\u9009 \xB7 \u5C1A\u672A\u542F\u7528\u6216\u5B8C\u5168\u5339\u914D",batchMatched:"\u53EF\u5B8C\u5168\u5339\u914D \xB7 \u624B\u8BED\u4ECD\u9700\u4EBA\u5DE5\u6838\u9A8C",batchUnverified:"\u72B6\u6001\u672A\u6838\u9A8C\uFF0C\u8BF7\u91CD\u8BD5",batchSummary:"\u672C\u6279 {count}/{max} \u4E2A \xB7 \u53EF\u5B8C\u5168\u5339\u914D {matched} \u4E2A \xB7 \u65E0\u6548\u5E93\u8BB0\u5F55 {invalid} \u4E2A\u3002\u4FEE\u6539\u52A8\u4F5C\u540E\u4F1A\u81EA\u52A8\u91CD\u65B0\u6838\u5BF9\u3002",batchPrivacy:"\u53EA\u6709\u4E3B\u52A8\u52A0\u5165\u7684\u8BCD\u4F1A\u4FDD\u5B58\u5230\u672C\u6269\u5C55\u672C\u5730\u5B58\u50A8\uFF08\u5237\u65B0\u540E\u4FDD\u7559\uFF09\uFF0C\u4E0D\u4FDD\u5B58\u539F\u6587\u6216\u4F8B\u53E5\u3001\u4E0D\u4E0A\u4F20\u3002\u6E05\u5355\u4E0D\u5C5E\u4E8E\u52A8\u4F5C\u5305\uFF0C\u4E0B\u8F7D\u7684\u8FDB\u5EA6\u5305\u542B\u6240\u9009\u8BCD\u53CA\u5339\u914D ID\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u9690\u79C1\u3002",batchFailure:"\u8865\u8BCD\u6E05\u5355\u64CD\u4F5C\u5931\u8D25\uFF1A{detail}",batchFull:"\u672C\u6279\u5DF2\u6EE1 8 \u4E2A\uFF0C\u8BF7\u5148\u5B8C\u6210\u6216\u79FB\u9664\u90E8\u5206\u8BCD\u3002",batchInvalid:"\u8865\u8BCD\u6E05\u5355\u6570\u636E\u65E0\u6548\uFF0C\u539F\u8BB0\u5F55\u672A\u88AB\u8986\u76D6\u3002\u53EF\u660E\u786E\u6E05\u7A7A\u540E\u91CD\u65B0\u52A0\u5165\u3002",batchLockUnavailable:"\u8DE8\u9875\u9762\u5199\u5165\u9501\u4E0D\u53EF\u7528\uFF0C\u5DF2\u505C\u6B62\u4FEE\u6539\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u6253\u5F00\u6B64\u9875\u3002",reviewTitle:"\u52A8\u4F5C\u9A8C\u6536",reviewIntro:"\u6279\u91CF\u56DE\u653E\u5DF2\u4FDD\u5B58\u7684\u52A8\u4F5C\uFF0C\u4EE5\u56FA\u5B9A\u6B63\u9762\u3001\u53F3\u4FA7\u3001\u5DE6\u4FA7\u622A\u56FE\u5BF9\u7167\u81EA\u5DF1\u786E\u8BA4\u7684\u57FA\u51C6\u3002\u4E0D\u6539\u9AA8\u9ABC\u53C2\u6570\uFF0C\u4E5F\u4E0D\u81EA\u52A8\u542F\u7528\u7FFB\u8BD1\u3002",reviewLimits:"\u6BCF\u6279\u6700\u591A 8 \u4E2A\u52A8\u4F5C\uFF0C\u6BCF\u4E2A\u6700\u591A\u62BD\u53D6 12 \u4E2A\u5173\u952E\u5E27\uFF0C\u5305\u542B\u9996\u5C3E\u5E27\u3002\u622A\u56FE\u4EC5\u68C0\u67E5\u76EE\u6807\u59FF\u6001\uFF0C\u4E0D\u8986\u76D6\u6240\u6709\u8FC7\u6E21\u3001\u78B0\u649E\u3001\u5B57\u5E55\u53E5\u7EA7\u64AD\u653E\u6216\u624B\u8BED\u542B\u4E49\uFF1B\u89C6\u89C9\u53D8\u5316\u9700\u4EBA\u5DE5\u590D\u6838\u3002\u5185\u7F6E\u5217\u8868\u4F7F\u7528 SIGNS\uFF0C\u4E0D\u5305\u542B CHARS \u5355\u5B57\u56DE\u9000\u3002",reviewHelp:"\u63A7\u5236\u9762\u677F \u2192 \u52A8\u4F5C\u9A8C\u6536\u3002\u52FE\u9009\u52A8\u4F5C\u540E\u53EF\u81EA\u52A8\u4F9D\u6B21\u56DE\u653E\u6216\u751F\u6210\u4E09\u89C6\u56FE\uFF1B\u67E5\u770B\u624B\u5F62\u3001\u65B9\u5411\u548C\u7A7F\u6A21\uFF0C\u786E\u8BA4\u540E\u70B9\u51FB\u201C\u4FDD\u5B58 / \u66FF\u6362\u89C6\u89C9\u57FA\u51C6\u201D\u3002\u4EE5\u540E\u91CD\u65B0\u622A\u56FE\u53EF\u5E76\u6392\u5BF9\u6BD4\u3002\u52A8\u4F5C\u6570\u636E\u6539\u53D8\u4F1A\u63D0\u793A\u91CD\u65B0\u6838\u9A8C\uFF0C\u6A21\u578B/\u6D4F\u89C8\u5668/\u6E32\u67D3\u73AF\u5883\u6539\u53D8\u65F6\u4E0D\u8FDB\u884C\u6570\u503C\u5BF9\u6BD4\u3002\u4FDD\u5B58\u57FA\u51C6\u4E0D\u7B49\u4E8E\u786E\u8BA4\u624B\u8BED\u6B63\u786E\uFF0C\u4E0D\u4F1A\u4FEE\u6539\u52A8\u4F5C\u5E93\u7684\u8349\u7A3F\u6216\u542F\u7528\u72B6\u6001\u3002",reviewStorageHelp:"\u89C6\u89C9\u57FA\u51C6\u53EA\u5B58\u4E8E\u5F53\u524D\u6269\u5C55\u7684 IndexedDB\uFF0C\u4E0E\u52A8\u4F5C\u5E93\u5206\u5F00\uFF0C\u6700\u591A 100 \u4E2A / 64 MiB\u3002\u4E0D\u5305\u542B\u5728\u52A8\u4F5C\u5305\u5907\u4EFD\u4E2D\uFF1B\u5378\u8F7D\u524D\u8BF7\u4E0B\u8F7D PNG \u548C JSON \u62A5\u544A\u7559\u5B58\uFF08\u672C\u8F6E\u4E0D\u652F\u6301\u91CD\u65B0\u5BFC\u5165\u57FA\u51C6\uFF09\u3002\u622A\u56FE\u548C\u62A5\u544A\u4EC5\u5728\u4F60\u70B9\u51FB\u4E0B\u8F7D\u65F6\u5BFC\u51FA\uFF0C\u4E0D\u53D1\u9001\u5230\u7F51\u7EDC\u3002",reviewReload:"\u91CD\u65B0\u52A0\u8F7D\u6A21\u578B / \u91CD\u8BD5",reviewSelect:"1 \xB7 \u9009\u62E9\u52A8\u4F5C",reviewSearch:"\u6309\u540D\u79F0\u3001ID \u6216\u72B6\u6001\u7B5B\u9009\uFF08\u4E0D\u4F1A\u53D6\u6D88\u5DF2\u52FE\u9009\u52A8\u4F5C\uFF09",reviewCatalogCount:"\u53EF\u7528 {total} \u4E2A \xB7 \u5DF2\u9009 {count}/{max} \xB7 \u65E0\u6548\u5E93\u8BB0\u5F55 {invalid} \u4E2A",reviewPlay:"\u4F9D\u6B21\u56DE\u653E\u5168\u90E8\u5E27",reviewCapture:"\u751F\u6210\u5173\u952E\u5E27\u4E09\u89C6\u56FE",reviewStop:"\u505C\u6B62\u5F53\u524D\u4EFB\u52A1",reviewPreview:"\u56FA\u5B9A\u89C6\u89D2\u9884\u89C8",reviewView:"\u56DE\u653E\u89C6\u89D2",reviewFront:"\u6B63\u9762",reviewRight:"\u4EBA\u7269\u53F3\u4FA7",reviewLeft:"\u4EBA\u7269\u5DE6\u4FA7",reviewPreviewHelp:"\u89C6\u89D2\u53EA\u7528\u4E8E\u68C0\u67E5\uFF0C\u4E0D\u6539\u53D8\u6D6E\u7A97\u4F4D\u7F6E\u6216\u5927\u5C0F\u3002\u56DE\u653E\u6BCF\u4E2A\u52A8\u4F5C\u524D\u6062\u590D REST\uFF1B\u622A\u56FE\u5B8C\u6210\u540E\u6062\u590D\u6B63\u9762\u3002",reviewResults:"2 \xB7 \u4EBA\u5DE5\u6838\u9A8C\u4E0E\u57FA\u51C6\u5BF9\u6BD4",reviewExport:"\u4E0B\u8F7D\u672C\u6279 JSON \u62A5\u544A",reviewBuiltin:"\u5185\u7F6E \xB7 \u5F85\u4EBA\u5DE5\u6838\u9A8C",reviewEnabled:"\u81EA\u5B9A\u4E49 \xB7 \u5DF2\u542F\u7528",reviewDraft:"\u81EA\u5B9A\u4E49 \xB7 \u8349\u7A3F",reviewLoading:"\u6B63\u5728\u52A0\u8F7D\u5B9E\u9645\u6A21\u578B\u3001\u9AA8\u9ABC\u548C\u52A8\u4F5C\u5E93\u2026",reviewReady:"\u5DF2\u5C31\u7EEA\uFF0C\u5171 {total} \u4E2A\u52A8\u4F5C\u3002\u9009\u62E9\u52A8\u4F5C\u540E\u56DE\u653E\u6216\u622A\u56FE\u3002",reviewFailure:"\u9A8C\u6536\u5931\u8D25\uFF1A{detail}",reviewCatalogChanged:"\u52A8\u4F5C\u5E93\u5DF2\u53D8\u5316\uFF0C\u672C\u6279\u7ED3\u679C\u5931\u6548\u3002\u8BF7\u91CD\u65B0\u9009\u62E9\u5E76\u622A\u56FE\uFF0C\u65E7\u57FA\u51C6\u4E0D\u4F1A\u81EA\u52A8\u8986\u76D6\u3002",reviewPlaying:"\u6B63\u5728\u56DE\u653E {index}/{total}\uFF1A{name}",reviewCapturing:"\u6B63\u5728\u622A\u56FE {index}/{total}\uFF1A{name}",reviewFinished:"\u672C\u6279\u5B8C\u6210 {count} \u4E2A\uFF0C\u7ED3\u6784\u9519\u8BEF {failures} \u4E2A\uFF1B\u7ED3\u679C\u4ECD\u9700\u4EBA\u5DE5\u68C0\u67E5\u3002",reviewCancelled:"\u5DF2\u505C\u6B62\uFF1B\u672A\u5B8C\u6210\u6279\u6B21\u4E0D\u4FDD\u7559\u622A\u56FE\u7ED3\u679C\uFF0C\u4E0D\u4FEE\u6539\u57FA\u51C6\u3002",reviewDiagnostics:"\u5171 {frames} \u5E27 / {duration} \u79D2\uFF0C\u4F7F\u7528 {bones} \u4E2A\u9AA8\u9ABC\u3002\u622A\u56FE\u884C\u5BF9\u5E94\u5E27\uFF1A{indices}\uFF1B\u672A\u622A\u56FE {omitted} \u5E27\u3002",reviewSheetOrder:"\u6BCF\u884C\u4ECE\u5DE6\u5230\u53F3\uFF1A\u6B63\u9762 \u2192 \u4EBA\u7269\u53F3\u4FA7 \u2192 \u4EBA\u7269\u5DE6\u4FA7\uFF1B\u884C\u987A\u5E8F\u6309\u5E27\u53F7\u3002\u4E0B\u8F7D PNG \u53EF\u653E\u5927\u68C0\u67E5\u3002",reviewCurrent:"\u5F53\u524D\u622A\u56FE",reviewBaseline:"\u5DF2\u786E\u8BA4\u7684\u89C6\u89C9\u57FA\u51C6",reviewNoBaseline:"\u5C1A\u65E0\u89C6\u89C9\u57FA\u51C6\u3002\u5148\u68C0\u67E5\u52A8\u4F5C\uFF0C\u518D\u624B\u52A8\u4FDD\u5B58\u3002",reviewCompared:"\u57FA\u51C6\u65F6\u95F4 {date}\u3002RGB \u5355\u901A\u9053\u5DEE\u5F02 >16 \u7684\u50CF\u7D20\u5360 {ratio}%\uFF0C\u5E73\u5747\u901A\u9053\u5DEE\u5F02 {mean}/255\u3002\u4EC5\u4F9B\u4EBA\u5DE5\u590D\u6838\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u6B63\u786E\u6216\u4E0D\u5B58\u5728\u7A7F\u6A21\u3002",reviewMotionChanged:"\u52A8\u4F5C\u6570\u636E\u5DF2\u6539\u53D8\uFF08\u5305\u62EC\u65F6\u957F\u6216\u540D\u79F0\uFF09\uFF0C\u65E7\u57FA\u51C6\u4ECD\u4FDD\u7559\u3002\u6570\u503C\u5BF9\u6BD4\u5DF2\u505C\u6B62\uFF0C\u8BF7\u91CD\u65B0\u6838\u9A8C\u3002",reviewIncompatible:"\u6A21\u578B\u3001\u9AA8\u9ABC\u3001\u6D4F\u89C8\u5668\u6216\u6E32\u67D3\u73AF\u5883\u4E0E\u65E7\u57FA\u51C6\u4E0D\u540C\uFF0C\u4E0D\u80FD\u53EF\u9760\u8FDB\u884C\u6570\u503C\u5BF9\u6BD4\u3002\u65E7\u56FE\u53EA\u4F9B\u53C2\u8003\u3002",reviewUnavailable:"\u57FA\u51C6\u8BFB\u53D6 / \u5BF9\u6BD4\u5931\u8D25\uFF1A{detail}\u3002\u5F53\u524D\u622A\u56FE\u4ECD\u53EF\u4E0B\u8F7D\uFF0C\u4FDD\u5B58\u5C06\u518D\u6B21\u5C1D\u8BD5\u3002",reviewSaveBaseline:"\u4FDD\u5B58 / \u66FF\u6362\u89C6\u89C9\u57FA\u51C6",reviewDeleteBaseline:"\u5220\u9664\u6B64\u52A8\u4F5C\u57FA\u51C6",reviewDownloadImage:"\u4E0B\u8F7D\u5F53\u524D PNG",reviewSaveConfirm:"\u786E\u8BA4\u5DF2\u68C0\u67E5\u201C{name}\u201D\u7684\u4E09\u89C6\u56FE\uFF1F\u5C06\u4FDD\u5B58\u5F53\u524D\u622A\u56FE\u5E76\u66FF\u6362\u5DF2\u6709\u89C6\u89C9\u57FA\u51C6\uFF0C\u4EC5\u7528\u4E8E\u56DE\u5F52\u6BD4\u8F83\uFF1B\u4E0D\u4F1A\u542F\u7528\u7FFB\u8BD1\u6216\u8BA4\u8BC1\u624B\u8BED\u6B63\u786E\u6027\u3002",reviewDeleteConfirm:"\u5220\u9664\u201C{name}\u201D\u7684\u89C6\u89C9\u57FA\u51C6\uFF1F\u6B64\u64CD\u4F5C\u4E0D\u5220\u9664\u52A8\u4F5C\u5E93\u4E2D\u7684\u52A8\u4F5C\u3002",reviewSaved:"\u89C6\u89C9\u57FA\u51C6\u5DF2\u4FDD\u5B58\uFF1B\u52A8\u4F5C\u5E93\u4E0E\u7FFB\u8BD1\u542F\u7528\u72B6\u6001\u672A\u6539\u53D8\u3002",reviewDeleted:"\u6B64\u52A8\u4F5C\u7684\u89C6\u89C9\u57FA\u51C6\u5DF2\u5220\u9664\uFF0C\u52A8\u4F5C\u6570\u636E\u672A\u6539\u53D8\u3002",reviewStorageError:"\u65E0\u6CD5\u8BBF\u95EE\u672C\u5730\u57FA\u51C6\u5B58\u50A8\u3002\u8BF7\u68C0\u67E5\u6D4F\u89C8\u5668\u53EF\u7528\u7A7A\u95F4\u5E76\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u91CD\u5F00\u3002",reviewStorageFull:"\u89C6\u89C9\u57FA\u51C6\u8FBE\u5230 100 \u4E2A\u6216 64 MiB \u4E0A\u9650\u3002\u8BF7\u5148\u4E0B\u8F7D\u7559\u5B58\uFF0C\u518D\u5220\u9664\u4E0D\u9700\u8981\u7684\u57FA\u51C6\u3002",reviewBaselineChanged:"\u53E6\u4E00\u9875\u9762\u5DF2\u66F4\u65B0\u57FA\u51C6\uFF0C\u672A\u8986\u76D6\u3002\u8BF7\u91CD\u65B0\u622A\u56FE\u8BFB\u53D6\u6700\u65B0\u57FA\u51C6\u540E\u518D\u786E\u8BA4\u3002",reviewModelError:"\u6A21\u578B\u52A0\u8F7D\u5931\u8D25\u6216\u5C3A\u5BF8\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u6784\u5EFA\u6269\u5C55\u5E76\u91CD\u8BD5\u3002",reviewMissingBones:"\u6A21\u578B\u7F3A\u5C11\u624B\u8BED\u5FC5\u9700\u9AA8\u9ABC\uFF0C\u5DF2\u963B\u6B62\u9A8C\u6536\u3002",reviewRenderError:"\u6E32\u67D3\u5931\u8D25\u6216 WebGL \u4E0A\u4E0B\u6587\u4E22\u5931\uFF0C\u505C\u6B62\u4EFB\u52A1\u540E\u8BF7\u70B9\u51FB\u91CD\u65B0\u52A0\u8F7D\u3002",reviewInvalidSamples:"\u5173\u952E\u5E27\u62BD\u6837\u53C2\u6570\u65E0\u6548\u3002",reviewImageMismatch:"\u57FA\u51C6\u56FE\u7247\u635F\u574F\u6216\u5C3A\u5BF8\u4E0D\u4E00\u81F4\uFF0C\u4E0D\u80FD\u8FDB\u884C\u5BF9\u6BD4\u3002",motionPackTitle:"\u52A8\u4F5C\u5E93\u5907\u4EFD / \u6279\u91CF\u5BFC\u5165",motionPackHelp:"\u5BFC\u51FA\u5F53\u524D\u6A21\u578B\u4E0B\u5168\u90E8\u5DF2\u4FDD\u5B58\u7684\u81EA\u5B9A\u4E49\u52A8\u4F5C\uFF08\u4E0D\u542B\u672A\u4FDD\u5B58\u7F16\u8F91\u6216\u5185\u7F6E\u8BCD\u5178\uFF09\u3002\u9009\u6587\u4EF6\u53EA\u505A\u9884\u68C0\uFF0C\u786E\u8BA4\u540E\u65B0\u589E\u8349\u7A3F\uFF1B\u540C ID \u540C\u5185\u5BB9\u8DF3\u8FC7\uFF0C\u4E0D\u540C\u5185\u5BB9\u62D2\u7EDD\u6574\u5305\u5BFC\u5165\u3002\u65B0\u52A8\u4F5C\u4ECD\u987B\u9010\u6761\u8F7D\u5165\u3001\u9884\u89C8\u3001\u786E\u8BA4\u542F\u7528\u3002",motionPackPrivacy:"\u6587\u4EF6\u53EA\u5305\u542B\u52A8\u4F5C\u540D\u79F0\u3001\u5339\u914D\u6587\u5B57\u3001\u6807\u7B7E\u3001\u9AA8\u9ABC\u7ED1\u5B9A\u3001\u5E27\u6570\u636E\u53CA\u5BFC\u51FA\u65F6\u542F\u7528\u6807\u8BB0\uFF0C\u4E0D\u542B\u5BC6\u94A5\u6216\u5B57\u5E55\u3002\u540D\u79F0\u548C\u6807\u7B7E\u4E5F\u53EF\u80FD\u542B\u9690\u79C1\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u3002\u5BFC\u5165\u4E0D\u4F1A\u7EE7\u627F\u5BA1\u6838\u8BB0\u5F55\uFF0C\u4E5F\u4E0D\u4E0A\u4F20\u6587\u4EF6\u3002",motionPackExport:"\u5907\u4EFD\u5168\u90E8\u5DF2\u4FDD\u5B58\u52A8\u4F5C",motionPackFile:"\u9009\u62E9\u52A8\u4F5C\u5305 JSON\uFF08\u4E0D\u662F\u5355\u52A8\u4F5C JSON\uFF09",motionPackLimits:"\u6BCF\u5305\u6700\u591A 500 \u4E2A\u52A8\u4F5C\u30018 MiB\uFF1B\u5355\u52A8\u4F5C\u6700\u591A 2 MiB\u3002\u6A21\u578B\u4E0E REST \u5FC5\u987B\u4E00\u81F4\u3002",motionPackInspect:"\u91CD\u65B0\u9884\u68C0",motionPackImport:"\u786E\u8BA4\u5BFC\u5165\u65B0\u8349\u7A3F",motionPackClear:"\u53D6\u6D88\u5F85\u5BFC\u5165\u6587\u4EF6",motionPackSummary:"\u9884\u68C0\uFF1A\u65B0\u589E {new}\uFF0C\u5DF2\u5B58\u5728 {existing}\uFF0CID \u51B2\u7A81 {conflict}\u3002\u5C1A\u672A\u5199\u5165\u52A8\u4F5C\u5E93\u3002",motionPackName:"\u52A8\u4F5C / ID",motionPackState:"\u5904\u7406\u65B9\u5F0F",motionPackWarnings:"\u9700\u8981\u6CE8\u610F",motionPackNew:"\u65B0\u589E\u8349\u7A3F",motionPackExisting:"\u76F8\u540C\u5185\u5BB9\uFF0C\u8DF3\u8FC7",motionPackIdConflict:"ID \u51B2\u7A81\uFF0C\u4E0D\u8986\u76D6",motionPackWasEnabled:"\u5305\u5185\u6807\u8BB0\u66FE\u542F\u7528\uFF1B\u53EA\u662F\u6765\u6E90\u4FE1\u606F\uFF0C\u4E0D\u4EE3\u8868\u5BA1\u6838\u53EF\u4FE1\u3002",motionPackAliases:"\u5339\u914D\u6587\u5B57\u53EF\u80FD\u91CD\u590D\uFF1A{aliases}\u3002\u8349\u7A3F\u53EF\u4FDD\u5B58\uFF0C\u542F\u7528\u524D\u9700\u68C0\u67E5\uFF08\u542B\u672A\u542F\u7528\u6761\u76EE\uFF09\u3002",motionPackMaterial:"\u65E0\u5339\u914D\u6587\u5B57\uFF0C\u53EA\u4F5C\u59FF\u52BF\u7D20\u6750\uFF0C\u4E0D\u80FD\u542F\u7528\u7FFB\u8BD1\u3002",motionPackReady:"\u9884\u68C0\u5B8C\u6210\u3002\u53EA\u4F1A\u65B0\u589E\u8349\u7A3F\uFF0C\u4E0D\u6539\u53D8\u5F53\u524D\u59FF\u52BF\u6216\u5DF2\u6709\u52A8\u4F5C\u7684\u542F\u7528\u72B6\u6001\u3002",motionPackChecking:"\u6B63\u5728\u6838\u5BF9\u6A21\u578B\u548C\u672C\u5730\u52A8\u4F5C\u5E93\u2026",motionPackCleared:"\u5DF2\u53D6\u6D88\uFF0C\u52A8\u4F5C\u5E93\u6CA1\u6709\u6539\u53D8\u3002",motionPackConfirm:"\u5C06\u65B0\u589E {count} \u4E2A\u8349\u7A3F\uFF0C\u4E0D\u8986\u76D6\u65E7\u52A8\u4F5C\u3001\u4E0D\u81EA\u52A8\u542F\u7528\u3002\u8BF7\u786E\u8BA4\u6765\u6E90\u6388\u6743\uFF0C\u5BFC\u5165\u540E\u9010\u6761\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u548C\u542B\u4E49\u3002\u7EE7\u7EED\uFF1F",motionPackImported:"\u5DF2\u65B0\u589E {imported} \u4E2A\u8349\u7A3F\uFF0C\u8DF3\u8FC7 {skipped} \u4E2A\u5DF2\u6709\u52A8\u4F5C\u3002\u8BF7\u4ECE\u5217\u8868\u8F7D\u5165\u3001\u9884\u89C8\u5E76\u9010\u6761\u786E\u8BA4\u3002",motionPackExported:"\u5DF2\u53D1\u8D77 {count} \u4E2A\u5DF2\u4FDD\u5B58\u52A8\u4F5C\u7684\u4E0B\u8F7D\uFF0C\u8BF7\u68C0\u67E5\u4E0B\u8F7D\u7ED3\u679C\uFF1B\u4E0D\u542B\u5C1A\u672A\u4FDD\u5B58\u7684\u7F16\u8F91\u3002",motionPackInvalid:"\u4E0D\u662F\u6709\u6548\u7684 v1 \u52A8\u4F5C\u5305 JSON\uFF1B\u5355\u52A8\u4F5C\u6587\u4EF6\u8BF7\u4F7F\u7528\u4E0A\u65B9\u201C\u5BFC\u5165\u52A8\u4F5C JSON\u201D\u3002",motionPackEmpty:"\u52A8\u4F5C\u5305\u4E3A\u7A7A\uFF0C\u6216\u5F53\u524D\u6CA1\u6709\u53EF\u5907\u4EFD\u7684\u5DF2\u4FDD\u5B58\u52A8\u4F5C\u3002",motionPackTooLarge:"\u8D85\u8FC7\u9650\u5236\uFF1A\u52A8\u4F5C\u5305 8 MiB / 500 \u4E2A\u52A8\u4F5C\uFF0C\u5355\u52A8\u4F5C 2 MiB\u3002\u6CA1\u6709\u5199\u5165\u3002",motionPackDuplicateId:"\u5305\u5185\u5B58\u5728\u91CD\u590D ID\uFF0C\u65E0\u6CD5\u786E\u5B9A\u5E94\u4FDD\u7559\u54EA\u4E2A\u52A8\u4F5C\uFF0C\u5DF2\u62D2\u7EDD\u5BFC\u5165\u3002",motionPackInvalidStored:"\u672C\u5730\u5E93\u6709\u635F\u574F\u6216\u4E0E\u5F53\u524D\u6A21\u578B\u4E0D\u517C\u5BB9\u7684\u8BB0\u5F55\uFF0C\u672A\u751F\u6210\u4E0D\u5B8C\u6574\u5907\u4EFD\uFF1B\u539F\u6570\u636E\u4FDD\u7559\uFF0C\u8BF7\u5148\u68C0\u67E5\u8FD9\u4E9B\u8BB0\u5F55\u3002",motionPackConflict:"\u540C ID \u7684\u672C\u5730\u5185\u5BB9\u4E0D\u540C\u6216\u635F\u574F\uFF0C\u6574\u5305\u5BFC\u5165\u5DF2\u963B\u6B62\uFF0C\u4E0D\u4F1A\u8986\u76D6\u3002\u9700\u8981\u53E6\u5B58\u65F6\u8BF7\u4F7F\u7528\u5355\u52A8\u4F5C\u5BFC\u5165\u521B\u5EFA\u526F\u672C\u3002",motionPackStale:"\u52A8\u4F5C\u5E93\u5DF2\u6539\u53D8\uFF0C\u65E7\u9884\u68C0\u5931\u6548\u3002\u8BF7\u70B9\u51FB\u201C\u91CD\u65B0\u9884\u68C0\u201D\uFF0C\u786E\u8BA4\u6E05\u5355\u540E\u518D\u5BFC\u5165\u3002",motionPackLockUnavailable:"\u8DE8\u9875\u9762\u5199\u5165\u9501\u4E0D\u53EF\u7528\uFF0C\u5DF2\u505C\u6B62\u6279\u91CF\u5BFC\u5165\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u91CD\u65B0\u6253\u5F00\u5DE5\u5177\u9875\u3002",motionPackEncoding:"\u6587\u4EF6\u4E0D\u662F\u6709\u6548\u7684 UTF-8 JSON\uFF0C\u8BF7\u8F6C\u6362\u7F16\u7801\u540E\u91CD\u8BD5\u3002",coverageTitle:"\u8BCD\u5E93\u8986\u76D6\u5206\u6790",coverageHelpWorkflow:"\u5728\u63A7\u5236\u9762\u677F\u6253\u5F00\u201C\u8BCD\u5E93\u8986\u76D6\u5206\u6790\u201D\uFF0C\u7C98\u8D34\u6587\u5B57\u6216\u5BFC\u5165 UTF-8 TXT / SRT / VTT\uFF0C\u5206\u6790\u672A\u8986\u76D6\u8BCD\u7684\u9891\u6B21\u4E0E\u8BED\u5883\u3002\u70B9\u51FB\u8BCD\u6761\u65C1\u7684\u59FF\u52BF\u7F16\u8F91\u5668\u6216\u5F55\u5236\u5DE5\u5177\u53EA\u4F1A\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\uFF1B\u5236\u4F5C\u5E76\u4EBA\u5DE5\u786E\u8BA4\u52A8\u4F5C\u540E\u56DE\u5230\u5206\u6790\u9875\u91CD\u65B0\u5206\u6790\uFF0C\u53EF\u6838\u5BF9\u662F\u5426\u5B9E\u9645\u751F\u6548\u3002",coverageIntro:"\u5148\u627E\u51FA\u771F\u5B9E\u8BED\u6599\u91CC\u7F3A\u5C11\u7684\u8BCD\uFF0C\u518D\u5236\u4F5C\u5E76\u9A8C\u8BC1\u52A8\u4F5C\u3002\u4E0D\u4F1A\u81EA\u52A8\u751F\u6210\u624B\u8BED\uFF0C\u4E5F\u4E0D\u4F1A\u6539\u52A8\u73B0\u6709\u59FF\u52BF\u3002",coverageInput:"1 \xB7 \u9009\u62E9\u5206\u6790\u6750\u6599",coverageTextLabel:"\u7C98\u8D34\u6587\u5B57\uFF08\u6BCF\u884C\u4E00\u6BB5\uFF09\uFF0C\u6216\u5BFC\u5165 UTF-8 \u5B57\u5E55",coverageLimits:"\u4E0A\u9650\uFF1A256 KiB \u6587\u4EF6\u300150,000 \u5B57\u7B26\u30011,000 \u6BB5\u3001\u6BCF\u6BB5 2,000 \u5B57\u7B26\u3002SRT / WebVTT \u6309\u5B57\u5E55\u6761\u76EE\u5206\u6790\u3002",coverageFormat:"\u683C\u5F0F",coveragePlainText:"\u7EAF\u6587\u5B57 \xB7 \u6BCF\u884C\u4E00\u6BB5",coverageImport:"\u5BFC\u5165\u6587\u4EF6",coverageAnalyze:"\u5206\u6790\u5F53\u524D\u8BCD\u5E93",coverageClear:"\u6E05\u7A7A",coverageResults:"2 \xB7 \u627E\u5230\u8865\u8BCD\u4F18\u5148\u7EA7",coverageMetricHelp:"\u8986\u76D6\u7387 = \u547D\u4E2D\u7684\u5206\u8BCD\u6570 \xF7\uFF08\u547D\u4E2D\u5206\u8BCD\u6570 + \u672A\u8986\u76D6\u5206\u8BCD\u6570\uFF09\uFF0C\u8DF3\u8FC7\u7684\u865A\u8BCD\u4E0E\u6807\u70B9\u4E0D\u8BA1\u5165\u3002\u7EDF\u8BA1\u7684\u662F\u6574\u6BB5\u8BCD\u5E93\u8986\u76D6\uFF0C\u4E0D\u662F\u624B\u8BED\u51C6\u786E\u7387\uFF0C\u4E5F\u4E0D\u4FDD\u8BC1\u53E5\u610F\u5B8C\u6574\u6216\u5168\u90E8\u52A8\u4F5C\u4F1A\u64AD\u5B8C\u3002",coverageUnknownTitle:"\u672A\u8986\u76D6\u8BCD \xB7 \u6309\u51FA\u73B0\u6B21\u6570\u6392\u5E8F",coverageDraftHelp:"\u4F18\u5148\u7EA7\u53EA\u662F\u5206\u8BCD\u7ED3\u679C\uFF0C\u5148\u7ED3\u5408\u8BED\u5883\u5224\u65AD\u662F\u5426\u5E94\u5236\u4F5C\u5B8C\u6574\u8BCD\u7EC4\u3002\u8FDB\u5165\u5DE5\u5177\u53EA\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\uFF0C\u4E5F\u4E0D\u4F1A\u628A\u5F53\u524D\u59FF\u52BF\u5F53\u6210\u8BE5\u8BCD\u7684\u6B63\u786E\u624B\u8BED\u3002",coverageWord:"\u672A\u8986\u76D6\u8BCD",coverageFrequency:"\u6B21\u6570 / \u6BB5\u6570",coverageExamples:"\u4F8B\u53E5\u6BB5\u53F7",coverageMake:"\u5236\u4F5C\u4E0E\u4EBA\u5DE5\u9A8C\u8BC1",coverageDetailsTitle:"3 \xB7 \u9010\u6BB5\u6838\u5BF9\u5B9E\u9645\u547D\u4E2D",coverageDisplayLimit:"\u9875\u9762\u6700\u591A\u663E\u793A\u524D 100 \u4E2A\u672A\u8986\u76D6\u8BCD\u548C\u524D 200 \u6BB5\uFF1B\u7EDF\u8BA1\u5305\u542B\u5168\u90E8\u8F93\u5165\u3002\u5BFC\u51FA\u62A5\u544A\u53EF\u4FDD\u7559\u5168\u90E8\u7ED3\u679C\u3002",coverageIncludeText:"\u5BFC\u51FA\u65F6\u5305\u542B\u539F\u6587\u548C\u9010\u6BB5\u660E\u7EC6\uFF08\u53EF\u80FD\u542B\u9690\u79C1\uFF09",coverageExport:"\u5BFC\u51FA\u5206\u6790\u62A5\u544A JSON",coveragePrivacy:"\u6750\u6599\u4EC5\u5728\u672C\u9875\u5185\u5B58\u5206\u6790\uFF0C\u4E0D\u4E0A\u4F20\u3001\u4E0D\u81EA\u52A8\u4FDD\u5B58\uFF0C\u5173\u95ED\u9875\u9762\u5373\u4E22\u5F03\u3002\u9ED8\u8BA4\u62A5\u544A\u4E0D\u542B\u539F\u6587\uFF0C\u4F46\u4ECD\u5305\u542B\u672A\u8986\u76D6\u8BCD\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u3002",coverageSummary:"\u8986\u76D6 {ratio} \xB7 {segments} \u6BB5 \xB7 \u547D\u4E2D {matched} / \u672A\u8986\u76D6 {unknown} / \u8DF3\u8FC7 {skipped}",coverageNoTokens:"\u4E0D\u9002\u7528\uFF08\u65E0\u5F85\u7FFB\u8BD1\u8BCD\uFF09",coverageTruncation:"{count} \u6BB5\u89E6\u53CA\u5B9E\u65F6\u64AD\u653E\u6BCF\u6BB5 12 \u4E2A\u52A8\u4F5C\u4E0A\u9650\uFF1B\u8FD9\u90E8\u5206\u53EF\u80FD\u672A\u64AD\u653E\uFF0C\u8BF7\u67E5\u770B\u9010\u6BB5\u5269\u4F59\u6587\u672C\u3002",coverageOccurrences:"{count} \u6B21 / {segments} \u6BB5",coverageUniqueUnknown:"\u5171 {count} \u4E2A\u4E0D\u540C\u7684\u672A\u8986\u76D6\u8BCD\u3002\u8FC7\u957F\u7684\u8BCD\u8BF7\u5148\u62C6\u5206\u6216\u91CD\u65B0\u5224\u65AD\u5206\u8BCD\u3002",coverageNoUnknown:"\u672A\u53D1\u73B0\u672A\u8986\u76D6\u8BCD\uFF1B\u4ECD\u9700\u4EBA\u5DE5\u6838\u5BF9\u624B\u8BED\u542B\u4E49\u4E0E\u52A8\u4F5C\u3002",coverageMatches:"\u547D\u4E2D\uFF1A{value}",coverageUnmatched:"\u672A\u8986\u76D6\uFF1A{value}",coverageSkipped:"\u8DF3\u8FC7\uFF1A{value}",coverageRemaining:"\u8FBE\u5230\u64AD\u653E\u4E0A\u9650\u540E\u7684\u5269\u4F59\u6587\u672C\uFF1A{value}",coverageCatalog:"\u5F53\u524D\u8BCD\u5E93\uFF1A{signs} \u5185\u7F6E\u8BCD\u6761 / {aliases} \u67E5\u627E\u522B\u540D / {chars} \u5355\u5B57\uFF1B\u5DF2\u542F\u7528\u81EA\u5B9A\u4E49 {enabled}\uFF1B\u672A\u751F\u6548 {drafts}\uFF1B\u65E0\u6548\u6216\u6A21\u578B\u4E0D\u5339\u914D {invalid}\uFF08\u539F\u6570\u636E\u4FDD\u7559\uFF09\u3002",coverageReady:"\u7C98\u8D34\u6216\u5BFC\u5165\u6750\u6599\u540E\u70B9\u51FB\u5206\u6790\u3002\u9996\u6B21\u5206\u6790\u4F1A\u8BFB\u53D6\u5F53\u524D\u6A21\u578B\uFF0C\u6838\u9A8C\u81EA\u5B9A\u4E49\u52A8\u4F5C\u7ED1\u5B9A\u3002",coverageLoading:"\u6B63\u5728\u6838\u9A8C\u6A21\u578B\u4E0E\u52A8\u4F5C\u5E93\u5E76\u5206\u6790\u2026",coverageDone:"\u5206\u6790\u5B8C\u6210\u3002\u53EF\u5236\u4F5C\u7F3A\u5931\u52A8\u4F5C\uFF0C\u4EBA\u5DE5\u786E\u8BA4\u542F\u7528\u540E\u56DE\u5230\u6B64\u9875\u518D\u6B21\u5206\u6790\u3002",coverageChanged:"\u6750\u6599\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u5206\u6790\uFF1B\u65E7\u62A5\u544A\u4E0D\u53EF\u5BFC\u51FA\u3002",coverageCatalogChanged:"\u5171\u4EAB\u52A8\u4F5C\u5E93\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u5206\u6790\u4EE5\u67E5\u770B\u6700\u65B0\u8986\u76D6\uFF1B\u65E7\u62A5\u544A\u4E0D\u53EF\u5BFC\u51FA\u3002",coverageImported:"\u6750\u6599\u5DF2\u5BFC\u5165\u3002\u70B9\u51FB\u5206\u6790\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u64AD\u653E\u6216\u4FDD\u5B58\u3002",coverageFailure:"\u5206\u6790\u672A\u5B8C\u6210\uFF1A{detail}",coverageTooLarge:"\u8D85\u8FC7\u6750\u6599\u5927\u5C0F\u3001\u6BB5\u6570\u6216\u5355\u6BB5\u957F\u5EA6\u4E0A\u9650\uFF0C\u8BF7\u62C6\u5206\u540E\u5206\u6790\u3002",coverageEmpty:"\u8BF7\u63D0\u4F9B\u81F3\u5C11\u4E00\u6BB5\u975E\u7A7A\u6587\u5B57\u3002",coverageInvalidFormat:"\u4EC5\u652F\u6301 TXT\u3001SRT\u3001WebVTT\uFF0C\u8BF7\u9009\u62E9\u6B63\u786E\u683C\u5F0F\u3002",coverageInvalidSubtitles:"\u5B57\u5E55\u683C\u5F0F\u65E0\u6548\u3002\u8BF7\u68C0\u67E5\u7A7A\u884C\u3001\u65F6\u95F4\u8F74\u3001\u8D77\u6B62\u987A\u5E8F\u53CA WebVTT \u6587\u4EF6\u5934\uFF1B\u4E0D\u4F1A\u628A\u65F6\u95F4\u8F74\u5F53\u6B63\u6587\u7EDF\u8BA1\u3002",coverageEncoding:"\u6587\u4EF6\u4E0D\u662F\u6709\u6548 UTF-8\uFF0C\u8BF7\u8F6C\u6362\u7F16\u7801\u540E\u91CD\u8BD5\u3002",coverageModelError:"\u65E0\u6CD5\u6838\u9A8C\u5F53\u524D\u6A21\u578B\u6216\u5171\u4EAB\u52A8\u4F5C\u5E93\uFF0C\u8BF7\u786E\u8BA4\u4ECE\u63D2\u4EF6\u6253\u5F00\u4E14\u6A21\u578B\u53EF\u52A0\u8F7D\uFF0C\u7136\u540E\u91CD\u8BD5\u3002\u6CA1\u6709\u9000\u56DE\u5230\u4E0D\u5B8C\u6574\u7684\u7EDF\u8BA1\u3002",coverageOpenFailed:"\u5DE5\u5177\u9875\u9762\u672A\u80FD\u6253\u5F00\uFF0C\u8BF7\u4ECE\u63D2\u4EF6\u63A7\u5236\u9762\u677F\u91CD\u8BD5\u3002",coveragePrefilled:"\u5DF2\u4ECE\u8986\u76D6\u5206\u6790\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\u3002\u5F53\u524D\u59FF\u52BF\u4E0D\u662F\u8BE5\u8BCD\u7684\u5DF2\u9A8C\u8BC1\u52A8\u4F5C\uFF1B\u8BF7\u5236\u4F5C\u3001\u4FDD\u5B58\u3001\u9884\u89C8\u5E76\u4EBA\u5DE5\u786E\u8BA4\u3002",motionLibraryTitle:"\u5171\u4EAB\u52A8\u4F5C\u5E93 \xB7 \u7B2C\u4E8C\u9636\u6BB5",motionLibraryHelp:"\u7F16\u8F91\u5668\u3001\u5F55\u5236\u5668\u3001\u6D6E\u7A97\u4F7F\u7528\u540C\u4E00\u4EFD\u5F27\u5EA6\u6570\u636E\u3002\u4FDD\u5B58\u7684\u662F\u8349\u7A3F\uFF1B\u9884\u89C8\u5E76\u786E\u8BA4\u542F\u7528\u540E\uFF0C\u5339\u914D\u6587\u5B57\u624D\u53C2\u4E0E\u7FFB\u8BD1\u3002",motionName:"\u52A8\u4F5C\u540D\u79F0\uFF08\u5FC5\u586B\uFF09",motionTexts:"\u5339\u914D\u6587\u5B57\uFF08\u591A\u4E2A\u7528\u9017\u53F7\u5206\u9694\uFF1B\u7559\u7A7A\u4EC5\u4F5C\u59FF\u52BF\u7D20\u6750\uFF09",motionTags:"\u5206\u7C7B\u6807\u7B7E\uFF08\u9017\u53F7\u5206\u9694\uFF09",motionNew:"\u65B0\u5EFA\u526F\u672C",motionNewHelp:"\u5F53\u524D\u59FF\u52BF\u4FDD\u7559\uFF0C\u8BF7\u586B\u5199\u65B0\u7684\u52A8\u4F5C\u540D\u79F0\u3002",motionSave:"\u4FDD\u5B58\u8349\u7A3F",motionSaved:"\u5DF2\u4FDD\u5B58\u8349\u7A3F\uFF0C\u9700\u91CD\u65B0\u9884\u89C8\u3001\u786E\u8BA4\u540E\u542F\u7528\u3002",motionLoad:"\u8F7D\u5165\u9009\u4E2D",motionLoaded:"\u5DF2\u8F7D\u5165\u3002\u5BFC\u5165\u6587\u4EF6\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\uFF0C\u8BF7\u68C0\u67E5\u540E\u4FDD\u5B58\u8349\u7A3F\u3002",motionChoose:"\u9009\u62E9\u5DF2\u4FDD\u5B58\u7684\u52A8\u4F5C\u2026",motionDraft:"\u8349\u7A3F / \u672A\u542F\u7528",motionEnabled:"\u5DF2\u786E\u8BA4\u542F\u7528",motionPreview:"\u9884\u89C8\u5F53\u524D\u52A8\u4F5C",motionPreviewHelp:"\u6B63\u5728\u4F7F\u7528\u4E0E\u6D6E\u7A97\u76F8\u540C\u7684\u64AD\u653E\u5668\u3002\u8BF7\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u542B\u4E49\uFF1B\u4FEE\u6539\u540E\u9700\u91CD\u65B0\u4FDD\u5B58\u3002",motionEnable:"\u786E\u8BA4\u540E\u7528\u4E8E\u7FFB\u8BD1",motionDisable:"\u505C\u7528\u9009\u4E2D\u52A8\u4F5C",motionConfirm:"\u6211\u5DF2\u5B8C\u6574\u9884\u89C8\u5E76\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u6587\u5B57\u542B\u4E49\uFF0C\u786E\u8BA4\u5C06\u8FD9\u4E2A\u52A8\u4F5C\u7528\u4E8E\u7FFB\u8BD1\u3002\u6B64\u786E\u8BA4\u4E0D\u662F\u4E13\u4E1A\u624B\u8BED\u8BA4\u8BC1\u3002\u662F\u5426\u542F\u7528\uFF1F",motionEnabledHelp:"\u5DF2\u542F\u7528\uFF1B\u5DF2\u6253\u5F00\u7684\u6D6E\u7A97\u4F1A\u81EA\u52A8\u8BFB\u53D6\uFF0C\u65B0\u8F93\u5165\u7684\u5339\u914D\u6587\u5B57\u4F7F\u7528\u6B64\u52A8\u4F5C\u3002",motionDisabledHelp:"\u5DF2\u505C\u7528\uFF0C\u8349\u7A3F\u4FDD\u7559\u3002\u6D6E\u7A97\u53D6\u6D88\u6B63\u5728\u6392\u961F\u7684\u81EA\u5B9A\u4E49\u52A8\u4F5C\u3002",motionRefresh:"\u5237\u65B0\u52A8\u4F5C\u5217\u8868",motionExport:"\u4E0B\u8F7D\u7EDF\u4E00 JSON",motionExportCode:"\u5BFC\u51FA\u4EE3\u7801\uFF08\u4E0D\u4FDD\u5B58\uFF09",motionImport:"\u5BFC\u5165\u52A8\u4F5C JSON",motionImportFormat:"\u5BFC\u5165\u6587\u4EF6\u7684\u5355\u4F4D\u548C\u683C\u5F0F",motionFormat:"\u7EDF\u4E00\u683C\u5F0F \xB7 \u5F27\u5EA6 / REST \u589E\u91CF",motionLegacyEditor:"\u65E7\u7F16\u8F91\u5668 delta \xB7 \u5EA6\u6570\uFF08\u4EC5\u59FF\u52BF\u5BF9\u8C61\uFF09",motionLegacyRecorder:"\u65E7\u5F55\u5236\u5668 frames.pose \xB7 \u5EA6\u6570",motionLegacyAbsolute:"\u65E7\u7F16\u8F91\u5668\u7EDD\u5BF9\u65CB\u8F6C \xB7 \u5F27\u5EA6",motionMigrate:"\u8FC1\u79FB\u672C\u9875\u65E7\u52A8\u4F5C\u5E93",motionLegacyConfirm:"\u65E7\u6587\u4EF6\u6CA1\u6709\u6A21\u578B\u7ED1\u5B9A\u4FE1\u606F\u3002\u4EC5\u5F53\u5B83\u6765\u81EA\u5F53\u524D\u6A21\u578B\u4E14\u6240\u9009\u683C\u5F0F\u4E0E\u5355\u4F4D\u6B63\u786E\u65F6\u624D\u7EE7\u7EED\uFF1B\u8F6C\u6362\u540E\u5FC5\u987B\u9010\u4E2A\u68C0\u67E5\u3002\u539F\u59CB\u672C\u5730\u52A8\u4F5C\u5E93\u4E0D\u4F1A\u5220\u9664\u3002\u662F\u5426\u7EE7\u7EED\uFF1F",motionMigrated:"\u5DF2\u8FC1\u79FB {count} \u4E2A\u8349\u7A3F\uFF1B\u65E7\u5E93\u4FDD\u7559\uFF0C\u5C1A\u672A\u542F\u7528\u3002\u91CD\u590D\u8FC1\u79FB\u4F1A\u751F\u6210\u526F\u672C\u3002",motionIgnored:"\u6709 {count} \u4E2A\u635F\u574F\u6216\u6A21\u578B\u4E0D\u5339\u914D\u7684\u6761\u76EE\u672A\u8F7D\u5165\uFF1B\u539F\u6570\u636E\u4FDD\u7559\u3002",motionFailure:"\u672A\u5B8C\u6210\uFF1A{detail}",motionInvalidData:"\u52A8\u4F5C\u683C\u5F0F\u6216\u53C2\u6570\u65E0\u6548\uFF1A{detail}",motionModelNotReady:"\u6A21\u578B\u5C1A\u672A\u52A0\u8F7D\u5B8C\u6210\u3002",motionRigMismatch:"\u6A21\u578B\u9AA8\u9ABC\u6216 REST \u521D\u59CB\u59FF\u52BF\u4E0D\u4E00\u81F4\uFF0C\u5DF2\u62D2\u7EDD\u5E94\u7528\u3002",motionStorageUnavailable:"\u5171\u4EAB\u5B58\u50A8\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4ECE\u63D2\u4EF6\u63A7\u5236\u9762\u677F\u6253\u5F00\u5DE5\u5177\u9875\u9762\u3002",motionSelectFirst:"\u8BF7\u5148\u4FDD\u5B58\u6216\u9009\u62E9\u4E00\u4E2A\u52A8\u4F5C\u3002",motionSaveFirst:"\u52A8\u4F5C\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u4FDD\u5B58\u4E3A\u8349\u7A3F\u3001\u9884\u89C8\u540E\u542F\u7528\u3002",motionPreviewFirst:"\u8BF7\u5148\u9884\u89C8\u5F53\u524D\u52A8\u4F5C\uFF0C\u518D\u786E\u8BA4\u542F\u7528\u3002",motionAliasConflict:"\u5339\u914D\u6587\u5B57\u4E3A\u7A7A\u6216\u4E0E\u5DF2\u542F\u7528/\u5185\u7F6E\u8BCD\u6761\u91CD\u590D\uFF1A{detail}\u3002\u8BF7\u6362\u4E00\u4E2A\u660E\u786E\u7684\u65B0\u8BCD\u7EC4\u3002",motionFileTooLarge:"\u6587\u4EF6\u8FC7\u5927\u6216\u6761\u76EE\u8FC7\u591A\uFF08\u5355\u6587\u4EF6\u4E0A\u9650 2 MiB\uFF09\u3002",motionEditorSingleFrame:"\u7F16\u8F91\u5668\u53EA\u7F16\u8F91\u5355\u5E27\u59FF\u52BF\uFF1B\u8BF7\u7528\u5F55\u5236\u5668\u6253\u5F00\u591A\u5E27\u52A8\u753B\uFF0C\u907F\u514D\u4E22\u5E27\u3002",motionFrameLimit:"\u5DF2\u8FBE\u5230 240 \u5E27\u4E0A\u9650\uFF0C\u5F55\u5236\u5DF2\u505C\u6B62\u3002",motionFrameDuration:"\u5173\u952E\u5E27\u65F6\u957F\uFF08\u79D2\uFF0C0.05\u201310\uFF09",motionUpdateFrame:"\u66F4\u65B0\u9009\u4E2D\u5E27",motionHelpRig:"Godette \u4F7F\u7528\u6807\u51C6 Humanoid \u9AA8\u540D\u6620\u5C04\u53CA\u5B8C\u6574\u53EF\u7528\u6307\u9AA8\u94FE\u3002\u7F16\u8F91\u5668\u3001\u5F55\u5236\u5668\u4E0E\u6D6E\u7A97\u5171\u7528\u540C\u4E00\u4E2A profile \u548C REST \u521D\u59CB\u59FF\u52BF\uFF0C\u4E0D\u518D\u5404\u81EA\u89E3\u91CA\u9AA8\u9ABC\u3002",motionHelpAxes:"X/Y/Z \u662F\u9AA8\u9ABC\u672C\u5730\u8F74\uFF0C\u4E0D\u662F\u56FA\u5B9A\u7684\u4E16\u754C\u65B9\u5411\uFF1B\u4E0D\u540C\u9AA8\u9ABC\u7684\u8F74\u5411\u4E0D\u80FD\u4E00\u6982\u800C\u8BBA\u3002\u7EDF\u4E00\u5BFC\u51FA\u4E3A REST \u589E\u91CF\u5F27\u5EA6\uFF0C\u5F55\u5236\u5668\u9AA8\u9ABC\u6ED1\u5757\u663E\u793A\u7EDD\u5BF9\u672C\u5730\u5F27\u5EA6\u3002",motionHelpCreate:"\u59FF\u52BF\u7F16\u8F91\u5668\u5236\u4F5C\u5355\u5E27\uFF0C\u5F55\u5236\u5668\u5236\u4F5C\u591A\u5E27\u3002\u586B\u5199\u52A8\u4F5C\u540D\u79F0\u3001\u5339\u914D\u6587\u5B57\u3001\u6807\u7B7E\u540E\u4FDD\u5B58\u8349\u7A3F\uFF1B\u5339\u914D\u6587\u5B57\u7559\u7A7A\u53EF\u53EA\u4F5C\u59FF\u52BF\u7D20\u6750\u3002\u81EA\u5B9A\u4E49\u6587\u5B57\u4E0D\u80FD\u8986\u76D6\u5185\u7F6E\u8BCD\u6216\u5176\u5B83\u5DF2\u542F\u7528\u8BCD\u6761\u3002",motionHelpReview:"\u4FDD\u5B58\u8349\u7A3F \u2192 \u9884\u89C8\u5F53\u524D\u52A8\u4F5C \u2192 \u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u542B\u4E49 \u2192 \u786E\u8BA4\u540E\u7528\u4E8E\u7FFB\u8BD1\u3002\u4E4B\u540E\u5728\u63A7\u5236\u9762\u677F\u8F93\u5165\u5339\u914D\u6587\u5B57\u9A8C\u8BC1\u6D6E\u7A97\u3002\u4EBA\u5DE5\u786E\u8BA4\u4E0D\u662F\u4E13\u4E1A\u624B\u8BED\u8BA4\u8BC1\u3002",motionHelpFrames:"\u5F55\u5236\u5668\u70B9\u51FB\u65F6\u95F4\u7EBF\u9009\u5E27\uFF0C\u8C03\u597D\u9AA8\u9ABC\u548C\u65F6\u957F\u540E\u70B9\u51FB\u201C\u66F4\u65B0\u9009\u4E2D\u5E27\u201D\uFF1B\u65B0\u589E\u59FF\u52BF\u7528\u6DFB\u52A0\u5173\u952E\u5E27\u3002\u5355\u5E27 0.05\u201310 \u79D2\uFF0C\u6700\u591A 240 \u5E27\u4E14\u603B\u8BA1\u4E0D\u8D85\u8FC7 120 \u79D2\u3002\u81EA\u52A8\u5F55\u5236\u6BCF 0.3 \u79D2\u91C7\u6837\u3002",motionHelpUpdates:"\u4E24\u4E2A\u5DE5\u5177\u9875\u4E0E\u6D6E\u7A97\u5171\u4EAB\u540C\u4E00\u6269\u5C55 ID\u3001\u540C\u4E00\u6D4F\u89C8\u5668\u7528\u6237\u914D\u7F6E\u7684\u672C\u5730\u52A8\u4F5C\u5E93\u3002\u542F\u7528/\u505C\u7528\u4F1A\u81EA\u52A8\u66F4\u65B0\u6D6E\u7A97\u5E76\u53D6\u6D88\u65E7\u64AD\u653E\u961F\u5217\uFF1B\u518D\u6B21\u4FDD\u5B58\u64A4\u9500\u65E7\u786E\u8BA4\u3002\u65B0\u5EFA\u526F\u672C\u4FDD\u7559\u59FF\u52BF\u4F46\u4E0D\u8986\u76D6\u539F\u52A8\u4F5C\u3002",motionHelpBackup:"\u4E0B\u8F7D\u7EDF\u4E00 JSON \u7528\u4E8E\u5907\u4EFD\uFF0C\u5BFC\u51FA\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\u3002\u5BFC\u5165\u662F\u65B0\u8349\u7A3F\u526F\u672C\uFF0C\u5FC5\u987B\u91CD\u65B0\u4FDD\u5B58\u3001\u9884\u89C8\u3001\u786E\u8BA4\u3002\u7F16\u8F91\u5668\u4E0D\u622A\u65AD\u591A\u5E27\u6587\u4EF6\uFF0C\u8BF7\u7528\u5F55\u5236\u5668\u8F7D\u5165\u3002\u5378\u8F7D\u6269\u5C55\u6216\u66F4\u6362\u6269\u5C55 ID \u524D\u52A1\u5FC5\u4E0B\u8F7D\u5907\u4EFD\u3002",motionHelpLegacy:"\u8FC1\u79FB\u672C\u9875\u65E7\u52A8\u4F5C\u5E93\u4F1A\u4FDD\u7559 sb_gestures \u539F\u6570\u636E\uFF0C\u91CD\u590D\u8FC1\u79FB\u4F1A\u751F\u6210\u526F\u672C\u3002\u5BFC\u5165\u65E7 JSON \u65F6\u987B\u660E\u786E\u9009\u62E9\u5EA6\u6570/\u7EDD\u5BF9\u5F27\u5EA6\u7B49\u683C\u5F0F\uFF0C\u4E0D\u731C\u5355\u4F4D\u3001\u4E0D\u6267\u884C\u4EE3\u7801\u3002\u65E7\u6587\u4EF6\u6CA1\u6709\u6A21\u578B\u7ED1\u5B9A\uFF0C\u5FC5\u987B\u6765\u81EA\u5F53\u524D\u6A21\u578B\u5E76\u4EBA\u5DE5\u590D\u6838\u3002",motionHelpBinding:"\u6587\u4EF6\u6700\u591A 2 MiB\uFF0C\u9AA8\u9ABC/REST \u4E0D\u4E00\u81F4\u3001\u672A\u77E5\u9AA8\u540D\u6216\u4E0D\u5408\u6CD5\u53C2\u6570\u4F1A\u88AB\u62D2\u7EDD\u3002\u7ED1\u5B9A\u4E0D\u662F\u6574\u4E2A GLB \u6216\u8499\u76AE\u7684\u6307\u7EB9\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u6253\u5F00\u5DE5\u5177\uFF1B\u72EC\u7ACB localhost \u9875\u9762\u4E0D\u80FD\u5171\u4EAB\u8FD9\u4EFD\u5B58\u50A8\u3002\u5347\u7EA7\u6784\u5EFA\u540E\u987B\u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u5E76\u5173\u95ED\u3001\u91CD\u5F00\u65E7\u5DE5\u5177\u9875\u3002",motionHelpCollision:"\u5148\u5B9A\u4F4D\u5177\u4F53\u8BCD\u6761\u548C\u5173\u952E\u5E27\uFF0C\u5728\u7F16\u8F91\u5668/\u5F55\u5236\u5668\u4ECE\u6B63\u9762\u4E0E\u4FA7\u9762\u68C0\u67E5\u8098\u90E8\u548C\u624B\u8155\uFF1B\u4EC5\u4FEE\u6539\u8BE5\u52A8\u4F5C\u3001\u91CD\u65B0\u9884\u89C8\u786E\u8BA4\uFF0C\u4E0D\u5168\u5C40\u53CD\u8F6C\u6216\u6279\u91CF\u589E\u52A0\u89D2\u5EA6\u3002",motionHelpCoverage:"\u67E5\u770B\u547D\u4E2D\u7684 motionIds \u548C\u672A\u547D\u4E2D\u6587\u672C\uFF1B\u65E0\u5339\u914D\u65F6\u4E0D\u6253\u65AD\u6B63\u5728\u64AD\u653E\u7684\u52A8\u4F5C\u3002",motionHelpCatalog:"\u67E5\u770B\u5DF2\u542F\u7528\u81EA\u5B9A\u4E49\u52A8\u4F5C\u6570\u91CF\u548C\u65E0\u6548\u8BB0\u5F55\u6570\u91CF\uFF1B\u672A\u542F\u7528\u8349\u7A3F\u4E0D\u4F1A\u53C2\u4E0E\u7FFB\u8BD1\u3002",motionDurationInvalid:"\u5173\u952E\u5E27\u65F6\u957F\u987B\u4E3A 0.05\u201310 \u79D2\u3002",motionLoadingFailed:"\u6A21\u578B\u52A0\u8F7D\u5931\u8D25\uFF1A{detail}",name:"\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09",title:"SignBridge \u2014 \u624B\u8BED\u7FFB\u8BD1",description:"\u5B9E\u65F6\u5C06\u89C6\u9891\u8BED\u97F3\u7FFB\u8BD1\u6210\u624B\u8BED\uFF0C\u901A\u8FC73D\u865A\u62DF\u4EBA\u5C55\u793A",settings:"\u8BBE\u7F6E",avatar:"\u865A\u62DF\u4EBA",language:"\u8BED\u8A00",sourceLanguage:"\u89C6\u9891\u8BED\u8A00",targetSignLanguage:"\u624B\u8BED\u7C7B\u578B",avatarStyle:"\u865A\u62DF\u4EBA\u5916\u89C2",avatarSize:"\u865A\u62DF\u4EBA\u5927\u5C0F",avatarPosition:"\u865A\u62DF\u4EBA\u4F4D\u7F6E",positionBottomRight:"\u53F3\u4E0B\u89D2",positionBottomLeft:"\u5DE6\u4E0B\u89D2",positionTopRight:"\u53F3\u4E0A\u89D2",positionTopLeft:"\u5DE6\u4E0A\u89D2",enableAutoDetect:"\u81EA\u52A8\u68C0\u6D4B\u89C6\u9891",enableSubtitles:"\u663E\u793A\u5B57\u5E55",voiceVolume:"\u8BED\u97F3\u97F3\u91CF",speed:"\u624B\u8BED\u901F\u5EA6",about:"\u5173\u4E8E",start:"\u5F00\u59CB\u7FFB\u8BD1",stop:"\u505C\u6B62\u7FFB\u8BD1",loading:"\u52A0\u8F7D\u4E2D...",noVideo:"\u672A\u68C0\u6D4B\u5230\u89C6\u9891",error:"\u51FA\u9519\u4E86",errorNoVideo:"\u9875\u9762\u4E0A\u6CA1\u6709\u627E\u5230\u89C6\u9891",ready:"\u5DF2\u5C31\u7EEA",translating:"\u6B63\u5728\u7FFB\u8BD1...",unavailable:"\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u7528",inputPlaceholder:"\u8F93\u5165\u6587\u5B57\uFF0C\u865A\u62DF\u4EBA\u6253\u624B\u8BED...",send:"\u53D1\u9001",sent:"\u5DF2\u53D1\u9001",audioOff:"\u89C6\u9891\u58F0\u97F3\uFF1A\u5173\u95ED",audioOn:"\u89C6\u9891\u58F0\u97F3\uFF1A\u5F00\u542F",audioStopped:"\u5DF2\u5173\u95ED",audioListening:"\u8BC6\u522B\u4E2D...",audioStarting:"\u6B63\u5728\u6355\u83B7\u58F0\u97F3...",audioUnavailable:"\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u6355\u83B7",audioCaptureFailed:"\u58F0\u97F3\u6355\u83B7\u5931\u8D25",audioCloudKeyRequired:"\u8BF7\u5148\u914D\u7F6E\u4E91\u7AEF API Key",audioPermissionRequired:"\u8BF7\u5148\u4FDD\u5B58\u8BC6\u522B\u8BBE\u7F6E\u5E76\u6388\u6743\u670D\u52A1\u5730\u5740",audioLocalUnavailable:"\u8BF7\u5148\u4E00\u952E\u90E8\u7F72\u672C\u5730 Whisper",asrSettings:"\u58F0\u97F3\u8BC6\u522B\u8BBE\u7F6E",asrTitle:"\u89C6\u9891\u58F0\u97F3\u8BC6\u522B",asrPurpose:"\u9009\u62E9\u672C\u5730 Whisper \u6216\u4E91\u7AEF ASR\uFF0C\u5C06\u5F53\u524D\u89C6\u9891\u58F0\u97F3\u8F6C\u6362\u4E3A\u624B\u8BED\u52A8\u4F5C\u3002",asrProvider:"\u8BC6\u522B\u65B9\u5F0F",asrLocal:"\u672C\u5730 Whisper",asrCloud:"\u4E91\u7AEF ASR",asrLocalSettings:"\u672C\u5730 Whisper \u8BBE\u7F6E",asrLocalPrivacy:"\u6A21\u578B\u548C\u97F3\u9891\u90FD\u5728\u6D4F\u89C8\u5668\u6269\u5C55\u5185\u5904\u7406\uFF0C\u89C6\u9891\u58F0\u97F3\u4E0D\u4F1A\u4E0A\u4F20\u5230\u8BC6\u522B\u670D\u52A1\u3002",asrDeployLocal:"\u4E00\u952E\u90E8\u7F72\u672C\u5730 Whisper",asrEndpoint:"\u670D\u52A1\u5730\u5740",asrModel:"\u6A21\u578B",asrModelTiny:"tiny\uFF08\u6700\u5FEB\uFF0C\u7EA6 75 MB\uFF09",asrModelBase:"base\uFF08\u5747\u8861\uFF0C\u7EA6 150 MB\uFF09",asrModelSmall:"small\uFF08\u66F4\u51C6\u786E\uFF0C\u7EA6 500 MB\uFF09",asrDeployHint:"\u70B9\u51FB\u540E\u81EA\u52A8\u4E0B\u8F7D\u5E76\u7F13\u5B58\u6A21\u578B\uFF0C\u65E0\u9700\u5B89\u88C5 Python \u6216\u8FD0\u884C\u672C\u5730\u670D\u52A1\u3002",asrDeployRequired:"\u5F53\u524D\u6A21\u578B\u5C1A\u672A\u90E8\u7F72\u3002",asrRequestingModelPermission:"\u6B63\u5728\u7533\u8BF7\u6A21\u578B\u4E0B\u8F7D\u6743\u9650...",asrDeploying:"\u6B63\u5728\u4E0B\u8F7D\u5E76\u521D\u59CB\u5316\u6A21\u578B\uFF1A{progress}%",asrDeployReady:"\u672C\u5730\u6A21\u578B {model} \u5DF2\u5C31\u7EEA\u3002",asrDeployFailed:"\u672C\u5730\u6A21\u578B\u90E8\u7F72\u5931\u8D25",asrCloudSettings:"\u4E91\u7AEF ASR \u8BBE\u7F6E",asrCloudPrivacy:"\u89C6\u9891\u97F3\u9891\u5206\u7247\u4F1A\u53D1\u9001\u5230\u4F60\u914D\u7F6E\u7684\u670D\u52A1\uFF0C\u8BF7\u786E\u8BA4\u670D\u52A1\u7684\u9690\u79C1\u4E0E\u8BA1\u8D39\u89C4\u5219\u3002",asrApiKey:"API Key",asrCommonSettings:"\u901A\u7528\u8BBE\u7F6E",asrLanguage:"\u8BC6\u522B\u8BED\u8A00",asrChunkSeconds:"\u97F3\u9891\u5206\u7247",asrTest:"\u6D4B\u8BD5\u8FDE\u63A5",asrSave:"\u4FDD\u5B58\u8BBE\u7F6E",asrPermissionDenied:"\u672A\u6388\u4E88\u8BE5\u670D\u52A1\u5730\u5740\u7684\u7F51\u7EDC\u6743\u9650\u3002",asrSaved:"\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002",asrInvalidConfig:"\u8BBE\u7F6E\u65E0\u6548\uFF0C\u8BF7\u68C0\u67E5\u670D\u52A1\u5730\u5740\u548C\u6A21\u578B\u3002",asrTesting:"\u6B63\u5728\u6D4B\u8BD5\u8BC6\u522B\u670D\u52A1...",asrTestPassed:"\u8FDE\u63A5\u6D4B\u8BD5\u901A\u8FC7\u3002",asrTestFailed:"\u8FDE\u63A5\u6D4B\u8BD5\u5931\u8D25",poseEditor:"\u59FF\u52BF\u7F16\u8F91\u5668",recorder:"\u5F55\u5236\u5DE5\u5177",help:"\u5E2E\u52A9\u6587\u6863",tagline:"\u8BA9\u4FE1\u606F\u65E0\u969C\u788D",auto:"\u81EA\u52A8\u68C0\u6D4B",simplifiedChinese:"\u4E2D\u6587\uFF08\u666E\u901A\u8BDD\uFF09",footer:"SignBridge \u2014 \u8BA9\u4FE1\u606F\u65E0\u969C\u788D",signLanguageTypes:{csl:"\u4E2D\u56FD\u624B\u8BED (CSL)",asl:"\u7F8E\u56FD\u624B\u8BED (ASL)",bsl:"\u82F1\u56FD\u624B\u8BED (BSL)",jsl:"\u65E5\u672C\u624B\u8BED (JSL)",ksl:"\u97E9\u56FD\u624B\u8BED (KSL)",tsl:"\u53F0\u6E7E\u624B\u8BED (TSL)"},avatarStyles:{default:"\u9ED8\u8BA4",friendly:"\u53CB\u597D",professional:"\u4E13\u4E1A",anime:"\u52A8\u6F2B\u98CE\u683C"},voiceVolumeLevels:{low:"\u4F4E\uFF08\u4EC5\u89C6\u9891\uFF09",medium:"\u4E2D\uFF08\u89C6\u9891+\u624B\u8BED\uFF09",high:"\u9AD8\uFF08\u4EC5\u624B\u8BED\uFF09"}},en:{batchTitle:"Vocabulary batch \xB7 up to 8 items",batchManual:"Add a complete phrase manually (optional, avoids token-splitting mistakes)",batchInvalidWord:"Enter a word or phrase of 1\u2013100 characters, not only whitespace or punctuation.",batchIntro:"Add frequent gaps from the analysis. Save a draft, inspect it in Motion review, then explicitly enable it in the editor or recorder. A full match means data is available, not that the sign is linguistically correct. This list never generates, edits or enables motions.",batchAdd:"Add to batch",batchRefresh:"Refresh batch status",batchExport:"Download progress JSON",batchClear:"Clear batch list",batchClearConfirm:"Clear only this list? Motions and visual baselines will not be deleted.",batchRemove:"Remove from batch",batchState:"Actual match status / motion IDs",batchLoading:"Checking the current motion library\u2026",batchEmpty:"No selected words. Analyze a sample, then add vocabulary gaps to this batch.",batchMissing:"Needs authoring \xB7 not fully matched",batchDraft:"Candidate saved \xB7 not enabled or fully matched",batchMatched:"Fully matched \xB7 human sign-language review still required",batchUnverified:"Status not verified; please retry",batchSummary:"Batch {count}/{max} \xB7 fully matched {matched} \xB7 invalid library entries {invalid}. Motion changes trigger a fresh check.",batchPrivacy:"Only words you explicitly add persist in this extension's local storage. No source text or examples are saved or uploaded. The list is not part of a motion pack. Progress exports contain selected words and motion IDs; check privacy before sharing.",batchFailure:"Vocabulary batch failed: {detail}",batchFull:"This batch already has 8 words. Complete or remove some first.",batchInvalid:"Invalid batch data. Existing data was not overwritten; explicitly clear the list to start again.",batchLockUnavailable:"Cross-page write lock unavailable. No changes made. Open this page from the extension panel.",reviewTitle:"Motion review",reviewIntro:"Replay saved motions and compare fixed front, right and left snapshots with manually approved visual references. No rig changes or automatic translation approval.",reviewLimits:"Up to 8 motions per batch and 12 sampled keyframes per motion, including first and last. Snapshots cover target poses, not every transition, collision, subtitle sequence or linguistic meaning. Human review is required. The built-in list covers SIGNS, not CHARS fallbacks.",reviewHelp:"Control panel \u2192 Motion review. Select motions to replay or capture three views. Check hands, directions and intersections before saving a visual baseline. Later captures appear alongside it. Changed motion data requires new review; different model/browser/rendering environments disable numeric comparison. Baselines do not change draft or enabled status, and do not certify correct signing.",reviewStorageHelp:"References stay in this extension's IndexedDB, separate from the motion library, capped at 100 / 64 MiB. Motion packs do not include them. Download PNG and JSON before uninstalling (baseline reimport is not supported yet). Nothing is sent over the network.",reviewReload:"Reload model / retry",reviewSelect:"1 \xB7 Select motions",reviewSearch:"Filter by name, ID or status (checked motions remain selected)",reviewCatalogCount:"{total} available \xB7 {count}/{max} selected \xB7 {invalid} invalid library records",reviewPlay:"Replay all frames in order",reviewCapture:"Capture three-view keyframes",reviewStop:"Stop current task",reviewPreview:"Fixed-view preview",reviewView:"Playback view",reviewFront:"Front",reviewRight:"Character's right",reviewLeft:"Character's left",reviewPreviewHelp:"Views never change the floating avatar. Each replay starts from REST; capture resets to the front view.",reviewResults:"2 \xB7 Human review and baseline comparison",reviewExport:"Download batch JSON report",reviewBuiltin:"Built-in \xB7 needs human review",reviewEnabled:"Custom \xB7 enabled",reviewDraft:"Custom \xB7 draft",reviewLoading:"Loading the actual model, rig and motion library\u2026",reviewReady:"Ready: {total} motions. Select motions to replay or capture.",reviewFailure:"Review failed: {detail}",reviewCatalogChanged:"The library changed; these results are stale. Select and capture again. Existing baselines are never overwritten automatically.",reviewPlaying:"Playing {index}/{total}: {name}",reviewCapturing:"Capturing {index}/{total}: {name}",reviewFinished:"Finished {count} motions; {failures} structural errors. Human review is still required.",reviewCancelled:"Stopped. Incomplete batch captures discarded; baselines unchanged.",reviewDiagnostics:"{frames} frames / {duration}s, {bones} bones. Sheet rows: frames {indices}; {omitted} frames not captured.",reviewSheetOrder:"Columns: front \u2192 character's right \u2192 character's left. Rows follow frame indices. Download PNG to inspect at full size.",reviewCurrent:"Current capture",reviewBaseline:"Confirmed visual reference",reviewNoBaseline:"No visual reference yet. Inspect the motion before saving one.",reviewCompared:"Baseline {date}. Pixels with RGB channel difference >16: {ratio}%; mean channel difference {mean}/255. Review hint only, not signing or collision certification.",reviewMotionChanged:"Motion data changed (including duration or name). Previous reference retained; numeric comparison disabled. Review again.",reviewIncompatible:"Model, rig, browser or rendering environment differs. Numeric comparison is unreliable and disabled. Old image is for reference only.",reviewUnavailable:"Baseline read / comparison failed: {detail}. Current PNG remains downloadable; saving will retry.",reviewSaveBaseline:"Save / replace visual reference",reviewDeleteBaseline:"Delete this reference",reviewDownloadImage:"Download current PNG",reviewSaveConfirm:"Have you checked all three views of \u201C{name}\u201D? Saving replaces its existing visual reference for regression comparison only. It neither enables translation nor certifies correct signing.",reviewDeleteConfirm:"Delete the visual reference for \u201C{name}\u201D? The motion itself is not deleted.",reviewSaved:"Visual reference saved; motion library and translation status unchanged.",reviewDeleted:"Visual reference deleted; motion data unchanged.",reviewStorageError:"Cannot access local baseline storage. Check disk space and reopen from the extension control panel.",reviewStorageFull:"Reference limit reached (100 or 64 MiB). Download a copy, then remove unneeded references.",reviewBaselineChanged:"Another page updated this reference. Nothing overwritten. Capture again before confirming.",reviewModelError:"Model load failed or dimensions invalid. Rebuild the extension and retry.",reviewMissingBones:"Required signing bones are missing; review blocked.",reviewRenderError:"Rendering failed or WebGL context was lost. Stop and reload the model.",reviewInvalidSamples:"Invalid keyframe sampling parameters.",reviewImageMismatch:"Reference image is damaged or dimensions differ; comparison blocked.",motionPackTitle:"Library backup / batch import",motionPackHelp:"Export all saved custom motions for this model, not unsaved edits or built-in signs. Choosing a file only runs preflight. Confirmation adds drafts: identical IDs/content are skipped; differing content blocks the entire import. Load, preview and confirm each new motion separately.",motionPackPrivacy:"Files contain names, matching text, tags, rig binding, frames and an informational enabled-at-export flag, not keys or subtitles. Names and tags may be sensitive; check before sharing. Imports never inherit approval and are not uploaded.",motionPackExport:"Back up all saved motions",motionPackFile:"Select motion pack JSON (not a single-motion file)",motionPackLimits:"Up to 500 motions / 8 MiB per pack; 2 MiB per motion. Rig and REST must match.",motionPackInspect:"Run preflight again",motionPackImport:"Confirm import as new drafts",motionPackClear:"Cancel pending file",motionPackSummary:"Preflight: {new} new, {existing} existing, {conflict} ID conflicts. Nothing has been saved.",motionPackName:"Motion / ID",motionPackState:"Action",motionPackWarnings:"Review notes",motionPackNew:"New draft",motionPackExisting:"Identical; skip",motionPackIdConflict:"ID conflict; no overwrite",motionPackWasEnabled:"Pack says previously enabled; this is source information, not trusted approval.",motionPackAliases:"Potential duplicate matching text: {aliases}. Draft saving is allowed; review before enabling (includes disabled entries).",motionPackMaterial:"No matching text; pose material only, not eligible for translation.",motionPackReady:"Preflight complete. Only new drafts are added; current pose and existing approval remain unchanged.",motionPackChecking:"Checking the rig and local library\u2026",motionPackCleared:"Cancelled. The library is unchanged.",motionPackConfirm:"Add {count} drafts without overwriting or enabling motions? Ensure you have permission to use the source. Review handshape, direction and meaning individually after import.",motionPackImported:"Added {imported} drafts; skipped {skipped} existing motions. Load, preview and confirm each from the list.",motionPackExported:"Started download of {count} saved motions. Check the downloaded file; unsaved edits are not included.",motionPackInvalid:"Not a valid v1 motion pack JSON. For one motion, use the single-motion import above.",motionPackEmpty:"The pack is empty, or there are no saved motions to back up.",motionPackTooLarge:"Limit exceeded: 8 MiB / 500 motions per pack, 2 MiB per motion. Nothing was saved.",motionPackDuplicateId:"Duplicate IDs within the pack are ambiguous; import was rejected.",motionPackInvalidStored:"Local entries are damaged or incompatible with the current model. No incomplete backup was produced; originals are preserved. Inspect those entries first.",motionPackConflict:"A local ID has different or damaged content. The entire import is blocked; nothing is overwritten. Use single-motion import to create a separate copy if needed.",motionPackStale:"The library changed and preflight expired. Run preflight again and review the list before importing.",motionPackLockUnavailable:"Cross-page write locking is unavailable. Batch import stopped; reopen the tool from the extension panel.",motionPackEncoding:"Not valid UTF-8 JSON. Convert the encoding and retry.",coverageTitle:"Vocabulary coverage",coverageHelpWorkflow:"Open Vocabulary coverage from the control panel. Paste text or import UTF-8 TXT / SRT / VTT to inspect unknown words, frequency and context. Editor and recorder buttons only prefill a name and matching text. Create and review a motion, enable it, then analyze again to verify it is active.",coverageIntro:"Find missing vocabulary in real text, then create and review motions. This does not generate signs or change existing poses.",coverageInput:"1 \xB7 Choose material",coverageTextLabel:"Paste text (one segment per line), or import UTF-8 subtitles",coverageLimits:"Limits: 256 KiB file, 50,000 characters, 1,000 segments, 2,000 characters per segment. SRT / WebVTT use subtitle cues.",coverageFormat:"Format",coveragePlainText:"Plain text \xB7 one segment per line",coverageImport:"Import file",coverageAnalyze:"Analyze current vocabulary",coverageClear:"Clear",coverageResults:"2 \xB7 Prioritize missing vocabulary",coverageMetricHelp:"Coverage = matched word tokens / (matched + unknown word tokens). Skipped function words and punctuation are excluded. This measures full-segment dictionary coverage, not sign accuracy, sentence meaning or completed playback.",coverageUnknownTitle:"Unknown words \xB7 most frequent first",coverageDraftHelp:"These are tokenizer suggestions. Check context before deciding whether a full phrase is needed. Tools only prefill the name and matching text: no automatic save, approval or claim that the current pose represents the word.",coverageWord:"Unknown word",coverageFrequency:"Occurrences / segments",coverageExamples:"Example segment numbers",coverageMake:"Create and review",coverageDetailsTitle:"3 \xB7 Inspect actual matches by segment",coverageDisplayLimit:"Shows up to 100 unknown words and 200 segments. Totals cover all input; export for complete results.",coverageIncludeText:"Include source text and segment details in export (may contain private data)",coverageExport:"Export JSON report",coveragePrivacy:"Analysis stays in this page's memory: no uploads or automatic saving. Closing the page discards it. Default exports omit source text but still contain unknown words; check before sharing.",coverageSummary:"Coverage {ratio} \xB7 {segments} segments \xB7 {matched} matched / {unknown} unknown / {skipped} skipped",coverageNoTokens:"N/A (no translatable tokens)",coverageTruncation:"{count} segments reach the runtime limit of 12 motions per segment. Some text may not play; inspect the remaining text below.",coverageOccurrences:"{count} occurrences / {segments} segments",coverageUniqueUnknown:"{count} distinct unknown words. Split or reconsider tokenization for very long words.",coverageNoUnknown:"No unknown words found. Sign meaning and motion still need human review.",coverageMatches:"Matched: {value}",coverageUnmatched:"Unknown: {value}",coverageSkipped:"Skipped: {value}",coverageRemaining:"Text remaining after playback limit: {value}",coverageCatalog:"Vocabulary: {signs} built-in signs / {aliases} lookup aliases / {chars} characters; {enabled} active custom; {drafts} inactive; {invalid} invalid or incompatible entries (originals kept).",coverageReady:"Paste or import, then analyze. The first analysis loads the model to validate custom motion bindings.",coverageLoading:"Validating model and library, then analyzing\u2026",coverageDone:"Analysis complete. Create missing motions, review and enable them, then analyze again here.",coverageChanged:"Input changed. Analyze again; the old report cannot be exported.",coverageCatalogChanged:"Shared library changed. Analyze again for current coverage; the old report cannot be exported.",coverageImported:"Imported. Click Analyze; nothing is played or saved automatically.",coverageFailure:"Analysis did not complete: {detail}",coverageTooLarge:"Material exceeds size, segment count or segment length limits. Split it and try again.",coverageEmpty:"Provide at least one non-empty text segment.",coverageInvalidFormat:"Only TXT, SRT and WebVTT are supported. Select the matching format.",coverageInvalidSubtitles:"Invalid subtitles. Check blank lines, timestamps, start/end order and WebVTT header. Timing lines will not be counted as text.",coverageEncoding:"Not valid UTF-8. Convert the file encoding and retry.",coverageModelError:"Cannot validate the current model or shared library. Open from the extension, check model loading and retry. No incomplete fallback report was produced.",coverageOpenFailed:"Could not open the tool. Retry from the extension panel.",coveragePrefilled:"Name and matching text prefilled from coverage. The current pose is not a verified sign for this word. Create, save, preview and review it before enabling.",motionLibraryTitle:"Shared motion library \xB7 Phase 2",motionLibraryHelp:"Editor, recorder and avatar share radians and REST deltas. Saved drafts affect translation only after preview and explicit confirmation.",motionName:"Motion name (required)",motionTexts:"Matching text (comma separated; empty for pose-only assets)",motionTags:"Tags (comma separated)",motionNew:"New copy",motionNewHelp:"Current pose retained. Enter a new motion name.",motionSave:"Save draft",motionSaved:"Draft saved. Preview and confirm again before enabling.",motionLoad:"Load selected",motionLoaded:"Loaded. Imported files are not automatically saved or enabled. Review and save a draft.",motionChoose:"Choose a saved motion\u2026",motionDraft:"Draft / disabled",motionEnabled:"Confirmed and enabled",motionPreview:"Preview current motion",motionPreviewHelp:"Using the same player as the avatar. Check handshape, direction, collisions and meaning. Save again after edits.",motionEnable:"Confirm for translation",motionDisable:"Disable selected",motionConfirm:"I have previewed the entire motion and checked its handshape, direction, collisions and meaning. This is my confirmation, not professional sign-language certification. Enable it?",motionEnabledHelp:"Enabled. Open avatars reload automatically; newly matched text will use this motion.",motionDisabledHelp:"Disabled; draft retained. Queued custom motions are cancelled in open avatars.",motionRefresh:"Refresh list",motionExport:"Download unified JSON",motionExportCode:"Export code (no save)",motionImport:"Import motion JSON",motionImportFormat:"Import format and units",motionFormat:"Unified \xB7 radians / REST delta",motionLegacyEditor:"Legacy editor delta \xB7 degrees (pose object only)",motionLegacyRecorder:"Legacy recorder frames.pose \xB7 degrees",motionLegacyAbsolute:"Legacy editor absolute rotation \xB7 radians",motionMigrate:"Migrate this page's old library",motionLegacyConfirm:"Legacy data has no rig binding. Continue only if it came from the current model with the selected format and units. Review each converted draft. Original local data will be retained. Continue?",motionMigrated:"Migrated {count} drafts; originals retained, none enabled. Repeating creates copies.",motionIgnored:"Skipped {count} damaged or rig-incompatible entries; original data retained.",motionFailure:"Not completed: {detail}",motionInvalidData:"Invalid motion format or parameters: {detail}",motionModelNotReady:"The model is not ready.",motionRigMismatch:"Skeleton or REST pose mismatch. Motion rejected.",motionStorageUnavailable:"Shared storage unavailable. Open this tool from the extension panel.",motionSelectFirst:"Save or select a motion first.",motionSaveFirst:"Motion changed. Save a draft and preview again before enabling.",motionPreviewFirst:"Preview this motion before confirming.",motionAliasConflict:"Empty text or alias conflicts with an enabled/built-in sign: {detail}. Choose a distinct phrase.",motionFileTooLarge:"File or entry count too large (2 MiB per file).",motionEditorSingleFrame:"The editor handles single poses. Open multi-frame clips in the recorder to avoid losing frames.",motionFrameLimit:"240-frame limit reached. Recording stopped.",motionFrameDuration:"Keyframe duration (seconds, 0.05\u201310)",motionUpdateFrame:"Update selected frame",motionHelpRig:"Godette uses standard Humanoid bone mappings and the available finger chains. The editor, recorder and floating avatar share one profile and REST pose.",motionHelpAxes:"X/Y/Z are bone-local axes, not fixed world directions. Exports use REST-relative radians; recorder bone sliders show absolute local radians. Do not assume the same axis direction for every bone.",motionHelpCreate:"Use the editor for single poses and the recorder for clips. Enter a name, matching text and tags, then save a draft. Leave matching text empty for pose material. Custom aliases cannot override built-in or enabled aliases.",motionHelpReview:"Save draft \u2192 Preview current motion \u2192 Check handshape, direction, collisions and meaning \u2192 Confirm for translation. Test the matching text from the control panel. Confirmation is not professional sign-language certification.",motionHelpFrames:"Select a timeline frame, edit bones and duration, then click Update selected frame. Add keyframes for new poses. Each frame is 0.05\u201310 seconds; up to 240 frames and 120 seconds total. Automatic recording samples every 0.3 seconds.",motionHelpUpdates:"Both tools and the avatar share local storage within one extension ID and browser profile. Enabling or disabling refreshes the avatar and cancels old playback queues. Saving again revokes approval. New copy keeps poses without overwriting the original motion.",motionHelpBackup:"Download unified JSON for backups; exporting does not save or enable. Imports are new draft copies requiring saving, preview and confirmation. Open multi-frame files in the recorder, not the single-pose editor. Back up before uninstalling or changing extension IDs.",motionHelpLegacy:"Migrating the old page library retains sb_gestures; repeating migration creates copies. Explicitly select degrees or absolute radians for old JSON files. Units are never guessed and code is never executed. Legacy data must use the current model and requires manual review.",motionHelpBinding:"Files are limited to 2 MiB. Incompatible bone/REST bindings, unknown bones and invalid values are rejected. This binding is not a full GLB or skin-weight fingerprint. Open tools from the extension popup; standalone localhost pages cannot share this storage. Reload the extension and reopen old tool tabs after updating.",motionHelpCollision:"Identify the exact motion and frame. Inspect elbows and wrists from front and side views in the tools. Edit and review only that motion; do not globally reverse axes or increase angles.",motionHelpCoverage:"Inspect matched motionIds and unmatched text. Unknown input does not interrupt current playback.",motionHelpCatalog:"Inspect enabled custom motion and invalid entry counts. Drafts do not participate in translation.",motionDurationInvalid:"Keyframe duration must be 0.05\u201310 seconds.",motionLoadingFailed:"Model loading failed: {detail}",name:"English",title:"SignBridge \u2014 Sign Language Translation",description:"Real-time video speech to sign language translation via 3D avatar",settings:"Settings",avatar:"Avatar",language:"Language",sourceLanguage:"Video Language",targetSignLanguage:"Sign Language",avatarStyle:"Avatar Style",avatarSize:"Avatar Size",avatarPosition:"Avatar Position",positionBottomRight:"Bottom Right",positionBottomLeft:"Bottom Left",positionTopRight:"Top Right",positionTopLeft:"Top Left",enableAutoDetect:"Auto-detect Video",enableSubtitles:"Show Subtitles",voiceVolume:"Voice Volume",speed:"Sign Speed",about:"About",start:"Start Translation",stop:"Stop Translation",loading:"Loading...",noVideo:"No video detected",error:"Error",errorNoVideo:"No video found on this page",ready:"Ready",translating:"Translating...",unavailable:"Unavailable on this page",inputPlaceholder:"Enter text for the avatar to sign...",send:"Send",sent:"Sent",audioOff:"Video audio: Off",audioOn:"Video audio: On",audioStopped:"Stopped",audioListening:"Recognizing...",audioStarting:"Capturing audio...",audioUnavailable:"Audio capture is unavailable on this page",audioCaptureFailed:"Audio capture failed",audioCloudKeyRequired:"Configure the cloud API key first",audioPermissionRequired:"Save ASR settings and allow the service origin",audioLocalUnavailable:"Deploy local Whisper first",asrSettings:"Audio recognition settings",asrTitle:"Video audio recognition",asrPurpose:"Choose local Whisper or cloud ASR to convert video audio into sign language motion.",asrProvider:"Recognition provider",asrLocal:"Local Whisper",asrCloud:"Cloud ASR",asrLocalSettings:"Local Whisper settings",asrLocalPrivacy:"The model and audio stay inside the extension. Video audio is not uploaded to an ASR service.",asrDeployLocal:"Deploy local Whisper",asrEndpoint:"Service endpoint",asrModel:"Model",asrModelTiny:"tiny (fastest, about 75 MB)",asrModelBase:"base (balanced, about 150 MB)",asrModelSmall:"small (more accurate, about 500 MB)",asrDeployHint:"Downloads and caches the model automatically. Python and a local service are not required.",asrDeployRequired:"The selected model is not deployed.",asrRequestingModelPermission:"Requesting model download access...",asrDeploying:"Downloading and initializing model: {progress}%",asrDeployReady:"Local model {model} is ready.",asrDeployFailed:"Local model deployment failed",asrCloudSettings:"Cloud ASR settings",asrCloudPrivacy:"Video audio chunks are sent to the configured service. Review its privacy and billing terms.",asrApiKey:"API Key",asrCommonSettings:"Common settings",asrLanguage:"Recognition language",asrChunkSeconds:"Audio chunk",asrTest:"Test connection",asrSave:"Save settings",asrPermissionDenied:"Network access to this service was not granted.",asrSaved:"Settings saved.",asrInvalidConfig:"Invalid settings. Check the endpoint and model.",asrTesting:"Testing the recognition service...",asrTestPassed:"Connection test passed.",asrTestFailed:"Connection test failed",poseEditor:"Pose editor",recorder:"Recorder",help:"Help",tagline:"Accessible information",auto:"Auto detect",simplifiedChinese:"Chinese (Mandarin)",footer:"SignBridge \u2014 Making Information Accessible",signLanguageTypes:{csl:"Chinese Sign Language (CSL)",asl:"American Sign Language (ASL)",bsl:"British Sign Language (BSL)",jsl:"Japanese Sign Language (JSL)",ksl:"Korean Sign Language (KSL)",tsl:"Taiwan Sign Language (TSL)"},avatarStyles:{default:"Default",friendly:"Friendly",professional:"Professional",anime:"Anime Style"},voiceVolumeLevels:{low:"Low (video only)",medium:"Medium (video + sign)",high:"High (sign only)"}},ja:{batchTitle:"\u4ECA\u56DE\u306E\u8A9E\u5F59\u8FFD\u52A0\u30EA\u30B9\u30C8 \xB7 \u6700\u5927 8 \u4EF6",batchManual:"\u8A9E\u53E5\u3092\u624B\u52D5\u3067\u8FFD\u52A0\uFF08\u4EFB\u610F\u30FB\u5206\u5272\u306E\u8AA4\u308A\u3092\u56DE\u907F\uFF09",batchInvalidWord:"\u7A7A\u767D\u3084\u8A18\u53F7\u3060\u3051\u3067\u306F\u306A\u3044\u30011\uFF5E100 \u6587\u5B57\u306E\u8A9E\u53E5\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchIntro:"\u5206\u6790\u7D50\u679C\u304B\u3089\u983B\u51FA\u306E\u672A\u5BFE\u5FDC\u8A9E\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u300C\u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C\u300D\u3067\u78BA\u8A8D\u3057\u3066\u304B\u3089\u3001\u7DE8\u96C6\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u3067\u660E\u793A\u7684\u306B\u6709\u52B9\u5316\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5B8C\u5168\u4E00\u81F4\u306F\u30C7\u30FC\u30BF\u306E\u5B58\u5728\u3092\u793A\u3059\u3060\u3051\u3067\u3001\u624B\u8A71\u306E\u6B63\u78BA\u3055\u3092\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002\u3053\u306E\u30EA\u30B9\u30C8\u306F\u52D5\u4F5C\u306E\u751F\u6210\u30FB\u5909\u66F4\u30FB\u6709\u52B9\u5316\u3092\u884C\u3044\u307E\u305B\u3093\u3002",batchAdd:"\u4ECA\u56DE\u306E\u30EA\u30B9\u30C8\u306B\u8FFD\u52A0",batchRefresh:"\u5BFE\u5FDC\u72B6\u6CC1\u3092\u66F4\u65B0",batchExport:"\u9032\u6357 JSON \u3092\u4FDD\u5B58",batchClear:"\u4ECA\u56DE\u306E\u30EA\u30B9\u30C8\u3092\u6D88\u53BB",batchClearConfirm:"\u30EA\u30B9\u30C8\u3060\u3051\u3092\u6D88\u53BB\u3057\u307E\u3059\u304B\uFF1F\u52D5\u4F5C\u3068\u6BD4\u8F03\u57FA\u6E96\u306F\u524A\u9664\u3055\u308C\u307E\u305B\u3093\u3002",batchRemove:"\u30EA\u30B9\u30C8\u304B\u3089\u5916\u3059",batchState:"\u5B9F\u969B\u306E\u5BFE\u5FDC\u72B6\u6CC1 / \u52D5\u4F5C ID",batchLoading:"\u73FE\u5728\u306E\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u4E2D\u2026",batchEmpty:"\u30EA\u30B9\u30C8\u306F\u7A7A\u3067\u3059\u3002\u7D20\u6750\u3092\u5206\u6790\u3057\u3001\u672A\u5BFE\u5FDC\u8A9E\u3092\u8FFD\u52A0\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchMissing:"\u5236\u4F5C\u5F85\u3061 \xB7 \u5B8C\u5168\u4E00\u81F4\u306A\u3057",batchDraft:"\u5019\u88DC\u3092\u4FDD\u5B58\u6E08\u307F \xB7 \u672A\u6709\u52B9\u5316\u307E\u305F\u306F\u5B8C\u5168\u4E00\u81F4\u306A\u3057",batchMatched:"\u5B8C\u5168\u4E00\u81F4\u3042\u308A \xB7 \u624B\u8A71\u306E\u4EBA\u306B\u3088\u308B\u78BA\u8A8D\u304C\u5FC5\u8981",batchUnverified:"\u672A\u691C\u8A3C\u3067\u3059\u3002\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044",batchSummary:"\u4ECA\u56DE {count}/{max} \u4EF6 \xB7 \u5B8C\u5168\u4E00\u81F4 {matched} \u4EF6 \xB7 \u7121\u52B9\u306A\u8A18\u9332 {invalid} \u4EF6\u3002\u52D5\u4F5C\u306E\u5909\u66F4\u6642\u306B\u518D\u78BA\u8A8D\u3057\u307E\u3059\u3002",batchPrivacy:"\u660E\u793A\u7684\u306B\u8FFD\u52A0\u3057\u305F\u8A9E\u3060\u3051\u3092\u62E1\u5F35\u6A5F\u80FD\u5185\u306B\u4FDD\u5B58\u3057\u3001\u518D\u8AAD\u307F\u8FBC\u307F\u5F8C\u3082\u4FDD\u6301\u3057\u307E\u3059\u3002\u539F\u6587\u30FB\u4F8B\u6587\u306F\u4FDD\u5B58\u3082\u9001\u4FE1\u3082\u3057\u307E\u305B\u3093\u3002\u30EA\u30B9\u30C8\u306F\u52D5\u4F5C\u30D1\u30C3\u30AF\u306B\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u9032\u6357\u30D5\u30A1\u30A4\u30EB\u306B\u306F\u9078\u629E\u8A9E\u3068\u52D5\u4F5C ID \u304C\u5165\u308B\u305F\u3081\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchFailure:"\u8A9E\u5F59\u30EA\u30B9\u30C8\u306E\u64CD\u4F5C\u306B\u5931\u6557\uFF1A{detail}",batchFull:"\u6700\u5927 8 \u4EF6\u306B\u9054\u3057\u307E\u3057\u305F\u3002\u4E00\u90E8\u3092\u5B8C\u4E86\u307E\u305F\u306F\u524A\u9664\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchInvalid:"\u30EA\u30B9\u30C8\u306E\u30C7\u30FC\u30BF\u304C\u7121\u52B9\u3067\u3059\u3002\u5143\u306E\u8A18\u9332\u306F\u7DAD\u6301\u3055\u308C\u307E\u3059\u3002\u660E\u793A\u7684\u306B\u6D88\u53BB\u3057\u3066\u518D\u4F5C\u6210\u3067\u304D\u307E\u3059\u3002",batchLockUnavailable:"\u30DA\u30FC\u30B8\u9593\u66F8\u304D\u8FBC\u307F\u30ED\u30C3\u30AF\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u5909\u66F4\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u62E1\u5F35\u6A5F\u80FD\u30D1\u30CD\u30EB\u304B\u3089\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",reviewTitle:"\u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C",reviewIntro:"\u4FDD\u5B58\u6E08\u307F\u52D5\u4F5C\u3092\u518D\u751F\u3057\u3001\u6B63\u9762\u30FB\u53F3\u5074\u30FB\u5DE6\u5074\u306E\u56FA\u5B9A\u753B\u50CF\u3092\u624B\u52D5\u78BA\u8A8D\u6E08\u307F\u306E\u57FA\u6E96\u3068\u6BD4\u8F03\u3057\u307E\u3059\u3002\u9AA8\u683C\u3084\u7FFB\u8A33\u306E\u6709\u52B9\u5316\u72B6\u614B\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",reviewLimits:"\u4E00\u5EA6\u306B8\u52D5\u4F5C\u307E\u3067\u3001\u5404\u52D5\u4F5C\u306F\u5148\u982D\u3068\u672B\u5C3E\u3092\u542B\u3080\u6700\u592712\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u3092\u62BD\u51FA\u3057\u307E\u3059\u3002\u753B\u50CF\u306F\u76EE\u6A19\u59FF\u52E2\u306E\u307F\u3067\u3001\u5168\u9077\u79FB\u30FB\u885D\u7A81\u30FB\u5B57\u5E55\u6587\u306E\u518D\u751F\u30FB\u624B\u8A71\u306E\u610F\u5473\u306F\u691C\u8A3C\u3067\u304D\u307E\u305B\u3093\u3002\u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002\u5185\u8535\u4E00\u89A7\u306FSIGNS\u306E\u307F\u3067\u3001CHARS\u306F\u542B\u307F\u307E\u305B\u3093\u3002",reviewHelp:"\u30D1\u30CD\u30EB \u2192 \u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C\u3002\u52D5\u4F5C\u3092\u9078\u3073\u518D\u751F\u307E\u305F\u306F3\u65B9\u5411\u64AE\u5F71\u3092\u884C\u3044\u3001\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u3081\u308A\u8FBC\u307F\u3092\u78BA\u8A8D\u3057\u3066\u57FA\u6E96\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002\u6B21\u56DE\u306E\u753B\u50CF\u3092\u4E26\u3079\u3066\u6BD4\u8F03\u3067\u304D\u307E\u3059\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u306E\u5909\u66F4\u306F\u518D\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3001\u30E2\u30C7\u30EB\u30FB\u30D6\u30E9\u30A6\u30B6\u30FB\u63CF\u753B\u74B0\u5883\u304C\u7570\u306A\u308B\u5834\u5408\u306F\u6570\u5024\u6BD4\u8F03\u3057\u307E\u305B\u3093\u3002\u57FA\u6E96\u4FDD\u5B58\u306F\u624B\u8A71\u306E\u6B63\u3057\u3055\u3092\u4FDD\u8A3C\u305B\u305A\u3001\u4E0B\u66F8\u304D\u3084\u6709\u52B9\u5316\u72B6\u614B\u3082\u5909\u3048\u307E\u305B\u3093\u3002",reviewStorageHelp:"\u57FA\u6E96\u753B\u50CF\u306F\u62E1\u5F35\u6A5F\u80FD\u306EIndexedDB\u306B\u4FDD\u5B58\u3055\u308C\u3001\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3068\u306F\u5225\u3067\u6700\u5927100\u4EF6 / 64 MiB\u3067\u3059\u3002\u52D5\u4F5C\u30D1\u30C3\u30AF\u306B\u306F\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u524A\u9664\u524D\u306BPNG\u3068JSON\u3092\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u57FA\u6E96\u306E\u518D\u53D6\u8FBC\u306F\u672A\u5BFE\u5FDC\uFF09\u3002\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u9001\u4FE1\u306F\u3042\u308A\u307E\u305B\u3093\u3002",reviewReload:"\u30E2\u30C7\u30EB\u518D\u8AAD\u8FBC / \u518D\u8A66\u884C",reviewSelect:"1 \xB7 \u52D5\u4F5C\u3092\u9078\u629E",reviewSearch:"\u540D\u524D\u30FBID\u30FB\u72B6\u614B\u3067\u691C\u7D22\uFF08\u9078\u629E\u306F\u7DAD\u6301\u3055\u308C\u307E\u3059\uFF09",reviewCatalogCount:"{total}\u4EF6 \xB7 \u9078\u629E{count}/{max} \xB7 \u7121\u52B9\u30EC\u30B3\u30FC\u30C9{invalid}\u4EF6",reviewPlay:"\u5168\u30D5\u30EC\u30FC\u30E0\u3092\u9806\u756A\u306B\u518D\u751F",reviewCapture:"\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u30923\u65B9\u5411\u304B\u3089\u64AE\u5F71",reviewStop:"\u505C\u6B62",reviewPreview:"\u56FA\u5B9A\u8996\u70B9\u30D7\u30EC\u30D3\u30E5\u30FC",reviewView:"\u518D\u751F\u8996\u70B9",reviewFront:"\u6B63\u9762",reviewRight:"\u4EBA\u7269\u306E\u53F3\u5074",reviewLeft:"\u4EBA\u7269\u306E\u5DE6\u5074",reviewPreviewHelp:"\u30D5\u30ED\u30FC\u30C6\u30A3\u30F3\u30B0\u8868\u793A\u306B\u306F\u5F71\u97FF\u3057\u307E\u305B\u3093\u3002\u5404\u518D\u751F\u306FREST\u304B\u3089\u958B\u59CB\u3057\u3001\u64AE\u5F71\u5F8C\u306F\u6B63\u9762\u306B\u623B\u308A\u307E\u3059\u3002",reviewResults:"2 \xB7 \u76EE\u8996\u78BA\u8A8D\u3068\u57FA\u6E96\u6BD4\u8F03",reviewExport:"JSON\u30EC\u30DD\u30FC\u30C8\u3092\u4FDD\u5B58",reviewBuiltin:"\u5185\u8535 \xB7 \u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981",reviewEnabled:"\u30AB\u30B9\u30BF\u30E0 \xB7 \u6709\u52B9",reviewDraft:"\u30AB\u30B9\u30BF\u30E0 \xB7 \u4E0B\u66F8\u304D",reviewLoading:"\u5B9F\u969B\u306E\u30E2\u30C7\u30EB\u30FB\u9AA8\u683C\u30FB\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u8AAD\u8FBC\u4E2D\u2026",reviewReady:"{total}\u52D5\u4F5C\u3092\u8AAD\u8FBC\u5B8C\u4E86\u3002\u9078\u629E\u3057\u3066\u518D\u751F\u307E\u305F\u306F\u64AE\u5F71\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewFailure:"\u691C\u8A3C\u5931\u6557\uFF1A{detail}",reviewCatalogChanged:"\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u308F\u3063\u305F\u305F\u3081\u7D50\u679C\u306F\u7121\u52B9\u3067\u3059\u3002\u9078\u629E\u3057\u76F4\u3057\u3066\u64AE\u5F71\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u65E2\u5B58\u306E\u57FA\u6E96\u306F\u81EA\u52D5\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002",reviewPlaying:"\u518D\u751F {index}/{total}\uFF1A{name}",reviewCapturing:"\u64AE\u5F71 {index}/{total}\uFF1A{name}",reviewFinished:"{count}\u52D5\u4F5C\u5B8C\u4E86\u3001\u69CB\u9020\u30A8\u30E9\u30FC{failures}\u4EF6\u3002\u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002",reviewCancelled:"\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u672A\u5B8C\u4E86\u306E\u64AE\u5F71\u7D50\u679C\u306F\u7834\u68C4\u3057\u3001\u57FA\u6E96\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",reviewDiagnostics:"{frames}\u30D5\u30EC\u30FC\u30E0 / {duration}\u79D2\u3001{bones}\u9AA8\u683C\u3002\u753B\u50CF\u306E\u884C\uFF1A{indices}\u3002\u672A\u64AE\u5F71{omitted}\u30D5\u30EC\u30FC\u30E0\u3002",reviewSheetOrder:"\u5404\u884C\u306F\u5DE6\u304B\u3089\u6B63\u9762 \u2192 \u4EBA\u7269\u306E\u53F3\u5074 \u2192 \u5DE6\u5074\u3002\u884C\u306F\u30D5\u30EC\u30FC\u30E0\u9806\u3067\u3059\u3002PNG\u3092\u4FDD\u5B58\u3057\u3066\u62E1\u5927\u78BA\u8A8D\u3067\u304D\u307E\u3059\u3002",reviewCurrent:"\u73FE\u5728\u306E\u753B\u50CF",reviewBaseline:"\u78BA\u8A8D\u6E08\u307F\u306E\u57FA\u6E96\u753B\u50CF",reviewNoBaseline:"\u57FA\u6E96\u672A\u4FDD\u5B58\u3002\u52D5\u4F5C\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewCompared:"\u57FA\u6E96\u65E5\u6642{date}\u3002RGB\u5DEE\u5206>16\u306E\u753B\u7D20\uFF1A{ratio}%\u3001\u5E73\u5747\u5DEE\u5206{mean}/255\u3002\u53C2\u8003\u5024\u3067\u3042\u308A\u624B\u8A71\u306E\u6B63\u3057\u3055\u3084\u885D\u7A81\u3092\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002",reviewMotionChanged:"\u52D5\u4F5C\u30C7\u30FC\u30BF\uFF08\u6642\u9593\u3084\u540D\u79F0\u3092\u542B\u3080\uFF09\u304C\u5909\u308F\u308A\u307E\u3057\u305F\u3002\u65E7\u57FA\u6E96\u306F\u4FDD\u6301\u3057\u3001\u6570\u5024\u6BD4\u8F03\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u518D\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewIncompatible:"\u30E2\u30C7\u30EB\u30FB\u9AA8\u683C\u30FB\u30D6\u30E9\u30A6\u30B6\u30FB\u63CF\u753B\u74B0\u5883\u304C\u7570\u306A\u308A\u307E\u3059\u3002\u6570\u5024\u6BD4\u8F03\u306F\u884C\u308F\u305A\u3001\u65E7\u753B\u50CF\u306F\u53C2\u8003\u7528\u3067\u3059\u3002",reviewUnavailable:"\u57FA\u6E96\u8AAD\u8FBC / \u6BD4\u8F03\u5931\u6557\uFF1A{detail}\u3002\u73FE\u5728\u306E\u753B\u50CF\u306F\u4FDD\u5B58\u53EF\u80FD\u3067\u3059\u3002\u57FA\u6E96\u4FDD\u5B58\u3067\u518D\u8A66\u884C\u3057\u307E\u3059\u3002",reviewSaveBaseline:"\u76EE\u8996\u57FA\u6E96\u3092\u4FDD\u5B58 / \u7F6E\u63DB",reviewDeleteBaseline:"\u3053\u306E\u57FA\u6E96\u3092\u524A\u9664",reviewDownloadImage:"\u73FE\u5728\u306EPNG\u3092\u4FDD\u5B58",reviewSaveConfirm:"\u300C{name}\u300D\u30923\u65B9\u5411\u304B\u3089\u78BA\u8A8D\u3057\u307E\u3057\u305F\u304B\uFF1F\u65E2\u5B58\u306E\u76EE\u8996\u57FA\u6E96\u3092\u7F6E\u63DB\u3057\u307E\u3059\u3002\u7FFB\u8A33\u306E\u6709\u52B9\u5316\u3084\u624B\u8A71\u306E\u6B63\u3057\u3055\u306E\u8A8D\u8A3C\u306F\u884C\u3044\u307E\u305B\u3093\u3002",reviewDeleteConfirm:"\u300C{name}\u300D\u306E\u76EE\u8996\u57FA\u6E96\u3092\u524A\u9664\u3057\u307E\u3059\u304B\uFF1F\u52D5\u4F5C\u81EA\u4F53\u306F\u524A\u9664\u3057\u307E\u305B\u3093\u3002",reviewSaved:"\u76EE\u8996\u57FA\u6E96\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u3068\u7FFB\u8A33\u72B6\u614B\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",reviewDeleted:"\u76EE\u8996\u57FA\u6E96\u3092\u524A\u9664\u3057\u307E\u3057\u305F\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",reviewStorageError:"\u57FA\u6E96\u30B9\u30C8\u30EC\u30FC\u30B8\u306B\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u307E\u305B\u3093\u3002\u7A7A\u304D\u5BB9\u91CF\u3092\u78BA\u8A8D\u3057\u3001\u62E1\u5F35\u6A5F\u80FD\u30D1\u30CD\u30EB\u304B\u3089\u958B\u304D\u76F4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewStorageFull:"\u57FA\u6E96\u306E\u4E0A\u9650\uFF08100\u4EF6 / 64 MiB\uFF09\u3067\u3059\u3002\u753B\u50CF\u3092\u4FDD\u5B58\u3057\u3066\u4E0D\u8981\u306A\u57FA\u6E96\u3092\u524A\u9664\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewBaselineChanged:"\u5225\u30DA\u30FC\u30B8\u3067\u57FA\u6E96\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F\u3002\u4E0A\u66F8\u304D\u305B\u305A\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u518D\u64AE\u5F71\u3057\u3066\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewModelError:"\u30E2\u30C7\u30EB\u8AAD\u8FBC\u5931\u6557\u307E\u305F\u306F\u5BF8\u6CD5\u304C\u7121\u52B9\u3067\u3059\u3002\u518D\u30D3\u30EB\u30C9\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewMissingBones:"\u624B\u8A71\u306B\u5FC5\u8981\u306A\u9AA8\u683C\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u308B\u305F\u3081\u505C\u6B62\u3057\u307E\u3057\u305F\u3002",reviewRenderError:"\u63CF\u753B\u5931\u6557\u307E\u305F\u306FWebGL\u63A5\u7D9A\u304C\u5931\u308F\u308C\u307E\u3057\u305F\u3002\u505C\u6B62\u3057\u3066\u518D\u8AAD\u8FBC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewInvalidSamples:"\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u62BD\u51FA\u8A2D\u5B9A\u304C\u7121\u52B9\u3067\u3059\u3002",reviewImageMismatch:"\u57FA\u6E96\u753B\u50CF\u304C\u7834\u640D\u3057\u3066\u3044\u308B\u304B\u5BF8\u6CD5\u304C\u7570\u306A\u308B\u305F\u3081\u6BD4\u8F03\u3067\u304D\u307E\u305B\u3093\u3002",motionPackTitle:"\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u306E\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7 / \u4E00\u62EC\u53D6\u8FBC",motionPackHelp:"\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u306B\u5BFE\u5FDC\u3059\u308B\u4FDD\u5B58\u6E08\u307F\u30AB\u30B9\u30BF\u30E0\u52D5\u4F5C\u3092\u3059\u3079\u3066\u66F8\u304D\u51FA\u3057\u307E\u3059\u3002\u672A\u4FDD\u5B58\u306E\u7DE8\u96C6\u3084\u5185\u8535\u8F9E\u66F8\u306F\u542B\u307F\u307E\u305B\u3093\u3002\u30D5\u30A1\u30A4\u30EB\u9078\u629E\u306F\u4E8B\u524D\u78BA\u8A8D\u306E\u307F\u3067\u3059\u3002\u540C\u3058 ID\u30FB\u5185\u5BB9\u306F\u30B9\u30AD\u30C3\u30D7\u3057\u3001\u5185\u5BB9\u304C\u7570\u306A\u308B\u5834\u5408\u306F\u4E00\u62EC\u53D6\u8FBC\u5168\u4F53\u3092\u505C\u6B62\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u52D5\u4F5C\u306F\u4E0B\u66F8\u304D\u3068\u3057\u3066\u8FFD\u52A0\u3057\u3001\u500B\u5225\u306B\u8AAD\u8FBC\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackPrivacy:"\u30D5\u30A1\u30A4\u30EB\u306B\u306F\u540D\u524D\u3001\u7167\u5408\u6587\u5B57\u5217\u3001\u30BF\u30B0\u3001\u9AA8\u683C\u60C5\u5831\u3001\u30D5\u30EC\u30FC\u30E0\u3001\u66F8\u51FA\u6642\u306E\u6709\u52B9\u30D5\u30E9\u30B0\u306E\u307F\u542B\u307E\u308C\u3001\u30AD\u30FC\u3084\u5B57\u5E55\u306F\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u540D\u524D\u3084\u30BF\u30B0\u306E\u500B\u4EBA\u60C5\u5831\u3092\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u627F\u8A8D\u8A18\u9332\u306F\u5F15\u304D\u7D99\u304C\u305A\u3001\u30D5\u30A1\u30A4\u30EB\u3082\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u305B\u3093\u3002",motionPackExport:"\u4FDD\u5B58\u6E08\u307F\u306E\u5168\u52D5\u4F5C\u3092\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7",motionPackFile:"\u52D5\u4F5C\u30D1\u30C3\u30AF JSON \u3092\u9078\u629E\uFF08\u5358\u4E00\u52D5\u4F5C\u30D5\u30A1\u30A4\u30EB\u3067\u306F\u3042\u308A\u307E\u305B\u3093\uFF09",motionPackLimits:"1 \u30D1\u30C3\u30AF\u6700\u5927 500 \u52D5\u4F5C\u30FB8 MiB\u30011 \u52D5\u4F5C 2 MiB\u3002\u9AA8\u683C\u3068 REST \u306E\u4E00\u81F4\u304C\u5FC5\u8981\u3067\u3059\u3002",motionPackInspect:"\u518D\u5EA6\u4E8B\u524D\u78BA\u8A8D",motionPackImport:"\u65B0\u898F\u4E0B\u66F8\u304D\u3068\u3057\u3066\u53D6\u8FBC\u3092\u78BA\u8A8D",motionPackClear:"\u53D6\u8FBC\u5F85\u3061\u30D5\u30A1\u30A4\u30EB\u3092\u30AD\u30E3\u30F3\u30BB\u30EB",motionPackSummary:"\u4E8B\u524D\u78BA\u8A8D\uFF1A\u65B0\u898F {new}\u3001\u65E2\u5B58 {existing}\u3001ID \u7AF6\u5408 {conflict}\u3002\u307E\u3060\u4FDD\u5B58\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionPackName:"\u52D5\u4F5C / ID",motionPackState:"\u51E6\u7406",motionPackWarnings:"\u78BA\u8A8D\u4E8B\u9805",motionPackNew:"\u65B0\u898F\u4E0B\u66F8\u304D",motionPackExisting:"\u540C\u4E00\u5185\u5BB9\u30FB\u30B9\u30AD\u30C3\u30D7",motionPackIdConflict:"ID \u7AF6\u5408\u30FB\u4E0A\u66F8\u304D\u7981\u6B62",motionPackWasEnabled:"\u30D1\u30C3\u30AF\u4E0A\u3067\u306F\u4EE5\u524D\u6709\u52B9\u3002\u305F\u3060\u3057\u51FA\u6240\u306E\u60C5\u5831\u3067\u3042\u308A\u3001\u4FE1\u983C\u3055\u308C\u305F\u627F\u8A8D\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",motionPackAliases:"\u7167\u5408\u6587\u5B57\u5217\u304C\u91CD\u8907\u3059\u308B\u53EF\u80FD\u6027\uFF1A{aliases}\u3002\u4E0B\u66F8\u304D\u4FDD\u5B58\u306F\u53EF\u80FD\u3067\u3059\u304C\u3001\u6709\u52B9\u5316\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u7121\u52B9\u306A\u52D5\u4F5C\u3082\u542B\u3080\uFF09\u3002",motionPackMaterial:"\u7167\u5408\u6587\u5B57\u5217\u306A\u3057\u3002\u30DD\u30FC\u30BA\u7D20\u6750\u5C02\u7528\u3067\u3001\u7FFB\u8A33\u306B\u306F\u6709\u52B9\u5316\u3067\u304D\u307E\u305B\u3093\u3002",motionPackReady:"\u4E8B\u524D\u78BA\u8A8D\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002\u65B0\u898F\u4E0B\u66F8\u304D\u306E\u307F\u8FFD\u52A0\u3057\u3001\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u3068\u65E2\u5B58\u52D5\u4F5C\u306E\u627F\u8A8D\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",motionPackChecking:"\u9AA8\u683C\u3068\u30ED\u30FC\u30AB\u30EB\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u4E2D\u2026",motionPackCleared:"\u30AD\u30E3\u30F3\u30BB\u30EB\u3057\u307E\u3057\u305F\u3002\u30E9\u30A4\u30D6\u30E9\u30EA\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionPackConfirm:"{count} \u4EF6\u306E\u4E0B\u66F8\u304D\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002\u4E0A\u66F8\u304D\u3084\u81EA\u52D5\u6709\u52B9\u5316\u306F\u3057\u307E\u305B\u3093\u3002\u5229\u7528\u6A29\u9650\u3092\u78BA\u8A8D\u3057\u3001\u53D6\u8FBC\u5F8C\u306B\u624B\u5F62\u30FB\u5411\u304D\u30FB\u610F\u5473\u3092\u500B\u5225\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F",motionPackImported:"\u4E0B\u66F8\u304D {imported} \u4EF6\u3092\u8FFD\u52A0\u3001\u65E2\u5B58 {skipped} \u4EF6\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3057\u305F\u3002\u4E00\u89A7\u304B\u3089\u500B\u5225\u306B\u8AAD\u8FBC\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackExported:"\u4FDD\u5B58\u6E08\u307F {count} \u4EF6\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3092\u958B\u59CB\u3057\u307E\u3057\u305F\u3002\u7D50\u679C\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u672A\u4FDD\u5B58\u306E\u7DE8\u96C6\u306F\u542B\u307F\u307E\u305B\u3093\u3002",motionPackInvalid:"\u6709\u52B9\u306A v1 \u52D5\u4F5C\u30D1\u30C3\u30AF JSON \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u5358\u4E00\u52D5\u4F5C\u306B\u306F\u4E0A\u306E\u52D5\u4F5C JSON \u53D6\u8FBC\u3092\u4F7F\u3063\u3066\u304F\u3060\u3055\u3044\u3002",motionPackEmpty:"\u30D1\u30C3\u30AF\u304C\u7A7A\u304B\u3001\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3067\u304D\u308B\u4FDD\u5B58\u6E08\u307F\u52D5\u4F5C\u304C\u3042\u308A\u307E\u305B\u3093\u3002",motionPackTooLarge:"\u4E0A\u9650\u8D85\u904E\uFF1A1 \u30D1\u30C3\u30AF 8 MiB / 500 \u52D5\u4F5C\u30011 \u52D5\u4F5C 2 MiB\u3002\u4FDD\u5B58\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionPackDuplicateId:"\u30D1\u30C3\u30AF\u5185\u306B\u91CD\u8907 ID \u304C\u3042\u308A\u3001\u52D5\u4F5C\u3092\u7279\u5B9A\u3067\u304D\u306A\u3044\u305F\u3081\u53D6\u8FBC\u3092\u62D2\u5426\u3057\u307E\u3057\u305F\u3002",motionPackInvalidStored:"\u30ED\u30FC\u30AB\u30EB\u8A18\u9332\u304C\u7834\u640D\u3057\u3066\u3044\u308B\u304B\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u306B\u975E\u5BFE\u5FDC\u3067\u3059\u3002\u4E0D\u5B8C\u5168\u306A\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u306F\u4F5C\u6210\u305B\u305A\u3001\u5143\u30C7\u30FC\u30BF\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002\u5148\u306B\u8A72\u5F53\u8A18\u9332\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackConflict:"\u540C\u3058 ID \u306E\u30ED\u30FC\u30AB\u30EB\u5185\u5BB9\u304C\u7570\u306A\u308B\u304B\u7834\u640D\u3057\u3066\u3044\u307E\u3059\u3002\u5168\u4F53\u306E\u53D6\u8FBC\u3092\u505C\u6B62\u3057\u3001\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002\u5FC5\u8981\u306A\u3089\u5358\u4E00\u52D5\u4F5C\u306E\u53D6\u8FBC\u3067\u30B3\u30D4\u30FC\u3092\u4F5C\u6210\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackStale:"\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u66F4\u3055\u308C\u3001\u4E8B\u524D\u78BA\u8A8D\u304C\u5931\u52B9\u3057\u307E\u3057\u305F\u3002\u518D\u5EA6\u4E8B\u524D\u78BA\u8A8D\u3057\u3001\u4E00\u89A7\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u53D6\u308A\u8FBC\u3093\u3067\u304F\u3060\u3055\u3044\u3002",motionPackLockUnavailable:"\u30DA\u30FC\u30B8\u9593\u306E\u66F8\u8FBC\u30ED\u30C3\u30AF\u304C\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u4E00\u62EC\u53D6\u8FBC\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u30C4\u30FC\u30EB\u3092\u958B\u304D\u76F4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackEncoding:"\u6709\u52B9\u306A UTF-8 JSON \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6587\u5B57\u30B3\u30FC\u30C9\u3092\u5909\u63DB\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageTitle:"\u8A9E\u5F59\u30AB\u30D0\u30FC\u7387\u5206\u6790",coverageHelpWorkflow:"\u30D1\u30CD\u30EB\u304B\u3089\u8A9E\u5F59\u30AB\u30D0\u30FC\u7387\u5206\u6790\u3092\u958B\u304D\u3001\u6587\u7AE0\u307E\u305F\u306F UTF-8 TXT / SRT / VTT \u3092\u5165\u529B\u3057\u3066\u672A\u5BFE\u5FDC\u8A9E\u306E\u983B\u5EA6\u3068\u6587\u8108\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u7DE8\u96C6\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u306B\u306F\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u3060\u3051\u304C\u5165\u529B\u3055\u308C\u307E\u3059\u3002\u52D5\u4F5C\u306E\u4F5C\u6210\u30FB\u78BA\u8A8D\u30FB\u6709\u52B9\u5316\u5F8C\u306B\u518D\u5206\u6790\u3057\u3001\u53CD\u6620\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageIntro:"\u5B9F\u969B\u306E\u6587\u7AE0\u304B\u3089\u4E0D\u8DB3\u3059\u308B\u8A9E\u5F59\u3092\u63A2\u3057\u3001\u52D5\u4F5C\u3092\u4F5C\u6210\u30FB\u78BA\u8A8D\u3057\u307E\u3059\u3002\u624B\u8A71\u306E\u81EA\u52D5\u751F\u6210\u3084\u65E2\u5B58\u30DD\u30FC\u30BA\u306E\u5909\u66F4\u306F\u884C\u3044\u307E\u305B\u3093\u3002",coverageInput:"1 \xB7 \u5206\u6790\u3059\u308B\u7D20\u6750",coverageTextLabel:"\u6587\u7AE0\u3092\u8CBC\u308A\u4ED8\u3051\uFF081\u884C1\u533A\u9593\uFF09\u3001\u307E\u305F\u306F UTF-8 \u5B57\u5E55\u3092\u8AAD\u307F\u8FBC\u307F",coverageLimits:"\u4E0A\u9650\uFF1A\u30D5\u30A1\u30A4\u30EB256 KiB\u300150,000\u6587\u5B57\u30011,000\u533A\u9593\u30011\u533A\u95932,000\u6587\u5B57\u3002SRT / WebVTT \u306F\u5B57\u5E55\u5358\u4F4D\u3067\u5206\u6790\u3057\u307E\u3059\u3002",coverageFormat:"\u5F62\u5F0F",coveragePlainText:"\u30C6\u30AD\u30B9\u30C8 \xB7 1\u884C1\u533A\u9593",coverageImport:"\u30D5\u30A1\u30A4\u30EB\u3092\u8AAD\u307F\u8FBC\u3080",coverageAnalyze:"\u73FE\u5728\u306E\u8A9E\u5F59\u3092\u5206\u6790",coverageClear:"\u30AF\u30EA\u30A2",coverageResults:"2 \xB7 \u8FFD\u52A0\u3059\u308B\u8A9E\u5F59\u306E\u512A\u5148\u9806\u4F4D",coverageMetricHelp:"\u30AB\u30D0\u30FC\u7387 = \u4E00\u81F4\u3057\u305F\u5206\u5272\u8A9E\u6570 \xF7\uFF08\u4E00\u81F4 + \u672A\u5BFE\u5FDC\u306E\u5206\u5272\u8A9E\u6570\uFF09\u3002\u7701\u7565\u3057\u305F\u6A5F\u80FD\u8A9E\u30FB\u53E5\u8AAD\u70B9\u306F\u9664\u5916\u3057\u307E\u3059\u3002\u8F9E\u66F8\u306E\u30AB\u30D0\u30FC\u7387\u3067\u3042\u308A\u3001\u624B\u8A71\u306E\u6B63\u78BA\u3055\u30FB\u6587\u610F\u30FB\u518D\u751F\u5B8C\u4E86\u3092\u4FDD\u8A3C\u3059\u308B\u5024\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",coverageUnknownTitle:"\u672A\u5BFE\u5FDC\u306E\u8A9E \xB7 \u983B\u5EA6\u9806",coverageDraftHelp:"\u5206\u5272\u7D50\u679C\u3092\u6587\u8108\u3068\u7167\u5408\u3057\u3001\u53E5\u5168\u4F53\u304C\u5FC5\u8981\u304B\u5224\u65AD\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u30C4\u30FC\u30EB\u306B\u306F\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u306E\u307F\u5165\u529B\u3057\u307E\u3059\u3002\u81EA\u52D5\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u306F\u305B\u305A\u3001\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u304C\u305D\u306E\u8A9E\u306E\u6B63\u3057\u3044\u624B\u8A71\u3068\u306F\u9650\u308A\u307E\u305B\u3093\u3002",coverageWord:"\u672A\u5BFE\u5FDC\u306E\u8A9E",coverageFrequency:"\u56DE\u6570 / \u533A\u9593\u6570",coverageExamples:"\u4F8B\u6587\u306E\u533A\u9593\u756A\u53F7",coverageMake:"\u4F5C\u6210\u3068\u78BA\u8A8D",coverageDetailsTitle:"3 \xB7 \u533A\u9593\u3054\u3068\u306E\u4E00\u81F4\u7D50\u679C",coverageDisplayLimit:"\u672A\u5BFE\u5FDC\u8A9E\u306F100\u4EF6\u3001\u533A\u9593\u306F200\u4EF6\u307E\u3067\u8868\u793A\u3057\u307E\u3059\u3002\u96C6\u8A08\u306F\u5168\u5165\u529B\u304C\u5BFE\u8C61\u3067\u3059\u3002\u5168\u7D50\u679C\u306F\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3067\u304D\u307E\u3059\u3002",coverageIncludeText:"\u539F\u6587\u3068\u533A\u9593\u660E\u7D30\u3092\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306B\u542B\u3081\u308B\uFF08\u500B\u4EBA\u60C5\u5831\u306B\u6CE8\u610F\uFF09",coverageExport:"JSON \u30EC\u30DD\u30FC\u30C8\u3092\u51FA\u529B",coveragePrivacy:"\u5206\u6790\u306F\u30DA\u30FC\u30B8\u306E\u30E1\u30E2\u30EA\u5185\u306E\u307F\u3067\u884C\u3044\u3001\u9001\u4FE1\u30FB\u81EA\u52D5\u4FDD\u5B58\u3057\u307E\u305B\u3093\u3002\u9589\u3058\u308B\u3068\u7834\u68C4\u3055\u308C\u307E\u3059\u3002\u65E2\u5B9A\u306E\u51FA\u529B\u306F\u539F\u6587\u3092\u9664\u5916\u3057\u307E\u3059\u304C\u672A\u5BFE\u5FDC\u8A9E\u3092\u542B\u3080\u305F\u3081\u3001\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageSummary:"\u30AB\u30D0\u30FC\u7387 {ratio} \xB7 {segments} \u533A\u9593 \xB7 \u4E00\u81F4 {matched} / \u672A\u5BFE\u5FDC {unknown} / \u7701\u7565 {skipped}",coverageNoTokens:"\u5BFE\u8C61\u5916\uFF08\u7FFB\u8A33\u5BFE\u8C61\u8A9E\u306A\u3057\uFF09",coverageTruncation:"{count} \u533A\u9593\u304C1\u533A\u959312\u52D5\u4F5C\u306E\u518D\u751F\u4E0A\u9650\u306B\u9054\u3057\u3066\u3044\u307E\u3059\u3002\u4E00\u90E8\u306F\u518D\u751F\u3055\u308C\u306A\u3044\u53EF\u80FD\u6027\u304C\u3042\u308B\u305F\u3081\u3001\u6B8B\u308A\u306E\u6587\u7AE0\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageOccurrences:"{count} \u56DE / {segments} \u533A\u9593",coverageUniqueUnknown:"\u672A\u5BFE\u5FDC\u8A9E\u306F {count} \u7A2E\u985E\u3067\u3059\u3002\u9577\u3059\u304E\u308B\u8A9E\u306F\u5206\u5272\u3084\u6587\u8108\u3092\u518D\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageNoUnknown:"\u672A\u5BFE\u5FDC\u8A9E\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u624B\u8A71\u306E\u610F\u5473\u3068\u52D5\u4F5C\u306F\u4EBA\u306B\u3088\u308B\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002",coverageMatches:"\u4E00\u81F4\uFF1A{value}",coverageUnmatched:"\u672A\u5BFE\u5FDC\uFF1A{value}",coverageSkipped:"\u7701\u7565\uFF1A{value}",coverageRemaining:"\u518D\u751F\u4E0A\u9650\u4EE5\u964D\u306E\u6587\u7AE0\uFF1A{value}",coverageCatalog:"\u8A9E\u5F59\uFF1A\u5185\u8535 {signs} \u4EF6 / \u5225\u540D {aliases} \u4EF6 / \u6587\u5B57 {chars} \u4EF6\u3002\u6709\u52B9\u306A\u72EC\u81EA\u52D5\u4F5C {enabled}\u3001\u7121\u52B9 {drafts}\u3001\u4E0D\u6B63\u30FB\u975E\u4E92\u63DB {invalid}\uFF08\u5143\u30C7\u30FC\u30BF\u306F\u4FDD\u6301\uFF09\u3002",coverageReady:"\u8CBC\u308A\u4ED8\u3051\u30FB\u8AAD\u307F\u8FBC\u307F\u5F8C\u306B\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u521D\u56DE\u306F\u30E2\u30C7\u30EB\u3092\u8AAD\u307F\u8FBC\u307F\u3001\u72EC\u81EA\u52D5\u4F5C\u306E\u4E92\u63DB\u6027\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002",coverageLoading:"\u30E2\u30C7\u30EB\u3068\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u3057\u3001\u5206\u6790\u3057\u3066\u3044\u307E\u3059\u2026",coverageDone:"\u5206\u6790\u5B8C\u4E86\u3002\u4E0D\u8DB3\u3059\u308B\u52D5\u4F5C\u3092\u4F5C\u6210\u3057\u3001\u78BA\u8A8D\u30FB\u6709\u52B9\u5316\u3057\u3066\u304B\u3089\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageChanged:"\u7D20\u6750\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53E4\u3044\u30EC\u30DD\u30FC\u30C8\u306F\u51FA\u529B\u3067\u304D\u307E\u305B\u3093\u3002",coverageCatalogChanged:"\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53E4\u3044\u30EC\u30DD\u30FC\u30C8\u306F\u51FA\u529B\u3067\u304D\u307E\u305B\u3093\u3002",coverageImported:"\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86\u3002\u5206\u6790\u3092\u30AF\u30EA\u30C3\u30AF\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u81EA\u52D5\u518D\u751F\u30FB\u4FDD\u5B58\u306F\u3057\u307E\u305B\u3093\u3002",coverageFailure:"\u5206\u6790\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\uFF1A{detail}",coverageTooLarge:"\u5BB9\u91CF\u30FB\u533A\u9593\u6570\u30FB\u533A\u9593\u9577\u306E\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002\u5206\u5272\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageEmpty:"\u7A7A\u3067\u306A\u3044\u6587\u7AE0\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageInvalidFormat:"TXT\u3001SRT\u3001WebVTT \u306E\u307F\u5BFE\u5FDC\u3057\u3066\u3044\u307E\u3059\u3002\u6B63\u3057\u3044\u5F62\u5F0F\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageInvalidSubtitles:"\u5B57\u5E55\u5F62\u5F0F\u304C\u4E0D\u6B63\u3067\u3059\u3002\u7A7A\u884C\u3001\u6642\u523B\u3001\u958B\u59CB\u30FB\u7D42\u4E86\u9806\u5E8F\u3001WebVTT \u30D8\u30C3\u30C0\u30FC\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u6642\u523B\u884C\u3092\u672C\u6587\u3068\u3057\u3066\u96C6\u8A08\u3057\u307E\u305B\u3093\u3002",coverageEncoding:"UTF-8 \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6587\u5B57\u30B3\u30FC\u30C9\u3092\u5909\u63DB\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageModelError:"\u30E2\u30C7\u30EB\u307E\u305F\u306F\u5171\u6709\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u3067\u304D\u307E\u305B\u3093\u3002\u62E1\u5F35\u304B\u3089\u958B\u304D\u3001\u30E2\u30C7\u30EB\u8AAD\u307F\u8FBC\u307F\u3092\u78BA\u8A8D\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u4E0D\u5B8C\u5168\u306A\u96C6\u8A08\u306B\u306F\u5207\u308A\u66FF\u3048\u307E\u305B\u3093\u3002",coverageOpenFailed:"\u30C4\u30FC\u30EB\u3092\u958B\u3051\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coveragePrefilled:"\u5206\u6790\u7D50\u679C\u304B\u3089\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u3092\u5165\u529B\u3057\u307E\u3057\u305F\u3002\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u306F\u3053\u306E\u8A9E\u306E\u691C\u8A3C\u6E08\u307F\u624B\u8A71\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u4F5C\u6210\u30FB\u4FDD\u5B58\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304B\u3089\u6709\u52B9\u5316\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionLibraryTitle:"\u5171\u6709\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA \xB7 \u7B2C2\u6BB5\u968E",motionLibraryHelp:"\u30A8\u30C7\u30A3\u30BF\u30FC\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u30FB\u30A2\u30D0\u30BF\u30FC\u306F\u30E9\u30B8\u30A2\u30F3\u3068 REST \u5DEE\u5206\u3092\u5171\u6709\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u306F\u30D7\u30EC\u30D3\u30E5\u30FC\u3068\u78BA\u8A8D\u5F8C\u306B\u7FFB\u8A33\u3078\u4F7F\u7528\u3057\u307E\u3059\u3002",motionName:"\u52D5\u4F5C\u540D\uFF08\u5FC5\u9808\uFF09",motionTexts:"\u5BFE\u5FDC\u3059\u308B\u6587\u5B57\uFF08\u30AB\u30F3\u30DE\u533A\u5207\u308A\u30FB\u59FF\u52E2\u7D20\u6750\u306E\u307F\u306A\u3089\u7A7A\u6B04\uFF09",motionTags:"\u30BF\u30B0\uFF08\u30AB\u30F3\u30DE\u533A\u5207\u308A\uFF09",motionNew:"\u65B0\u3057\u3044\u30B3\u30D4\u30FC",motionNewHelp:"\u73FE\u5728\u306E\u59FF\u52E2\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u52D5\u4F5C\u540D\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionSave:"\u4E0B\u66F8\u304D\u4FDD\u5B58",motionSaved:"\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002\u30D7\u30EC\u30D3\u30E5\u30FC\u3068\u78BA\u8A8D\u5F8C\u306B\u6709\u52B9\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionLoad:"\u9078\u629E\u3092\u8AAD\u307F\u8FBC\u3080",motionLoaded:"\u8AAD\u307F\u8FBC\u307F\u307E\u3057\u305F\u3002\u30A4\u30F3\u30DD\u30FC\u30C8\u306F\u81EA\u52D5\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u3055\u308C\u307E\u305B\u3093\u3002\u78BA\u8A8D\u5F8C\u306B\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionChoose:"\u4FDD\u5B58\u6E08\u307F\u306E\u52D5\u4F5C\u3092\u9078\u629E\u2026",motionDraft:"\u4E0B\u66F8\u304D / \u7121\u52B9",motionEnabled:"\u78BA\u8A8D\u6E08\u307F / \u6709\u52B9",motionPreview:"\u73FE\u5728\u306E\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC",motionPreviewHelp:"\u30A2\u30D0\u30BF\u30FC\u3068\u540C\u3058\u518D\u751F\u51E6\u7406\u3067\u3059\u3002\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D\u3057\u3001\u5909\u66F4\u5F8C\u306F\u518D\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionEnable:"\u78BA\u8A8D\u3057\u3066\u7FFB\u8A33\u306B\u4F7F\u7528",motionDisable:"\u9078\u629E\u3057\u305F\u52D5\u4F5C\u3092\u7121\u52B9\u5316",motionConfirm:"\u5168\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3001\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D\u3057\u307E\u3057\u305F\u3002\u5C02\u9580\u5BB6\u306B\u3088\u308B\u624B\u8A71\u8A8D\u8A3C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6709\u52B9\u306B\u3057\u307E\u3059\u304B\uFF1F",motionEnabledHelp:"\u6709\u52B9\u5316\u3057\u307E\u3057\u305F\u3002\u958B\u3044\u3066\u3044\u308B\u30A2\u30D0\u30BF\u30FC\u306B\u81EA\u52D5\u53CD\u6620\u3057\u3001\u65B0\u3057\u304F\u4E00\u81F4\u3057\u305F\u6587\u5B57\u306B\u4F7F\u7528\u3057\u307E\u3059\u3002",motionDisabledHelp:"\u7121\u52B9\u5316\u3057\u307E\u3057\u305F\u3002\u4E0B\u66F8\u304D\u3092\u4FDD\u6301\u3057\u3001\u30A2\u30D0\u30BF\u30FC\u306E\u5F85\u6A5F\u4E2D\u306E\u72EC\u81EA\u52D5\u4F5C\u3092\u505C\u6B62\u3057\u307E\u3059\u3002",motionRefresh:"\u4E00\u89A7\u66F4\u65B0",motionExport:"\u7D71\u4E00 JSON \u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9",motionExportCode:"\u30B3\u30FC\u30C9\u51FA\u529B\uFF08\u4FDD\u5B58\u306A\u3057\uFF09",motionImport:"\u52D5\u4F5C JSON \u3092\u30A4\u30F3\u30DD\u30FC\u30C8",motionImportFormat:"\u30A4\u30F3\u30DD\u30FC\u30C8\u5F62\u5F0F\u3068\u5358\u4F4D",motionFormat:"\u7D71\u4E00\u5F62\u5F0F \xB7 \u30E9\u30B8\u30A2\u30F3 / REST \u5DEE\u5206",motionLegacyEditor:"\u65E7\u30A8\u30C7\u30A3\u30BF\u30FC\u5DEE\u5206 \xB7 \u5EA6\uFF08\u59FF\u52E2\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u306E\u307F\uFF09",motionLegacyRecorder:"\u65E7\u9332\u753B frames.pose \xB7 \u5EA6",motionLegacyAbsolute:"\u65E7\u30A8\u30C7\u30A3\u30BF\u30FC\u7D76\u5BFE\u89D2 \xB7 \u30E9\u30B8\u30A2\u30F3",motionMigrate:"\u3053\u306E\u30DA\u30FC\u30B8\u306E\u65E7\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u79FB\u884C",motionLegacyConfirm:"\u65E7\u30C7\u30FC\u30BF\u306B\u306F\u30E2\u30C7\u30EB\u60C5\u5831\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u3067\u6B63\u3057\u3044\u5F62\u5F0F\u30FB\u5358\u4F4D\u3067\u3042\u308B\u5834\u5408\u306E\u307F\u7D9A\u884C\u3057\u3001\u5909\u63DB\u5F8C\u306F\u5404\u52D5\u4F5C\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5143\u30C7\u30FC\u30BF\u306F\u524A\u9664\u3057\u307E\u305B\u3093\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F",motionMigrated:"{count} \u4EF6\u306E\u4E0B\u66F8\u304D\u3092\u79FB\u884C\u3057\u307E\u3057\u305F\u3002\u5143\u30C7\u30FC\u30BF\u3092\u4FDD\u6301\u3057\u3001\u672A\u6709\u52B9\u3067\u3059\u3002\u518D\u5B9F\u884C\u3059\u308B\u3068\u30B3\u30D4\u30FC\u3092\u4F5C\u6210\u3057\u307E\u3059\u3002",motionIgnored:"\u7834\u640D\u307E\u305F\u306F\u30E2\u30C7\u30EB\u4E0D\u4E00\u81F4\u306E {count} \u4EF6\u3092\u9664\u5916\u3057\u307E\u3057\u305F\u3002\u5143\u30C7\u30FC\u30BF\u306F\u4FDD\u6301\u3057\u307E\u3059\u3002",motionFailure:"\u672A\u5B8C\u4E86\uFF1A{detail}",motionInvalidData:"\u52D5\u4F5C\u5F62\u5F0F\u307E\u305F\u306F\u30D1\u30E9\u30E1\u30FC\u30BF\u30FC\u304C\u7121\u52B9\uFF1A{detail}",motionModelNotReady:"\u30E2\u30C7\u30EB\u306E\u8AAD\u307F\u8FBC\u307F\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionRigMismatch:"\u9AA8\u683C\u307E\u305F\u306F REST \u59FF\u52E2\u304C\u4E00\u81F4\u3057\u306A\u3044\u305F\u3081\u3001\u9069\u7528\u3057\u307E\u305B\u3093\u3002",motionStorageUnavailable:"\u5171\u6709\u30B9\u30C8\u30EC\u30FC\u30B8\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u62E1\u5F35\u6A5F\u80FD\u306E\u30D1\u30CD\u30EB\u304B\u3089\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",motionSelectFirst:"\u52D5\u4F5C\u3092\u4FDD\u5B58\u307E\u305F\u306F\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionSaveFirst:"\u52D5\u4F5C\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u4FDD\u5B58\u3068\u30D7\u30EC\u30D3\u30E5\u30FC\u304C\u5FC5\u8981\u3067\u3059\u3002",motionPreviewFirst:"\u6709\u52B9\u5316\u306E\u524D\u306B\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionAliasConflict:"\u5BFE\u5FDC\u6587\u5B57\u304C\u7A7A\u6B04\u3001\u307E\u305F\u306F\u65E2\u5B58\u306E\u52D5\u4F5C\u3068\u91CD\u8907\uFF1A{detail}\u3002\u5225\u306E\u8A9E\u53E5\u3092\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionFileTooLarge:"\u30D5\u30A1\u30A4\u30EB\u307E\u305F\u306F\u9805\u76EE\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\uFF082 MiB\uFF09\u3002",motionEditorSingleFrame:"\u30A8\u30C7\u30A3\u30BF\u30FC\u306F\u5358\u4E00\u59FF\u52E2\u5C02\u7528\u3067\u3059\u3002\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",motionFrameLimit:"240 \u30D5\u30EC\u30FC\u30E0\u306B\u9054\u3057\u305F\u305F\u3081\u9332\u753B\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002",motionFrameDuration:"\u30D5\u30EC\u30FC\u30E0\u6642\u9593\uFF08\u79D2\u30010.05\u201310\uFF09",motionUpdateFrame:"\u9078\u629E\u30D5\u30EC\u30FC\u30E0\u3092\u66F4\u65B0",motionHelpRig:"Godette \u306F\u6A19\u6E96 Humanoid \u30DC\u30FC\u30F3\u3068\u5229\u7528\u53EF\u80FD\u306A\u6307\u306E\u30DC\u30FC\u30F3\u30C1\u30A7\u30FC\u30F3\u3092\u4F7F\u3044\u307E\u3059\u3002\u30A8\u30C7\u30A3\u30BF\u30FC\u3001\u9332\u753B\u30C4\u30FC\u30EB\u3001\u30A2\u30D0\u30BF\u30FC\u306F\u540C\u3058 profile \u3068 REST \u30DD\u30FC\u30BA\u3092\u5171\u6709\u3057\u307E\u3059\u3002",motionHelpAxes:"X/Y/Z \u306F\u30DC\u30FC\u30F3\u306E\u30ED\u30FC\u30AB\u30EB\u8EF8\u3067\u3001\u56FA\u5B9A\u306E\u4E16\u754C\u65B9\u5411\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u51FA\u529B\u306F REST \u5DEE\u5206\u30E9\u30B8\u30A2\u30F3\u3001\u9332\u753B\u30C4\u30FC\u30EB\u306E\u30B9\u30E9\u30A4\u30C0\u30FC\u306F\u7D76\u5BFE\u30ED\u30FC\u30AB\u30EB\u30E9\u30B8\u30A2\u30F3\u3067\u3059\u3002\u5168\u30DC\u30FC\u30F3\u3092\u540C\u3058\u8EF8\u65B9\u5411\u3068\u307F\u306A\u3055\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3002",motionHelpCreate:"\u5358\u4E00\u30DD\u30FC\u30BA\u306F\u30A8\u30C7\u30A3\u30BF\u30FC\u3001\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u4F5C\u308A\u307E\u3059\u3002\u540D\u524D\u3001\u7167\u5408\u30C6\u30AD\u30B9\u30C8\u3001\u30BF\u30B0\u3092\u5165\u529B\u3057\u3066\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002\u7167\u5408\u30C6\u30AD\u30B9\u30C8\u304C\u7A7A\u306A\u3089\u7D20\u6750\u3068\u3057\u3066\u4FDD\u5B58\u3067\u304D\u307E\u3059\u3002\u65E2\u5B58\u306E\u7167\u5408\u8A9E\u306F\u4E0A\u66F8\u304D\u3067\u304D\u307E\u305B\u3093\u3002",motionHelpReview:"\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58 \u2192 \u73FE\u5728\u306E\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC \u2192 \u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D \u2192 \u7FFB\u8A33\u306B\u6709\u52B9\u5316\u3002\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB\u30D1\u30CD\u30EB\u304B\u3089\u7167\u5408\u8A9E\u3092\u5165\u529B\u3057\u3066\u691C\u8A3C\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u3053\u306E\u78BA\u8A8D\u306F\u624B\u8A71\u306E\u5C02\u9580\u8A8D\u8A3C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",motionHelpFrames:"\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306E\u30D5\u30EC\u30FC\u30E0\u3092\u9078\u629E\u3057\u3001\u30DC\u30FC\u30F3\u3068\u6642\u9593\u3092\u7DE8\u96C6\u3057\u3066\u300C\u9078\u629E\u30D5\u30EC\u30FC\u30E0\u3092\u66F4\u65B0\u300D\u3092\u62BC\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u59FF\u52E2\u306B\u306F\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u3092\u8FFD\u52A0\u3057\u307E\u3059\u30021 \u30D5\u30EC\u30FC\u30E0 0.05\u201310 \u79D2\u3001\u6700\u5927 240 \u30D5\u30EC\u30FC\u30E0\u3001\u5408\u8A08 120 \u79D2\u3002\u81EA\u52D5\u9332\u753B\u306F 0.3 \u79D2\u9593\u9694\u3067\u3059\u3002",motionHelpUpdates:"\u4E21\u30C4\u30FC\u30EB\u3068\u30A2\u30D0\u30BF\u30FC\u306F\u540C\u3058\u62E1\u5F35 ID\u30FB\u30D6\u30E9\u30A6\u30B6\u30FC\u30D7\u30ED\u30D5\u30A1\u30A4\u30EB\u306E\u4FDD\u5B58\u9818\u57DF\u3092\u5171\u6709\u3057\u307E\u3059\u3002\u6709\u52B9\u5316\u30FB\u7121\u52B9\u5316\u3067\u30A2\u30D0\u30BF\u30FC\u3068\u5F85\u3061\u884C\u5217\u3092\u66F4\u65B0\u3057\u307E\u3059\u3002\u518D\u4FDD\u5B58\u3059\u308B\u3068\u627F\u8A8D\u3092\u89E3\u9664\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u30B3\u30D4\u30FC\u306F\u5143\u306E\u52D5\u4F5C\u3092\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002",motionHelpBackup:"\u7D71\u4E00 JSON \u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3057\u307E\u3059\u3002\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3060\u3051\u3067\u306F\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u3055\u308C\u307E\u305B\u3093\u3002\u30A4\u30F3\u30DD\u30FC\u30C8\u306F\u65B0\u3057\u3044\u4E0B\u66F8\u304D\u3068\u3057\u3066\u518D\u4FDD\u5B58\u30FB\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u958B\u304D\u307E\u3059\u3002\u62E1\u5F35\u306E\u524A\u9664\u3084 ID \u5909\u66F4\u524D\u306B\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionHelpLegacy:"\u65E7\u30E9\u30A4\u30D6\u30E9\u30EA\u306E\u79FB\u884C\u306F sb_gestures \u3092\u6B8B\u3057\u3001\u518D\u5B9F\u884C\u3059\u308B\u3068\u30B3\u30D4\u30FC\u3092\u4F5C\u308A\u307E\u3059\u3002\u65E7 JSON \u306E\u5EA6\u6570\u30FB\u7D76\u5BFE\u30E9\u30B8\u30A2\u30F3\u5F62\u5F0F\u3092\u660E\u793A\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5358\u4F4D\u3092\u63A8\u6E2C\u305B\u305A\u3001\u30B3\u30FC\u30C9\u3082\u5B9F\u884C\u3057\u307E\u305B\u3093\u3002\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u7528\u30C7\u30FC\u30BF\u3067\u3042\u308B\u3053\u3068\u3092\u78BA\u8A8D\u3057\u3001\u5FC5\u305A\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionHelpBinding:"\u30D5\u30A1\u30A4\u30EB\u4E0A\u9650\u306F 2 MiB\u3002\u4E0D\u4E00\u81F4\u306E\u30DC\u30FC\u30F3/REST\u3001\u672A\u77E5\u306E\u30DC\u30FC\u30F3\u3001\u4E0D\u6B63\u306A\u5024\u306F\u62D2\u5426\u3057\u307E\u3059\u3002\u3053\u308C\u306F GLB \u5168\u4F53\u3084\u30B9\u30AD\u30F3\u306E\u6307\u7D0B\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u30C4\u30FC\u30EB\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002localhost \u306E\u30DA\u30FC\u30B8\u3068\u306F\u5171\u6709\u3067\u304D\u307E\u305B\u3093\u3002\u66F4\u65B0\u5F8C\u306F\u62E1\u5F35\u3092\u518D\u8AAD\u8FBC\u3057\u3001\u53E4\u3044\u30C4\u30FC\u30EB\u30BF\u30D6\u3092\u958B\u304D\u76F4\u3057\u307E\u3059\u3002",motionHelpCollision:"\u8A72\u5F53\u3059\u308B\u52D5\u4F5C\u3068\u30D5\u30EC\u30FC\u30E0\u3092\u7279\u5B9A\u3057\u3001\u6B63\u9762\u3068\u5074\u9762\u304B\u3089\u8098\u30FB\u624B\u9996\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u305D\u306E\u52D5\u4F5C\u306E\u307F\u4FEE\u6B63\u3057\u3066\u518D\u78BA\u8A8D\u3057\u3001\u5168\u4F53\u306E\u8EF8\u53CD\u8EE2\u3084\u4E00\u62EC\u89D2\u5EA6\u5909\u66F4\u3092\u907F\u3051\u3066\u304F\u3060\u3055\u3044\u3002",motionHelpCoverage:"\u4E00\u81F4\u3057\u305F motionIds \u3068\u672A\u4E00\u81F4\u30C6\u30AD\u30B9\u30C8\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u672A\u53CE\u9332\u306E\u5165\u529B\u306F\u73FE\u5728\u306E\u518D\u751F\u3092\u4E2D\u65AD\u3057\u307E\u305B\u3093\u3002",motionHelpCatalog:"\u6709\u52B9\u306A\u30AB\u30B9\u30BF\u30E0\u52D5\u4F5C\u6570\u3068\u4E0D\u6B63\u306A\u8A18\u9332\u6570\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u306F\u7FFB\u8A33\u3055\u308C\u307E\u305B\u3093\u3002",motionDurationInvalid:"\u6642\u9593\u306F 0.05\u201310 \u79D2\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionLoadingFailed:"\u30E2\u30C7\u30EB\u8AAD\u307F\u8FBC\u307F\u5931\u6557\uFF1A{detail}",name:"\u65E5\u672C\u8A9E",title:"SignBridge \u2014 \u624B\u8A71\u7FFB\u8A33",description:"\u52D5\u753B\u306E\u97F3\u58F0\u3092\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0\u3067\u624B\u8A71\u306B\u7FFB\u8A33\u30013D\u30A2\u30D0\u30BF\u30FC\u3067\u8868\u793A",settings:"\u8A2D\u5B9A",avatar:"\u30A2\u30D0\u30BF\u30FC",language:"\u8A00\u8A9E",sourceLanguage:"\u52D5\u753B\u306E\u8A00\u8A9E",targetSignLanguage:"\u624B\u8A71\u306E\u7A2E\u985E",avatarStyle:"\u30A2\u30D0\u30BF\u30FC\u30B9\u30BF\u30A4\u30EB",avatarSize:"\u30A2\u30D0\u30BF\u30FC\u30B5\u30A4\u30BA",avatarPosition:"\u30A2\u30D0\u30BF\u30FC\u4F4D\u7F6E",positionBottomRight:"\u53F3\u4E0B",positionBottomLeft:"\u5DE6\u4E0B",positionTopRight:"\u53F3\u4E0A",positionTopLeft:"\u5DE6\u4E0A",enableAutoDetect:"\u52D5\u753B\u3092\u81EA\u52D5\u691C\u51FA",enableSubtitles:"\u5B57\u5E55\u3092\u8868\u793A",voiceVolume:"\u97F3\u58F0\u97F3\u91CF",speed:"\u624B\u8A71\u306E\u901F\u5EA6",about:"\u306B\u3064\u3044\u3066",start:"\u7FFB\u8A33\u958B\u59CB",stop:"\u7FFB\u8A33\u505C\u6B62",loading:"\u8AAD\u307F\u8FBC\u307F\u4E2D...",noVideo:"\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",error:"\u30A8\u30E9\u30FC",errorNoVideo:"\u30DA\u30FC\u30B8\u306B\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",ready:"\u6E96\u5099\u5B8C\u4E86",translating:"\u7FFB\u8A33\u4E2D...",unavailable:"\u3053\u306E\u30DA\u30FC\u30B8\u3067\u306F\u5229\u7528\u3067\u304D\u307E\u305B\u3093",inputPlaceholder:"\u624B\u8A71\u306B\u3059\u308B\u30C6\u30AD\u30B9\u30C8\u3092\u5165\u529B...",send:"\u9001\u4FE1",sent:"\u9001\u4FE1\u6E08\u307F",audioOff:"\u52D5\u753B\u97F3\u58F0\uFF1A\u30AA\u30D5",audioOn:"\u52D5\u753B\u97F3\u58F0\uFF1A\u30AA\u30F3",audioStopped:"\u505C\u6B62\u4E2D",audioListening:"\u8A8D\u8B58\u4E2D...",audioStarting:"\u97F3\u58F0\u3092\u53D6\u5F97\u4E2D...",audioUnavailable:"\u3053\u306E\u30DA\u30FC\u30B8\u3067\u306F\u97F3\u58F0\u3092\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093",audioCaptureFailed:"\u97F3\u58F0\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F",audioCloudKeyRequired:"\u30AF\u30E9\u30A6\u30C9 API Key \u3092\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044",audioPermissionRequired:"ASR \u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u3066\u63A5\u7D9A\u5148\u3092\u8A31\u53EF\u3057\u3066\u304F\u3060\u3055\u3044",audioLocalUnavailable:"\u5148\u306B\u30ED\u30FC\u30AB\u30EB Whisper \u3092\u5C0E\u5165\u3057\u3066\u304F\u3060\u3055\u3044",asrSettings:"\u97F3\u58F0\u8A8D\u8B58\u8A2D\u5B9A",asrTitle:"\u52D5\u753B\u97F3\u58F0\u8A8D\u8B58",asrPurpose:"\u30ED\u30FC\u30AB\u30EB Whisper \u307E\u305F\u306F\u30AF\u30E9\u30A6\u30C9 ASR \u3067\u52D5\u753B\u97F3\u58F0\u3092\u624B\u8A71\u52D5\u4F5C\u306B\u5909\u63DB\u3057\u307E\u3059\u3002",asrProvider:"\u8A8D\u8B58\u65B9\u5F0F",asrLocal:"\u30ED\u30FC\u30AB\u30EB Whisper",asrCloud:"\u30AF\u30E9\u30A6\u30C9 ASR",asrLocalSettings:"\u30ED\u30FC\u30AB\u30EB Whisper \u8A2D\u5B9A",asrLocalPrivacy:"\u30E2\u30C7\u30EB\u3068\u97F3\u58F0\u306F\u62E1\u5F35\u6A5F\u80FD\u5185\u3067\u51E6\u7406\u3055\u308C\u3001\u52D5\u753B\u97F3\u58F0\u306F\u8A8D\u8B58\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u305B\u3093\u3002",asrDeployLocal:"\u30ED\u30FC\u30AB\u30EB Whisper \u3092\u5C0E\u5165",asrEndpoint:"\u30B5\u30FC\u30D3\u30B9 URL",asrModel:"\u30E2\u30C7\u30EB",asrModelTiny:"tiny\uFF08\u6700\u901F\u3001\u7D04 75 MB\uFF09",asrModelBase:"base\uFF08\u30D0\u30E9\u30F3\u30B9\u3001\u7D04 150 MB\uFF09",asrModelSmall:"small\uFF08\u9AD8\u7CBE\u5EA6\u3001\u7D04 500 MB\uFF09",asrDeployHint:"\u30AF\u30EA\u30C3\u30AF\u3059\u308B\u3068\u30E2\u30C7\u30EB\u3092\u81EA\u52D5\u3067\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u4FDD\u5B58\u3057\u307E\u3059\u3002Python \u3084\u30ED\u30FC\u30AB\u30EB\u30B5\u30FC\u30D3\u30B9\u306F\u4E0D\u8981\u3067\u3059\u3002",asrDeployRequired:"\u9078\u629E\u3057\u305F\u30E2\u30C7\u30EB\u306F\u307E\u3060\u5C0E\u5165\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002",asrRequestingModelPermission:"\u30E2\u30C7\u30EB\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u6A29\u9650\u3092\u78BA\u8A8D\u4E2D...",asrDeploying:"\u30E2\u30C7\u30EB\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u521D\u671F\u5316\u4E2D\uFF1A{progress}%",asrDeployReady:"\u30ED\u30FC\u30AB\u30EB\u30E2\u30C7\u30EB {model} \u306E\u6E96\u5099\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002",asrDeployFailed:"\u30ED\u30FC\u30AB\u30EB\u30E2\u30C7\u30EB\u306E\u5C0E\u5165\u306B\u5931\u6557\u3057\u307E\u3057\u305F",asrCloudSettings:"\u30AF\u30E9\u30A6\u30C9 ASR \u8A2D\u5B9A",asrCloudPrivacy:"\u52D5\u753B\u97F3\u58F0\u306F\u8A2D\u5B9A\u3057\u305F\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u3059\u3002\u30D7\u30E9\u30A4\u30D0\u30B7\u30FC\u3068\u6599\u91D1\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",asrApiKey:"API Key",asrCommonSettings:"\u5171\u901A\u8A2D\u5B9A",asrLanguage:"\u8A8D\u8B58\u8A00\u8A9E",asrChunkSeconds:"\u97F3\u58F0\u30C1\u30E3\u30F3\u30AF",asrTest:"\u63A5\u7D9A\u30C6\u30B9\u30C8",asrSave:"\u8A2D\u5B9A\u3092\u4FDD\u5B58",asrPermissionDenied:"\u3053\u306E\u30B5\u30FC\u30D3\u30B9\u3078\u306E\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093\u3002",asrSaved:"\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002",asrInvalidConfig:"\u8A2D\u5B9A\u304C\u7121\u52B9\u3067\u3059\u3002URL \u3068\u30E2\u30C7\u30EB\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",asrTesting:"\u8A8D\u8B58\u30B5\u30FC\u30D3\u30B9\u3092\u30C6\u30B9\u30C8\u3057\u3066\u3044\u307E\u3059...",asrTestPassed:"\u63A5\u7D9A\u30C6\u30B9\u30C8\u306B\u6210\u529F\u3057\u307E\u3057\u305F\u3002",asrTestFailed:"\u63A5\u7D9A\u30C6\u30B9\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F",poseEditor:"\u30DD\u30FC\u30BA\u7DE8\u96C6",recorder:"\u9332\u753B\u30C4\u30FC\u30EB",help:"\u30D8\u30EB\u30D7",tagline:"\u60C5\u5831\u3092\u30A2\u30AF\u30BB\u30B7\u30D6\u30EB\u306B",auto:"\u81EA\u52D5\u691C\u51FA",simplifiedChinese:"\u4E2D\u56FD\u8A9E\uFF08\u6A19\u6E96\u8A9E\uFF09",footer:"SignBridge \u2014 \u60C5\u5831\u3092\u30A2\u30AF\u30BB\u30B7\u30D6\u30EB\u306B",signLanguageTypes:{csl:"\u4E2D\u56FD\u624B\u8A71 (CSL)",asl:"\u30A2\u30E1\u30EA\u30AB\u624B\u8A71 (ASL)",bsl:"\u30A4\u30AE\u30EA\u30B9\u624B\u8A71 (BSL)",jsl:"\u65E5\u672C\u624B\u8A71 (JSL)",ksl:"\u97D3\u56FD\u624B\u8A71 (KSL)"},avatarStyles:{default:"\u30C7\u30D5\u30A9\u30EB\u30C8",friendly:"\u30D5\u30EC\u30F3\u30C9\u30EA\u30FC",professional:"\u30D7\u30ED\u30D5\u30A7\u30C3\u30B7\u30E7\u30CA\u30EB",anime:"\u30A2\u30CB\u30E1\u98A8"}}},_c="en",rd=null;function vc(){return rd||navigator.language||_c}function od(i){rd=i}function vt(i,e={}){let t=vc(),n=Io[t]||Io[t.split("-")[0]]||Io[_c],s=i.split("."),r=n;for(let o of s)if(r&&typeof r=="object")r=r[o];else{r=void 0;break}if(r===void 0){n=Io[_c],r=n;for(let o of s)if(r&&typeof r=="object")r=r[o];else break}return typeof r!="string"?i:r.replace(/\{(\w+)\}/g,(o,a)=>e[a]??`{${a}}`)}var Ze=i=>document.getElementById(i),dv=Ze("review-status"),Po=new Set,xc=new Set,yt=null,bs=null,sr=null,Ss=null,mi=null,Lt=null,rr=0,fn=!1,or=[],gi=[],Sc=0;function Sn(i,e){dv.textContent=vt(i,e)}function bc(i){return vt(i.message,{detail:i.detail||""})}function Ni(i){Sn("reviewFailure",{detail:bc(i)})}function bt(i,e,t){let n=document.createElement(e);return t!==void 0&&(n.textContent=t),i.appendChild(n),n}function fv(i){let e=URL.createObjectURL(i);return Po.add(e),e}function wc(){Po.forEach(i=>URL.revokeObjectURL(i)),Po.clear()}function yc(){wc(),gi=[],Ze("review-cards").replaceChildren(),Ze("review-results").hidden=!0,Ze("review-export").disabled=!0}function Ac(){let i=new Set(Array.from(Ze("review-catalog").querySelectorAll("input:checked"),e=>e.value));return or.filter(e=>i.has(`${e.source}:${e.motion.id}`))}function Yn(){let i=Ac().length;Ze("review-count").textContent=vt("reviewCatalogCount",{total:or.length,count:i,invalid:Sc,max:pr});let e=yt&&!Lt&&!mi&&i>0&&i<=pr;Ze("review-play").disabled=!e,Ze("review-capture").disabled=!e,Ze("review-stop").disabled=!Lt&&!mi,Ze("review-load").disabled=!!mi||!!Lt,Ze("review-view").disabled=!!Lt,Ze("review-catalog").querySelectorAll("input").forEach(t=>{t.disabled=!!Lt}),Ze("review-cards").querySelectorAll("button").forEach(t=>{t.disabled=!!Lt})}function Tc(){mi?.abort(),Lt?.abort(),yt?.stop()}function Mc(){rr+=1,Tc(),yc()}async function ud(){return sr||(sr=nh().then(i=>{if(fn)throw i.close(),new Error("reviewStorageError");return i}).catch(i=>{throw sr=null,i})),sr}function pv(i){return vt(i.source==="builtin"?"reviewBuiltin":i.enabled?"reviewEnabled":"reviewDraft")}function dd(){let i=Ze("review-search").value.trim().toLocaleLowerCase();Ze("review-catalog").querySelectorAll("label").forEach(e=>{e.hidden=!e.textContent.toLocaleLowerCase().includes(i)})}async function ad(){let i=rr,e=new Set(Ac().map(s=>`${s.source}:${s.motion.id}`)),t=await bs.list();if(fn||i!==rr)return;Sc=t.invalidCount,or=[...Object.values(An).map(s=>({source:"builtin",motion:s})),...t.entries.map(s=>({source:"custom",motion:s.asset,enabled:s.enabled}))];let n=Ze("review-catalog");n.replaceChildren();for(let s of or){let r=bt(n,"label"),o=bt(r,"input");o.type="checkbox",o.value=`${s.source}:${s.motion.id}`,o.checked=e.has(o.value),bt(r,"span",`${s.motion.gloss} \xB7 ${s.motion.id} \xB7 ${pv(s)}`),o.addEventListener("change",Yn)}dd(),Yn()}async function fd(){if(mi||Lt)return;Mc(),Ss?.(),Ss=null,yt?.dispose(),yt=null,bs=null;let i=new globalThis.AbortController;mi=i;let e=setTimeout(()=>i.abort(new Error("reviewModelError")),2e4);Sn("reviewLoading"),Yn();try{yt=await ed(Ze("review-canvas"),i.signal),bs=Kc(yt.rig),Ss=bs.subscribe(()=>{Mc(),Sn("reviewCatalogChanged"),ad().catch(Ni)}),await ad(),i.signal.throwIfAborted(),Sn("reviewReady",{total:or.length})}catch(t){Ss?.(),Ss=null,yt?.dispose(),yt=null,bs=null,fn||(t.name==="AbortError"?Sn("reviewCancelled"):Ni(t))}finally{clearTimeout(e),mi=null,fn||Yn()}}async function ld(i,e,t){let n=await globalThis.createImageBitmap(i),s=document.createElement("canvas");try{if(n.width!==e||n.height!==t)throw new Error("reviewImageMismatch");s.width=e,s.height=t;let r=s.getContext("2d",{willReadFrequently:!0});return r.drawImage(n,0,0),r.getImageData(0,0,e,t).data}finally{n.close(),s.width=s.height=0}}async function pd(i){i.baselineError=null,i.difference=null;try{if(i.baseline=await(await ud()).read(i.key),i.comparison=th(i,i.baseline),i.comparison==="comparable"){if(await $n(await i.baseline.image.arrayBuffer())!==i.baseline.imageHash)throw new Error("reviewImageMismatch");i.difference=eh(await ld(i.image,i.width,i.height),await ld(i.baseline.image,i.width,i.height))}}catch(e){i.comparison="unavailable",i.baselineError=bc(e)}}function md(i,e){let t=document.createElement("a"),n=URL.createObjectURL(i);t.href=n,t.download=e,t.click();let s=setTimeout(()=>{URL.revokeObjectURL(n),xc.delete(s)},1e4);xc.add(s),Po.add(n)}async function cd(i){if(!gi.includes(i))throw new Error("reviewCatalogChanged");if(i.source==="custom"){let t=(await bs.list()).entries.find(n=>n.asset.id===i.id);if(!t||await $n(t.asset)!==i.motionHash)throw new Error("reviewCatalogChanged")}}async function hd(i,e=!1){if(Lt)return;let t=new globalThis.AbortController;Lt=t,Yn();try{if(await cd(i),!confirm(vt(e?"reviewDeleteConfirm":"reviewSaveConfirm",{name:i.gloss})))return;t.signal.throwIfAborted();let n=await ud();await cd(i),t.signal.throwIfAborted();let s=e?null:{key:i.key,token:globalThis.crypto.randomUUID(),protocol:xi,savedAt:new Date().toISOString(),motionHash:i.motionHash,environmentHash:i.environmentHash,image:i.image,imageHash:i.imageHash,width:i.width,height:i.height,indices:i.indices};await n.update(i.key,i.baseline?.token||null,s,t.signal),await pd(i),t.signal.throwIfAborted(),gd(),Sn(e?"reviewDeleted":"reviewSaved")}catch(n){!fn&&n.name!=="AbortError"&&Ni(n)}finally{Lt===t&&(Lt=null),fn||Yn()}}function gd(){wc();let i=Ze("review-cards");i.replaceChildren(),Ze("review-results").hidden=!gi.length,Ze("review-export").disabled=!gi.length;for(let e of gi){let t=bt(i,"article");if(t.className="review-card",t.dataset.key=e.key,bt(t,"h3",`${e.gloss} \xB7 ${e.id}`),e.error){bt(t,"p",vt("reviewFailure",{detail:e.error}));continue}let n=bt(t,"p",vt("reviewDiagnostics",{frames:e.frameCount,duration:e.duration.toFixed(2),bones:e.usedBones.length,indices:e.indices.map(c=>c+1).join(", "),omitted:e.frameCount-e.indices.length}));n.className="diagnostic";let s={missing:"reviewNoBaseline",incompatible:"reviewIncompatible",motionChanged:"reviewMotionChanged",comparable:"reviewCompared",unavailable:"reviewUnavailable"}[e.comparison];bt(t,"p",vt(s,{ratio:((e.difference?.changedRatio||0)*100).toFixed(3),mean:(e.difference?.meanDifference||0).toFixed(3),detail:e.baselineError||"",date:e.baseline?.savedAt||""})),bt(t,"p",vt("reviewSheetOrder"));let r=bt(t,"div");r.className="comparison";for(let[c,h]of[[e.image,vt("reviewCurrent")],[e.baseline?.image,vt("reviewBaseline")]]){if(!(c instanceof Blob))continue;let u=bt(r,"figure");bt(u,"figcaption",h);let d=bt(u,"img");d.src=fv(c),d.alt=`${e.gloss} \xB7 ${h} \xB7 ${vt("reviewSheetOrder")}`}let o=bt(t,"div");o.className="actions";let a=bt(o,"button",vt("reviewSaveBaseline"));a.dataset.action="save",a.addEventListener("click",()=>hd(e));let l=bt(o,"button",vt("reviewDownloadImage"));if(l.dataset.action="download",l.addEventListener("click",()=>md(e.image,`${e.id}.review.png`)),e.baseline){let c=bt(o,"button",vt("reviewDeleteBaseline"));c.dataset.action="delete",c.addEventListener("click",()=>hd(e,!0))}}Yn()}async function _d(i){if(Lt||!yt)return;let e=Ac();if(!e.length||e.length>pr)return;let t=new globalThis.AbortController,n=rr;Lt=t,i&&yc(),Yn();let s=0;try{for(let[r,o]of e.entries()){t.signal.throwIfAborted(),Sn(i?"reviewCapturing":"reviewPlaying",{name:o.motion.gloss,index:r+1,total:e.length});let a;try{a=jc(o,yt.rig)}catch(u){s+=1,i&&gi.push({key:`${o.source}:${o.motion.id}`,id:o.motion.id,gloss:o.motion.gloss,error:bc(u)});continue}if(!i){await yt.play(a.asset.frames,t.signal);continue}let l=Qc(a.asset.frames.length),c=await td(yt,a.asset.frames,l,t.signal),h={...c,protocol:xi,key:a.key,id:a.id,source:a.source,gloss:a.asset.gloss,enabled:a.enabled,frameCount:a.asset.frames.length,duration:a.totalDuration,usedBones:a.usedBones,indices:l,motionHash:await $n(a.asset),imageHash:await $n(await c.image.arrayBuffer()),environmentHash:yt.environmentHash,capturedAt:new Date().toISOString()};await pd(h),t.signal.throwIfAborted(),gi.push(h)}i&&gd(),Sn("reviewFinished",{count:e.length-s,failures:s})}catch(r){r.name==="AbortError"?n===rr&&!fn&&Sn("reviewCancelled"):fn||Ni(r),i&&yc()}finally{if(Lt===t&&(Lt=null),!fn){yt?.stop(),i&&(Ze("review-view").value="front");try{yt?.render(Ze("review-view").value)}catch(r){Ni(r)}Yn()}}}function mv(){let i={type:xi,createdAt:new Date().toISOString(),scope:"SIGNS and saved compatible custom motions; not CHARS or sentence interpolation",linguisticApproval:!1,pixelChannelTolerance:16,environment:yt.environment,invalidLibraryEntries:Sc,views:Bi,motions:gi.map(({image:e,baseline:t,...n})=>({...n,baseline:t?{savedAt:t.savedAt,motionHash:t.motionHash,environmentHash:t.environmentHash}:null}))};md(new Blob([JSON.stringify(i,null,2)],{type:"application/json"}),"signbridge-visual-review.json")}Ze("review-load").addEventListener("click",fd);Ze("review-search").addEventListener("input",dd);Ze("review-play").addEventListener("click",()=>_d(!1));Ze("review-capture").addEventListener("click",()=>_d(!0));Ze("review-stop").addEventListener("click",Tc);Ze("review-export").addEventListener("click",mv);Ze("review-view").addEventListener("change",()=>{try{yt?.render(Ze("review-view").value)}catch(i){Ni(i)}});Ze("review-canvas").addEventListener("webglcontextlost",i=>{i.preventDefault(),Mc(),fn||Sn("reviewRenderError")});window.addEventListener("pagehide",()=>{fn=!0,mi?.abort(),Tc(),Ss?.(),yt?.dispose(),sr?.then(i=>i.close()).catch(()=>{}),wc(),xc.forEach(clearTimeout)});sd().then(i=>(od(i.uiLocale==="auto"?navigator.language:i.uiLocale),document.documentElement.lang=vc(),document.title=`SignBridge \xB7 ${vt("reviewTitle")}`,document.querySelectorAll("[data-i18n]").forEach(e=>{e.textContent=vt(e.dataset.i18n)}),document.querySelectorAll("[data-i18n-aria]").forEach(e=>{e.setAttribute("aria-label",vt(e.dataset.i18nAria))}),fd())).catch(Ni);
