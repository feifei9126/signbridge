#!/bin/zsh
cd -- "$(dirname -- "$0")"
exec /usr/bin/python3 start-demo.py
