# SignBridge 中文语义研究 Demo

研究和演示版，2026-10-18。训练的是有限中文语义角色，不是中国手语翻译或手语视频识别。

## 快速运行

需要 Python 3.10–3.12（已在 Python 3.12 / NumPy 1.26.4 验证）。无需 GPU 或 Node.js。
解压后在本目录打开终端。macOS / Linux：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python src/tools/sign-csl-learned.py --output runs/roles-v1 --examples 8000 --epochs 14 --seed 17
.venv/bin/python src/tools/sign-private-serve.py --model runs/roles-v1 --client client --port 8770
```

Windows：第一步使用 `py -3.12 -m venv .venv`，后续将 `.venv/bin/python` 替换为 `.venv\Scripts\python.exe`。无需激活虚拟环境。

服务终端会显示本机页面地址和本次会话口令。打开页面并输入口令，即可测试“我帮你”“你帮我”“今天我去学校”“你去吗”。复杂／未知输入会拒绝，不强行生成动作。训练输出必须使用新目录；重试时请换 `roles-v2` 等新目录。

## Chrome 客户端（可选）

同一页面也可作为独立扩展使用。打开 chrome://extensions，开启开发者模式，选择“加载已解压的扩展程序”，选中 `client` 目录。点击扩展图标后打开语义页面。若从插件跨来源连接，重启服务并附加：

```sh
.venv/bin/python src/tools/sign-private-serve.py --model runs/roles-v1 --client client --port 8770 --allow-extension chrome-extension://YOUR_32_CHARACTER_EXTENSION_ID
```

用 Chrome 显示的准确32位扩展 ID 替换占位内容；口令仍从本次终端获取。服务只绑定127.0.0.1，不接受通配 Origin。直接访问本机网页无需此参数。

## 复现检查

```sh
.venv/bin/python tests/sign-csl-learned.test.py
.venv/bin/python tests/sign-private-serve.test.py
```

模型使用 NumPy 平均结构感知机和 BIO 字符角色标签，实际更新权重。训练、验证、测试按施事／谓词／对象组合分组隔离，挑战文本从所有生成集合排除。学习范围由训练数据支持表限制，超出范围则拒绝。

## 已知范围

- 训练和评估均为 `assistant_synthetic_chinese` 合成中文监督；32种谓词表面形式和11类角色。不代表32个已验证手语词。
- 参考运行：训练6355、验证881、测试764；验证和测试角色完整匹配，34条同开发者构造挑战通过（17条拒绝）。模板简单、评估有偏差，这不是现实语言或中国手语准确率。
- 无人类中国手语批准，无已确认词级动作边界、镜像、手语者、空间指代或非手部表达；不自动播放词库、整句动作或生成手语。
- 该包不包含预训练权重、六批视频、原始动作、完整词库或原始评估语料。首次运行从代码生成合成样本并在自己的电脑训练。
- 服务是本机研究用途，不是已部署的公网多用户推理服务。随机口令仅终端显示，重启失效，不写文件、URL或浏览器存储；默认60次／分钟，最多12连接／2并发推理。
- 代码与客户端作为临时公开研究 Demo 分发，可被下载和复制；不保证防提取。原始授权素材和后续私有资产不由此包分发。

## 文件核验

`MANIFEST.json` 记录源码版本、范围与每个内容文件的 SHA256；`SHA256SUMS` 包含该元数据。使用系统校验工具核对，或用 Python hashlib 逐文件核验。不要把自己的会话口令、原视频或模型目录放进再次发布的包。

代码许可见 LICENSE；外部素材不随包提供。所有模型标注 `csl_translation_trained=false`、`human_approved=false`、`model_training_ready=false`。
