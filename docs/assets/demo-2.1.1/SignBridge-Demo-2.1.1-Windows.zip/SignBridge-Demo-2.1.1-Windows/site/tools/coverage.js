var an=0,Ba=1,Po=2;var Rr=1;var Ir=100;var Pr=204,Lr=205;var Dr=0,Nr=1,Ur=2,ci=3,Fr=4,Or=5,kr=6,Br=7,za=0;var zr="attached",Ha="detached",Lo=300;var Nt=1e3,Lt=1001,li=1002,cn=1003,Do=1004;var No=1005;var xn=1006,Uo=1007;var Ei=1008;var Va=1009;var Os=1015;var Fo=1023;var Ga=1028;var Ut=2300,Ft=2301,Gi=2302,Hr=2400,Vr=2401,Gr=2402,Wa=2500;var Oo=0,Ci=1,yn=2;var Xa=0;var ko="",Y="srgb",fe="srgb-linear",Bo="linear",ms="srgb";var xt=7680;var Wr=519;var gs=35044;var ut=2e3,vs=2001,Ot=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let i=this._listeners[e];if(i!==void 0){let s=i.indexOf(t);s!==-1&&i.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let n=this._listeners[e.type];if(n!==void 0){e.target=this;let i=n.slice(0);for(let s=0,r=i.length;s<r;s++)i[s].call(this,e);e.target=null}}},K=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Xr=1234567,rn=Math.PI/180,ln=180/Math.PI;function ye(){let c=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(K[c&255]+K[c>>8&255]+K[c>>16&255]+K[c>>24&255]+"-"+K[e&255]+K[e>>8&255]+"-"+K[e>>16&15|64]+K[e>>24&255]+"-"+K[t&63|128]+K[t>>8&255]+"-"+K[t>>16&255]+K[t>>24&255]+K[n&255]+K[n>>8&255]+K[n>>16&255]+K[n>>24&255]).toLowerCase()}function $(c,e,t){return Math.max(e,Math.min(t,c))}function ks(c,e){return(c%e+e)%e}function qa(c,e,t,n,i){return n+(c-e)*(i-n)/(t-e)}function Ya(c,e,t){return c!==e?(t-c)/(e-c):0}function on(c,e,t){return(1-t)*c+t*e}function Ja(c,e,t,n){return on(c,e,1-Math.exp(-t*n))}function Ka(c,e=1){return e-Math.abs(ks(c,e*2)-e)}function Za(c,e,t){return c<=e?0:c>=t?1:(c=(c-e)/(t-e),c*c*(3-2*c))}function $a(c,e,t){return c<=e?0:c>=t?1:(c=(c-e)/(t-e),c*c*c*(c*(c*6-15)+10))}function ja(c,e){return c+Math.floor(Math.random()*(e-c+1))}function Qa(c,e){return c+Math.random()*(e-c)}function ec(c){return c*(.5-Math.random())}function tc(c){c!==void 0&&(Xr=c);let e=Xr+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function nc(c){return c*rn}function ic(c){return c*ln}function sc(c){return(c&c-1)===0&&c!==0}function rc(c){return Math.pow(2,Math.ceil(Math.log(c)/Math.LN2))}function oc(c){return Math.pow(2,Math.floor(Math.log(c)/Math.LN2))}function ac(c,e,t,n,i){let s=Math.cos,r=Math.sin,o=s(t/2),a=r(t/2),l=s((e+n)/2),d=r((e+n)/2),h=s((e-n)/2),u=r((e-n)/2),f=s((n-e)/2),p=r((n-e)/2);switch(i){case"XYX":c.set(o*d,a*h,a*u,o*l);break;case"YZY":c.set(a*u,o*d,a*h,o*l);break;case"ZXZ":c.set(a*h,a*u,o*d,o*l);break;case"XZX":c.set(o*d,a*p,a*f,o*l);break;case"YXY":c.set(a*f,o*d,a*p,o*l);break;case"ZYZ":c.set(a*p,a*f,o*d,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+i)}}function xe(c,e){switch(e.constructor){case Float32Array:return c;case Uint32Array:return c/4294967295;case Uint16Array:return c/65535;case Uint8Array:return c/255;case Int32Array:return Math.max(c/2147483647,-1);case Int16Array:return Math.max(c/32767,-1);case Int8Array:return Math.max(c/127,-1);default:throw new Error("Invalid component type.")}}function F(c,e){switch(e.constructor){case Float32Array:return c;case Uint32Array:return Math.round(c*4294967295);case Uint16Array:return Math.round(c*65535);case Uint8Array:return Math.round(c*255);case Int32Array:return Math.round(c*2147483647);case Int16Array:return Math.round(c*32767);case Int8Array:return Math.round(c*127);default:throw new Error("Invalid component type.")}}var zo={DEG2RAD:rn,RAD2DEG:ln,generateUUID:ye,clamp:$,euclideanModulo:ks,mapLinear:qa,inverseLerp:Ya,lerp:on,damp:Ja,pingpong:Ka,smoothstep:Za,smootherstep:$a,randInt:ja,randFloat:Qa,randFloatSpread:ec,seededRandom:tc,degToRad:nc,radToDeg:ic,isPowerOfTwo:sc,ceilPowerOfTwo:rc,floorPowerOfTwo:oc,setQuaternionFromProperEuler:ac,normalize:F,denormalize:xe},z=class c{constructor(e=0,t=0){c.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6],this.y=i[1]*t+i[4]*n+i[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos($(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),i=Math.sin(t),s=this.x-e.x,r=this.y-e.y;return this.x=s*n-r*i+e.x,this.y=s*i+r*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},R=class c{constructor(e,t,n,i,s,r,o,a,l){c.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,i,s,r,o,a,l)}set(e,t,n,i,s,r,o,a,l){let d=this.elements;return d[0]=e,d[1]=i,d[2]=o,d[3]=t,d[4]=s,d[5]=a,d[6]=n,d[7]=r,d[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,i=t.elements,s=this.elements,r=n[0],o=n[3],a=n[6],l=n[1],d=n[4],h=n[7],u=n[2],f=n[5],p=n[8],m=i[0],g=i[3],v=i[6],x=i[1],y=i[4],M=i[7],b=i[2],C=i[5],A=i[8];return s[0]=r*m+o*x+a*b,s[3]=r*g+o*y+a*C,s[6]=r*v+o*M+a*A,s[1]=l*m+d*x+h*b,s[4]=l*g+d*y+h*C,s[7]=l*v+d*M+h*A,s[2]=u*m+f*x+p*b,s[5]=u*g+f*y+p*C,s[8]=u*v+f*M+p*A,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],r=e[4],o=e[5],a=e[6],l=e[7],d=e[8];return t*r*d-t*o*l-n*s*d+n*o*a+i*s*l-i*r*a}invert(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],r=e[4],o=e[5],a=e[6],l=e[7],d=e[8],h=d*r-o*l,u=o*a-d*s,f=l*s-r*a,p=t*h+n*u+i*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=h*m,e[1]=(i*l-d*n)*m,e[2]=(o*n-i*r)*m,e[3]=u*m,e[4]=(d*t-i*a)*m,e[5]=(i*s-o*t)*m,e[6]=f*m,e[7]=(n*a-l*t)*m,e[8]=(r*t-n*s)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,i,s,r,o){let a=Math.cos(s),l=Math.sin(s);return this.set(n*a,n*l,-n*(a*r+l*o)+r+e,-i*l,i*a,-i*(-l*r+a*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Wi.makeScale(e,t)),this}rotate(e){return this.premultiply(Wi.makeRotation(-e)),this}translate(e,t){return this.premultiply(Wi.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let i=0;i<9;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},Wi=new R;function cc(c){for(let e=c.length-1;e>=0;--e)if(c[e]>=65535)return!0;return!1}function _s(c){return document.createElementNS("http://www.w3.org/1999/xhtml",c)}var ee={enabled:!0,workingColorSpace:fe,spaces:{},convert:function(c,e,t){return this.enabled===!1||e===t||!e||!t||(this.spaces[e].transfer===ms&&(c.r=Le(c.r),c.g=Le(c.g),c.b=Le(c.b)),this.spaces[e].primaries!==this.spaces[t].primaries&&(c.applyMatrix3(this.spaces[e].toXYZ),c.applyMatrix3(this.spaces[t].fromXYZ)),this.spaces[t].transfer===ms&&(c.r=Dt(c.r),c.g=Dt(c.g),c.b=Dt(c.b))),c},fromWorkingColorSpace:function(c,e){return this.convert(c,this.workingColorSpace,e)},toWorkingColorSpace:function(c,e){return this.convert(c,e,this.workingColorSpace)},getPrimaries:function(c){return this.spaces[c].primaries},getTransfer:function(c){return c===ko?Bo:this.spaces[c].transfer},getLuminanceCoefficients:function(c,e=this.workingColorSpace){return c.fromArray(this.spaces[e].luminanceCoefficients)},define:function(c){Object.assign(this.spaces,c)},_getMatrix:function(c,e,t){return c.copy(this.spaces[e].toXYZ).multiply(this.spaces[t].fromXYZ)},_getDrawingBufferColorSpace:function(c){return this.spaces[c].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(c=this.workingColorSpace){return this.spaces[c].workingColorSpaceConfig.unpackColorSpace}};function Le(c){return c<.04045?c*.0773993808:Math.pow(c*.9478672986+.0521327014,2.4)}function Dt(c){return c<.0031308?c*12.92:1.055*Math.pow(c,.41666)-.055}var qr=[.64,.33,.3,.6,.15,.06],Yr=[.2126,.7152,.0722],Jr=[.3127,.329],Kr=new R().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Zr=new R().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);ee.define({[fe]:{primaries:qr,whitePoint:Jr,transfer:Bo,toXYZ:Kr,fromXYZ:Zr,luminanceCoefficients:Yr,workingColorSpaceConfig:{unpackColorSpace:Y},outputColorSpaceConfig:{drawingBufferColorSpace:Y}},[Y]:{primaries:qr,whitePoint:Jr,transfer:ms,toXYZ:Kr,fromXYZ:Zr,luminanceCoefficients:Yr,outputColorSpaceConfig:{drawingBufferColorSpace:Y}}});var yt,xs=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{yt===void 0&&(yt=_s("canvas")),yt.width=e.width,yt.height=e.height;let n=yt.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=yt}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=_s("canvas");t.width=e.width,t.height=e.height;let n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);let i=n.getImageData(0,0,e.width,e.height),s=i.data;for(let r=0;r<s.length;r++)s[r]=Le(s[r]/255)*255;return n.putImageData(i,0,0),t}else if(e.data){let t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Le(t[n]/255)*255):t[n]=Le(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},lc=0,ys=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:lc++}),this.uuid=ye(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let r=0,o=i.length;r<o;r++)i[r].isDataTexture?s.push(Xi(i[r].image)):s.push(Xi(i[r]))}else s=Xi(i);n.url=s}return t||(e.images[this.uuid]=n),n}};function Xi(c){return typeof HTMLImageElement<"u"&&c instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&c instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&c instanceof ImageBitmap?xs.getDataURL(c):c.data?{data:Array.from(c.data),width:c.width,height:c.height,type:c.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var dc=0,we=class c extends Ot{constructor(e=c.DEFAULT_IMAGE,t=c.DEFAULT_MAPPING,n=Lt,i=Lt,s=xn,r=Ei,o=Fo,a=Va,l=c.DEFAULT_ANISOTROPY,d=ko){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:dc++}),this.uuid=ye(),this.name="",this.source=new ys(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=r,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=a,this.offset=new z(0,0),this.repeat=new z(1,1),this.center=new z(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new R,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Lo)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Nt:e.x=e.x-Math.floor(e.x);break;case Lt:e.x=e.x<0?0:1;break;case li:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Nt:e.y=e.y-Math.floor(e.y);break;case Lt:e.y=e.y<0?0:1;break;case li:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};we.DEFAULT_IMAGE=null;we.DEFAULT_MAPPING=Lo;we.DEFAULT_ANISOTROPY=1;var te=class c{constructor(e=0,t=0,n=0,i=1){c.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=i}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,i){return this.x=e,this.y=t,this.z=n,this.w=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,i=this.z,s=this.w,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*i+r[12]*s,this.y=r[1]*t+r[5]*n+r[9]*i+r[13]*s,this.z=r[2]*t+r[6]*n+r[10]*i+r[14]*s,this.w=r[3]*t+r[7]*n+r[11]*i+r[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,i,s,a=e.elements,l=a[0],d=a[4],h=a[8],u=a[1],f=a[5],p=a[9],m=a[2],g=a[6],v=a[10];if(Math.abs(d-u)<.01&&Math.abs(h-m)<.01&&Math.abs(p-g)<.01){if(Math.abs(d+u)<.1&&Math.abs(h+m)<.1&&Math.abs(p+g)<.1&&Math.abs(l+f+v-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let y=(l+1)/2,M=(f+1)/2,b=(v+1)/2,C=(d+u)/4,A=(h+m)/4,E=(p+g)/4;return y>M&&y>b?y<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(y),i=C/n,s=A/n):M>b?M<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(M),n=C/i,s=E/i):b<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(b),n=A/s,i=E/s),this.set(n,i,s,t),this}let x=Math.sqrt((g-p)*(g-p)+(h-m)*(h-m)+(u-d)*(u-d));return Math.abs(x)<.001&&(x=1),this.x=(g-p)/x,this.y=(h-m)/x,this.z=(u-d)/x,this.w=Math.acos((l+f+v-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};var Me=class{constructor(e=0,t=0,n=0,i=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=i}static slerpFlat(e,t,n,i,s,r,o){let a=n[i+0],l=n[i+1],d=n[i+2],h=n[i+3],u=s[r+0],f=s[r+1],p=s[r+2],m=s[r+3];if(o===0){e[t+0]=a,e[t+1]=l,e[t+2]=d,e[t+3]=h;return}if(o===1){e[t+0]=u,e[t+1]=f,e[t+2]=p,e[t+3]=m;return}if(h!==m||a!==u||l!==f||d!==p){let g=1-o,v=a*u+l*f+d*p+h*m,x=v>=0?1:-1,y=1-v*v;if(y>Number.EPSILON){let b=Math.sqrt(y),C=Math.atan2(b,v*x);g=Math.sin(g*C)/b,o=Math.sin(o*C)/b}let M=o*x;if(a=a*g+u*M,l=l*g+f*M,d=d*g+p*M,h=h*g+m*M,g===1-o){let b=1/Math.sqrt(a*a+l*l+d*d+h*h);a*=b,l*=b,d*=b,h*=b}}e[t]=a,e[t+1]=l,e[t+2]=d,e[t+3]=h}static multiplyQuaternionsFlat(e,t,n,i,s,r){let o=n[i],a=n[i+1],l=n[i+2],d=n[i+3],h=s[r],u=s[r+1],f=s[r+2],p=s[r+3];return e[t]=o*p+d*h+a*f-l*u,e[t+1]=a*p+d*u+l*h-o*f,e[t+2]=l*p+d*f+o*u-a*h,e[t+3]=d*p-o*h-a*u-l*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,i){return this._x=e,this._y=t,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,i=e._y,s=e._z,r=e._order,o=Math.cos,a=Math.sin,l=o(n/2),d=o(i/2),h=o(s/2),u=a(n/2),f=a(i/2),p=a(s/2);switch(r){case"XYZ":this._x=u*d*h+l*f*p,this._y=l*f*h-u*d*p,this._z=l*d*p+u*f*h,this._w=l*d*h-u*f*p;break;case"YXZ":this._x=u*d*h+l*f*p,this._y=l*f*h-u*d*p,this._z=l*d*p-u*f*h,this._w=l*d*h+u*f*p;break;case"ZXY":this._x=u*d*h-l*f*p,this._y=l*f*h+u*d*p,this._z=l*d*p+u*f*h,this._w=l*d*h-u*f*p;break;case"ZYX":this._x=u*d*h-l*f*p,this._y=l*f*h+u*d*p,this._z=l*d*p-u*f*h,this._w=l*d*h+u*f*p;break;case"YZX":this._x=u*d*h+l*f*p,this._y=l*f*h+u*d*p,this._z=l*d*p-u*f*h,this._w=l*d*h-u*f*p;break;case"XZY":this._x=u*d*h-l*f*p,this._y=l*f*h-u*d*p,this._z=l*d*p+u*f*h,this._w=l*d*h+u*f*p;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+r)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,i=Math.sin(n);return this._x=e.x*i,this._y=e.y*i,this._z=e.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],i=t[4],s=t[8],r=t[1],o=t[5],a=t[9],l=t[2],d=t[6],h=t[10],u=n+o+h;if(u>0){let f=.5/Math.sqrt(u+1);this._w=.25/f,this._x=(d-a)*f,this._y=(s-l)*f,this._z=(r-i)*f}else if(n>o&&n>h){let f=2*Math.sqrt(1+n-o-h);this._w=(d-a)/f,this._x=.25*f,this._y=(i+r)/f,this._z=(s+l)/f}else if(o>h){let f=2*Math.sqrt(1+o-n-h);this._w=(s-l)/f,this._x=(i+r)/f,this._y=.25*f,this._z=(a+d)/f}else{let f=2*Math.sqrt(1+h-n-o);this._w=(r-i)/f,this._x=(s+l)/f,this._y=(a+d)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs($(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let i=Math.min(1,t/n);return this.slerp(e,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,i=e._y,s=e._z,r=e._w,o=t._x,a=t._y,l=t._z,d=t._w;return this._x=n*d+r*o+i*l-s*a,this._y=i*d+r*a+s*o-n*l,this._z=s*d+r*l+n*a-i*o,this._w=r*d-n*o-i*a-s*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let n=this._x,i=this._y,s=this._z,r=this._w,o=r*e._w+n*e._x+i*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=r,this._x=n,this._y=i,this._z=s,this;let a=1-o*o;if(a<=Number.EPSILON){let f=1-t;return this._w=f*r+t*this._w,this._x=f*n+t*this._x,this._y=f*i+t*this._y,this._z=f*s+t*this._z,this.normalize(),this}let l=Math.sqrt(a),d=Math.atan2(l,o),h=Math.sin((1-t)*d)/l,u=Math.sin(t*d)/l;return this._w=r*h+this._w*u,this._x=n*h+this._x*u,this._y=i*h+this._y*u,this._z=s*h+this._z*u,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(i*Math.sin(e),i*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},_=class c{constructor(e=0,t=0,n=0){c.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion($r.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion($r.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*i,this.y=s[1]*t+s[4]*n+s[7]*i,this.z=s[2]*t+s[5]*n+s[8]*i,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,i=this.z,s=e.elements,r=1/(s[3]*t+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*i+s[12])*r,this.y=(s[1]*t+s[5]*n+s[9]*i+s[13])*r,this.z=(s[2]*t+s[6]*n+s[10]*i+s[14])*r,this}applyQuaternion(e){let t=this.x,n=this.y,i=this.z,s=e.x,r=e.y,o=e.z,a=e.w,l=2*(r*i-o*n),d=2*(o*t-s*i),h=2*(s*n-r*t);return this.x=t+a*l+r*h-o*d,this.y=n+a*d+o*l-s*h,this.z=i+a*h+s*d-r*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*i,this.y=s[1]*t+s[5]*n+s[9]*i,this.z=s[2]*t+s[6]*n+s[10]*i,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,i=e.y,s=e.z,r=t.x,o=t.y,a=t.z;return this.x=i*a-s*o,this.y=s*r-n*a,this.z=n*o-i*r,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return qi.copy(this).projectOnVector(e),this.sub(qi)}reflect(e){return this.sub(qi.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos($(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,i=this.z-e.z;return t*t+n*n+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let i=Math.sin(t)*e;return this.x=i*Math.sin(n),this.y=Math.cos(t)*e,this.z=i*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),i=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=i,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},qi=new _,$r=new Me,he=class{constructor(e=new _(1/0,1/0,1/0),t=new _(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(ge.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(ge.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=ge.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let r=0,o=s.count;r<o;r++)e.isMesh===!0?e.getVertexPosition(r,ge):ge.fromBufferAttribute(s,r),ge.applyMatrix4(e.matrixWorld),this.expandByPoint(ge);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),kn.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),kn.copy(n.boundingBox)),kn.applyMatrix4(e.matrixWorld),this.union(kn)}let i=e.children;for(let s=0,r=i.length;s<r;s++)this.expandByObject(i[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,ge),ge.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Zt),Bn.subVectors(this.max,Zt),Mt.subVectors(e.a,Zt),St.subVectors(e.b,Zt),bt.subVectors(e.c,Zt),Xe.subVectors(St,Mt),qe.subVectors(bt,St),ot.subVectors(Mt,bt);let t=[0,-Xe.z,Xe.y,0,-qe.z,qe.y,0,-ot.z,ot.y,Xe.z,0,-Xe.x,qe.z,0,-qe.x,ot.z,0,-ot.x,-Xe.y,Xe.x,0,-qe.y,qe.x,0,-ot.y,ot.x,0];return!Yi(t,Mt,St,bt,Bn)||(t=[1,0,0,0,1,0,0,0,1],!Yi(t,Mt,St,bt,Bn))?!1:(zn.crossVectors(Xe,qe),t=[zn.x,zn.y,zn.z],Yi(t,Mt,St,bt,Bn))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,ge).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(ge).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Ae[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Ae[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Ae[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Ae[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Ae[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Ae[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Ae[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Ae[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Ae),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},Ae=[new _,new _,new _,new _,new _,new _,new _,new _],ge=new _,kn=new he,Mt=new _,St=new _,bt=new _,Xe=new _,qe=new _,ot=new _,Zt=new _,Bn=new _,zn=new _,at=new _;function Yi(c,e,t,n,i){for(let s=0,r=c.length-3;s<=r;s+=3){at.fromArray(c,s);let o=i.x*Math.abs(at.x)+i.y*Math.abs(at.y)+i.z*Math.abs(at.z),a=e.dot(at),l=t.dot(at),d=n.dot(at);if(Math.max(-Math.max(a,l,d),Math.min(a,l,d))>o)return!1}return!0}var hc=new he,$t=new _,Ji=new _,oe=class{constructor(e=new _,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t!==void 0?n.copy(t):hc.setFromPoints(e).getCenter(n);let i=0;for(let s=0,r=e.length;s<r;s++)i=Math.max(i,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(i),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;$t.subVectors(e,this.center);let t=$t.lengthSq();if(t>this.radius*this.radius){let n=Math.sqrt(t),i=(n-this.radius)*.5;this.center.addScaledVector($t,i/n),this.radius+=i}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Ji.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint($t.copy(e.center).add(Ji)),this.expandByPoint($t.copy(e.center).sub(Ji))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},Ee=new _,Ki=new _,Hn=new _,Ye=new _,Zi=new _,Vn=new _,$i=new _,kt=class{constructor(e=new _,t=new _(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Ee)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=Ee.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Ee.copy(this.origin).addScaledVector(this.direction,t),Ee.distanceToSquared(e))}distanceSqToSegment(e,t,n,i){Ki.copy(e).add(t).multiplyScalar(.5),Hn.copy(t).sub(e).normalize(),Ye.copy(this.origin).sub(Ki);let s=e.distanceTo(t)*.5,r=-this.direction.dot(Hn),o=Ye.dot(this.direction),a=-Ye.dot(Hn),l=Ye.lengthSq(),d=Math.abs(1-r*r),h,u,f,p;if(d>0)if(h=r*a-o,u=r*o-a,p=s*d,h>=0)if(u>=-p)if(u<=p){let m=1/d;h*=m,u*=m,f=h*(h+r*u+2*o)+u*(r*h+u+2*a)+l}else u=s,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*a)+l;else u=-s,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*a)+l;else u<=-p?(h=Math.max(0,-(-r*s+o)),u=h>0?-s:Math.min(Math.max(-s,-a),s),f=-h*h+u*(u+2*a)+l):u<=p?(h=0,u=Math.min(Math.max(-s,-a),s),f=u*(u+2*a)+l):(h=Math.max(0,-(r*s+o)),u=h>0?s:Math.min(Math.max(-s,-a),s),f=-h*h+u*(u+2*a)+l);else u=r>0?-s:s,h=Math.max(0,-(r*u+o)),f=-h*h+u*(u+2*a)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,h),i&&i.copy(Ki).addScaledVector(Hn,u),f}intersectSphere(e,t){Ee.subVectors(e.center,this.origin);let n=Ee.dot(this.direction),i=Ee.dot(Ee)-n*n,s=e.radius*e.radius;if(i>s)return null;let r=Math.sqrt(s-i),o=n-r,a=n+r;return a<0?null:o<0?this.at(a,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,i,s,r,o,a,l=1/this.direction.x,d=1/this.direction.y,h=1/this.direction.z,u=this.origin;return l>=0?(n=(e.min.x-u.x)*l,i=(e.max.x-u.x)*l):(n=(e.max.x-u.x)*l,i=(e.min.x-u.x)*l),d>=0?(s=(e.min.y-u.y)*d,r=(e.max.y-u.y)*d):(s=(e.max.y-u.y)*d,r=(e.min.y-u.y)*d),n>r||s>i||((s>n||isNaN(n))&&(n=s),(r<i||isNaN(i))&&(i=r),h>=0?(o=(e.min.z-u.z)*h,a=(e.max.z-u.z)*h):(o=(e.max.z-u.z)*h,a=(e.min.z-u.z)*h),n>a||o>i)||((o>n||n!==n)&&(n=o),(a<i||i!==i)&&(i=a),i<0)?null:this.at(n>=0?n:i,t)}intersectsBox(e){return this.intersectBox(e,Ee)!==null}intersectTriangle(e,t,n,i,s){Zi.subVectors(t,e),Vn.subVectors(n,e),$i.crossVectors(Zi,Vn);let r=this.direction.dot($i),o;if(r>0){if(i)return null;o=1}else if(r<0)o=-1,r=-r;else return null;Ye.subVectors(this.origin,e);let a=o*this.direction.dot(Vn.crossVectors(Ye,Vn));if(a<0)return null;let l=o*this.direction.dot(Zi.cross(Ye));if(l<0||a+l>r)return null;let d=-o*Ye.dot($i);return d<0?null:this.at(d/r,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},D=class c{constructor(e,t,n,i,s,r,o,a,l,d,h,u,f,p,m,g){c.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,i,s,r,o,a,l,d,h,u,f,p,m,g)}set(e,t,n,i,s,r,o,a,l,d,h,u,f,p,m,g){let v=this.elements;return v[0]=e,v[4]=t,v[8]=n,v[12]=i,v[1]=s,v[5]=r,v[9]=o,v[13]=a,v[2]=l,v[6]=d,v[10]=h,v[14]=u,v[3]=f,v[7]=p,v[11]=m,v[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new c().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,n=e.elements,i=1/wt.setFromMatrixColumn(e,0).length(),s=1/wt.setFromMatrixColumn(e,1).length(),r=1/wt.setFromMatrixColumn(e,2).length();return t[0]=n[0]*i,t[1]=n[1]*i,t[2]=n[2]*i,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*r,t[9]=n[9]*r,t[10]=n[10]*r,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,i=e.y,s=e.z,r=Math.cos(n),o=Math.sin(n),a=Math.cos(i),l=Math.sin(i),d=Math.cos(s),h=Math.sin(s);if(e.order==="XYZ"){let u=r*d,f=r*h,p=o*d,m=o*h;t[0]=a*d,t[4]=-a*h,t[8]=l,t[1]=f+p*l,t[5]=u-m*l,t[9]=-o*a,t[2]=m-u*l,t[6]=p+f*l,t[10]=r*a}else if(e.order==="YXZ"){let u=a*d,f=a*h,p=l*d,m=l*h;t[0]=u+m*o,t[4]=p*o-f,t[8]=r*l,t[1]=r*h,t[5]=r*d,t[9]=-o,t[2]=f*o-p,t[6]=m+u*o,t[10]=r*a}else if(e.order==="ZXY"){let u=a*d,f=a*h,p=l*d,m=l*h;t[0]=u-m*o,t[4]=-r*h,t[8]=p+f*o,t[1]=f+p*o,t[5]=r*d,t[9]=m-u*o,t[2]=-r*l,t[6]=o,t[10]=r*a}else if(e.order==="ZYX"){let u=r*d,f=r*h,p=o*d,m=o*h;t[0]=a*d,t[4]=p*l-f,t[8]=u*l+m,t[1]=a*h,t[5]=m*l+u,t[9]=f*l-p,t[2]=-l,t[6]=o*a,t[10]=r*a}else if(e.order==="YZX"){let u=r*a,f=r*l,p=o*a,m=o*l;t[0]=a*d,t[4]=m-u*h,t[8]=p*h+f,t[1]=h,t[5]=r*d,t[9]=-o*d,t[2]=-l*d,t[6]=f*h+p,t[10]=u-m*h}else if(e.order==="XZY"){let u=r*a,f=r*l,p=o*a,m=o*l;t[0]=a*d,t[4]=-h,t[8]=l*d,t[1]=u*h+m,t[5]=r*d,t[9]=f*h-p,t[2]=p*h-f,t[6]=o*d,t[10]=m*h+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(uc,e,fc)}lookAt(e,t,n){let i=this.elements;return se.subVectors(e,t),se.lengthSq()===0&&(se.z=1),se.normalize(),Je.crossVectors(n,se),Je.lengthSq()===0&&(Math.abs(n.z)===1?se.x+=1e-4:se.z+=1e-4,se.normalize(),Je.crossVectors(n,se)),Je.normalize(),Gn.crossVectors(se,Je),i[0]=Je.x,i[4]=Gn.x,i[8]=se.x,i[1]=Je.y,i[5]=Gn.y,i[9]=se.y,i[2]=Je.z,i[6]=Gn.z,i[10]=se.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,i=t.elements,s=this.elements,r=n[0],o=n[4],a=n[8],l=n[12],d=n[1],h=n[5],u=n[9],f=n[13],p=n[2],m=n[6],g=n[10],v=n[14],x=n[3],y=n[7],M=n[11],b=n[15],C=i[0],A=i[4],E=i[8],N=i[12],k=i[1],X=i[5],Ge=i[9],J=i[13],We=i[2],Pn=i[6],Ln=i[10],Dn=i[14],Nn=i[3],Un=i[7],Fn=i[11],On=i[15];return s[0]=r*C+o*k+a*We+l*Nn,s[4]=r*A+o*X+a*Pn+l*Un,s[8]=r*E+o*Ge+a*Ln+l*Fn,s[12]=r*N+o*J+a*Dn+l*On,s[1]=d*C+h*k+u*We+f*Nn,s[5]=d*A+h*X+u*Pn+f*Un,s[9]=d*E+h*Ge+u*Ln+f*Fn,s[13]=d*N+h*J+u*Dn+f*On,s[2]=p*C+m*k+g*We+v*Nn,s[6]=p*A+m*X+g*Pn+v*Un,s[10]=p*E+m*Ge+g*Ln+v*Fn,s[14]=p*N+m*J+g*Dn+v*On,s[3]=x*C+y*k+M*We+b*Nn,s[7]=x*A+y*X+M*Pn+b*Un,s[11]=x*E+y*Ge+M*Ln+b*Fn,s[15]=x*N+y*J+M*Dn+b*On,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],i=e[8],s=e[12],r=e[1],o=e[5],a=e[9],l=e[13],d=e[2],h=e[6],u=e[10],f=e[14],p=e[3],m=e[7],g=e[11],v=e[15];return p*(+s*a*h-i*l*h-s*o*u+n*l*u+i*o*f-n*a*f)+m*(+t*a*f-t*l*u+s*r*u-i*r*f+i*l*d-s*a*d)+g*(+t*l*h-t*o*f-s*r*h+n*r*f+s*o*d-n*l*d)+v*(-i*o*d-t*a*h+t*o*u+i*r*h-n*r*u+n*a*d)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let i=this.elements;return e.isVector3?(i[12]=e.x,i[13]=e.y,i[14]=e.z):(i[12]=e,i[13]=t,i[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],r=e[4],o=e[5],a=e[6],l=e[7],d=e[8],h=e[9],u=e[10],f=e[11],p=e[12],m=e[13],g=e[14],v=e[15],x=h*g*l-m*u*l+m*a*f-o*g*f-h*a*v+o*u*v,y=p*u*l-d*g*l-p*a*f+r*g*f+d*a*v-r*u*v,M=d*m*l-p*h*l+p*o*f-r*m*f-d*o*v+r*h*v,b=p*h*a-d*m*a-p*o*u+r*m*u+d*o*g-r*h*g,C=t*x+n*y+i*M+s*b;if(C===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/C;return e[0]=x*A,e[1]=(m*u*s-h*g*s-m*i*f+n*g*f+h*i*v-n*u*v)*A,e[2]=(o*g*s-m*a*s+m*i*l-n*g*l-o*i*v+n*a*v)*A,e[3]=(h*a*s-o*u*s-h*i*l+n*u*l+o*i*f-n*a*f)*A,e[4]=y*A,e[5]=(d*g*s-p*u*s+p*i*f-t*g*f-d*i*v+t*u*v)*A,e[6]=(p*a*s-r*g*s-p*i*l+t*g*l+r*i*v-t*a*v)*A,e[7]=(r*u*s-d*a*s+d*i*l-t*u*l-r*i*f+t*a*f)*A,e[8]=M*A,e[9]=(p*h*s-d*m*s-p*n*f+t*m*f+d*n*v-t*h*v)*A,e[10]=(r*m*s-p*o*s+p*n*l-t*m*l-r*n*v+t*o*v)*A,e[11]=(d*o*s-r*h*s-d*n*l+t*h*l+r*n*f-t*o*f)*A,e[12]=b*A,e[13]=(d*m*i-p*h*i+p*n*u-t*m*u-d*n*g+t*h*g)*A,e[14]=(p*o*i-r*m*i-p*n*a+t*m*a+r*n*g-t*o*g)*A,e[15]=(r*h*i-d*o*i+d*n*a-t*h*a-r*n*u+t*o*u)*A,this}scale(e){let t=this.elements,n=e.x,i=e.y,s=e.z;return t[0]*=n,t[4]*=i,t[8]*=s,t[1]*=n,t[5]*=i,t[9]*=s,t[2]*=n,t[6]*=i,t[10]*=s,t[3]*=n,t[7]*=i,t[11]*=s,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],i=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,i))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),i=Math.sin(t),s=1-n,r=e.x,o=e.y,a=e.z,l=s*r,d=s*o;return this.set(l*r+n,l*o-i*a,l*a+i*o,0,l*o+i*a,d*o+n,d*a-i*r,0,l*a-i*o,d*a+i*r,s*a*a+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,i,s,r){return this.set(1,n,s,0,e,1,r,0,t,i,1,0,0,0,0,1),this}compose(e,t,n){let i=this.elements,s=t._x,r=t._y,o=t._z,a=t._w,l=s+s,d=r+r,h=o+o,u=s*l,f=s*d,p=s*h,m=r*d,g=r*h,v=o*h,x=a*l,y=a*d,M=a*h,b=n.x,C=n.y,A=n.z;return i[0]=(1-(m+v))*b,i[1]=(f+M)*b,i[2]=(p-y)*b,i[3]=0,i[4]=(f-M)*C,i[5]=(1-(u+v))*C,i[6]=(g+x)*C,i[7]=0,i[8]=(p+y)*A,i[9]=(g-x)*A,i[10]=(1-(u+m))*A,i[11]=0,i[12]=e.x,i[13]=e.y,i[14]=e.z,i[15]=1,this}decompose(e,t,n){let i=this.elements,s=wt.set(i[0],i[1],i[2]).length(),r=wt.set(i[4],i[5],i[6]).length(),o=wt.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),e.x=i[12],e.y=i[13],e.z=i[14],ve.copy(this);let l=1/s,d=1/r,h=1/o;return ve.elements[0]*=l,ve.elements[1]*=l,ve.elements[2]*=l,ve.elements[4]*=d,ve.elements[5]*=d,ve.elements[6]*=d,ve.elements[8]*=h,ve.elements[9]*=h,ve.elements[10]*=h,t.setFromRotationMatrix(ve),n.x=s,n.y=r,n.z=o,this}makePerspective(e,t,n,i,s,r,o=ut){let a=this.elements,l=2*s/(t-e),d=2*s/(n-i),h=(t+e)/(t-e),u=(n+i)/(n-i),f,p;if(o===ut)f=-(r+s)/(r-s),p=-2*r*s/(r-s);else if(o===vs)f=-r/(r-s),p=-r*s/(r-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return a[0]=l,a[4]=0,a[8]=h,a[12]=0,a[1]=0,a[5]=d,a[9]=u,a[13]=0,a[2]=0,a[6]=0,a[10]=f,a[14]=p,a[3]=0,a[7]=0,a[11]=-1,a[15]=0,this}makeOrthographic(e,t,n,i,s,r,o=ut){let a=this.elements,l=1/(t-e),d=1/(n-i),h=1/(r-s),u=(t+e)*l,f=(n+i)*d,p,m;if(o===ut)p=(r+s)*h,m=-2*h;else if(o===vs)p=s*h,m=-1*h;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return a[0]=2*l,a[4]=0,a[8]=0,a[12]=-u,a[1]=0,a[5]=2*d,a[9]=0,a[13]=-f,a[2]=0,a[6]=0,a[10]=m,a[14]=-p,a[3]=0,a[7]=0,a[11]=0,a[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let i=0;i<16;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},wt=new _,ve=new D,uc=new _(0,0,0),fc=new _(1,1,1),Je=new _,Gn=new _,se=new _,jr=new D,Qr=new Me,Bt=class c{constructor(e=0,t=0,n=0,i=c.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,i=this._order){return this._x=e,this._y=t,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let i=e.elements,s=i[0],r=i[4],o=i[8],a=i[1],l=i[5],d=i[9],h=i[2],u=i[6],f=i[10];switch(t){case"XYZ":this._y=Math.asin($(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,f),this._z=Math.atan2(-r,s)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-$(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(a,l)):(this._y=Math.atan2(-h,s),this._z=0);break;case"ZXY":this._x=Math.asin($(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,f),this._z=Math.atan2(-r,l)):(this._y=0,this._z=Math.atan2(a,s));break;case"ZYX":this._y=Math.asin(-$(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,f),this._z=Math.atan2(a,s)):(this._x=0,this._z=Math.atan2(-r,l));break;case"YZX":this._z=Math.asin($(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-d,l),this._y=Math.atan2(-h,s)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-$(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return jr.makeRotationFromQuaternion(e),this.setFromRotationMatrix(jr,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Qr.setFromEuler(this),this.setFromQuaternion(Qr,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Bt.DEFAULT_ORDER="XYZ";var Ms=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},pc=0,eo=new _,Tt=new Me,Ce=new D,Wn=new _,jt=new _,mc=new _,gc=new Me,to=new _(1,0,0),no=new _(0,1,0),io=new _(0,0,1),so={type:"added"},vc={type:"removed"},At={type:"childadded",child:null},ji={type:"childremoved",child:null},G=class c extends Ot{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:pc++}),this.uuid=ye(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=c.DEFAULT_UP.clone();let e=new _,t=new Bt,n=new Me,i=new _(1,1,1);function s(){n.setFromEuler(t,!1)}function r(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(r),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new D},normalMatrix:{value:new R}}),this.matrix=new D,this.matrixWorld=new D,this.matrixAutoUpdate=c.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=c.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ms,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Tt.setFromAxisAngle(e,t),this.quaternion.multiply(Tt),this}rotateOnWorldAxis(e,t){return Tt.setFromAxisAngle(e,t),this.quaternion.premultiply(Tt),this}rotateX(e){return this.rotateOnAxis(to,e)}rotateY(e){return this.rotateOnAxis(no,e)}rotateZ(e){return this.rotateOnAxis(io,e)}translateOnAxis(e,t){return eo.copy(e).applyQuaternion(this.quaternion),this.position.add(eo.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(to,e)}translateY(e){return this.translateOnAxis(no,e)}translateZ(e){return this.translateOnAxis(io,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Ce.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Wn.copy(e):Wn.set(e,t,n);let i=this.parent;this.updateWorldMatrix(!0,!1),jt.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Ce.lookAt(jt,Wn,this.up):Ce.lookAt(Wn,jt,this.up),this.quaternion.setFromRotationMatrix(Ce),i&&(Ce.extractRotation(i.matrixWorld),Tt.setFromRotationMatrix(Ce),this.quaternion.premultiply(Tt.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(so),At.child=e,this.dispatchEvent(At),At.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(vc),ji.child=e,this.dispatchEvent(ji),ji.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Ce.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Ce.multiply(e.parent.matrixWorld)),e.applyMatrix4(Ce),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(so),At.child=e,this.dispatchEvent(At),At.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,i=this.children.length;n<i;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let i=this.children;for(let s=0,r=i.length;s<r;s++)i[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(jt,e,mc),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(jt,gc,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){let n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){let i=this.children;for(let s=0,r=i.length;s<r;s++)i[s].updateWorldMatrix(!1,!0)}}toJSON(e){let t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function s(o,a){return o[a.uuid]===void 0&&(o[a.uuid]=a.toJSON(e)),a.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(e.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let a=o.shapes;if(Array.isArray(a))for(let l=0,d=a.length;l<d;l++){let h=a[l];s(e.shapes,h)}else s(e.shapes,a)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let a=0,l=this.material.length;a<l;a++)o.push(s(e.materials,this.material[a]));i.material=o}else i.material=s(e.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){let a=this.animations[o];i.animations.push(s(e.animations,a))}}if(t){let o=r(e.geometries),a=r(e.materials),l=r(e.textures),d=r(e.images),h=r(e.shapes),u=r(e.skeletons),f=r(e.animations),p=r(e.nodes);o.length>0&&(n.geometries=o),a.length>0&&(n.materials=a),l.length>0&&(n.textures=l),d.length>0&&(n.images=d),h.length>0&&(n.shapes=h),u.length>0&&(n.skeletons=u),f.length>0&&(n.animations=f),p.length>0&&(n.nodes=p)}return n.object=i,n;function r(o){let a=[];for(let l in o){let d=o[l];delete d.metadata,a.push(d)}return a}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){let i=e.children[n];this.add(i.clone())}return this}};G.DEFAULT_UP=new _(0,1,0);G.DEFAULT_MATRIX_AUTO_UPDATE=!0;G.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var _e=new _,Re=new _,Qi=new _,Ie=new _,Et=new _,Ct=new _,ro=new _,es=new _,ts=new _,ns=new _,is=new te,ss=new te,rs=new te,ht=class c{constructor(e=new _,t=new _,n=new _){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,i){i.subVectors(n,t),_e.subVectors(e,t),i.cross(_e);let s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(e,t,n,i,s){_e.subVectors(i,t),Re.subVectors(n,t),Qi.subVectors(e,t);let r=_e.dot(_e),o=_e.dot(Re),a=_e.dot(Qi),l=Re.dot(Re),d=Re.dot(Qi),h=r*l-o*o;if(h===0)return s.set(0,0,0),null;let u=1/h,f=(l*a-o*d)*u,p=(r*d-o*a)*u;return s.set(1-f-p,p,f)}static containsPoint(e,t,n,i){return this.getBarycoord(e,t,n,i,Ie)===null?!1:Ie.x>=0&&Ie.y>=0&&Ie.x+Ie.y<=1}static getInterpolation(e,t,n,i,s,r,o,a){return this.getBarycoord(e,t,n,i,Ie)===null?(a.x=0,a.y=0,"z"in a&&(a.z=0),"w"in a&&(a.w=0),null):(a.setScalar(0),a.addScaledVector(s,Ie.x),a.addScaledVector(r,Ie.y),a.addScaledVector(o,Ie.z),a)}static getInterpolatedAttribute(e,t,n,i,s,r){return is.setScalar(0),ss.setScalar(0),rs.setScalar(0),is.fromBufferAttribute(e,t),ss.fromBufferAttribute(e,n),rs.fromBufferAttribute(e,i),r.setScalar(0),r.addScaledVector(is,s.x),r.addScaledVector(ss,s.y),r.addScaledVector(rs,s.z),r}static isFrontFacing(e,t,n,i){return _e.subVectors(n,t),Re.subVectors(e,t),_e.cross(Re).dot(i)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,i){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[i]),this}setFromAttributeAndIndices(e,t,n,i){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return _e.subVectors(this.c,this.b),Re.subVectors(this.a,this.b),_e.cross(Re).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return c.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return c.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,i,s){return c.getInterpolation(e,this.a,this.b,this.c,t,n,i,s)}containsPoint(e){return c.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return c.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,i=this.b,s=this.c,r,o;Et.subVectors(i,n),Ct.subVectors(s,n),es.subVectors(e,n);let a=Et.dot(es),l=Ct.dot(es);if(a<=0&&l<=0)return t.copy(n);ts.subVectors(e,i);let d=Et.dot(ts),h=Ct.dot(ts);if(d>=0&&h<=d)return t.copy(i);let u=a*h-d*l;if(u<=0&&a>=0&&d<=0)return r=a/(a-d),t.copy(n).addScaledVector(Et,r);ns.subVectors(e,s);let f=Et.dot(ns),p=Ct.dot(ns);if(p>=0&&f<=p)return t.copy(s);let m=f*l-a*p;if(m<=0&&l>=0&&p<=0)return o=l/(l-p),t.copy(n).addScaledVector(Ct,o);let g=d*p-f*h;if(g<=0&&h-d>=0&&f-p>=0)return ro.subVectors(s,i),o=(h-d)/(h-d+(f-p)),t.copy(i).addScaledVector(ro,o);let v=1/(g+m+u);return r=m*v,o=u*v,t.copy(n).addScaledVector(Et,r).addScaledVector(Ct,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Ho={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ke={h:0,s:0,l:0},Xn={h:0,s:0,l:0};function os(c,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?c+(e-c)*6*t:t<1/2?e:t<2/3?c+(e-c)*6*(2/3-t):c}var L=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let i=e;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Y){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,ee.toWorkingColorSpace(this,t),this}setRGB(e,t,n,i=ee.workingColorSpace){return this.r=e,this.g=t,this.b=n,ee.toWorkingColorSpace(this,i),this}setHSL(e,t,n,i=ee.workingColorSpace){if(e=ks(e,1),t=$(t,0,1),n=$(n,0,1),t===0)this.r=this.g=this.b=n;else{let s=n<=.5?n*(1+t):n+t-n*t,r=2*n-s;this.r=os(r,s,e+1/3),this.g=os(r,s,e),this.b=os(r,s,e-1/3)}return ee.toWorkingColorSpace(this,i),this}setStyle(e,t=Y){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(e)){let s,r=i[1],o=i[2];switch(r){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(e)){let s=i[1],r=s.length;if(r===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(r===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Y){let n=Ho[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Le(e.r),this.g=Le(e.g),this.b=Le(e.b),this}copyLinearToSRGB(e){return this.r=Dt(e.r),this.g=Dt(e.g),this.b=Dt(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Y){return ee.fromWorkingColorSpace(Z.copy(this),e),Math.round($(Z.r*255,0,255))*65536+Math.round($(Z.g*255,0,255))*256+Math.round($(Z.b*255,0,255))}getHexString(e=Y){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=ee.workingColorSpace){ee.fromWorkingColorSpace(Z.copy(this),t);let n=Z.r,i=Z.g,s=Z.b,r=Math.max(n,i,s),o=Math.min(n,i,s),a,l,d=(o+r)/2;if(o===r)a=0,l=0;else{let h=r-o;switch(l=d<=.5?h/(r+o):h/(2-r-o),r){case n:a=(i-s)/h+(i<s?6:0);break;case i:a=(s-n)/h+2;break;case s:a=(n-i)/h+4;break}a/=6}return e.h=a,e.s=l,e.l=d,e}getRGB(e,t=ee.workingColorSpace){return ee.fromWorkingColorSpace(Z.copy(this),t),e.r=Z.r,e.g=Z.g,e.b=Z.b,e}getStyle(e=Y){ee.fromWorkingColorSpace(Z.copy(this),e);let t=Z.r,n=Z.g,i=Z.b;return e!==Y?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(e,t,n){return this.getHSL(Ke),this.setHSL(Ke.h+e,Ke.s+t,Ke.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Ke),e.getHSL(Xn);let n=on(Ke.h,Xn.h,t),i=on(Ke.s,Xn.s,t),s=on(Ke.l,Xn.l,t);return this.setHSL(n,i,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,i=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*i,this.g=s[1]*t+s[4]*n+s[7]*i,this.b=s[2]*t+s[5]*n+s[8]*i,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Z=new L;L.NAMES=Ho;var _c=0,Te=class extends Ot{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:_c++}),this.uuid=ye(),this.name="",this.blending=Rr,this.side=an,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Pr,this.blendDst=Lr,this.blendEquation=Ir,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new L(0,0,0),this.blendAlpha=0,this.depthFunc=ci,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Wr,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=xt,this.stencilZFail=xt,this.stencilZPass=xt,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let i=this[t];if(i===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Rr&&(n.blending=this.blending),this.side!==an&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Pr&&(n.blendSrc=this.blendSrc),this.blendDst!==Lr&&(n.blendDst=this.blendDst),this.blendEquation!==Ir&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ci&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Wr&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==xt&&(n.stencilFail=this.stencilFail),this.stencilZFail!==xt&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==xt&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(s){let r=[];for(let o in s){let a=s[o];delete a.metadata,r.push(a)}return r}if(t){let s=i(e.textures),r=i(e.images);s.length>0&&(n.textures=s),r.length>0&&(n.images=r)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let i=t.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},De=class extends Te{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new L(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Bt,this.combine=za,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}};var V=new _,qn=new z,ne=class{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=gs,this.updateRanges=[],this.gpuType=Os,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[e+i]=t.array[n+i];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)qn.fromBufferAttribute(this,t),qn.applyMatrix3(e),this.setXY(t,qn.x,qn.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)V.fromBufferAttribute(this,t),V.applyMatrix3(e),this.setXYZ(t,V.x,V.y,V.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)V.fromBufferAttribute(this,t),V.applyMatrix4(e),this.setXYZ(t,V.x,V.y,V.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)V.fromBufferAttribute(this,t),V.applyNormalMatrix(e),this.setXYZ(t,V.x,V.y,V.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)V.fromBufferAttribute(this,t),V.transformDirection(e),this.setXYZ(t,V.x,V.y,V.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=xe(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=F(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=xe(t,this.array)),t}setX(e,t){return this.normalized&&(t=F(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=xe(t,this.array)),t}setY(e,t){return this.normalized&&(t=F(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=xe(t,this.array)),t}setZ(e,t){return this.normalized&&(t=F(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=xe(t,this.array)),t}setW(e,t){return this.normalized&&(t=F(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=F(t,this.array),n=F(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,i){return e*=this.itemSize,this.normalized&&(t=F(t,this.array),n=F(n,this.array),i=F(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e*=this.itemSize,this.normalized&&(t=F(t,this.array),n=F(n,this.array),i=F(i,this.array),s=F(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==gs&&(e.usage=this.usage),e}};var Ss=class extends ne{constructor(e,t,n){super(new Uint16Array(e),t,n)}};var bs=class extends ne{constructor(e,t,n){super(new Uint32Array(e),t,n)}};var zt=class extends ne{constructor(e,t,n){super(new Float32Array(e),t,n)}},xc=0,de=new D,as=new G,Rt=new _,re=new he,Qt=new he,q=new _,Qe=class c extends Ot{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:xc++}),this.uuid=ye(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(cc(e)?bs:Ss)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let s=new R().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(e),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return de.makeRotationFromQuaternion(e),this.applyMatrix4(de),this}rotateX(e){return de.makeRotationX(e),this.applyMatrix4(de),this}rotateY(e){return de.makeRotationY(e),this.applyMatrix4(de),this}rotateZ(e){return de.makeRotationZ(e),this.applyMatrix4(de),this}translate(e,t,n){return de.makeTranslation(e,t,n),this.applyMatrix4(de),this}scale(e,t,n){return de.makeScale(e,t,n),this.applyMatrix4(de),this}lookAt(e){return as.lookAt(e),as.updateMatrix(),this.applyMatrix4(as.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Rt).negate(),this.translate(Rt.x,Rt.y,Rt.z),this}setFromPoints(e){let t=this.getAttribute("position");if(t===void 0){let n=[];for(let i=0,s=e.length;i<s;i++){let r=e[i];n.push(r.x,r.y,r.z||0)}this.setAttribute("position",new zt(n,3))}else{for(let n=0,i=t.count;n<i;n++){let s=e[n];t.setXYZ(n,s.x,s.y,s.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new he);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new _(-1/0,-1/0,-1/0),new _(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,i=t.length;n<i;n++){let s=t[n];re.setFromBufferAttribute(s),this.morphTargetsRelative?(q.addVectors(this.boundingBox.min,re.min),this.boundingBox.expandByPoint(q),q.addVectors(this.boundingBox.max,re.max),this.boundingBox.expandByPoint(q)):(this.boundingBox.expandByPoint(re.min),this.boundingBox.expandByPoint(re.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new oe);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new _,1/0);return}if(e){let n=this.boundingSphere.center;if(re.setFromBufferAttribute(e),t)for(let s=0,r=t.length;s<r;s++){let o=t[s];Qt.setFromBufferAttribute(o),this.morphTargetsRelative?(q.addVectors(re.min,Qt.min),re.expandByPoint(q),q.addVectors(re.max,Qt.max),re.expandByPoint(q)):(re.expandByPoint(Qt.min),re.expandByPoint(Qt.max))}re.getCenter(n);let i=0;for(let s=0,r=e.count;s<r;s++)q.fromBufferAttribute(e,s),i=Math.max(i,n.distanceToSquared(q));if(t)for(let s=0,r=t.length;s<r;s++){let o=t[s],a=this.morphTargetsRelative;for(let l=0,d=o.count;l<d;l++)q.fromBufferAttribute(o,l),a&&(Rt.fromBufferAttribute(e,l),q.add(Rt)),i=Math.max(i,n.distanceToSquared(q))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.position,i=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new ne(new Float32Array(4*n.count),4));let r=this.getAttribute("tangent"),o=[],a=[];for(let E=0;E<n.count;E++)o[E]=new _,a[E]=new _;let l=new _,d=new _,h=new _,u=new z,f=new z,p=new z,m=new _,g=new _;function v(E,N,k){l.fromBufferAttribute(n,E),d.fromBufferAttribute(n,N),h.fromBufferAttribute(n,k),u.fromBufferAttribute(s,E),f.fromBufferAttribute(s,N),p.fromBufferAttribute(s,k),d.sub(l),h.sub(l),f.sub(u),p.sub(u);let X=1/(f.x*p.y-p.x*f.y);isFinite(X)&&(m.copy(d).multiplyScalar(p.y).addScaledVector(h,-f.y).multiplyScalar(X),g.copy(h).multiplyScalar(f.x).addScaledVector(d,-p.x).multiplyScalar(X),o[E].add(m),o[N].add(m),o[k].add(m),a[E].add(g),a[N].add(g),a[k].add(g))}let x=this.groups;x.length===0&&(x=[{start:0,count:e.count}]);for(let E=0,N=x.length;E<N;++E){let k=x[E],X=k.start,Ge=k.count;for(let J=X,We=X+Ge;J<We;J+=3)v(e.getX(J+0),e.getX(J+1),e.getX(J+2))}let y=new _,M=new _,b=new _,C=new _;function A(E){b.fromBufferAttribute(i,E),C.copy(b);let N=o[E];y.copy(N),y.sub(b.multiplyScalar(b.dot(N))).normalize(),M.crossVectors(C,N);let X=M.dot(a[E])<0?-1:1;r.setXYZW(E,y.x,y.y,y.z,X)}for(let E=0,N=x.length;E<N;++E){let k=x[E],X=k.start,Ge=k.count;for(let J=X,We=X+Ge;J<We;J+=3)A(e.getX(J+0)),A(e.getX(J+1)),A(e.getX(J+2))}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new ne(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let u=0,f=n.count;u<f;u++)n.setXYZ(u,0,0,0);let i=new _,s=new _,r=new _,o=new _,a=new _,l=new _,d=new _,h=new _;if(e)for(let u=0,f=e.count;u<f;u+=3){let p=e.getX(u+0),m=e.getX(u+1),g=e.getX(u+2);i.fromBufferAttribute(t,p),s.fromBufferAttribute(t,m),r.fromBufferAttribute(t,g),d.subVectors(r,s),h.subVectors(i,s),d.cross(h),o.fromBufferAttribute(n,p),a.fromBufferAttribute(n,m),l.fromBufferAttribute(n,g),o.add(d),a.add(d),l.add(d),n.setXYZ(p,o.x,o.y,o.z),n.setXYZ(m,a.x,a.y,a.z),n.setXYZ(g,l.x,l.y,l.z)}else for(let u=0,f=t.count;u<f;u+=3)i.fromBufferAttribute(t,u+0),s.fromBufferAttribute(t,u+1),r.fromBufferAttribute(t,u+2),d.subVectors(r,s),h.subVectors(i,s),d.cross(h),n.setXYZ(u+0,d.x,d.y,d.z),n.setXYZ(u+1,d.x,d.y,d.z),n.setXYZ(u+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)q.fromBufferAttribute(e,t),q.normalize(),e.setXYZ(t,q.x,q.y,q.z)}toNonIndexed(){function e(o,a){let l=o.array,d=o.itemSize,h=o.normalized,u=new l.constructor(a.length*d),f=0,p=0;for(let m=0,g=a.length;m<g;m++){o.isInterleavedBufferAttribute?f=a[m]*o.data.stride+o.offset:f=a[m]*d;for(let v=0;v<d;v++)u[p++]=l[f++]}return new ne(u,d,h)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new c,n=this.index.array,i=this.attributes;for(let o in i){let a=i[o],l=e(a,n);t.setAttribute(o,l)}let s=this.morphAttributes;for(let o in s){let a=[],l=s[o];for(let d=0,h=l.length;d<h;d++){let u=l[d],f=e(u,n);a.push(f)}t.morphAttributes[o]=a}t.morphTargetsRelative=this.morphTargetsRelative;let r=this.groups;for(let o=0,a=r.length;o<a;o++){let l=r[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let a=this.parameters;for(let l in a)a[l]!==void 0&&(e[l]=a[l]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let a in n){let l=n[a];e.data.attributes[a]=l.toJSON(e.data)}let i={},s=!1;for(let a in this.morphAttributes){let l=this.morphAttributes[a],d=[];for(let h=0,u=l.length;h<u;h++){let f=l[h];d.push(f.toJSON(e.data))}d.length>0&&(i[a]=d,s=!0)}s&&(e.data.morphAttributes=i,e.data.morphTargetsRelative=this.morphTargetsRelative);let r=this.groups;r.length>0&&(e.data.groups=JSON.parse(JSON.stringify(r)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone(t));let i=e.attributes;for(let l in i){let d=i[l];this.setAttribute(l,d.clone(t))}let s=e.morphAttributes;for(let l in s){let d=[],h=s[l];for(let u=0,f=h.length;u<f;u++)d.push(h[u].clone(t));this.morphAttributes[l]=d}this.morphTargetsRelative=e.morphTargetsRelative;let r=e.groups;for(let l=0,d=r.length;l<d;l++){let h=r[l];this.addGroup(h.start,h.count,h.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let a=e.boundingSphere;return a!==null&&(this.boundingSphere=a.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},oo=new D,ct=new kt,Yn=new oe,ao=new _,Jn=new _,Kn=new _,Zn=new _,cs=new _,$n=new _,co=new _,jn=new _,ft=class extends G{constructor(e=new Qe,t=new De){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,r=i.length;s<r;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){let n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,r=n.morphTargetsRelative;t.fromBufferAttribute(i,e);let o=this.morphTargetInfluences;if(s&&o){$n.set(0,0,0);for(let a=0,l=s.length;a<l;a++){let d=o[a],h=s[a];d!==0&&(cs.fromBufferAttribute(h,e),r?$n.addScaledVector(cs,d):$n.addScaledVector(cs.sub(t),d))}t.add($n)}return t}raycast(e,t){let n=this.geometry,i=this.material,s=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Yn.copy(n.boundingSphere),Yn.applyMatrix4(s),ct.copy(e.ray).recast(e.near),!(Yn.containsPoint(ct.origin)===!1&&(ct.intersectSphere(Yn,ao)===null||ct.origin.distanceToSquared(ao)>(e.far-e.near)**2))&&(oo.copy(s).invert(),ct.copy(e.ray).applyMatrix4(oo),!(n.boundingBox!==null&&ct.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,ct)))}_computeIntersections(e,t,n){let i,s=this.geometry,r=this.material,o=s.index,a=s.attributes.position,l=s.attributes.uv,d=s.attributes.uv1,h=s.attributes.normal,u=s.groups,f=s.drawRange;if(o!==null)if(Array.isArray(r))for(let p=0,m=u.length;p<m;p++){let g=u[p],v=r[g.materialIndex],x=Math.max(g.start,f.start),y=Math.min(o.count,Math.min(g.start+g.count,f.start+f.count));for(let M=x,b=y;M<b;M+=3){let C=o.getX(M),A=o.getX(M+1),E=o.getX(M+2);i=Qn(this,v,e,n,l,d,h,C,A,E),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=g.materialIndex,t.push(i))}}else{let p=Math.max(0,f.start),m=Math.min(o.count,f.start+f.count);for(let g=p,v=m;g<v;g+=3){let x=o.getX(g),y=o.getX(g+1),M=o.getX(g+2);i=Qn(this,r,e,n,l,d,h,x,y,M),i&&(i.faceIndex=Math.floor(g/3),t.push(i))}}else if(a!==void 0)if(Array.isArray(r))for(let p=0,m=u.length;p<m;p++){let g=u[p],v=r[g.materialIndex],x=Math.max(g.start,f.start),y=Math.min(a.count,Math.min(g.start+g.count,f.start+f.count));for(let M=x,b=y;M<b;M+=3){let C=M,A=M+1,E=M+2;i=Qn(this,v,e,n,l,d,h,C,A,E),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=g.materialIndex,t.push(i))}}else{let p=Math.max(0,f.start),m=Math.min(a.count,f.start+f.count);for(let g=p,v=m;g<v;g+=3){let x=g,y=g+1,M=g+2;i=Qn(this,r,e,n,l,d,h,x,y,M),i&&(i.faceIndex=Math.floor(g/3),t.push(i))}}}};function yc(c,e,t,n,i,s,r,o){let a;if(e.side===Ba?a=n.intersectTriangle(r,s,i,!0,o):a=n.intersectTriangle(i,s,r,e.side===an,o),a===null)return null;jn.copy(o),jn.applyMatrix4(c.matrixWorld);let l=t.ray.origin.distanceTo(jn);return l<t.near||l>t.far?null:{distance:l,point:jn.clone(),object:c}}function Qn(c,e,t,n,i,s,r,o,a,l){c.getVertexPosition(o,Jn),c.getVertexPosition(a,Kn),c.getVertexPosition(l,Zn);let d=yc(c,e,t,n,Jn,Kn,Zn,co);if(d){let h=new _;ht.getBarycoord(co,Jn,Kn,Zn,h),i&&(d.uv=ht.getInterpolatedAttribute(i,o,a,l,h,new z)),s&&(d.uv1=ht.getInterpolatedAttribute(s,o,a,l,h,new z)),r&&(d.normal=ht.getInterpolatedAttribute(r,o,a,l,h,new _),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));let u={a:o,b:a,c:l,normal:new _,materialIndex:0};ht.getNormal(Jn,Kn,Zn,u.normal),d.face=u,d.barycoord=h}return d}function Mc(c){let e={};for(let t in c){e[t]={};for(let n in c[t]){let i=c[t][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=i.clone():Array.isArray(i)?e[t][n]=i.slice():e[t][n]=i}}return e}function ie(c){let e={};for(let t=0;t<c.length;t++){let n=Mc(c[t]);for(let i in n)e[i]=n[i]}return e}var di=class extends G{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new D,this.projectionMatrix=new D,this.projectionMatrixInverse=new D,this.coordinateSystem=ut}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Ze=new _,lo=new z,ho=new z,Ht=class extends di{constructor(e=50,t=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=ln*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(rn*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return ln*2*Math.atan(Math.tan(rn*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Ze.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Ze.x,Ze.y).multiplyScalar(-e/Ze.z),Ze.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Ze.x,Ze.y).multiplyScalar(-e/Ze.z)}getViewSize(e,t){return this.getViewBounds(e,lo,ho),t.subVectors(ho,lo)}setViewOffset(e,t,n,i,s,r){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(rn*.5*this.fov)/this.zoom,n=2*t,i=this.aspect*n,s=-.5*i,r=this.view;if(this.view!==null&&this.view.enabled){let a=r.fullWidth,l=r.fullHeight;s+=r.offsetX*i/a,t-=r.offsetY*n/l,i*=r.width/a,n*=r.height/l}let o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}};var ls=new _,Sc=new _,bc=new R,$e=class{constructor(e=new _(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,i){return this.normal.set(e,t,n),this.constant=i,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let i=ls.subVectors(n,t).cross(Sc.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(i,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let n=e.delta(ls),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let s=-(e.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:t.copy(e.start).addScaledVector(n,s)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||bc.getNormalMatrix(e),i=this.coplanarPoint(ls).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},lt=new oe,ei=new _,ws=class{constructor(e=new $e,t=new $e,n=new $e,i=new $e,s=new $e,r=new $e){this.planes=[e,t,n,i,s,r]}set(e,t,n,i,s,r){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(i),o[4].copy(s),o[5].copy(r),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ut){let n=this.planes,i=e.elements,s=i[0],r=i[1],o=i[2],a=i[3],l=i[4],d=i[5],h=i[6],u=i[7],f=i[8],p=i[9],m=i[10],g=i[11],v=i[12],x=i[13],y=i[14],M=i[15];if(n[0].setComponents(a-s,u-l,g-f,M-v).normalize(),n[1].setComponents(a+s,u+l,g+f,M+v).normalize(),n[2].setComponents(a+r,u+d,g+p,M+x).normalize(),n[3].setComponents(a-r,u-d,g-p,M-x).normalize(),n[4].setComponents(a-o,u-h,g-m,M-y).normalize(),t===ut)n[5].setComponents(a+o,u+h,g+m,M+y).normalize();else if(t===vs)n[5].setComponents(o,h,m,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),lt.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),lt.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(lt)}intersectsSprite(e){return lt.center.set(0,0,0),lt.radius=.7071067811865476,lt.applyMatrix4(e.matrixWorld),this.intersectsSphere(lt)}intersectsSphere(e){let t=this.planes,n=e.center,i=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let i=t[n];if(ei.x=i.normal.x>0?e.max.x:e.min.x,ei.y=i.normal.y>0?e.max.y:e.min.y,ei.z=i.normal.z>0?e.max.z:e.min.z,i.distanceToPoint(ei)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};var wc=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Tc=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Ac=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Ec=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Cc=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Rc=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ic=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Pc=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Lc=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Dc=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Nc=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Uc=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Fc=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Oc=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,kc=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Bc=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,zc=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Hc=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Vc=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Gc=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Wc=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Xc=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,qc=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Yc=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Jc=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Kc=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Zc=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,$c=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,jc=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Qc=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,el="gl_FragColor = linearToOutputTexel( gl_FragColor );",tl=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,nl=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,il=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,sl=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,rl=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,ol=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,al=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,cl=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,ll=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,dl=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,hl=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,ul=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,fl=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,pl=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,ml=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,gl=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,vl=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,_l=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,xl=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,yl=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Ml=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Sl=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,bl=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,wl=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Tl=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Al=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,El=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Cl=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Rl=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Il=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Pl=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Ll=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Dl=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Nl=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Ul=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Fl=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Ol=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,kl=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Bl=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,zl=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Hl=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Vl=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Gl=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Wl=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Xl=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,ql=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Yl=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Jl=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Kl=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Zl=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,$l=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,jl=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Ql=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,ed=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,td=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,nd=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,id=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,sd=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,rd=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,od=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,ad=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,cd=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,ld=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,dd=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,hd=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,ud=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,fd=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,pd=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,md=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,gd=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,vd=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,_d=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,xd=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,yd=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Md=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Sd=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,bd=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,wd=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Td=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ad=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ed=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Cd=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Rd=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Id=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Pd=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Ld=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Dd=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Nd=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ud=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Fd=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Od=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,kd=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Bd=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,zd=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Hd=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Vd=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Gd=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Wd=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Xd=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,qd=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Yd=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Jd=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Kd=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Zd=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$d=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,jd=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Qd=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,eh=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,th=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,nh=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,P={alphahash_fragment:wc,alphahash_pars_fragment:Tc,alphamap_fragment:Ac,alphamap_pars_fragment:Ec,alphatest_fragment:Cc,alphatest_pars_fragment:Rc,aomap_fragment:Ic,aomap_pars_fragment:Pc,batching_pars_vertex:Lc,batching_vertex:Dc,begin_vertex:Nc,beginnormal_vertex:Uc,bsdfs:Fc,iridescence_fragment:Oc,bumpmap_pars_fragment:kc,clipping_planes_fragment:Bc,clipping_planes_pars_fragment:zc,clipping_planes_pars_vertex:Hc,clipping_planes_vertex:Vc,color_fragment:Gc,color_pars_fragment:Wc,color_pars_vertex:Xc,color_vertex:qc,common:Yc,cube_uv_reflection_fragment:Jc,defaultnormal_vertex:Kc,displacementmap_pars_vertex:Zc,displacementmap_vertex:$c,emissivemap_fragment:jc,emissivemap_pars_fragment:Qc,colorspace_fragment:el,colorspace_pars_fragment:tl,envmap_fragment:nl,envmap_common_pars_fragment:il,envmap_pars_fragment:sl,envmap_pars_vertex:rl,envmap_physical_pars_fragment:gl,envmap_vertex:ol,fog_vertex:al,fog_pars_vertex:cl,fog_fragment:ll,fog_pars_fragment:dl,gradientmap_pars_fragment:hl,lightmap_pars_fragment:ul,lights_lambert_fragment:fl,lights_lambert_pars_fragment:pl,lights_pars_begin:ml,lights_toon_fragment:vl,lights_toon_pars_fragment:_l,lights_phong_fragment:xl,lights_phong_pars_fragment:yl,lights_physical_fragment:Ml,lights_physical_pars_fragment:Sl,lights_fragment_begin:bl,lights_fragment_maps:wl,lights_fragment_end:Tl,logdepthbuf_fragment:Al,logdepthbuf_pars_fragment:El,logdepthbuf_pars_vertex:Cl,logdepthbuf_vertex:Rl,map_fragment:Il,map_pars_fragment:Pl,map_particle_fragment:Ll,map_particle_pars_fragment:Dl,metalnessmap_fragment:Nl,metalnessmap_pars_fragment:Ul,morphinstance_vertex:Fl,morphcolor_vertex:Ol,morphnormal_vertex:kl,morphtarget_pars_vertex:Bl,morphtarget_vertex:zl,normal_fragment_begin:Hl,normal_fragment_maps:Vl,normal_pars_fragment:Gl,normal_pars_vertex:Wl,normal_vertex:Xl,normalmap_pars_fragment:ql,clearcoat_normal_fragment_begin:Yl,clearcoat_normal_fragment_maps:Jl,clearcoat_pars_fragment:Kl,iridescence_pars_fragment:Zl,opaque_fragment:$l,packing:jl,premultiplied_alpha_fragment:Ql,project_vertex:ed,dithering_fragment:td,dithering_pars_fragment:nd,roughnessmap_fragment:id,roughnessmap_pars_fragment:sd,shadowmap_pars_fragment:rd,shadowmap_pars_vertex:od,shadowmap_vertex:ad,shadowmask_pars_fragment:cd,skinbase_vertex:ld,skinning_pars_vertex:dd,skinning_vertex:hd,skinnormal_vertex:ud,specularmap_fragment:fd,specularmap_pars_fragment:pd,tonemapping_fragment:md,tonemapping_pars_fragment:gd,transmission_fragment:vd,transmission_pars_fragment:_d,uv_pars_fragment:xd,uv_pars_vertex:yd,uv_vertex:Md,worldpos_vertex:Sd,background_vert:bd,background_frag:wd,backgroundCube_vert:Td,backgroundCube_frag:Ad,cube_vert:Ed,cube_frag:Cd,depth_vert:Rd,depth_frag:Id,distanceRGBA_vert:Pd,distanceRGBA_frag:Ld,equirect_vert:Dd,equirect_frag:Nd,linedashed_vert:Ud,linedashed_frag:Fd,meshbasic_vert:Od,meshbasic_frag:kd,meshlambert_vert:Bd,meshlambert_frag:zd,meshmatcap_vert:Hd,meshmatcap_frag:Vd,meshnormal_vert:Gd,meshnormal_frag:Wd,meshphong_vert:Xd,meshphong_frag:qd,meshphysical_vert:Yd,meshphysical_frag:Jd,meshtoon_vert:Kd,meshtoon_frag:Zd,points_vert:$d,points_frag:jd,shadow_vert:Qd,shadow_frag:eh,sprite_vert:th,sprite_frag:nh},w={common:{diffuse:{value:new L(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new R},alphaMap:{value:null},alphaMapTransform:{value:new R},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new R}},envmap:{envMap:{value:null},envMapRotation:{value:new R},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new R}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new R}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new R},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new R},normalScale:{value:new z(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new R},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new R}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new R}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new R}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new L(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new L(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new R},alphaTest:{value:0},uvTransform:{value:new R}},sprite:{diffuse:{value:new L(16777215)},opacity:{value:1},center:{value:new z(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new R},alphaMap:{value:null},alphaMapTransform:{value:new R},alphaTest:{value:0}}},uo={basic:{uniforms:ie([w.common,w.specularmap,w.envmap,w.aomap,w.lightmap,w.fog]),vertexShader:P.meshbasic_vert,fragmentShader:P.meshbasic_frag},lambert:{uniforms:ie([w.common,w.specularmap,w.envmap,w.aomap,w.lightmap,w.emissivemap,w.bumpmap,w.normalmap,w.displacementmap,w.fog,w.lights,{emissive:{value:new L(0)}}]),vertexShader:P.meshlambert_vert,fragmentShader:P.meshlambert_frag},phong:{uniforms:ie([w.common,w.specularmap,w.envmap,w.aomap,w.lightmap,w.emissivemap,w.bumpmap,w.normalmap,w.displacementmap,w.fog,w.lights,{emissive:{value:new L(0)},specular:{value:new L(1118481)},shininess:{value:30}}]),vertexShader:P.meshphong_vert,fragmentShader:P.meshphong_frag},standard:{uniforms:ie([w.common,w.envmap,w.aomap,w.lightmap,w.emissivemap,w.bumpmap,w.normalmap,w.displacementmap,w.roughnessmap,w.metalnessmap,w.fog,w.lights,{emissive:{value:new L(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:P.meshphysical_vert,fragmentShader:P.meshphysical_frag},toon:{uniforms:ie([w.common,w.aomap,w.lightmap,w.emissivemap,w.bumpmap,w.normalmap,w.displacementmap,w.gradientmap,w.fog,w.lights,{emissive:{value:new L(0)}}]),vertexShader:P.meshtoon_vert,fragmentShader:P.meshtoon_frag},matcap:{uniforms:ie([w.common,w.bumpmap,w.normalmap,w.displacementmap,w.fog,{matcap:{value:null}}]),vertexShader:P.meshmatcap_vert,fragmentShader:P.meshmatcap_frag},points:{uniforms:ie([w.points,w.fog]),vertexShader:P.points_vert,fragmentShader:P.points_frag},dashed:{uniforms:ie([w.common,w.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:P.linedashed_vert,fragmentShader:P.linedashed_frag},depth:{uniforms:ie([w.common,w.displacementmap]),vertexShader:P.depth_vert,fragmentShader:P.depth_frag},normal:{uniforms:ie([w.common,w.bumpmap,w.normalmap,w.displacementmap,{opacity:{value:1}}]),vertexShader:P.meshnormal_vert,fragmentShader:P.meshnormal_frag},sprite:{uniforms:ie([w.sprite,w.fog]),vertexShader:P.sprite_vert,fragmentShader:P.sprite_frag},background:{uniforms:{uvTransform:{value:new R},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:P.background_vert,fragmentShader:P.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new R}},vertexShader:P.backgroundCube_vert,fragmentShader:P.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:P.cube_vert,fragmentShader:P.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:P.equirect_vert,fragmentShader:P.equirect_frag},distanceRGBA:{uniforms:ie([w.common,w.displacementmap,{referencePosition:{value:new _},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:P.distanceRGBA_vert,fragmentShader:P.distanceRGBA_frag},shadow:{uniforms:ie([w.lights,w.fog,{color:{value:new L(0)},opacity:{value:1}}]),vertexShader:P.shadow_vert,fragmentShader:P.shadow_frag}};uo.physical={uniforms:ie([uo.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new R},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new R},clearcoatNormalScale:{value:new z(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new R},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new R},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new R},sheen:{value:0},sheenColor:{value:new L(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new R},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new R},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new R},transmissionSamplerSize:{value:new z},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new R},attenuationDistance:{value:0},attenuationColor:{value:new L(0)},specularColor:{value:new L(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new R},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new R},anisotropyVector:{value:new z},anisotropyMap:{value:null},anisotropyMapTransform:{value:new R}}]),vertexShader:P.meshphysical_vert,fragmentShader:P.meshphysical_frag};var dn=class extends di{constructor(e=-1,t=1,n=1,i=-1,s=.1,r=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=i,this.near=s,this.far=r,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,i,s,r){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=r,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,s=n-e,r=n+e,o=i+t,a=i-t;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,r=s+l*this.view.width,o-=d*this.view.offsetY,a=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,r,o,a,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}};var dt=(1+Math.sqrt(5))/2,It=1/dt,ru=[new _(-dt,It,0),new _(dt,It,0),new _(-It,0,dt),new _(It,0,dt),new _(0,dt,-It),new _(0,dt,It),new _(-1,1,-1),new _(1,1,-1),new _(-1,1,1),new _(1,1,1)];var ou=new Float32Array(16),au=new Float32Array(9),cu=new Float32Array(4);var lu={[Dr]:Nr,[Ur]:kr,[Fr]:Br,[ci]:Or,[Nr]:Dr,[kr]:Ur,[Br]:Fr,[Or]:ci};var Vt=class extends G{constructor(){super(),this.isGroup=!0,this.type="Group"}};var hn=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=gs,this.updateRanges=[],this.version=0,this.uuid=ye()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let i=0,s=this.stride;i<s;i++)this.array[e+i]=t.array[n+i];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ye()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ye()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},Q=new _,un=class c{constructor(e,t,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)Q.fromBufferAttribute(this,t),Q.applyMatrix4(e),this.setXYZ(t,Q.x,Q.y,Q.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Q.fromBufferAttribute(this,t),Q.applyNormalMatrix(e),this.setXYZ(t,Q.x,Q.y,Q.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Q.fromBufferAttribute(this,t),Q.transformDirection(e),this.setXYZ(t,Q.x,Q.y,Q.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=xe(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=F(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=F(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=F(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=F(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=F(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=xe(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=xe(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=xe(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=xe(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=F(t,this.array),n=F(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=F(t,this.array),n=F(n,this.array),i=F(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=F(t,this.array),n=F(n,this.array),i=F(i,this.array),s=F(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return new ne(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new c(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}};var fo=new _,po=new te,mo=new te,ih=new _,go=new D,ti=new _,ds=new oe,vo=new D,hs=new kt,hi=class extends ft{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=zr,this.bindMatrix=new D,this.bindMatrixInverse=new D,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;this.boundingBox===null&&(this.boundingBox=new he),this.boundingBox.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,ti),this.boundingBox.expandByPoint(ti)}computeBoundingSphere(){let e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new oe),this.boundingSphere.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,ti),this.boundingSphere.expandByPoint(ti)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){let n=this.material,i=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ds.copy(this.boundingSphere),ds.applyMatrix4(i),e.ray.intersectsSphere(ds)!==!1&&(vo.copy(i).invert(),hs.copy(e.ray).applyMatrix4(vo),!(this.boundingBox!==null&&hs.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,hs)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new te,t=this.geometry.attributes.skinWeight;for(let n=0,i=t.count;n<i;n++){e.fromBufferAttribute(t,n);let s=1/e.manhattanLength();s!==1/0?e.multiplyScalar(s):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===zr?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===Ha?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){let n=this.skeleton,i=this.geometry;po.fromBufferAttribute(i.attributes.skinIndex,e),mo.fromBufferAttribute(i.attributes.skinWeight,e),fo.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let s=0;s<4;s++){let r=mo.getComponent(s);if(r!==0){let o=po.getComponent(s);go.multiplyMatrices(n.bones[o].matrixWorld,n.boneInverses[o]),t.addScaledVector(ih.copy(fo).applyMatrix4(go),r)}}return t.applyMatrix4(this.bindMatrixInverse)}},fn=class extends G{constructor(){super(),this.isBone=!0,this.type="Bone"}},ui=class extends we{constructor(e=null,t=1,n=1,i,s,r,o,a,l=cn,d=cn,h,u){super(null,r,o,a,l,d,i,s,h,u),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},_o=new D,sh=new D,fi=class c{constructor(e=[],t=[]){this.uuid=ye(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){let e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,i=this.bones.length;n<i;n++)this.boneInverses.push(new D)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){let n=new D;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){let e=this.bones,t=this.boneInverses,n=this.boneMatrices,i=this.boneTexture;for(let s=0,r=e.length;s<r;s++){let o=e[s]?e[s].matrixWorld:sh;_o.multiplyMatrices(o,t[s]),_o.toArray(n,s*16)}i!==null&&(i.needsUpdate=!0)}clone(){return new c(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4);t.set(this.boneMatrices);let n=new ui(t,e,e,Fo,Os);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){let i=this.bones[t];if(i.name===e)return i}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,i=e.bones.length;n<i;n++){let s=e.bones[n],r=t[s];r===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",s),r=new fn),this.bones.push(r),this.boneInverses.push(new D().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){let e={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;let t=this.bones,n=this.boneInverses;for(let i=0,s=t.length;i<s;i++){let r=t[i];e.bones.push(r.uuid);let o=n[i];e.boneInverses.push(o.toArray())}return e}},pt=class extends ne{constructor(e,t,n,i=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Pt=new D,xo=new D,ni=[],yo=new he,rh=new D,en=new ft,tn=new oe,pi=class extends ft{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new pt(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,rh)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new he),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Pt),yo.copy(e.boundingBox).applyMatrix4(Pt),this.boundingBox.union(yo)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new oe),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,Pt),tn.copy(e.boundingSphere).applyMatrix4(Pt),this.boundingSphere.union(tn)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,i=this.morphTexture.source.data.data,s=n.length+1,r=e*s+1;for(let o=0;o<n.length;o++)n[o]=i[r+o]}raycast(e,t){let n=this.matrixWorld,i=this.count;if(en.geometry=this.geometry,en.material=this.material,en.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),tn.copy(this.boundingSphere),tn.applyMatrix4(n),e.ray.intersectsSphere(tn)!==!1))for(let s=0;s<i;s++){this.getMatrixAt(s,Pt),xo.multiplyMatrices(n,Pt),en.matrixWorld=xo,en.raycast(e,ni);for(let r=0,o=ni.length;r<o;r++){let a=ni[r];a.instanceId=s,a.object=this,t.push(a)}ni.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new pt(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){let n=t.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new ui(new Float32Array(i*this.count),i,this.count,Ga,Os));let s=this.morphTexture.source.data.data,r=0;for(let l=0;l<n.length;l++)r+=n[l];let o=this.geometry.morphTargetsRelative?1:1-r,a=i*e;s[a]=o,s.set(n,a+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var pn=class extends Te{static get type(){return"LineBasicMaterial"}constructor(e){super(),this.isLineBasicMaterial=!0,this.color=new L(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},mi=new _,gi=new _,Mo=new D,nn=new kt,ii=new oe,us=new _,So=new _,Gt=class extends G{constructor(e=new Qe,t=new pn){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let i=1,s=t.count;i<s;i++)mi.fromBufferAttribute(t,i-1),gi.fromBufferAttribute(t,i),n[i]=n[i-1],n[i]+=mi.distanceTo(gi);e.setAttribute("lineDistance",new zt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let n=this.geometry,i=this.matrixWorld,s=e.params.Line.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ii.copy(n.boundingSphere),ii.applyMatrix4(i),ii.radius+=s,e.ray.intersectsSphere(ii)===!1)return;Mo.copy(i).invert(),nn.copy(e.ray).applyMatrix4(Mo);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),a=o*o,l=this.isLineSegments?2:1,d=n.index,u=n.attributes.position;if(d!==null){let f=Math.max(0,r.start),p=Math.min(d.count,r.start+r.count);for(let m=f,g=p-1;m<g;m+=l){let v=d.getX(m),x=d.getX(m+1),y=si(this,e,nn,a,v,x);y&&t.push(y)}if(this.isLineLoop){let m=d.getX(p-1),g=d.getX(f),v=si(this,e,nn,a,m,g);v&&t.push(v)}}else{let f=Math.max(0,r.start),p=Math.min(u.count,r.start+r.count);for(let m=f,g=p-1;m<g;m+=l){let v=si(this,e,nn,a,m,m+1);v&&t.push(v)}if(this.isLineLoop){let m=si(this,e,nn,a,p-1,f);m&&t.push(m)}}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,r=i.length;s<r;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}};function si(c,e,t,n,i,s){let r=c.geometry.attributes.position;if(mi.fromBufferAttribute(r,i),gi.fromBufferAttribute(r,s),t.distanceSqToSegment(mi,gi,us,So)>n)return;us.applyMatrix4(c.matrixWorld);let a=e.ray.origin.distanceTo(us);if(!(a<e.near||a>e.far))return{distance:a,point:So.clone().applyMatrix4(c.matrixWorld),index:i,face:null,faceIndex:null,barycoord:null,object:c}}var bo=new _,wo=new _,vi=class extends Gt{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let i=0,s=t.count;i<s;i+=2)bo.fromBufferAttribute(t,i),wo.fromBufferAttribute(t,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+bo.distanceTo(wo);e.setAttribute("lineDistance",new zt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}},_i=class extends Gt{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}},mn=class extends Te{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new L(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},To=new D,Ts=new kt,ri=new oe,oi=new _,xi=class extends G{constructor(e=new Qe,t=new mn){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let n=this.geometry,i=this.matrixWorld,s=e.params.Points.threshold,r=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ri.copy(n.boundingSphere),ri.applyMatrix4(i),ri.radius+=s,e.ray.intersectsSphere(ri)===!1)return;To.copy(i).invert(),Ts.copy(e.ray).applyMatrix4(To);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),a=o*o,l=n.index,h=n.attributes.position;if(l!==null){let u=Math.max(0,r.start),f=Math.min(l.count,r.start+r.count);for(let p=u,m=f;p<m;p++){let g=l.getX(p);oi.fromBufferAttribute(h,g),Ao(oi,g,a,i,e,t,this)}}else{let u=Math.max(0,r.start),f=Math.min(h.count,r.start+r.count);for(let p=u,m=f;p<m;p++)oi.fromBufferAttribute(h,p),Ao(oi,p,a,i,e,t,this)}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,r=i.length;s<r;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}};function Ao(c,e,t,n,i,s,r){let o=Ts.distanceSqToPoint(c);if(o<t){let a=new _;Ts.closestPointToPoint(c,a),a.applyMatrix4(n);let l=i.ray.origin.distanceTo(a);if(l<i.near||l>i.far)return;s.push({distance:l,distanceToRay:Math.sqrt(o),point:a,index:e,face:null,faceIndex:null,barycoord:null,object:r})}}var Wt=class extends Te{static get type(){return"MeshStandardMaterial"}constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new L(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new L(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Xa,this.normalScale=new z(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Bt,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},ae=class extends Wt{static get type(){return"MeshPhysicalMaterial"}constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new z(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return $(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new L(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new L(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new L(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}};function ai(c,e,t){return!c||!t&&c.constructor===e?c:typeof e.BYTES_PER_ELEMENT=="number"?new e(c):Array.prototype.slice.call(c)}function oh(c){return ArrayBuffer.isView(c)&&!(c instanceof DataView)}function ah(c){function e(i,s){return c[i]-c[s]}let t=c.length,n=new Array(t);for(let i=0;i!==t;++i)n[i]=i;return n.sort(e),n}function Eo(c,e,t){let n=c.length,i=new c.constructor(n);for(let s=0,r=0;r!==n;++s){let o=t[s]*e;for(let a=0;a!==e;++a)i[r++]=c[o+a]}return i}function Vo(c,e,t,n){let i=1,s=c[0];for(;s!==void 0&&s[n]===void 0;)s=c[i++];if(s===void 0)return;let r=s[n];if(r!==void 0)if(Array.isArray(r))do r=s[n],r!==void 0&&(e.push(s.time),t.push.apply(t,r)),s=c[i++];while(s!==void 0);else if(r.toArray!==void 0)do r=s[n],r!==void 0&&(e.push(s.time),r.toArray(t,t.length)),s=c[i++];while(s!==void 0);else do r=s[n],r!==void 0&&(e.push(s.time),t.push(r)),s=c[i++];while(s!==void 0)}var et=class{constructor(e,t,n,i){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,i=t[n],s=t[n-1];n:{e:{let r;t:{i:if(!(e<i)){for(let o=n+2;;){if(i===void 0){if(e<s)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(s=i,i=t[++n],e<i)break e}r=t.length;break t}if(!(e>=s)){let o=t[1];e<o&&(n=2,s=o);for(let a=n-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(i=s,s=t[--n-1],e>=s)break e}r=n,n=0;break t}break n}for(;n<r;){let o=n+r>>>1;e<t[o]?r=o:n=o+1}if(i=t[n],s=t[n-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,s,i)}return this.interpolate_(n,s,e,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,i=this.valueSize,s=e*i;for(let r=0;r!==i;++r)t[r]=n[s+r];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},As=class extends et{constructor(e,t,n,i){super(e,t,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Hr,endingEnd:Hr}}intervalChanged_(e,t,n){let i=this.parameterPositions,s=e-2,r=e+1,o=i[s],a=i[r];if(o===void 0)switch(this.getSettings_().endingStart){case Vr:s=e,o=2*t-n;break;case Gr:s=i.length-2,o=t+i[s]-i[s+1];break;default:s=e,o=n}if(a===void 0)switch(this.getSettings_().endingEnd){case Vr:r=e,a=2*n-t;break;case Gr:r=1,a=n+i[1]-i[0];break;default:r=e-1,a=t}let l=(n-t)*.5,d=this.valueSize;this._weightPrev=l/(t-o),this._weightNext=l/(a-n),this._offsetPrev=s*d,this._offsetNext=r*d}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=e*o,l=a-o,d=this._offsetPrev,h=this._offsetNext,u=this._weightPrev,f=this._weightNext,p=(n-t)/(i-t),m=p*p,g=m*p,v=-u*g+2*u*m-u*p,x=(1+u)*g+(-1.5-2*u)*m+(-.5+u)*p+1,y=(-1-f)*g+(1.5+f)*m+.5*p,M=f*g-f*m;for(let b=0;b!==o;++b)s[b]=v*r[d+b]+x*r[l+b]+y*r[a+b]+M*r[h+b];return s}},Es=class extends et{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=e*o,l=a-o,d=(n-t)/(i-t),h=1-d;for(let u=0;u!==o;++u)s[u]=r[l+u]*h+r[a+u]*d;return s}},Cs=class extends et{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e){return this.copySampleValue_(e-1)}},ue=class{constructor(e,t,n,i){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=ai(t,this.TimeBufferType),this.values=ai(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:ai(e.times,Array),values:ai(e.values,Array)};let i=e.getInterpolation();i!==e.DefaultInterpolation&&(n.interpolation=i)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Cs(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Es(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new As(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Ut:t=this.InterpolantFactoryMethodDiscrete;break;case Ft:t=this.InterpolantFactoryMethodLinear;break;case Gi:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Ut;case this.InterpolantFactoryMethodLinear:return Ft;case this.InterpolantFactoryMethodSmooth:return Gi}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]*=e}return this}trim(e,t){let n=this.times,i=n.length,s=0,r=i-1;for(;s!==i&&n[s]<e;)++s;for(;r!==-1&&n[r]>t;)--r;if(++r,s!==0||r!==i){s>=r&&(r=Math.max(r,1),s=r-1);let o=this.getValueSize();this.times=n.slice(s,r),this.values=this.values.slice(s*o,r*o)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let n=this.times,i=this.values,s=n.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let r=null;for(let o=0;o!==s;o++){let a=n[o];if(typeof a=="number"&&isNaN(a)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,a),e=!1;break}if(r!==null&&r>a){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,a,r),e=!1;break}r=a}if(i!==void 0&&oh(i))for(let o=0,a=i.length;o!==a;++o){let l=i[o];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,l),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===Gi,s=e.length-1,r=1;for(let o=1;o<s;++o){let a=!1,l=e[o],d=e[o+1];if(l!==d&&(o!==1||l!==e[0]))if(i)a=!0;else{let h=o*n,u=h-n,f=h+n;for(let p=0;p!==n;++p){let m=t[h+p];if(m!==t[u+p]||m!==t[f+p]){a=!0;break}}}if(a){if(o!==r){e[r]=e[o];let h=o*n,u=r*n;for(let f=0;f!==n;++f)t[u+f]=t[h+f]}++r}}if(s>0){e[r]=e[s];for(let o=s*n,a=r*n,l=0;l!==n;++l)t[a+l]=t[o+l];++r}return r!==e.length?(this.times=e.slice(0,r),this.values=t.slice(0,r*n)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,i=new n(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}};ue.prototype.TimeBufferType=Float32Array;ue.prototype.ValueBufferType=Float32Array;ue.prototype.DefaultInterpolation=Ft;var tt=class extends ue{constructor(e,t,n){super(e,t,n)}};tt.prototype.ValueTypeName="bool";tt.prototype.ValueBufferType=Array;tt.prototype.DefaultInterpolation=Ut;tt.prototype.InterpolantFactoryMethodLinear=void 0;tt.prototype.InterpolantFactoryMethodSmooth=void 0;var yi=class extends ue{};yi.prototype.ValueTypeName="color";var Ne=class extends ue{};Ne.prototype.ValueTypeName="number";var Rs=class extends et{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=(n-t)/(i-t),l=e*o;for(let d=l+o;l!==d;l+=4)Me.slerpFlat(s,0,r,l-o,r,l,a);return s}},Ue=class extends ue{InterpolantFactoryMethodLinear(e){return new Rs(this.times,this.values,this.getValueSize(),e)}};Ue.prototype.ValueTypeName="quaternion";Ue.prototype.InterpolantFactoryMethodSmooth=void 0;var nt=class extends ue{constructor(e,t,n){super(e,t,n)}};nt.prototype.ValueTypeName="string";nt.prototype.ValueBufferType=Array;nt.prototype.DefaultInterpolation=Ut;nt.prototype.InterpolantFactoryMethodLinear=void 0;nt.prototype.InterpolantFactoryMethodSmooth=void 0;var Fe=class extends ue{};Fe.prototype.ValueTypeName="vector";var Mi=class{constructor(e="",t=-1,n=[],i=Wa){this.name=e,this.tracks=n,this.duration=t,this.blendMode=i,this.uuid=ye(),this.duration<0&&this.resetDuration()}static parse(e){let t=[],n=e.tracks,i=1/(e.fps||1);for(let r=0,o=n.length;r!==o;++r)t.push(lh(n[r]).scale(i));let s=new this(e.name,e.duration,t,e.blendMode);return s.uuid=e.uuid,s}static toJSON(e){let t=[],n=e.tracks,i={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let s=0,r=n.length;s!==r;++s)t.push(ue.toJSON(n[s]));return i}static CreateFromMorphTargetSequence(e,t,n,i){let s=t.length,r=[];for(let o=0;o<s;o++){let a=[],l=[];a.push((o+s-1)%s,o,(o+1)%s),l.push(0,1,0);let d=ah(a);a=Eo(a,1,d),l=Eo(l,1,d),!i&&a[0]===0&&(a.push(s),l.push(l[0])),r.push(new Ne(".morphTargetInfluences["+t[o].name+"]",a,l).scale(1/n))}return new this(e,-1,r)}static findByName(e,t){let n=e;if(!Array.isArray(e)){let i=e;n=i.geometry&&i.geometry.animations||i.animations}for(let i=0;i<n.length;i++)if(n[i].name===t)return n[i];return null}static CreateClipsFromMorphTargetSequences(e,t,n){let i={},s=/^([\w-]*?)([\d]+)$/;for(let o=0,a=e.length;o<a;o++){let l=e[o],d=l.name.match(s);if(d&&d.length>1){let h=d[1],u=i[h];u||(i[h]=u=[]),u.push(l)}}let r=[];for(let o in i)r.push(this.CreateFromMorphTargetSequence(o,i[o],t,n));return r}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;let n=function(h,u,f,p,m){if(f.length!==0){let g=[],v=[];Vo(f,g,v,p),g.length!==0&&m.push(new h(u,g,v))}},i=[],s=e.name||"default",r=e.fps||30,o=e.blendMode,a=e.length||-1,l=e.hierarchy||[];for(let h=0;h<l.length;h++){let u=l[h].keys;if(!(!u||u.length===0))if(u[0].morphTargets){let f={},p;for(p=0;p<u.length;p++)if(u[p].morphTargets)for(let m=0;m<u[p].morphTargets.length;m++)f[u[p].morphTargets[m]]=-1;for(let m in f){let g=[],v=[];for(let x=0;x!==u[p].morphTargets.length;++x){let y=u[p];g.push(y.time),v.push(y.morphTarget===m?1:0)}i.push(new Ne(".morphTargetInfluence["+m+"]",g,v))}a=f.length*r}else{let f=".bones["+t[h].name+"]";n(Fe,f+".position",u,"pos",i),n(Ue,f+".quaternion",u,"rot",i),n(Fe,f+".scale",u,"scl",i)}}return i.length===0?null:new this(s,a,i,o)}resetDuration(){let e=this.tracks,t=0;for(let n=0,i=e.length;n!==i;++n){let s=this.tracks[n];t=Math.max(t,s.times[s.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}};function ch(c){switch(c.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Ne;case"vector":case"vector2":case"vector3":case"vector4":return Fe;case"color":return yi;case"quaternion":return Ue;case"bool":case"boolean":return tt;case"string":return nt}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+c)}function lh(c){if(c.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");let e=ch(c.type);if(c.times===void 0){let t=[],n=[];Vo(c.keys,t,n,"value"),c.times=t,c.values=n}return e.parse!==void 0?e.parse(c):new e(c.name,c.times,c.values,c.interpolation)}var je={enabled:!1,files:{},add:function(c,e){this.enabled!==!1&&(this.files[c]=e)},get:function(c){if(this.enabled!==!1)return this.files[c]},remove:function(c){delete this.files[c]},clear:function(){this.files={}}},Is=class{constructor(e,t,n){let i=this,s=!1,r=0,o=0,a,l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(d){o++,s===!1&&i.onStart!==void 0&&i.onStart(d,r,o),s=!0},this.itemEnd=function(d){r++,i.onProgress!==void 0&&i.onProgress(d,r,o),r===o&&(s=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(d){i.onError!==void 0&&i.onError(d)},this.resolveURL=function(d){return a?a(d):d},this.setURLModifier=function(d){return a=d,this},this.addHandler=function(d,h){return l.push(d,h),this},this.removeHandler=function(d){let h=l.indexOf(d);return h!==-1&&l.splice(h,2),this},this.getHandler=function(d){for(let h=0,u=l.length;h<u;h+=2){let f=l[h],p=l[h+1];if(f.global&&(f.lastIndex=0),f.test(d))return p}return null}}},dh=new Is,Oe=class{constructor(e){this.manager=e!==void 0?e:dh,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let n=this;return new Promise(function(i,s){n.load(e,i,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};Oe.DEFAULT_MATERIAL_NAME="__DEFAULT";var Pe={},Ps=class extends Error{constructor(e,t){super(e),this.response=t}},gn=class extends Oe{constructor(e){super(e)}load(e,t,n,i){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let s=je.get(e);if(s!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(s),this.manager.itemEnd(e)},0),s;if(Pe[e]!==void 0){Pe[e].push({onLoad:t,onProgress:n,onError:i});return}Pe[e]=[],Pe[e].push({onLoad:t,onProgress:n,onError:i});let r=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),o=this.mimeType,a=this.responseType;fetch(r).then(l=>{if(l.status===200||l.status===0){if(l.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||l.body===void 0||l.body.getReader===void 0)return l;let d=Pe[e],h=l.body.getReader(),u=l.headers.get("X-File-Size")||l.headers.get("Content-Length"),f=u?parseInt(u):0,p=f!==0,m=0,g=new ReadableStream({start(v){x();function x(){h.read().then(({done:y,value:M})=>{if(y)v.close();else{m+=M.byteLength;let b=new ProgressEvent("progress",{lengthComputable:p,loaded:m,total:f});for(let C=0,A=d.length;C<A;C++){let E=d[C];E.onProgress&&E.onProgress(b)}v.enqueue(M),x()}},y=>{v.error(y)})}}});return new Response(g)}else throw new Ps(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`,l)}).then(l=>{switch(a){case"arraybuffer":return l.arrayBuffer();case"blob":return l.blob();case"document":return l.text().then(d=>new DOMParser().parseFromString(d,o));case"json":return l.json();default:if(o===void 0)return l.text();{let h=/charset="?([^;"\s]*)"?/i.exec(o),u=h&&h[1]?h[1].toLowerCase():void 0,f=new TextDecoder(u);return l.arrayBuffer().then(p=>f.decode(p))}}}).then(l=>{je.add(e,l);let d=Pe[e];delete Pe[e];for(let h=0,u=d.length;h<u;h++){let f=d[h];f.onLoad&&f.onLoad(l)}}).catch(l=>{let d=Pe[e];if(d===void 0)throw this.manager.itemError(e),l;delete Pe[e];for(let h=0,u=d.length;h<u;h++){let f=d[h];f.onError&&f.onError(l)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}};var Ls=class extends Oe{constructor(e){super(e)}load(e,t,n,i){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let s=this,r=je.get(e);if(r!==void 0)return s.manager.itemStart(e),setTimeout(function(){t&&t(r),s.manager.itemEnd(e)},0),r;let o=_s("img");function a(){d(),je.add(e,this),t&&t(this),s.manager.itemEnd(e)}function l(h){d(),i&&i(h),s.manager.itemError(e),s.manager.itemEnd(e)}function d(){o.removeEventListener("load",a,!1),o.removeEventListener("error",l,!1)}return o.addEventListener("load",a,!1),o.addEventListener("error",l,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(o.crossOrigin=this.crossOrigin),s.manager.itemStart(e),o.src=e,o}};var Si=class extends Oe{constructor(e){super(e)}load(e,t,n,i){let s=new we,r=new Ls(this.manager);return r.setCrossOrigin(this.crossOrigin),r.setPath(this.path),r.load(e,function(o){s.image=o,s.needsUpdate=!0,t!==void 0&&t(s)},n,i),s}},vn=class extends G{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new L(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}};var fs=new D,Co=new _,Ro=new _,_n=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new z(512,512),this.map=null,this.mapPass=null,this.matrix=new D,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new ws,this._frameExtents=new z(1,1),this._viewportCount=1,this._viewports=[new te(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,n=this.matrix;Co.setFromMatrixPosition(e.matrixWorld),t.position.copy(Co),Ro.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Ro),t.updateMatrixWorld(),fs.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(fs),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(fs)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},Ds=class extends _n{constructor(){super(new Ht(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,n=ln*2*e.angle*this.focus,i=this.mapSize.width/this.mapSize.height,s=e.distance||t.far;(n!==t.fov||i!==t.aspect||s!==t.far)&&(t.fov=n,t.aspect=i,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},bi=class extends vn{constructor(e,t,n=0,i=Math.PI/3,s=0,r=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(G.DEFAULT_UP),this.updateMatrix(),this.target=new G,this.distance=n,this.angle=i,this.penumbra=s,this.decay=r,this.map=null,this.shadow=new Ds}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},Io=new D,sn=new _,ps=new _,Ns=class extends _n{constructor(){super(new Ht(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new z(4,2),this._viewportCount=6,this._viewports=[new te(2,1,1,1),new te(0,1,1,1),new te(3,1,1,1),new te(1,1,1,1),new te(3,0,1,1),new te(1,0,1,1)],this._cubeDirections=[new _(1,0,0),new _(-1,0,0),new _(0,0,1),new _(0,0,-1),new _(0,1,0),new _(0,-1,0)],this._cubeUps=[new _(0,1,0),new _(0,1,0),new _(0,1,0),new _(0,1,0),new _(0,0,1),new _(0,0,-1)]}updateMatrices(e,t=0){let n=this.camera,i=this.matrix,s=e.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),sn.setFromMatrixPosition(e.matrixWorld),n.position.copy(sn),ps.copy(n.position),ps.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(ps),n.updateMatrixWorld(),i.makeTranslation(-sn.x,-sn.y,-sn.z),Io.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Io)}},wi=class extends vn{constructor(e,t,n=0,i=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new Ns}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},Us=class extends _n{constructor(){super(new dn(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Ti=class extends vn{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(G.DEFAULT_UP),this.updateMatrix(),this.target=new G,this.shadow=new Us}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var it=class{static decodeText(e){if(console.warn("THREE.LoaderUtils: decodeText() has been deprecated with r165 and will be removed with r175. Use TextDecoder instead."),typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let n=0,i=e.length;n<i;n++)t+=String.fromCharCode(e[n]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){let t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}};var Ai=class extends Oe{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"}}setOptions(e){return this.options=e,this}load(e,t,n,i){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let s=this,r=je.get(e);if(r!==void 0){if(s.manager.itemStart(e),r.then){r.then(l=>{t&&t(l),s.manager.itemEnd(e)}).catch(l=>{i&&i(l)});return}return setTimeout(function(){t&&t(r),s.manager.itemEnd(e)},0),r}let o={};o.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",o.headers=this.requestHeader;let a=fetch(e,o).then(function(l){return l.blob()}).then(function(l){return createImageBitmap(l,Object.assign(s.options,{colorSpaceConversion:"none"}))}).then(function(l){return je.add(e,l),t&&t(l),s.manager.itemEnd(e),l}).catch(function(l){i&&i(l),je.remove(e),s.manager.itemError(e),s.manager.itemEnd(e)});je.add(e,a),s.manager.itemStart(e)}};var Bs="\\[\\]\\.:\\/",hh=new RegExp("["+Bs+"]","g"),zs="[^"+Bs+"]",uh="[^"+Bs.replace("\\.","")+"]",fh=/((?:WC+[\/:])*)/.source.replace("WC",zs),ph=/(WCOD+)?/.source.replace("WCOD",uh),mh=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",zs),gh=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",zs),vh=new RegExp("^"+fh+ph+mh+gh+"$"),_h=["material","materials","bones","map"],Fs=class{constructor(e,t,n){let i=n||B.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,i)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,s=n.length;i!==s;++i)n[i].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},B=class c{constructor(e,t,n){this.path=t,this.parsedPath=n||c.parseTrackName(t),this.node=c.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new c.Composite(e,t,n):new c(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(hh,"")}static parseTrackName(e){let t=vh.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let s=n.nodeName.substring(i+1);_h.indexOf(s)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=s)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(s){for(let r=0;r<s.length;r++){let o=s[r];if(o.name===t||o.uuid===t)return o;let a=n(o.children);if(a)return a}return null},i=n(e.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)e[t++]=n[i]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,n=t.objectName,i=t.propertyName,s=t.propertyIndex;if(e||(e=c.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let l=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let d=0;d<e.length;d++)if(e[d].name===l){l=d;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(l!==void 0){if(e[l]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[l]}}let r=e[i];if(r===void 0){let l=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+i+" but it wasn't found.",e);return}let o=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let a=this.BindingType.Direct;if(s!==void 0){if(i==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}a=this.BindingType.ArrayElement,this.resolvedProperty=r,this.propertyIndex=s}else r.fromArray!==void 0&&r.toArray!==void 0?(a=this.BindingType.HasFromToArray,this.resolvedProperty=r):Array.isArray(r)?(a=this.BindingType.EntireArray,this.resolvedProperty=r):this.propertyName=i;this.getValue=this.GetterByBindingType[a],this.setValue=this.SetterByBindingTypeAndVersioning[a][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};B.Composite=Fs;B.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};B.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};B.prototype.GetterByBindingType=[B.prototype._getValue_direct,B.prototype._getValue_array,B.prototype._getValue_arrayElement,B.prototype._getValue_toArray];B.prototype.SetterByBindingTypeAndVersioning=[[B.prototype._setValue_direct,B.prototype._setValue_direct_setNeedsUpdate,B.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[B.prototype._setValue_array,B.prototype._setValue_array_setNeedsUpdate,B.prototype._setValue_array_setMatrixWorldNeedsUpdate],[B.prototype._setValue_arrayElement,B.prototype._setValue_arrayElement_setNeedsUpdate,B.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[B.prototype._setValue_fromArray,B.prototype._setValue_fromArray_setNeedsUpdate,B.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var du=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"170"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="170");function Hs(c,e){if(e===Oo)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),c;if(e===yn||e===Ci){let t=c.getIndex();if(t===null){let r=[],o=c.getAttribute("position");if(o!==void 0){for(let a=0;a<o.count;a++)r.push(a);c.setIndex(r),t=c.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),c}let n=t.count-2,i=[];if(e===yn)for(let r=1;r<=n;r++)i.push(t.getX(0)),i.push(t.getX(r)),i.push(t.getX(r+1));else for(let r=0;r<n;r++)r%2===0?(i.push(t.getX(r)),i.push(t.getX(r+1)),i.push(t.getX(r+2))):(i.push(t.getX(r+2)),i.push(t.getX(r+1)),i.push(t.getX(r)));i.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");let s=c.clone();return s.setIndex(i),s.clearGroups(),s}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),c}var Ri=class extends Oe{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new Js(t)}),this.register(function(t){return new Ks(t)}),this.register(function(t){return new sr(t)}),this.register(function(t){return new rr(t)}),this.register(function(t){return new or(t)}),this.register(function(t){return new $s(t)}),this.register(function(t){return new js(t)}),this.register(function(t){return new Qs(t)}),this.register(function(t){return new er(t)}),this.register(function(t){return new Ys(t)}),this.register(function(t){return new tr(t)}),this.register(function(t){return new Zs(t)}),this.register(function(t){return new ir(t)}),this.register(function(t){return new nr(t)}),this.register(function(t){return new Xs(t)}),this.register(function(t){return new ar(t)}),this.register(function(t){return new cr(t)})}load(e,t,n,i){let s=this,r;if(this.resourcePath!=="")r=this.resourcePath;else if(this.path!==""){let l=it.extractUrlBase(e);r=it.resolveURL(l,this.path)}else r=it.extractUrlBase(e);this.manager.itemStart(e);let o=function(l){i?i(l):console.error(l),s.manager.itemError(e),s.manager.itemEnd(e)},a=new gn(this.manager);a.setPath(this.path),a.setResponseType("arraybuffer"),a.setRequestHeader(this.requestHeader),a.setWithCredentials(this.withCredentials),a.load(e,function(l){try{s.parse(l,r,function(d){t(d),s.manager.itemEnd(e)},o)}catch(d){o(d)}},n,o)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,i){let s,r={},o={},a=new TextDecoder;if(typeof e=="string")s=JSON.parse(e);else if(e instanceof ArrayBuffer)if(a.decode(new Uint8Array(e,0,4))===Yo){try{r[I.KHR_BINARY_GLTF]=new lr(e)}catch(h){i&&i(h);return}s=JSON.parse(r[I.KHR_BINARY_GLTF].content)}else s=JSON.parse(a.decode(e));else s=e;if(s.asset===void 0||s.asset.version[0]<2){i&&i(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}let l=new gr(s,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let d=0;d<this.pluginCallbacks.length;d++){let h=this.pluginCallbacks[d](l);h.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),o[h.name]=h,r[h.name]=!0}if(s.extensionsUsed)for(let d=0;d<s.extensionsUsed.length;++d){let h=s.extensionsUsed[d],u=s.extensionsRequired||[];switch(h){case I.KHR_MATERIALS_UNLIT:r[h]=new qs;break;case I.KHR_DRACO_MESH_COMPRESSION:r[h]=new dr(s,this.dracoLoader);break;case I.KHR_TEXTURE_TRANSFORM:r[h]=new hr;break;case I.KHR_MESH_QUANTIZATION:r[h]=new ur;break;default:u.indexOf(h)>=0&&o[h]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+h+'".')}}l.setExtensions(r),l.setPlugins(o),l.parse(n,i)}parseAsync(e,t){let n=this;return new Promise(function(i,s){n.parse(e,t,i,s)})}};function xh(){let c={};return{get:function(e){return c[e]},add:function(e,t){c[e]=t},remove:function(e){delete c[e]},removeAll:function(){c={}}}}var I={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"},Xs=class{constructor(e){this.parser=e,this.name=I.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let n=0,i=t.length;n<i;n++){let s=t[n];s.extensions&&s.extensions[this.name]&&s.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,s.extensions[this.name].light)}}_loadLight(e){let t=this.parser,n="light:"+e,i=t.cache.get(n);if(i)return i;let s=t.json,a=((s.extensions&&s.extensions[this.name]||{}).lights||[])[e],l,d=new L(16777215);a.color!==void 0&&d.setRGB(a.color[0],a.color[1],a.color[2],fe);let h=a.range!==void 0?a.range:0;switch(a.type){case"directional":l=new Ti(d),l.target.position.set(0,0,-1),l.add(l.target);break;case"point":l=new wi(d),l.distance=h;break;case"spot":l=new bi(d),l.distance=h,a.spot=a.spot||{},a.spot.innerConeAngle=a.spot.innerConeAngle!==void 0?a.spot.innerConeAngle:0,a.spot.outerConeAngle=a.spot.outerConeAngle!==void 0?a.spot.outerConeAngle:Math.PI/4,l.angle=a.spot.outerConeAngle,l.penumbra=1-a.spot.innerConeAngle/a.spot.outerConeAngle,l.target.position.set(0,0,-1),l.add(l.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+a.type)}return l.position.set(0,0,0),l.decay=2,ke(l,a),a.intensity!==void 0&&(l.intensity=a.intensity),l.name=t.createUniqueName(a.name||"light_"+e),i=Promise.resolve(l),t.cache.add(n,i),i}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){let t=this,n=this.parser,s=n.json.nodes[e],o=(s.extensions&&s.extensions[this.name]||{}).light;return o===void 0?null:this._loadLight(o).then(function(a){return n._getNodeRef(t.cache,o,a)})}},qs=class{constructor(){this.name=I.KHR_MATERIALS_UNLIT}getMaterialType(){return De}extendParams(e,t,n){let i=[];e.color=new L(1,1,1),e.opacity=1;let s=t.pbrMetallicRoughness;if(s){if(Array.isArray(s.baseColorFactor)){let r=s.baseColorFactor;e.color.setRGB(r[0],r[1],r[2],fe),e.opacity=r[3]}s.baseColorTexture!==void 0&&i.push(n.assignTexture(e,"map",s.baseColorTexture,Y))}return Promise.all(i)}},Ys=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let i=this.parser.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=i.extensions[this.name].emissiveStrength;return s!==void 0&&(t.emissiveIntensity=s),Promise.resolve()}},Js=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[],r=i.extensions[this.name];if(r.clearcoatFactor!==void 0&&(t.clearcoat=r.clearcoatFactor),r.clearcoatTexture!==void 0&&s.push(n.assignTexture(t,"clearcoatMap",r.clearcoatTexture)),r.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=r.clearcoatRoughnessFactor),r.clearcoatRoughnessTexture!==void 0&&s.push(n.assignTexture(t,"clearcoatRoughnessMap",r.clearcoatRoughnessTexture)),r.clearcoatNormalTexture!==void 0&&(s.push(n.assignTexture(t,"clearcoatNormalMap",r.clearcoatNormalTexture)),r.clearcoatNormalTexture.scale!==void 0)){let o=r.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new z(o,o)}return Promise.all(s)}},Ks=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_DISPERSION}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let i=this.parser.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=i.extensions[this.name];return t.dispersion=s.dispersion!==void 0?s.dispersion:0,Promise.resolve()}},Zs=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[],r=i.extensions[this.name];return r.iridescenceFactor!==void 0&&(t.iridescence=r.iridescenceFactor),r.iridescenceTexture!==void 0&&s.push(n.assignTexture(t,"iridescenceMap",r.iridescenceTexture)),r.iridescenceIor!==void 0&&(t.iridescenceIOR=r.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),r.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=r.iridescenceThicknessMinimum),r.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=r.iridescenceThicknessMaximum),r.iridescenceThicknessTexture!==void 0&&s.push(n.assignTexture(t,"iridescenceThicknessMap",r.iridescenceThicknessTexture)),Promise.all(s)}},$s=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_SHEEN}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[];t.sheenColor=new L(0,0,0),t.sheenRoughness=0,t.sheen=1;let r=i.extensions[this.name];if(r.sheenColorFactor!==void 0){let o=r.sheenColorFactor;t.sheenColor.setRGB(o[0],o[1],o[2],fe)}return r.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=r.sheenRoughnessFactor),r.sheenColorTexture!==void 0&&s.push(n.assignTexture(t,"sheenColorMap",r.sheenColorTexture,Y)),r.sheenRoughnessTexture!==void 0&&s.push(n.assignTexture(t,"sheenRoughnessMap",r.sheenRoughnessTexture)),Promise.all(s)}},js=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[],r=i.extensions[this.name];return r.transmissionFactor!==void 0&&(t.transmission=r.transmissionFactor),r.transmissionTexture!==void 0&&s.push(n.assignTexture(t,"transmissionMap",r.transmissionTexture)),Promise.all(s)}},Qs=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_VOLUME}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[],r=i.extensions[this.name];t.thickness=r.thicknessFactor!==void 0?r.thicknessFactor:0,r.thicknessTexture!==void 0&&s.push(n.assignTexture(t,"thicknessMap",r.thicknessTexture)),t.attenuationDistance=r.attenuationDistance||1/0;let o=r.attenuationColor||[1,1,1];return t.attenuationColor=new L().setRGB(o[0],o[1],o[2],fe),Promise.all(s)}},er=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_IOR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let i=this.parser.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=i.extensions[this.name];return t.ior=s.ior!==void 0?s.ior:1.5,Promise.resolve()}},tr=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_SPECULAR}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[],r=i.extensions[this.name];t.specularIntensity=r.specularFactor!==void 0?r.specularFactor:1,r.specularTexture!==void 0&&s.push(n.assignTexture(t,"specularIntensityMap",r.specularTexture));let o=r.specularColorFactor||[1,1,1];return t.specularColor=new L().setRGB(o[0],o[1],o[2],fe),r.specularColorTexture!==void 0&&s.push(n.assignTexture(t,"specularColorMap",r.specularColorTexture,Y)),Promise.all(s)}},nr=class{constructor(e){this.parser=e,this.name=I.EXT_MATERIALS_BUMP}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[],r=i.extensions[this.name];return t.bumpScale=r.bumpFactor!==void 0?r.bumpFactor:1,r.bumpTexture!==void 0&&s.push(n.assignTexture(t,"bumpMap",r.bumpTexture)),Promise.all(s)}},ir=class{constructor(e){this.parser=e,this.name=I.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){let n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:ae}extendMaterialParams(e,t){let n=this.parser,i=n.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let s=[],r=i.extensions[this.name];return r.anisotropyStrength!==void 0&&(t.anisotropy=r.anisotropyStrength),r.anisotropyRotation!==void 0&&(t.anisotropyRotation=r.anisotropyRotation),r.anisotropyTexture!==void 0&&s.push(n.assignTexture(t,"anisotropyMap",r.anisotropyTexture)),Promise.all(s)}},sr=class{constructor(e){this.parser=e,this.name=I.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,n=t.json,i=n.textures[e];if(!i.extensions||!i.extensions[this.name])return null;let s=i.extensions[this.name],r=t.options.ktx2Loader;if(!r){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,s.source,r)}},rr=class{constructor(e){this.parser=e,this.name=I.EXT_TEXTURE_WEBP,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,i=n.json,s=i.textures[e];if(!s.extensions||!s.extensions[t])return null;let r=s.extensions[t],o=i.images[r.source],a=n.textureLoader;if(o.uri){let l=n.options.manager.getHandler(o.uri);l!==null&&(a=l)}return this.detectSupport().then(function(l){if(l)return n.loadTextureImage(e,r.source,a);if(i.extensionsRequired&&i.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},or=class{constructor(e){this.parser=e,this.name=I.EXT_TEXTURE_AVIF,this.isSupported=null}loadTexture(e){let t=this.name,n=this.parser,i=n.json,s=i.textures[e];if(!s.extensions||!s.extensions[t])return null;let r=s.extensions[t],o=i.images[r.source],a=n.textureLoader;if(o.uri){let l=n.options.manager.getHandler(o.uri);l!==null&&(a=l)}return this.detectSupport().then(function(l){if(l)return n.loadTextureImage(e,r.source,a);if(i.extensionsRequired&&i.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");return n.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},ar=class{constructor(e){this.name=I.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){let t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){let i=n.extensions[this.name],s=this.parser.getDependency("buffer",i.buffer),r=this.parser.options.meshoptDecoder;if(!r||!r.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return s.then(function(o){let a=i.byteOffset||0,l=i.byteLength||0,d=i.count,h=i.byteStride,u=new Uint8Array(o,a,l);return r.decodeGltfBufferAsync?r.decodeGltfBufferAsync(d,h,u,i.mode,i.filter).then(function(f){return f.buffer}):r.ready.then(function(){let f=new ArrayBuffer(d*h);return r.decodeGltfBuffer(new Uint8Array(f),d,h,u,i.mode,i.filter),f})})}else return null}},cr=class{constructor(e){this.name=I.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;let i=t.meshes[n.mesh];for(let l of i.primitives)if(l.mode!==pe.TRIANGLES&&l.mode!==pe.TRIANGLE_STRIP&&l.mode!==pe.TRIANGLE_FAN&&l.mode!==void 0)return null;let r=n.extensions[this.name].attributes,o=[],a={};for(let l in r)o.push(this.parser.getDependency("accessor",r[l]).then(d=>(a[l]=d,a[l])));return o.length<1?null:(o.push(this.parser.createNodeMesh(e)),Promise.all(o).then(l=>{let d=l.pop(),h=d.isGroup?d.children:[d],u=l[0].count,f=[];for(let p of h){let m=new D,g=new _,v=new Me,x=new _(1,1,1),y=new pi(p.geometry,p.material,u);for(let M=0;M<u;M++)a.TRANSLATION&&g.fromBufferAttribute(a.TRANSLATION,M),a.ROTATION&&v.fromBufferAttribute(a.ROTATION,M),a.SCALE&&x.fromBufferAttribute(a.SCALE,M),y.setMatrixAt(M,m.compose(g,v,x));for(let M in a)if(M==="_COLOR_0"){let b=a[M];y.instanceColor=new pt(b.array,b.itemSize,b.normalized)}else M!=="TRANSLATION"&&M!=="ROTATION"&&M!=="SCALE"&&p.geometry.setAttribute(M,a[M]);G.prototype.copy.call(y,p),this.parser.assignFinalMaterial(y),f.push(y)}return d.isGroup?(d.clear(),d.add(...f),d):f[0]}))}},Yo="glTF",Mn=12,Go={JSON:1313821514,BIN:5130562},lr=class{constructor(e){this.name=I.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,Mn),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==Yo)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");let i=this.header.length-Mn,s=new DataView(e,Mn),r=0;for(;r<i;){let o=s.getUint32(r,!0);r+=4;let a=s.getUint32(r,!0);if(r+=4,a===Go.JSON){let l=new Uint8Array(e,Mn+r,o);this.content=n.decode(l)}else if(a===Go.BIN){let l=Mn+r;this.body=e.slice(l,l+o)}r+=o}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}},dr=class{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=I.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let n=this.json,i=this.dracoLoader,s=e.extensions[this.name].bufferView,r=e.extensions[this.name].attributes,o={},a={},l={};for(let d in r){let h=pr[d]||d.toLowerCase();o[h]=r[d]}for(let d in e.attributes){let h=pr[d]||d.toLowerCase();if(r[d]!==void 0){let u=n.accessors[e.attributes[d]],f=Xt[u.componentType];l[h]=f.name,a[h]=u.normalized===!0}}return t.getDependency("bufferView",s).then(function(d){return new Promise(function(h,u){i.decodeDracoFile(d,function(f){for(let p in f.attributes){let m=f.attributes[p],g=a[p];g!==void 0&&(m.normalized=g)}h(f)},o,l,fe,u)})})}},hr=class{constructor(){this.name=I.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}},ur=class{constructor(){this.name=I.KHR_MESH_QUANTIZATION}},Ii=class extends et{constructor(e,t,n,i){super(e,t,n,i)}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,i=this.valueSize,s=e*i*3+i;for(let r=0;r!==i;r++)t[r]=n[s+r];return t}interpolate_(e,t,n,i){let s=this.resultBuffer,r=this.sampleValues,o=this.valueSize,a=o*2,l=o*3,d=i-t,h=(n-t)/d,u=h*h,f=u*h,p=e*l,m=p-l,g=-2*f+3*u,v=f-u,x=1-g,y=v-u+h;for(let M=0;M!==o;M++){let b=r[m+M+o],C=r[m+M+a]*d,A=r[p+M+o],E=r[p+M]*d;s[M]=x*b+y*C+g*A+v*E}return s}},yh=new Me,fr=class extends Ii{interpolate_(e,t,n,i){let s=super.interpolate_(e,t,n,i);return yh.fromArray(s).normalize().toArray(s),s}},pe={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},Xt={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Wo={9728:cn,9729:xn,9984:Do,9985:Uo,9986:No,9987:Ei},Xo={33071:Lt,33648:li,10497:Nt},Vs={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},pr={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},st={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},Mh={CUBICSPLINE:void 0,LINEAR:Ft,STEP:Ut},Gs={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function Sh(c){return c.DefaultMaterial===void 0&&(c.DefaultMaterial=new Wt({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:an})),c.DefaultMaterial}function mt(c,e,t){for(let n in t.extensions)c[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function ke(c,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(c.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function bh(c,e,t){let n=!1,i=!1,s=!1;for(let l=0,d=e.length;l<d;l++){let h=e[l];if(h.POSITION!==void 0&&(n=!0),h.NORMAL!==void 0&&(i=!0),h.COLOR_0!==void 0&&(s=!0),n&&i&&s)break}if(!n&&!i&&!s)return Promise.resolve(c);let r=[],o=[],a=[];for(let l=0,d=e.length;l<d;l++){let h=e[l];if(n){let u=h.POSITION!==void 0?t.getDependency("accessor",h.POSITION):c.attributes.position;r.push(u)}if(i){let u=h.NORMAL!==void 0?t.getDependency("accessor",h.NORMAL):c.attributes.normal;o.push(u)}if(s){let u=h.COLOR_0!==void 0?t.getDependency("accessor",h.COLOR_0):c.attributes.color;a.push(u)}}return Promise.all([Promise.all(r),Promise.all(o),Promise.all(a)]).then(function(l){let d=l[0],h=l[1],u=l[2];return n&&(c.morphAttributes.position=d),i&&(c.morphAttributes.normal=h),s&&(c.morphAttributes.color=u),c.morphTargetsRelative=!0,c})}function wh(c,e){if(c.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)c.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){let t=e.extras.targetNames;if(c.morphTargetInfluences.length===t.length){c.morphTargetDictionary={};for(let n=0,i=t.length;n<i;n++)c.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function Th(c){let e,t=c.extensions&&c.extensions[I.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+Ws(t.attributes):e=c.indices+":"+Ws(c.attributes)+":"+c.mode,c.targets!==void 0)for(let n=0,i=c.targets.length;n<i;n++)e+=":"+Ws(c.targets[n]);return e}function Ws(c){let e="",t=Object.keys(c).sort();for(let n=0,i=t.length;n<i;n++)e+=t[n]+":"+c[t[n]]+";";return e}function mr(c){switch(c){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function Ah(c){return c.search(/\.jpe?g($|\?)/i)>0||c.search(/^data\:image\/jpeg/)===0?"image/jpeg":c.search(/\.webp($|\?)/i)>0||c.search(/^data\:image\/webp/)===0?"image/webp":c.search(/\.ktx2($|\?)/i)>0||c.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}var Eh=new D,gr=class{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new xh,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,i=-1,s=!1,r=-1;if(typeof navigator<"u"){let o=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(o)===!0;let a=o.match(/Version\/(\d+)/);i=n&&a?parseInt(a[1],10):-1,s=o.indexOf("Firefox")>-1,r=s?o.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&i<17||s&&r<98?this.textureLoader=new Si(this.options.manager):this.textureLoader=new Ai(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new gn(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let n=this,i=this.json,s=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(r){return r._markDefs&&r._markDefs()}),Promise.all(this._invokeAll(function(r){return r.beforeRoot&&r.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(r){let o={scene:r[0][i.scene||0],scenes:r[0],animations:r[1],cameras:r[2],asset:i.asset,parser:n,userData:{}};return mt(s,o,i),ke(o,i),Promise.all(n._invokeAll(function(a){return a.afterRoot&&a.afterRoot(o)})).then(function(){for(let a of o.scenes)a.updateMatrixWorld();e(o)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let i=0,s=t.length;i<s;i++){let r=t[i].joints;for(let o=0,a=r.length;o<a;o++)e[r[o]].isBone=!0}for(let i=0,s=e.length;i<s;i++){let r=e[i];r.mesh!==void 0&&(this._addNodeRef(this.meshCache,r.mesh),r.skin!==void 0&&(n[r.mesh].isSkinnedMesh=!0)),r.camera!==void 0&&this._addNodeRef(this.cameraCache,r.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;let i=n.clone(),s=(r,o)=>{let a=this.associations.get(r);a!=null&&this.associations.set(o,a);for(let[l,d]of r.children.entries())s(d,o.children[l])};return s(n,i),i.name+="_instance_"+e.uses[t]++,i}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){let i=e(t[n]);if(i)return i}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let n=[];for(let i=0;i<t.length;i++){let s=e(t[i]);s&&n.push(s)}return n}getDependency(e,t){let n=e+":"+t,i=this.cache.get(n);if(!i){switch(e){case"scene":i=this.loadScene(t);break;case"node":i=this._invokeOne(function(s){return s.loadNode&&s.loadNode(t)});break;case"mesh":i=this._invokeOne(function(s){return s.loadMesh&&s.loadMesh(t)});break;case"accessor":i=this.loadAccessor(t);break;case"bufferView":i=this._invokeOne(function(s){return s.loadBufferView&&s.loadBufferView(t)});break;case"buffer":i=this.loadBuffer(t);break;case"material":i=this._invokeOne(function(s){return s.loadMaterial&&s.loadMaterial(t)});break;case"texture":i=this._invokeOne(function(s){return s.loadTexture&&s.loadTexture(t)});break;case"skin":i=this.loadSkin(t);break;case"animation":i=this._invokeOne(function(s){return s.loadAnimation&&s.loadAnimation(t)});break;case"camera":i=this.loadCamera(t);break;default:if(i=this._invokeOne(function(s){return s!=this&&s.getDependency&&s.getDependency(e,t)}),!i)throw new Error("Unknown type: "+e);break}this.cache.add(n,i)}return i}getDependencies(e){let t=this.cache.get(e);if(!t){let n=this,i=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(i.map(function(s,r){return n.getDependency(e,r)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[I.KHR_BINARY_GLTF].body);let i=this.options;return new Promise(function(s,r){n.load(it.resolveURL(t.uri,i.path),s,void 0,function(){r(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){let i=t.byteLength||0,s=t.byteOffset||0;return n.slice(s,s+i)})}loadAccessor(e){let t=this,n=this.json,i=this.json.accessors[e];if(i.bufferView===void 0&&i.sparse===void 0){let r=Vs[i.type],o=Xt[i.componentType],a=i.normalized===!0,l=new o(i.count*r);return Promise.resolve(new ne(l,r,a))}let s=[];return i.bufferView!==void 0?s.push(this.getDependency("bufferView",i.bufferView)):s.push(null),i.sparse!==void 0&&(s.push(this.getDependency("bufferView",i.sparse.indices.bufferView)),s.push(this.getDependency("bufferView",i.sparse.values.bufferView))),Promise.all(s).then(function(r){let o=r[0],a=Vs[i.type],l=Xt[i.componentType],d=l.BYTES_PER_ELEMENT,h=d*a,u=i.byteOffset||0,f=i.bufferView!==void 0?n.bufferViews[i.bufferView].byteStride:void 0,p=i.normalized===!0,m,g;if(f&&f!==h){let v=Math.floor(u/f),x="InterleavedBuffer:"+i.bufferView+":"+i.componentType+":"+v+":"+i.count,y=t.cache.get(x);y||(m=new l(o,v*f,i.count*f/d),y=new hn(m,f/d),t.cache.add(x,y)),g=new un(y,a,u%f/d,p)}else o===null?m=new l(i.count*a):m=new l(o,u,i.count*a),g=new ne(m,a,p);if(i.sparse!==void 0){let v=Vs.SCALAR,x=Xt[i.sparse.indices.componentType],y=i.sparse.indices.byteOffset||0,M=i.sparse.values.byteOffset||0,b=new x(r[1],y,i.sparse.count*v),C=new l(r[2],M,i.sparse.count*a);o!==null&&(g=new ne(g.array.slice(),g.itemSize,g.normalized)),g.normalized=!1;for(let A=0,E=b.length;A<E;A++){let N=b[A];if(g.setX(N,C[A*a]),a>=2&&g.setY(N,C[A*a+1]),a>=3&&g.setZ(N,C[A*a+2]),a>=4&&g.setW(N,C[A*a+3]),a>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}g.normalized=p}return g})}loadTexture(e){let t=this.json,n=this.options,s=t.textures[e].source,r=t.images[s],o=this.textureLoader;if(r.uri){let a=n.manager.getHandler(r.uri);a!==null&&(o=a)}return this.loadTextureImage(e,s,o)}loadTextureImage(e,t,n){let i=this,s=this.json,r=s.textures[e],o=s.images[t],a=(o.uri||o.bufferView)+":"+r.sampler;if(this.textureCache[a])return this.textureCache[a];let l=this.loadImageSource(t,n).then(function(d){d.flipY=!1,d.name=r.name||o.name||"",d.name===""&&typeof o.uri=="string"&&o.uri.startsWith("data:image/")===!1&&(d.name=o.uri);let u=(s.samplers||{})[r.sampler]||{};return d.magFilter=Wo[u.magFilter]||xn,d.minFilter=Wo[u.minFilter]||Ei,d.wrapS=Xo[u.wrapS]||Nt,d.wrapT=Xo[u.wrapT]||Nt,d.generateMipmaps=!d.isCompressedTexture&&d.minFilter!==cn&&d.minFilter!==xn,i.associations.set(d,{textures:e}),d}).catch(function(){return null});return this.textureCache[a]=l,l}loadImageSource(e,t){let n=this,i=this.json,s=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(h=>h.clone());let r=i.images[e],o=self.URL||self.webkitURL,a=r.uri||"",l=!1;if(r.bufferView!==void 0)a=n.getDependency("bufferView",r.bufferView).then(function(h){l=!0;let u=new Blob([h],{type:r.mimeType});return a=o.createObjectURL(u),a});else if(r.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");let d=Promise.resolve(a).then(function(h){return new Promise(function(u,f){let p=u;t.isImageBitmapLoader===!0&&(p=function(m){let g=new we(m);g.needsUpdate=!0,u(g)}),t.load(it.resolveURL(h,s.path),p,void 0,f)})}).then(function(h){return l===!0&&o.revokeObjectURL(a),ke(h,r),h.userData.mimeType=r.mimeType||Ah(r.uri),h}).catch(function(h){throw console.error("THREE.GLTFLoader: Couldn't load texture",a),h});return this.sourceCache[e]=d,d}assignTexture(e,t,n,i){let s=this;return this.getDependency("texture",n.index).then(function(r){if(!r)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(r=r.clone(),r.channel=n.texCoord),s.extensions[I.KHR_TEXTURE_TRANSFORM]){let o=n.extensions!==void 0?n.extensions[I.KHR_TEXTURE_TRANSFORM]:void 0;if(o){let a=s.associations.get(r);r=s.extensions[I.KHR_TEXTURE_TRANSFORM].extendTexture(r,o),s.associations.set(r,a)}}return i!==void 0&&(r.colorSpace=i),e[t]=r,r})}assignFinalMaterial(e){let t=e.geometry,n=e.material,i=t.attributes.tangent===void 0,s=t.attributes.color!==void 0,r=t.attributes.normal===void 0;if(e.isPoints){let o="PointsMaterial:"+n.uuid,a=this.cache.get(o);a||(a=new mn,Te.prototype.copy.call(a,n),a.color.copy(n.color),a.map=n.map,a.sizeAttenuation=!1,this.cache.add(o,a)),n=a}else if(e.isLine){let o="LineBasicMaterial:"+n.uuid,a=this.cache.get(o);a||(a=new pn,Te.prototype.copy.call(a,n),a.color.copy(n.color),a.map=n.map,this.cache.add(o,a)),n=a}if(i||s||r){let o="ClonedMaterial:"+n.uuid+":";i&&(o+="derivative-tangents:"),s&&(o+="vertex-colors:"),r&&(o+="flat-shading:");let a=this.cache.get(o);a||(a=n.clone(),s&&(a.vertexColors=!0),r&&(a.flatShading=!0),i&&(a.normalScale&&(a.normalScale.y*=-1),a.clearcoatNormalScale&&(a.clearcoatNormalScale.y*=-1)),this.cache.add(o,a),this.associations.set(a,this.associations.get(n))),n=a}e.material=n}getMaterialType(){return Wt}loadMaterial(e){let t=this,n=this.json,i=this.extensions,s=n.materials[e],r,o={},a=s.extensions||{},l=[];if(a[I.KHR_MATERIALS_UNLIT]){let h=i[I.KHR_MATERIALS_UNLIT];r=h.getMaterialType(),l.push(h.extendParams(o,s,t))}else{let h=s.pbrMetallicRoughness||{};if(o.color=new L(1,1,1),o.opacity=1,Array.isArray(h.baseColorFactor)){let u=h.baseColorFactor;o.color.setRGB(u[0],u[1],u[2],fe),o.opacity=u[3]}h.baseColorTexture!==void 0&&l.push(t.assignTexture(o,"map",h.baseColorTexture,Y)),o.metalness=h.metallicFactor!==void 0?h.metallicFactor:1,o.roughness=h.roughnessFactor!==void 0?h.roughnessFactor:1,h.metallicRoughnessTexture!==void 0&&(l.push(t.assignTexture(o,"metalnessMap",h.metallicRoughnessTexture)),l.push(t.assignTexture(o,"roughnessMap",h.metallicRoughnessTexture))),r=this._invokeOne(function(u){return u.getMaterialType&&u.getMaterialType(e)}),l.push(Promise.all(this._invokeAll(function(u){return u.extendMaterialParams&&u.extendMaterialParams(e,o)})))}s.doubleSided===!0&&(o.side=Po);let d=s.alphaMode||Gs.OPAQUE;if(d===Gs.BLEND?(o.transparent=!0,o.depthWrite=!1):(o.transparent=!1,d===Gs.MASK&&(o.alphaTest=s.alphaCutoff!==void 0?s.alphaCutoff:.5)),s.normalTexture!==void 0&&r!==De&&(l.push(t.assignTexture(o,"normalMap",s.normalTexture)),o.normalScale=new z(1,1),s.normalTexture.scale!==void 0)){let h=s.normalTexture.scale;o.normalScale.set(h,h)}if(s.occlusionTexture!==void 0&&r!==De&&(l.push(t.assignTexture(o,"aoMap",s.occlusionTexture)),s.occlusionTexture.strength!==void 0&&(o.aoMapIntensity=s.occlusionTexture.strength)),s.emissiveFactor!==void 0&&r!==De){let h=s.emissiveFactor;o.emissive=new L().setRGB(h[0],h[1],h[2],fe)}return s.emissiveTexture!==void 0&&r!==De&&l.push(t.assignTexture(o,"emissiveMap",s.emissiveTexture,Y)),Promise.all(l).then(function(){let h=new r(o);return s.name&&(h.name=s.name),ke(h,s),t.associations.set(h,{materials:e}),s.extensions&&mt(i,h,s),h})}createUniqueName(e){let t=B.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,n=this.extensions,i=this.primitiveCache;function s(o){return n[I.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(o,t).then(function(a){return qo(a,o,t)})}let r=[];for(let o=0,a=e.length;o<a;o++){let l=e[o],d=Th(l),h=i[d];if(h)r.push(h.promise);else{let u;l.extensions&&l.extensions[I.KHR_DRACO_MESH_COMPRESSION]?u=s(l):u=qo(new Qe,l,t),i[d]={primitive:l,promise:u},r.push(u)}}return Promise.all(r)}loadMesh(e){let t=this,n=this.json,i=this.extensions,s=n.meshes[e],r=s.primitives,o=[];for(let a=0,l=r.length;a<l;a++){let d=r[a].material===void 0?Sh(this.cache):this.getDependency("material",r[a].material);o.push(d)}return o.push(t.loadGeometries(r)),Promise.all(o).then(function(a){let l=a.slice(0,a.length-1),d=a[a.length-1],h=[];for(let f=0,p=d.length;f<p;f++){let m=d[f],g=r[f],v,x=l[f];if(g.mode===pe.TRIANGLES||g.mode===pe.TRIANGLE_STRIP||g.mode===pe.TRIANGLE_FAN||g.mode===void 0)v=s.isSkinnedMesh===!0?new hi(m,x):new ft(m,x),v.isSkinnedMesh===!0&&v.normalizeSkinWeights(),g.mode===pe.TRIANGLE_STRIP?v.geometry=Hs(v.geometry,Ci):g.mode===pe.TRIANGLE_FAN&&(v.geometry=Hs(v.geometry,yn));else if(g.mode===pe.LINES)v=new vi(m,x);else if(g.mode===pe.LINE_STRIP)v=new Gt(m,x);else if(g.mode===pe.LINE_LOOP)v=new _i(m,x);else if(g.mode===pe.POINTS)v=new xi(m,x);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+g.mode);Object.keys(v.geometry.morphAttributes).length>0&&wh(v,s),v.name=t.createUniqueName(s.name||"mesh_"+e),ke(v,s),g.extensions&&mt(i,v,g),t.assignFinalMaterial(v),h.push(v)}for(let f=0,p=h.length;f<p;f++)t.associations.set(h[f],{meshes:e,primitives:f});if(h.length===1)return s.extensions&&mt(i,h[0],s),h[0];let u=new Vt;s.extensions&&mt(i,u,s),t.associations.set(u,{meshes:e});for(let f=0,p=h.length;f<p;f++)u.add(h[f]);return u})}loadCamera(e){let t,n=this.json.cameras[e],i=n[n.type];if(!i){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Ht(zo.radToDeg(i.yfov),i.aspectRatio||1,i.znear||1,i.zfar||2e6):n.type==="orthographic"&&(t=new dn(-i.xmag,i.xmag,i.ymag,-i.ymag,i.znear,i.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),ke(t,n),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],n=[];for(let i=0,s=t.joints.length;i<s;i++)n.push(this._loadNodeShallow(t.joints[i]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(i){let s=i.pop(),r=i,o=[],a=[];for(let l=0,d=r.length;l<d;l++){let h=r[l];if(h){o.push(h);let u=new D;s!==null&&u.fromArray(s.array,l*16),a.push(u)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[l])}return new fi(o,a)})}loadAnimation(e){let t=this.json,n=this,i=t.animations[e],s=i.name?i.name:"animation_"+e,r=[],o=[],a=[],l=[],d=[];for(let h=0,u=i.channels.length;h<u;h++){let f=i.channels[h],p=i.samplers[f.sampler],m=f.target,g=m.node,v=i.parameters!==void 0?i.parameters[p.input]:p.input,x=i.parameters!==void 0?i.parameters[p.output]:p.output;m.node!==void 0&&(r.push(this.getDependency("node",g)),o.push(this.getDependency("accessor",v)),a.push(this.getDependency("accessor",x)),l.push(p),d.push(m))}return Promise.all([Promise.all(r),Promise.all(o),Promise.all(a),Promise.all(l),Promise.all(d)]).then(function(h){let u=h[0],f=h[1],p=h[2],m=h[3],g=h[4],v=[];for(let x=0,y=u.length;x<y;x++){let M=u[x],b=f[x],C=p[x],A=m[x],E=g[x];if(M===void 0)continue;M.updateMatrix&&M.updateMatrix();let N=n._createAnimationTracks(M,b,C,A,E);if(N)for(let k=0;k<N.length;k++)v.push(N[k])}return new Mi(s,void 0,v)})}createNodeMesh(e){let t=this.json,n=this,i=t.nodes[e];return i.mesh===void 0?null:n.getDependency("mesh",i.mesh).then(function(s){let r=n._getNodeRef(n.meshCache,i.mesh,s);return i.weights!==void 0&&r.traverse(function(o){if(o.isMesh)for(let a=0,l=i.weights.length;a<l;a++)o.morphTargetInfluences[a]=i.weights[a]}),r})}loadNode(e){let t=this.json,n=this,i=t.nodes[e],s=n._loadNodeShallow(e),r=[],o=i.children||[];for(let l=0,d=o.length;l<d;l++)r.push(n.getDependency("node",o[l]));let a=i.skin===void 0?Promise.resolve(null):n.getDependency("skin",i.skin);return Promise.all([s,Promise.all(r),a]).then(function(l){let d=l[0],h=l[1],u=l[2];u!==null&&d.traverse(function(f){f.isSkinnedMesh&&f.bind(u,Eh)});for(let f=0,p=h.length;f<p;f++)d.add(h[f]);return d})}_loadNodeShallow(e){let t=this.json,n=this.extensions,i=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let s=t.nodes[e],r=s.name?i.createUniqueName(s.name):"",o=[],a=i._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(e)});return a&&o.push(a),s.camera!==void 0&&o.push(i.getDependency("camera",s.camera).then(function(l){return i._getNodeRef(i.cameraCache,s.camera,l)})),i._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(e)}).forEach(function(l){o.push(l)}),this.nodeCache[e]=Promise.all(o).then(function(l){let d;if(s.isBone===!0?d=new fn:l.length>1?d=new Vt:l.length===1?d=l[0]:d=new G,d!==l[0])for(let h=0,u=l.length;h<u;h++)d.add(l[h]);if(s.name&&(d.userData.name=s.name,d.name=r),ke(d,s),s.extensions&&mt(n,d,s),s.matrix!==void 0){let h=new D;h.fromArray(s.matrix),d.applyMatrix4(h)}else s.translation!==void 0&&d.position.fromArray(s.translation),s.rotation!==void 0&&d.quaternion.fromArray(s.rotation),s.scale!==void 0&&d.scale.fromArray(s.scale);return i.associations.has(d)||i.associations.set(d,{}),i.associations.get(d).nodes=e,d}),this.nodeCache[e]}loadScene(e){let t=this.extensions,n=this.json.scenes[e],i=this,s=new Vt;n.name&&(s.name=i.createUniqueName(n.name)),ke(s,n),n.extensions&&mt(t,s,n);let r=n.nodes||[],o=[];for(let a=0,l=r.length;a<l;a++)o.push(i.getDependency("node",r[a]));return Promise.all(o).then(function(a){for(let d=0,h=a.length;d<h;d++)s.add(a[d]);let l=d=>{let h=new Map;for(let[u,f]of i.associations)(u instanceof Te||u instanceof we)&&h.set(u,f);return d.traverse(u=>{let f=i.associations.get(u);f!=null&&h.set(u,f)}),h};return i.associations=l(s),s})}_createAnimationTracks(e,t,n,i,s){let r=[],o=e.name?e.name:e.uuid,a=[];st[s.path]===st.weights?e.traverse(function(u){u.morphTargetInfluences&&a.push(u.name?u.name:u.uuid)}):a.push(o);let l;switch(st[s.path]){case st.weights:l=Ne;break;case st.rotation:l=Ue;break;case st.position:case st.scale:l=Fe;break;default:n.itemSize===1?l=Ne:l=Fe;break}let d=i.interpolation!==void 0?Mh[i.interpolation]:Ft,h=this._getArrayFromAccessor(n);for(let u=0,f=a.length;u<f;u++){let p=new l(a[u]+"."+st[s.path],t.array,h,d);i.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(p),r.push(p)}return r}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let n=mr(t.constructor),i=new Float32Array(t.length);for(let s=0,r=t.length;s<r;s++)i[s]=t[s]*n;t=i}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){let i=this instanceof Ue?fr:Ii;return new i(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}};function Ch(c,e,t){let n=e.attributes,i=new he;if(n.POSITION!==void 0){let o=t.json.accessors[n.POSITION],a=o.min,l=o.max;if(a!==void 0&&l!==void 0){if(i.set(new _(a[0],a[1],a[2]),new _(l[0],l[1],l[2])),o.normalized){let d=mr(Xt[o.componentType]);i.min.multiplyScalar(d),i.max.multiplyScalar(d)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;let s=e.targets;if(s!==void 0){let o=new _,a=new _;for(let l=0,d=s.length;l<d;l++){let h=s[l];if(h.POSITION!==void 0){let u=t.json.accessors[h.POSITION],f=u.min,p=u.max;if(f!==void 0&&p!==void 0){if(a.setX(Math.max(Math.abs(f[0]),Math.abs(p[0]))),a.setY(Math.max(Math.abs(f[1]),Math.abs(p[1]))),a.setZ(Math.max(Math.abs(f[2]),Math.abs(p[2]))),u.normalized){let m=mr(Xt[u.componentType]);a.multiplyScalar(m)}o.max(a)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}i.expandByVector(o)}c.boundingBox=i;let r=new oe;i.getCenter(r.center),r.radius=i.min.distanceTo(i.max)/2,c.boundingSphere=r}function qo(c,e,t){let n=e.attributes,i=[];function s(r,o){return t.getDependency("accessor",r).then(function(a){c.setAttribute(o,a)})}for(let r in n){let o=pr[r]||r.toLowerCase();o in c.attributes||i.push(s(n[r],o))}if(e.indices!==void 0&&!c.index){let r=t.getDependency("accessor",e.indices).then(function(o){c.setIndex(o)});i.push(r)}return ee.workingColorSpace!==fe&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${ee.workingColorSpace}" not supported.`),ke(c,e),Ch(c,e,t),Promise.all(i).then(function(){return e.targets!==void 0?bh(c,e.targets,t):c})}var Jo=Object.freeze(["root","body","hips","spine","chest","upperChest","neck","neck2","neck3","head","rightShoulder","rightUpperArm","rightLowerArm","rightHand","leftShoulder","leftUpperArm","leftLowerArm","leftHand","rightThumbMetacarpal","rightThumbProximal","rightThumbDistal","rightIndexProximal","rightIndexIntermediate","rightIndexDistal","rightMiddleProximal","rightMiddleIntermediate","rightMiddleDistal","rightRingProximal","rightRingIntermediate","rightRingDistal","rightLittleProximal","rightLittleIntermediate","rightLittleDistal","leftThumbMetacarpal","leftThumbProximal","leftThumbDistal","leftIndexProximal","leftIndexIntermediate","leftIndexDistal","leftMiddleProximal","leftMiddleIntermediate","leftMiddleDistal","leftRingProximal","leftRingIntermediate","leftRingDistal","leftLittleProximal","leftLittleIntermediate","leftLittleDistal","jaw","leftUpperEyelid","rightUpperEyelid","leftLowerEyelid","rightLowerEyelid"]),Rh=Object.freeze(["rightUpperArm","rightLowerArm","rightHand","leftUpperArm","leftLowerArm","leftHand","rightThumbMetacarpal","rightThumbProximal","rightThumbDistal","rightIndexProximal","rightIndexIntermediate","rightIndexDistal","rightMiddleProximal","rightMiddleIntermediate","rightMiddleDistal","rightRingProximal","rightRingIntermediate","rightRingDistal","rightLittleProximal","rightLittleIntermediate","rightLittleDistal","leftThumbMetacarpal","leftThumbProximal","leftThumbDistal","leftIndexProximal","leftIndexIntermediate","leftIndexDistal","leftMiddleProximal","leftMiddleIntermediate","leftMiddleDistal","leftRingProximal","leftRingIntermediate","leftRingDistal","leftLittleProximal","leftLittleIntermediate","leftLittleDistal"]),Ko=Object.freeze({id:"godette-v1",motionSpace:"humanoid-local-v1",bones:Object.freeze({root:["Root_225"],body:["Body_220"],hips:["Hip_218"],spine:["Spine_1_199"],chest:["Spine_2_198"],upperChest:["Ribcage_197"],neck:["Neck_1_132"],neck2:["Neck_2_131"],neck3:["Neck_3_130"],head:["Head_129"],rightShoulder:["ClavicR_192","Clavic.R_192"],rightUpperArm:["Arm_Upper_1R_187","Arm_Upper_1.R_187"],rightLowerArm:["Arm_Lower_1R_185","Arm_Lower_1.R_185"],rightHand:["HandR_184","Hand.R_184"],leftShoulder:["ClavicL_162","Clavic.L_162"],leftUpperArm:["Arm_Upper_1L_157","Arm_Upper_1.L_157"],leftLowerArm:["Arm_Lower_1L_155","Arm_Lower_1.L_155"],leftHand:["HandL_154","Hand.L_154"],rightThumbMetacarpal:["ThumbR_178","Thumb.R_178"],rightThumbProximal:["ThumbR002_177","Thumb.R.002_177"],rightThumbDistal:["ThumbR001_176","Thumb.R.001_176"],rightIndexProximal:["Finger_1R_166","Finger_1.R_166"],rightIndexIntermediate:["Finger_1R002_165","Finger_1.R.002_165"],rightIndexDistal:["Finger_1R001_164","Finger_1.R.001_164"],rightMiddleProximal:["Finger_2R_169","Finger_2.R_169"],rightMiddleIntermediate:["Finger_2R002_168","Finger_2.R.002_168"],rightMiddleDistal:["Finger_2R001_167","Finger_2.R.001_167"],rightRingProximal:["Finger_3R_172","Finger_3.R_172"],rightRingIntermediate:["Finger_3R002_171","Finger_3.R.002_171"],rightRingDistal:["Finger_3R001_170","Finger_3.R.001_170"],rightLittleProximal:["Finger_4R_175","Finger_4.R_175"],rightLittleIntermediate:["Finger_4R002_174","Finger_4.R.002_174"],rightLittleDistal:["Finger_4R001_173","Finger_4.R.001_173"],leftThumbMetacarpal:["ThumbL_148","Thumb.L_148"],leftThumbProximal:["ThumbL002_147","Thumb.L.002_147"],leftThumbDistal:["ThumbL001_146","Thumb.L.001_146"],leftIndexProximal:["Finger_1L_136","Finger_1.L_136"],leftIndexIntermediate:["Finger_1L002_135","Finger_1.L.002_135"],leftIndexDistal:["Finger_1L001_134","Finger_1.L.001_134"],leftMiddleProximal:["Finger_2L_139","Finger_2.L_139"],leftMiddleIntermediate:["Finger_2L002_138","Finger_2.L.002_138"],leftMiddleDistal:["Finger_2L001_137","Finger_2.L.001_137"],leftRingProximal:["Finger_3L_142","Finger_3.L_142"],leftRingIntermediate:["Finger_3L002_141","Finger_3.L.002_141"],leftRingDistal:["Finger_3L001_140","Finger_3.L.001_140"],leftLittleProximal:["Finger_4L_145","Finger_4.L_145"],leftLittleIntermediate:["Finger_4L002_144","Finger_4.L.002_144"],leftLittleDistal:["Finger_4L001_143","Finger_4.L.001_143"],jaw:["Jaw_4"],leftUpperEyelid:["Eyelid_Control_UpperL_14"],rightUpperEyelid:["Eyelid_Control_UpperR_15"],leftLowerEyelid:["Eyelid_Control_LowerL_16"],rightLowerEyelid:["Eyelid_Control_LowerR_17"]})}),Ih=Object.freeze({hip:"hips",ribcage:"upperChest",rShoulder:"rightShoulder",rUpperArm:"rightUpperArm",rForearm:"rightLowerArm",rHand:"rightHand",lShoulder:"leftShoulder",lUpperArm:"leftUpperArm",lForearm:"leftLowerArm",lHand:"leftHand",rthumb:"rightThumbMetacarpal",rindex:"rightIndexIntermediate",rmiddle:"rightMiddleIntermediate",rring:"rightRingIntermediate",rpinky:"rightLittleIntermediate",lthumb:"leftThumbMetacarpal",lindex:"leftIndexIntermediate",lmiddle:"leftMiddleIntermediate",lring:"leftRingIntermediate",lpinky:"leftLittleIntermediate",lUpperEyelid:"leftUpperEyelid",rUpperEyelid:"rightUpperEyelid",lLowerEyelid:"leftLowerEyelid",rLowerEyelid:"rightLowerEyelid"});function Zo(c){return String(c||"").replace(/[._\s-]/g,"").toLowerCase()}function $o(c={}){let e={};for(let[t,n]of Object.entries(c))e[Ih[t]||t]=n;return e}function Ph(c){let e=new Map,t=new Map,n=new Set;return c?.traverse?.(i=>{i.isBone&&(e.set(i.name,i),t.set(Zo(i.name),i)),i.isSkinnedMesh&&i.skeleton&&n.add(i.skeleton)}),{exact:e,normalized:t,skeletons:[...n]}}function Lh(c,e=Ko){let t=Ph(c),n={};for(let[i,s]of Object.entries(e.bones))for(let r of s){let o=t.exact.get(r)||t.normalized.get(Zo(r));if(o){n[i]=o;break}}return{bones:n,skeletons:t.skeletons}}function jo(c,e=Ko){let{bones:t,skeletons:n}=Lh(c,e),i={};for(let[f,p]of Object.entries(t))i[f]={quaternion:p.quaternion.clone(),rotation:{x:p.rotation.x,y:p.rotation.y,z:p.rotation.z,order:p.rotation.order}};function s(){for(let f of n)f.update()}function r(f={}){let p=$o(f),m={};for(let[g,v]of Object.entries(t)){let x=i[g],y=p[g];if(!y){m[g]=x.quaternion.clone();continue}let M=v.rotation.clone();M.set(x.rotation.x+(y.x||0),x.rotation.y+(y.y||0),x.rotation.z+(y.z||0),x.rotation.order),m[g]=v.quaternion.clone().setFromEuler(M)}return m}function o(){let f={};for(let[p,m]of Object.entries(t))f[p]=m.quaternion.clone();return f}function a(){let f={};for(let[p,m]of Object.entries(t)){let g=i[p].rotation;f[p]={x:m.rotation.x-g.x,y:m.rotation.y-g.y,z:m.rotation.z-g.z}}return f}function l(f,p,m){for(let[g,v]of Object.entries(t)){let x=f[g]||i[g].quaternion,y=p[g]||i[g].quaternion;v.quaternion.copy(x).slerp(y,m)}s()}function d(f){let p=r(f);for(let[m,g]of Object.entries(t))g.quaternion.copy(p[m]);s()}function h(){for(let[f,p]of Object.entries(t))p.quaternion.copy(i[f].quaternion);s()}let u=Rh.filter(f=>!t[f]);return{profile:e,bones:t,rest:i,missing:u,isSigningReady:u.length===0,createTargets:r,capture:o,capturePose:a,interpolate:l,applyPose:d,reset:h,update:s}}function Qo(c){let e=new Set;function t(n){!n?.dispose||e.has(n)||(e.add(n),n.dispose())}c?.traverse(n=>{t(n.geometry),t(n.skeleton);let i=Array.isArray(n.material)?n.material:[n.material];for(let s of i)if(s){for(let r of Object.values(s))r?.isTexture&&t(r);t(s)}})}var ta=2*1024*1024,Dh=240,Nh=new Set(Jo);function Se(c,e="motionInvalidData"){let t=new Error(e);throw t.detail=c,t}function Pi(c){return c!==null&&typeof c=="object"&&!Array.isArray(c)}function vr(c,e,t=100){return(typeof c!="string"||!c.trim()||c.length>t)&&Se(e),c.trim()}function ea(c,e,t=20){return(!Array.isArray(c)||c.length>t)&&Se(e),[...new Set(c.map(n=>vr(n,e)))]}function Uh(c){(!c?.rest||!c?.profile)&&Se("rig","motionModelNotReady");let e=Object.keys(c.rest).sort().map(t=>{let n=c.bones[t],i=c.rest[t].rotation;return[t,n.name,n.parent?.name||"",i.order,...[i.x,i.y,i.z,...n.position.toArray(),...n.scale.toArray()].map(s=>Number(s.toFixed(9)))]});return{profile:c.profile.id,rest:JSON.stringify(e)}}function qt(c,e){(!Pi(c)||c.type!=="signbridge-motion"||c.version!==1||c.space!=="humanoid-local-v1"||c.unit!=="radians")&&Se("type/version/space/unit");let t=vr(c.id,"id",90);/^custom_[a-zA-Z0-9_-]+$/.test(t)||Se("id");let n=Uh(e);(c.rig?.profile!==n.profile||c.rig?.rest!==n.rest)&&Se("rig","motionRigMismatch"),(!Array.isArray(c.frames)||!c.frames.length||c.frames.length>Dh)&&Se("frames");let i=0,s=c.frames.map((r,o)=>{(!Pi(r?.value)||!Number.isFinite(r.duration)||r.duration<.05||r.duration>10)&&Se(`frames[${o}]`),i+=r.duration;let a={};for(let[l,d]of Object.entries(r.value)){(!Nh.has(l)||!e.bones[l]||!Pi(d))&&Se(`frames[${o}].${l}`);for(let h of["x","y","z"])(!Number.isFinite(d[h])||Math.abs(d[h])>Math.PI*2)&&Se(`${l}.${h}`);a[l]={x:d.x,y:d.y,z:d.z}}return{value:a,duration:r.duration}});return i>120&&Se("duration > 120s"),{type:"signbridge-motion",version:1,id:t,gloss:vr(c.gloss,"gloss"),texts:ea(c.texts,"texts"),tags:ea(c.tags,"tags"),space:"humanoid-local-v1",unit:"radians",rig:n,frames:s}}function Be(c,e=!1){return JSON.stringify(c,(t,n)=>e&&typeof n=="number"?Number(n.toFixed(8)):Pi(n)?Object.fromEntries(Object.keys(n).sort().map(i=>[i,n[i]])):n)}function _r(c){return Be(c,!0)}function H(c,e,t){let n=Math.PI/180;return{x:(c||0)*n,y:(e||0)*n,z:(t||0)*n}}function S(c,e){return{value:c,duration:e||.8}}function na(c,e,t={}){if(!c||!Array.isArray(e)||e.length===0)throw new TypeError("A motion clip requires an id and at least one frame.");return{id:c,version:1,space:"humanoid-local-v1",frames:e,metadata:t}}var Sn=["Index","Middle","Ring","Little"];function gt(c,e,t,[n,i,s]){c[`${e}${t}Proximal`]=H(n,0,0),c[`${e}${t}Intermediate`]=H(i,0,0),c[`${e}${t}Distal`]=H(s,0,0)}function Yt(c,e,t){let[n,i,s]=t;c[`${e}ThumbMetacarpal`]=n,c[`${e}ThumbProximal`]=i,c[`${e}ThumbDistal`]=s}function ia(c,e="right"){if(c==="relax")return{};let t={},n=e==="left"?-1:1,i=[-25,-55,-30],s=[8,14,8],r=[H(-10,0,0),H(-20,0,0),H(-10,0,0)],o=[H(8,0,0),H(14,0,0),H(8,0,0)];if(c==="fist"){for(let a of Sn)gt(t,e,a,i);Yt(t,e,r)}else if(c==="flat"){for(let a of Sn)gt(t,e,a,s);Yt(t,e,o)}else if(c==="point"){for(let a of Sn)gt(t,e,a,a==="Index"?s:i);Yt(t,e,r)}else if(c==="thumbUp"){for(let a of Sn)gt(t,e,a,i);Yt(t,e,[H(0,63*n,63*n),H(0,0,0),H(0,0,0)])}else if(c==="peace"){for(let a of Sn)gt(t,e,a,a==="Index"||a==="Middle"?s:i);Yt(t,e,r)}else if(c==="ok"){gt(t,e,"Index",[-20,-45,-25]);for(let a of["Middle","Ring","Little"])gt(t,e,a,[-15,-35,-20]);Yt(t,e,[H(-10,30*n,0),H(-10,0,0),H(0,0,0)])}return t}function T(c,e,t,n){let i={};if(i.rightShoulder=H(c[0]||0,c[1]||0,c[2]||0),i.rightUpperArm=H(c[3]||0,c[4]||0,c[5]||0),i.rightLowerArm=H(c[6]||0,c[7]||0,c[8]||0),i.rightHand=H(c[9]||0,c[10]||0,c[11]||0),t&&(i.leftShoulder=H(t[0]||0,t[1]||0,t[2]||0),i.leftUpperArm=H(t[3]||0,t[4]||0,t[5]||0),i.leftLowerArm=H(t[6]||0,t[7]||0,t[8]||0),i.leftHand=H(t[9]||0,t[10]||0,t[11]||0)),e){let s=ia(e,"right");for(let r in s)i[r]=s[r]}if(n){let s=ia(n,"left");for(let r in s)i[r]=s[r]}return i}var O=[0,0,0,35,50,-15,15,0,0,0,0,0],rt=[0,0,0,30,50,-10,10,0,0,0,0,0],oa=[0,0,0,55,5,-10,20,0,0,0,10,10],yr=[10,20,0,35,20,0,15,5,0,10,0,0],Li=[10,-20,0,35,-5,0,15,-5,0,10,0,0],sa=[0,0,0,35,40,-10,20,0,0,0,-5,0],xr=[0,0,0,40,50,-15,20,0,0,5,0,0],ra=[15,20,0,50,40,-15,25,5,0,5,0,0],ze={csl_hello:{id:"csl_hello",gloss:"\u4F60\u597D",texts:["\u4F60\u597D","\u60A8\u597D","\u55E8","hello","hi"],tags:["greeting"],frames:[S(T(O,"point"),.6),S(T(O,"thumbUp"),.7)],meta:{handshape:"point+thumbUp",location:"chest",movement:"none"}},csl_thanks:{id:"csl_thanks",gloss:"\u8C22\u8C22",texts:["\u8C22\u8C22","\u591A\u8C22","\u611F\u8C22","thanks"],tags:["polite"],frames:[S(T(oa,"fist"),.8)],meta:{handshape:"fist",location:"chest",movement:"nod"}},csl_yes:{id:"csl_yes",gloss:"\u662F",texts:["\u662F","\u5BF9","\u6B63\u786E","yes","ok"],tags:["confirm"],frames:[S(T(O,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"nod"}},csl_no:{id:"csl_no",gloss:"\u4E0D",texts:["\u4E0D","\u6CA1","\u6CA1\u6709","\u522B","no","not"],tags:["negation"],frames:[S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"point"),.5)],meta:{handshape:"point",location:"chest",movement:"sway"}},csl_good:{id:"csl_good",gloss:"\u597D",texts:["\u597D","\u68D2","\u4F18\u79C0","good","great"],tags:["positive"],frames:[S(T(O,"thumbUp"),.7)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_me:{id:"csl_me",gloss:"\u6211",texts:["\u6211","\u81EA\u5DF1","me","I"],tags:["pronoun"],frames:[S(T([0,0,0,35,50,-15,25,0,0,5,0,0],"point"),.6)],meta:{handshape:"point",location:"chest",movement:"self"}},csl_you:{id:"csl_you",gloss:"\u4F60",texts:["\u4F60","\u60A8","you"],tags:["pronoun"],frames:[S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"point"),.6)],meta:{handshape:"point",location:"forward",movement:"none"}},csl_help:{id:"csl_help",gloss:"\u5E2E\u52A9",texts:["\u5E2E\u52A9","\u5E2E\u5FD9","\u5E2E","help"],tags:["action"],frames:[S(T([0,0,0,40,40,-10,25,0,0,-5,5,0],"flat"),.7)],meta:{handshape:"flat",location:"chest",movement:"support"}},csl_welcome:{id:"csl_welcome",gloss:"\u6B22\u8FCE",texts:["\u6B22\u8FCE","welcome"],tags:["greeting"],frames:[S(T(yr,"flat",Li,"flat"),.8)],meta:{handshape:"flat",location:"side",movement:"open"}},csl_love:{id:"csl_love",gloss:"\u7231",texts:["\u7231","\u559C\u6B22","love","like"],tags:["emotion"],frames:[S(T(rt,"fist",rt,"fist"),.8)],meta:{handshape:"fist",location:"heart",movement:"none"}},csl_goodbye:{id:"csl_goodbye",gloss:"\u518D\u89C1",texts:["\u518D\u89C1","\u62DC\u62DC","bye","goodbye"],tags:["greeting"],frames:[S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.6),S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.4),S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.4)],meta:{handshape:"flat",location:"side",movement:"wave"}},csl_happy:{id:"csl_happy",gloss:"\u5F00\u5FC3",texts:["\u5F00\u5FC3","\u9AD8\u5174","\u5FEB\u4E50","happy"],tags:["emotion"],frames:[S(T([0,0,0,40,50,-15,25,0,0,0,0,0],"flat"),.6)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_true:{id:"csl_true",gloss:"\u771F",texts:["\u771F","\u771F\u7684","\u786E\u5B9E","true","really"],tags:["confirm"],frames:[S(T(O,"point"),.5)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_too:{id:"csl_too",gloss:"\u592A",texts:["\u592A","\u5F88","\u975E\u5E38","very","too"],tags:["degree"],frames:[S(T(O,"thumbUp"),.5)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_what:{id:"csl_what",gloss:"\u4EC0\u4E48",texts:["\u4EC0\u4E48","\u5565","what"],tags:["question"],frames:[S(T(O,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_he:{id:"csl_he",gloss:"\u4ED6",texts:["\u4ED6","\u5979","\u5B83","he","she"],tags:["pronoun"],frames:[S(T([0,0,0,40,60,-15,20,0,0,5,0,0],"point"),.6)],meta:{handshape:"point",location:"side",movement:"none"}},csl_we:{id:"csl_we",gloss:"\u6211\u4EEC",texts:["\u6211\u4EEC","\u54B1\u4EEC","we","us"],tags:["pronoun"],frames:[S(T([0,0,0,30,40,-10,20,0,0,5,0,0],"point"),.7)],meta:{handshape:"point",location:"chest",movement:"arc"}},csl_this:{id:"csl_this",gloss:"\u8FD9",texts:["\u8FD9","\u8FD9\u4E2A","this"],tags:["demonstrative"],frames:[S(T(sa,"point"),.5)],meta:{handshape:"point",location:"down",movement:"none"}},csl_that:{id:"csl_that",gloss:"\u90A3",texts:["\u90A3","\u90A3\u4E2A","that"],tags:["demonstrative"],frames:[S(T([0,0,0,40,60,-15,20,0,0,5,0,0],"point"),.5)],meta:{handshape:"point",location:"forward",movement:"none"}},csl_who:{id:"csl_who",gloss:"\u8C01",texts:["\u8C01","who"],tags:["question"],frames:[S(T(O,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_how:{id:"csl_how",gloss:"\u600E\u4E48",texts:["\u600E\u4E48","\u600E\u6837","how"],tags:["question"],frames:[S(T(O,"flat"),.6)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_where:{id:"csl_where",gloss:"\u54EA",texts:["\u54EA","\u54EA\u91CC","where"],tags:["question"],frames:[S(T(O,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_have:{id:"csl_have",gloss:"\u6709",texts:["\u6709","have","has"],tags:["state"],frames:[S(T(O,"thumbUp"),.6)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_can:{id:"csl_can",gloss:"\u53EF\u4EE5",texts:["\u53EF\u4EE5","\u80FD","can","may"],tags:["modal"],frames:[S(T(O,"ok"),.6)],meta:{handshape:"ok",location:"chest",movement:"nod"}},csl_want:{id:"csl_want",gloss:"\u8981",texts:["\u8981","\u60F3","want","need"],tags:["modal"],frames:[S(T(O,"flat"),.6)],meta:{handshape:"flat",location:"chest",movement:"pull"}},csl_come:{id:"csl_come",gloss:"\u6765",texts:["\u6765","\u8FC7\u6765","come"],tags:["action"],frames:[S(T(xr,"flat"),.6)],meta:{handshape:"flat",location:"side",movement:"beckon"}},csl_go:{id:"csl_go",gloss:"\u53BB",texts:["\u53BB","\u8D70","go"],tags:["action"],frames:[S(T([0,0,0,40,50,-15,25,0,0,0,0,0],"flat"),.5)],meta:{handshape:"flat",location:"forward",movement:"push"}},csl_say:{id:"csl_say",gloss:"\u8BF4",texts:["\u8BF4","\u8BB2","say","speak"],tags:["action"],frames:[S(T([0,0,0,35,40,-15,20,0,0,-5,0,0],"flat"),.6)],meta:{handshape:"flat",location:"mouth",movement:"none"}},csl_see:{id:"csl_see",gloss:"\u770B",texts:["\u770B","\u89C1","see","look"],tags:["action"],frames:[S(T([0,0,0,35,35,-10,20,0,0,0,0,0],"point"),.6)],meta:{handshape:"point",location:"eyes",movement:"none"}},csl_know:{id:"csl_know",gloss:"\u77E5\u9053",texts:["\u77E5\u9053","\u61C2","know","understand"],tags:["cognition"],frames:[S(T(O,"point"),.6)],meta:{handshape:"point",location:"temple",movement:"none"}},csl_big:{id:"csl_big",gloss:"\u5927",texts:["\u5927","big","large"],tags:["size"],frames:[S(T(ra,"flat"),.6)],meta:{handshape:"flat",location:"side",movement:"spread"}},csl_small:{id:"csl_small",gloss:"\u5C0F",texts:["\u5C0F","small","little"],tags:["size"],frames:[S(T([0,0,0,35,30,-10,20,0,0,0,0,0],"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"close"}},csl_many:{id:"csl_many",gloss:"\u591A",texts:["\u591A","\u5F88\u591A","many","much"],tags:["quantity"],frames:[S(T(O,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_up:{id:"csl_up",gloss:"\u4E0A",texts:["\u4E0A","up","above"],tags:["direction"],frames:[S(T([0,0,0,40,40,-15,15,0,0,10,0,0],"point"),.5)],meta:{handshape:"point",location:"up",movement:"none"}},csl_down:{id:"csl_down",gloss:"\u4E0B",texts:["\u4E0B","down","below"],tags:["direction"],frames:[S(T([0,0,0,35,40,-15,25,0,0,-5,0,0],"point"),.5)],meta:{handshape:"point",location:"down",movement:"none"}},csl_now:{id:"csl_now",gloss:"\u73B0\u5728",texts:["\u73B0\u5728","now"],tags:["time"],frames:[S(T(O,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_today:{id:"csl_today",gloss:"\u4ECA\u5929",texts:["\u4ECA\u5929","today"],tags:["time"],frames:[S(T(O,"point"),.5)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_also:{id:"csl_also",gloss:"\u4E5F",texts:["\u4E5F","also","too"],tags:["conjunction"],frames:[S(T(O,"point"),.5)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_all:{id:"csl_all",gloss:"\u90FD",texts:["\u90FD","\u5168\u90E8","all"],tags:["quantity"],frames:[S(T(ra,"flat",Li,"flat"),.6)],meta:{handshape:"flat",location:"side",movement:"arc"}},csl_but:{id:"csl_but",gloss:"\u4F46\u662F",texts:["\u4F46\u662F","\u4F46","but"],tags:["conjunction"],frames:[S(T(O,"point"),.6)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_if:{id:"csl_if",gloss:"\u5982\u679C",texts:["\u5982\u679C","\u8981\u662F","if"],tags:["conjunction"],frames:[S(T(O,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_very:{id:"csl_very",gloss:"\u5F88",texts:["\u5F88","\u975E\u5E38","very","quite"],tags:["degree"],frames:[S(T(O,"thumbUp"),.5)],meta:{handshape:"thumbUp",location:"chest",movement:"none"}},csl_and:{id:"csl_and",gloss:"\u548C",texts:["\u548C","\u8DDF","\u4E0E","and"],tags:["conjunction"],frames:[S(T([0,0,0,35,40,-15,20,0,0,5,0,0],"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_new:{id:"csl_new",gloss:"\u65B0",texts:["\u65B0","new"],tags:["quality"],frames:[S(T(xr,"flat"),.5)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_old:{id:"csl_old",gloss:"\u8001",texts:["\u8001","\u65E7","old"],tags:["quality"],frames:[S(T(sa,"fist"),.5)],meta:{handshape:"fist",location:"chest",movement:"none"}},csl_one:{id:"csl_one",gloss:"\u4E00",texts:["\u4E00","one"],tags:["number"],frames:[S(T(O,"point"),.4)],meta:{handshape:"point",location:"chest",movement:"none"}},csl_two:{id:"csl_two",gloss:"\u4E8C",texts:["\u4E8C","\u4E24","two"],tags:["number"],frames:[S(T(O,"peace"),.4)],meta:{handshape:"peace",location:"chest",movement:"none"}},csl_three:{id:"csl_three",gloss:"\u4E09",texts:["\u4E09","three"],tags:["number"],frames:[S(T(O,"ok"),.4)],meta:{handshape:"ok",location:"chest",movement:"none"}},csl_please:{id:"csl_please",gloss:"\u8BF7",texts:["\u8BF7","please"],tags:["polite"],frames:[S(T(xr,"flat"),.7)],meta:{handshape:"flat",location:"chest",movement:"none"}},csl_do:{id:"csl_do",gloss:"\u505A",texts:["\u505A","\u5E72","do"],tags:["action"],frames:[S(T(O,"fist"),.5)],meta:{handshape:"fist",location:"chest",movement:"none"}},csl_people:{id:"csl_people",gloss:"\u4EBA",texts:["\u4EBA","person","people"],tags:["noun"],frames:[S(T([0,0,0,35,50,-15,25,0,0,0,0,0],"point"),.6)],meta:{handshape:"point",location:"side",movement:"none"}},csl_self:{id:"csl_self",gloss:"\u81EA\u5DF1",texts:["\u81EA\u5DF1","self"],tags:["pronoun"],frames:[S(T(rt,"fist",rt,"fist"),.6)],meta:{handshape:"fist",location:"chest",movement:"self"}}};for(let c of Object.values(ze))c.motion=na(c.id,c.frames,{gloss:c.gloss,tags:c.tags,...c.meta});var Mr={};function j(c,e){Mr[c]=e}j("\u4F60",[S(T(O,"point"),.6)]);j("\u597D",[S(T(O,"thumbUp"),.7)]);j("\u8C22",[S(T(oa,"fist"),.8)]);j("\u6211",[S(T([0,0,0,35,50,-15,25,0,0,5,0,0],"point"),.6)]);j("\u7231",[S(T(rt,"fist",rt,"fist"),.8)]);j("\u662F",[S(T(O,"point"),.6)]);j("\u5BF9",[S(T(O,"point"),.6)]);j("\u4E0D",[S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"point"),.5)]);j("\u5E2E",[S(T([0,0,0,40,40,-10,25,0,0,-5,5,0],"flat"),.6)]);j("\u52A9",[S(T([0,0,0,40,40,-10,25,0,0,-5,5,0],"flat"),.6)]);j("\u518D",[S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.6)]);j("\u89C1",[S(T([0,0,0,40,50,-15,25,0,0,5,0,0],"flat"),.6)]);j("\u6B22",[S(T(yr,"flat",Li,"flat"),.6)]);j("\u8FCE",[S(T(yr,"flat",Li,"flat"),.6)]);j("\u559C",[S(T(rt,"fist",rt,"fist"),.7)]);j(" ",[S({},.3)]);function Fh(){let c={};for(let e of Object.values(ze))for(let t of e.texts)c[t]||(c[t]=e.frames);return c}function Di(c){return c?c.replace(/[，。！？、；："“”（）【】《》\s]+/g," ").replace(/[^\u4e00-\u9fff\u3400-\u4dbf a-zA-Z0-9'’-]/g," ").replace(/\s+/g," ").trim():""}var Oh=new Set(["\u7684","\u4E86","\u7740","\u8FC7","\u5427","\u5417","\u5462","\u554A","\u561B","\u5457","\u54E6","\u55EF","\u5440","\u5566","\u54C8","\u54C7","\u54CE","\u5582","\u4E2A"]),aa=new Intl.Segmenter("zh",{granularity:"word"});function ca(c){return[...aa.segment(c)].filter(e=>e.isWordLike)}function ce(c){let e=ca(Di(c).toLowerCase()).map(t=>t.segment);return e.length?JSON.stringify(e):""}function bn(c=[]){return[...Object.values(ze),...c].flatMap(e=>e.texts.map(t=>({id:e.id,sign:e,text:Di(t).toLowerCase(),tokens:ca(Di(t).toLowerCase()).map(n=>n.segment)}))).filter(e=>e.text&&e.tokens.length).sort((e,t)=>t.text.length-e.text.length)}var la=bn();function kh(){return{frames:[S({},.5)],matches:[]}}function Bh(c,e=12,t=la){let n=String(c).normalize("NFKC"),i=[...aa.segment(n)],s=[],r=[],o=[],a=0,l=d=>[...n.slice(0,d)].length;for(;a<i.length&&s.length<e;){let d=i[a];if(!d.isWordLike){/^[\s\p{P}]*$/u.test(d.segment)||r.push(d.segment),a++;continue}let h=a,u=t.find(g=>{let v=a;for(let x of g.tokens){for(;v<i.length&&!i[v].isWordLike&&/^[\s\p{P}]*$/u.test(i[v].segment);)v++;if(i[v]?.segment.toLowerCase()!==x)return!1;v++}return h=v,!0}),f=d.segment.toLowerCase(),p=u?.sign,m=!u&&Mr[f];if(u||m){u||(h=a+1);let g=i[h-1];s.push({id:u?.id||`char_${f}`,text:u?.text||f,gloss:p?.gloss||f,frames:p?.frames||m,start:l(d.index),end:l(g.index+g.segment.length)}),a=h;continue}Oh.has(f)?o.push(f):r.push(d.segment),a++}return{matches:s,unmatched:r,skipped:o,truncated:a<i.length,remainingText:a<i.length?n.slice(i[a].index):""}}function wn(c,e=12,t=la){let n=Di(c).toLowerCase();if(!n)return null;let i=Bh(n,e,t);return{...i,frames:i.matches.length?[...i.matches.flatMap(s=>s.frames),S({},.25)]:kh().frames,matches:i.matches.map(({id:s,text:r,gloss:o})=>({id:s,text:r,gloss:o}))}}var da=Fh(),ha=Mr;var zh=8*1024*1024,Hh=500;function Jt(c="motionPackInvalid"){throw new Error(c)}function Tn(c,e){(c?.type!=="signbridge-motion-pack"||c.version!==1||typeof c.createdAt!="string"||!Number.isFinite(Date.parse(c.createdAt))||!Array.isArray(c.motions))&&Jt(),c.motions.length||Jt("motionPackEmpty"),c.motions.length>Hh&&Jt("motionPackTooLarge");let t=new Set,n=c.motions.map(s=>{let r=qt(s?.asset,e);return t.has(r.id)&&Jt("motionPackDuplicateId"),t.add(r.id),new Blob([Be(r)]).size>ta&&Jt("motionPackTooLarge"),{asset:r,wasEnabled:s.wasEnabled===!0}}),i={type:"signbridge-motion-pack",version:1,createdAt:c.createdAt,motions:n};return new Blob([JSON.stringify(i,null,2)]).size>zh&&Jt("motionPackTooLarge"),i}function ua(c,e){return Tn({type:"signbridge-motion-pack",version:1,createdAt:new Date().toISOString(),motions:c.map(t=>({asset:t.asset,wasEnabled:t.enabled===!0}))},e)}function Sr(c,e,t){let n=Tn(c,t),i=new Map;function s(l){for(let d of l.texts){let h=ce(d);i.has(h)||i.set(h,new Set),i.get(h).add(l.id)}}Object.values(ze).forEach(s);let r=new Map;for(let[l,d]of Object.entries(e))try{let h=qt(d?.asset,t);if(h.id!==l)continue;r.set(l,h),s(h)}catch{continue}n.motions.forEach(l=>s(l.asset));let o={new:0,existing:0,conflict:0},a=n.motions.map(({asset:l,wasEnabled:d})=>{let h="new";return Object.hasOwn(e,l.id)&&(h=r.has(l.id)&&Be(r.get(l.id))===Be(l)?"existing":"conflict"),o[h]+=1,{id:l.id,gloss:l.gloss,state:h,wasEnabled:d,aliasConflicts:l.texts.filter(u=>{let f=ce(u);return!f||[...i.get(f)].some(p=>p!==l.id)}),emptyTexts:l.texts.length===0}});return{pack:n,items:a,counts:o,revision:Be(e)}}var be="signbridge.motion.v1.",An=ce,fa=new Set(Object.values(ze).flatMap(c=>c.texts.map(An)));function He(c,e=""){let t=new Error(c);return t.detail=e,t}function br(c){return c.enabled===!0&&typeof c.review?.confirmedAt=="string"&&c.review.assetJson===Be(c.asset)}function pa(c,e){return c.texts.length?c.texts.find(t=>!An(t)||e.has(An(t)))??null:"texts"}function Ni(c){let e=new Set(fa),t=[];for(let n of[...c].sort((i,s)=>i.asset.id.localeCompare(s.asset.id)))!br(n)||pa(n.asset,e)!==null||(t.push(n.asset),n.asset.texts.forEach(i=>e.add(An(i))));return t}function ma(c,e=globalThis.chrome?.storage,t=globalThis.navigator?.locks){if(!e?.local)throw He("motionStorageUnavailable");let n=e.local,i=f=>t?t.request(be,f):f();async function s(){let f=await n.get(null),p=[],m=0;for(let[g,v]of Object.entries(f))if(g.startsWith(be))try{let x=qt(v.asset,c);if(g!==be+x.id)throw He("motionInvalidData");p.push({asset:x,enabled:br({...v,asset:x}),review:v.review})}catch{m+=1}return{entries:p,invalidCount:m}}async function r(f){let p=qt(f,c),m={asset:p,enabled:!1,review:null};return await i(()=>n.set({[be+p.id]:m})),m}async function o(f,p,m){return i(async()=>{let{entries:g}=await s(),v=g.find(x=>x.asset.id===f);if(!v)throw He("motionSelectFirst");if(p){if(_r(v.asset)!==_r(m))throw He("motionSaveFirst");let x=new Set(fa);for(let M of g)M.asset.id!==f&&br(M)&&M.asset.texts.forEach(b=>x.add(An(b)));let y=pa(v.asset,x);if(y!==null)throw He("motionAliasConflict",y)}await n.set({[be+f]:{asset:v.asset,enabled:p,review:p?{confirmedAt:new Date().toISOString(),assetJson:Be(v.asset)}:null}})})}async function a(){let f=await n.get(null);return Object.fromEntries(Object.entries(f).filter(([p])=>p.startsWith(be)).map(([p,m])=>[p.slice(be.length),m]))}async function l(){let{entries:f,invalidCount:p}=await s();if(p)throw He("motionPackInvalidStored");return ua(f,c)}async function d(f){let p=Tn(f,c);return Sr(p,await a(),c)}async function h(f,p){if(!t?.request)throw He("motionPackLockUnavailable");let m=Tn(f,c);return i(async()=>{let g=Sr(m,await a(),c);if(g.revision!==p)throw He("motionPackStale");if(g.counts.conflict)throw He("motionPackConflict");let v=new Set(g.items.filter(y=>y.state==="new").map(y=>y.id)),x=Object.fromEntries(m.motions.filter(({asset:y})=>v.has(y.id)).map(({asset:y})=>[be+y.id,{asset:y,enabled:!1,review:null}]));return v.size&&await n.set(x),{imported:v.size,skipped:g.counts.existing}})}function u(f){let p=(m,g)=>{g==="local"&&Object.keys(m).some(v=>v.startsWith(be))&&f()};return e.onChanged.addListener(p),()=>e.onChanged.removeListener(p)}return{list:s,saveDraft:r,setEnabled:o,subscribe:u,exportPack:l,previewPack:d,importPack:h}}var va=256*1024,Ui=5e4,_a=1e3,xa=2e3;function le(c){throw new Error(c)}function Vh(c){let e={amp:"&",lt:"<",gt:">",nbsp:" ",lrm:"",rlm:""};return c.replace(/<[^>]*>/g,"").replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|nbsp|lrm|rlm);/gi,(t,n)=>{let i=n.toLowerCase();if(!i.startsWith("#"))return e[i];let s=i.startsWith("#x")?Number.parseInt(i.slice(2),16):Number.parseInt(i.slice(1),10);return s>0&&s<=1114111&&!(s>=55296&&s<=57343)?String.fromCodePoint(s):t}).replace(/\s+/g," ").trim()}function ga(c,e){let t=e==="srt"?/^(\d{2,}):([0-5]\d):([0-5]\d),(\d{3})$/:/^(?:(\d{2,}):)?([0-5]\d):([0-5]\d)\.(\d{3})$/,n=c.match(t);return n||le("coverageInvalidSubtitles"),Number(n[1]||0)*3600+Number(n[2])*60+Number(n[3])+Number(n[4])/1e3}function ya(c,e="text"){(typeof c!="string"||c.length>Ui)&&le("coverageTooLarge");let t=c.replace(/^\uFEFF/,"").replace(/\r\n?/g,`
`).trim();t||le("coverageEmpty"),["text","srt","vtt"].includes(e)||le("coverageInvalidFormat");let n;if(e==="text")n=t.split(`
`).map(i=>i.trim()).filter(Boolean);else{let i=t.split(/\n[\t ]*\n+/);e==="vtt"&&(/^WEBVTT(?:[\t ]|\n|$)/.test(i[0])||le("coverageInvalidSubtitles"),i[0].includes("-->")&&le("coverageInvalidSubtitles"),i.shift()),n=[];for(let s of i){if(e==="vtt"&&/^(?:NOTE(?:[\t ]|\n|$)|STYLE(?:\n|$)|REGION(?:\n|$))/.test(s))continue;let r=s.split(`
`);r.filter(d=>d.includes("-->")).length!==1&&le("coverageInvalidSubtitles");let o=r.findIndex(d=>d.includes("-->"));(o<0||o>1||e==="srt"&&o===1&&!/^\d+$/.test(r[0]))&&le("coverageInvalidSubtitles");let a=r[o].trim().match(/^(\S+)\s+-->\s+(\S+)(?:[\t ]+.*)?$/);(!a||ga(a[2],e)<=ga(a[1],e))&&le("coverageInvalidSubtitles");let l=Vh(r.slice(o+1).join(" "));l||le("coverageInvalidSubtitles"),n.push(l)}}return n.length||le("coverageEmpty"),(n.length>_a||n.some(i=>i.length>xa))&&le("coverageTooLarge"),n}function Ma(c,e=[]){(!Array.isArray(c)||!c.length||c.length>_a||c.some(l=>typeof l!="string"||l.length>xa)||c.join("").length>Ui)&&le("coverageTooLarge");let t=bn(e),n=new Map,i=0,s=0,r=0,o=c.map((l,d)=>{let h=wn(l,Number.MAX_SAFE_INTEGER,t),u=wn(l,12,t),f=h?.matches||[],p=h?.unmatched||[],m=h?.skipped||[];i+=f.reduce((g,v)=>g+JSON.parse(ce(v.text)).length,0),s+=p.length,r+=m.length;for(let g of p)n.has(g)||n.set(g,{word:g,count:0,segmentCount:0,examples:[]}),n.get(g).count+=1;for(let g of new Set(p)){let v=n.get(g);v.segmentCount+=1,v.examples.length<3&&v.examples.push(d+1)}return{segment:d+1,text:l,matches:f,unmatched:p,skipped:m,truncated:u?.truncated||!1,remainingText:u?.remainingText||""}}),a=i+s;return{type:"signbridge-coverage",version:1,metric:"matched-word-tokens-excluding-skipped",customMotionIds:e.map(l=>l.id).sort(),summary:{segments:c.length,matchedTokens:i,unknownTokens:s,skippedTokens:r,coverage:a?i/a:null,segmentsWithMatches:o.filter(l=>l.matches.length).length,runtimeTruncatedSegments:o.filter(l=>l.truncated).length},unknown:[...n.values()].sort((l,d)=>d.count-l.count||l.word.localeCompare(d.word,"zh")),details:o}}function Sa(c,e=!1){return{...c,includesSourceText:e,details:e?c.details:void 0}}var ba={enabled:!0,avatarSize:260,avatarPosition:"bottom-right",uiLocale:"auto"},wa="signbridge_config";async function Ta(){try{if(typeof chrome<"u"&&chrome.storage){let c=await chrome.storage.sync.get(wa);return{...ba,...c[wa]}}}catch{}return{...ba}}var Gh={corePlayableInstructions:"\u5148\u9009\u62E9\u4E0B\u65B9\u53EF\u64AD\u653E\u4F8B\u53E5\uFF0C\u518D\u70B9\u51FB\u201C\u64AD\u653E\u52A8\u4F5C\u201D\u3002",coreGapExamplesTitle:"\u6682\u4E0D\u80FD\u64AD\u653E\u7684\u4F8B\u53E5\uFF08\u67E5\u770B\u539F\u56E0\uFF09",coreGapExamplesNote:"\u8FD9\u4E9B\u4F8B\u53E5\u4EC5\u7528\u4E8E\u67E5\u770B\u7F3A\u8BCD\u6216\u65B9\u5411\u95EE\u9898\uFF0C\u4E0D\u4F1A\u64AD\u653E\u52A8\u753B\u3002",coreGapExampleLabel:"{text} \xB7 \u4EC5\u5206\u6790\uFF0C\u4E0D\u80FD\u64AD\u653E",coreDirectionUnavailable:"\u201C\u6211\u5E2E\u4F60\uFF0F\u4F60\u5E2E\u6211\u201D\u7684\u65B9\u5411\u52A8\u4F5C\u5C1A\u672A\u786E\u8BA4\uFF0C\u5F53\u524D\u53EA\u5206\u6790\u3001\u4E0D\u64AD\u653E\u3002\u53EF\u5148\u9009\u62E9\u201C\u6211\u8DD1\u6B65\u201D\u7B49\u53EF\u64AD\u653E\u4F8B\u53E5\u3002",coreReadyToPlay:"\u53EF\u64AD\u653E {count} \u4E2A\u52A8\u4F5C\uFF1B\u70B9\u51FB\u201C\u64AD\u653E\u52A8\u4F5C\u201D\u5F00\u59CB\u3002",coreMissingSource:"\u7F3A\u5C11\u52A8\u4F5C \xB7 \u672A\u4F7F\u7528\u5185\u7F6E\u540E\u5907",coreScenarioTitle:"\u65E5\u5E38\u751F\u6D3B\u4E0E\u51FA\u884C \xB7 \u56FA\u5B9A\u573A\u666F\u6F14\u793A",coreScenePlayable:"\u6709\u6838\u5FC3\u52A8\u4F5C\u652F\u6301\u7684\u6709\u9650\u4E2D\u6587\u8868\u8FBE\u8349\u6848",coreSceneGap:"\u7F3A\u8BCD\u6216\u65B9\u5411\u672A\u786E\u8BA4\uFF1A\u4EC5\u67E5\u770B\u89E3\u6790\uFF0C\u4E0D\u64AD\u653E",coreReturn:"\u6838\u5FC3\u6F14\u793A",coreCount:"{count} \u4E2A\u539F\u7247\u5BF9\u9F50\u5019\u9009\u5355\u5143",coreScope:"\u9ED8\u8BA4\u53EA\u4F7F\u7528\u6838\u5FC3\u52A8\u4F5C\u3002\u539F\u7247\u5E27\u533A\u95F4\u7531\u52A9\u624B\u6838\u5BF9\uFF0C\u8BCD\u4E49\u548C\u8BCD\u754C\u5C1A\u672A\u4EBA\u5DE5\u6279\u51C6\uFF1B\u4E0D\u56DE\u9000\u65E7\u52A8\u4F5C\u3002",coreResearchScope:"\u7814\u7A76\u5BF9\u7167\uFF1A\u5F53\u524D\u4F7F\u7528\u5168\u5019\u9009\u3001\u65E7\u62DF\u5408\u6216\u5185\u7F6E\u6765\u6E90\uFF0C\u672A\u7ECF\u8FC7\u672C\u8F6E\u6838\u5FC3\u8BCD\u754C\u7B5B\u9009\u3002\u8FD4\u56DE\u6838\u5FC3\u6F14\u793A\u53EF\u6062\u590D\u53D7\u9650\u8303\u56F4\u3002",coreModeDescription:"\u53EA\u5339\u914D\u539F\u7247\u5BF9\u9F50\u7684\u6838\u5FC3\u5355\u5143\u3002\u7F3A\u8BCD\u3001\u65B9\u5411\u7F3A\u53E3\u6216\u4E0D\u652F\u6301\u7684\u53E5\u5F0F\u4F1A\u4FDD\u7559\u6574\u53E5\u5E76\u505C\u6B62\u7EC4\u5408\u3002",coreCatalog:"{count} \u4E2A\u6709\u539F\u7247\u533A\u95F4\u548C\u4FEE\u590D\u9AA8\u9ABC\u6765\u6E90\u7684\u6838\u5FC3\u5019\u9009\uFF1B\u4E0D\u542B\u6574\u53E5\u67E5\u8868\u6216\u5185\u7F6E\u540E\u5907\u3002",coreSource:"\u539F\u7247\u533A\u95F4 \xB7 \u6838\u5FC3\u5019\u9009\uFF08\u8BCD\u4E49\u672A\u6279\u51C6\uFF09",coreGap:"\u7F3A\u5C11\u6838\u5FC3\u52A8\u4F5C\uFF1A{words}\u3002\u6574\u53E5\u5DF2\u4FDD\u7559\uFF0C\u672A\u56DE\u9000\u65E7\u52A8\u4F5C\u3002",coreBlocked:"\u53E5\u5F0F\u6216\u52A8\u4F5C\u8BC1\u636E\u4ECD\u6709\u7F3A\u53E3\uFF0C\u4FDD\u7559\u539F\u6587\u5E76\u6682\u505C\u64AD\u653E\u3002",coreExact:"\u5DF2\u627E\u5230\u6838\u5FC3\u5019\u9009\u533A\u95F4\uFF1B\u8FD9\u662F\u539F\u7247\u6807\u7B7E\u652F\u6301\u7684\u6F14\u793A\uFF0C\u4E0D\u4EE3\u8868\u8BED\u4E49\u6279\u51C6\u3002",coreEvidenceHeading:"\u672C\u6B21\u52A8\u4F5C\u7684\u539F\u7247\u4E0E\u5E27\u533A\u95F4",coreOriginal:"{word}\uFF1A\u67E5\u770B\u539F\u7247\uFF08\u6E90\u7247\u6BB5\u7B2C {start}\u2013{end} \u5E27\uFF09",coreAlignment:"{word}\uFF1A\u67E5\u770B\u6765\u6E90\u8BB0\u5F55",coreIssueDirection:"\u5E2E\u52A9\u7684\u65BD\u4E8B/\u53D7\u4E8B\u5DF2\u89E3\u6790\uFF0C\u4F46\u7F3A\u5C11\u7ECF\u6838\u5BF9\u7684\u6307\u5411\u52A8\u4F5C\uFF0C\u6682\u4E0D\u64AD\u653E\u3002",coreIssueScope:"\u5426\u5B9A\u3001\u60C5\u6001\u6216\u591A\u5206\u53E5\u8303\u56F4\u8D85\u51FA\u672C\u8F6E\u8868\u8FBE\u7EA6\u675F\uFF0C\u6682\u4E0D\u7EC4\u5408\u3002",coreIssueQuestion:"\u7591\u95EE\u6216\u591A\u5206\u53E5\u6240\u9700\u52A8\u4F5C\u8BC1\u636E\u672A\u9F50\uFF0C\u6682\u4E0D\u7EC4\u5408\u3002",coreIssueUnknown:"\u8F93\u5165\u672A\u88AB\u5F53\u524D\u6709\u9650\u53E5\u5F0F\u5B8C\u6574\u89E3\u6790\uFF0C\u539F\u6587\u672A\u4E22\u5F03\u3002",coreInvalidAsset:"\u6838\u5FC3\u52A8\u4F5C\u6765\u6E90\u6216\u5E27\u533A\u95F4\u6821\u9A8C\u5931\u8D25",nativeMode:"\u65B0\u9AA8\u9ABC\u5019\u9009\u5C55\u793A",nativeRepairSummary:"\u5F53\u524D\u4E3A\u52A8\u4F5C\u4FEE\u590D\u7248\uFF1A{count} \u6BB5\u5DF2\u91CD\u505A\u80A9\u81C2\u6BD4\u4F8B\u6620\u5C04\u3001\u624B\u6307\u53BB\u6296\u4E0E\u7A7F\u63D2\u7B5B\u67E5\u3002\u95EE\u9898\u7247\u6BB5\u5DF2\u79FB\u51FA\uFF1B\u8BCD\u4E49\u4ECD\u672A\u6838\u51C6\u3002",nativeCatalog:"\u672C\u8F6E {count} \u6BB5\u6280\u672F\u5019\u9009\uFF1B\u540C\u540D\u52A8\u4F5C\u4FDD\u7559\u4E0D\u540C\u7248\u672C\u3002\u5019\u9009\u6807\u7B7E\u5C1A\u672A\u6838\u51C6\u3002",nativeExactNote:"\u5339\u914D\u5230\u5B8C\u6574\u89C6\u9891\u5019\u9009\uFF1B\u8FD9\u662F\u6807\u7B7E\u68C0\u7D22\uFF0C\u5C1A\u672A\u6838\u51C6\u8BCD\u4E49\u3002",nativeUnitSources:"\u7EC4\u5408\u4EC5\u4E3A Demo \u8349\u6848\uFF0C\u5404\u5355\u5143\u6765\u6E90\uFF1A{sources}\u3002\u65B0\u5019\u9009\u4E0E\u5185\u7F6E\u5355\u5143\u5747\u672A\u83B7\u5F97\u672C\u8F6E\u8BED\u4E49\u6279\u51C6\u3002",nativeModeDescription:"\u4EC5\u4F7F\u7528\u6280\u672F\u7B5B\u9009\u901A\u8FC7\u7684\u65B0\u9AA8\u9ABC\u5019\u9009\uFF1B\u57FA\u672C\u89D2\u8272\u53E5\u53EF\u6DF7\u5408\u660E\u786E\u6807\u6CE8\u7684\u5185\u7F6E\u5355\u5143\u3002\u8BCD\u4E49\u3001\u8BCD\u754C\u53CA\u4E2D\u56FD\u624B\u8BED\u8BED\u6CD5\u672A\u6838\u51C6\u3002",nativeCount:"\u65B0\u9AA8\u9ABC\u5019\u9009",nativeSource:"\u539F\u89C6\u9891\u62DF\u5408 \xB7 \u6280\u672F\u5019\u9009\uFF08\u672A\u6838\u51C6\u8BCD\u4E49\uFF09",nativeWarning:"\u65B0\u5E93\u901A\u8FC7\u4EBA\u7269\u9AA8\u9ABC\u6570\u503C\u7B5B\u67E5\uFF0C\u4ECD\u4E0D\u4FDD\u8BC1\u96F6\u6296\u52A8\u6216\u8BED\u4E49\u6B63\u786E\u3002\u5019\u9009\u9700\u4E3B\u52A8\u9009\u62E9\uFF1B\u4ED6/\u6211\u4EEC\u7B49\u6CA1\u6709\u65B0\u52A8\u4F5C\u65F6\u660E\u786E\u4F7F\u7528\u5185\u7F6E\u5355\u5143\u3002",nativeInvalidAsset:"\u65B0\u9AA8\u9ABC\u5019\u9009\u8D44\u6E90\u6821\u9A8C\u5931\u8D25",nativeToken:"\u539F\u89C6\u9891 SMPL-X \u62DF\u5408\u5E76\u9884\u7F16\u8BD1\u4E3A\u4EBA\u7269\u56DB\u5143\u6570\uFF1B\u672A\u7ECF\u8FC7\u65B0\u6A21\u578B\u8BAD\u7EC3\u3002",optimizationAdaptiveWarning:"\u81EA\u9002\u5E94\u8FC7\u6EE4\u4EC5\u4E3A\u7814\u7A76\u5BF9\u7167\uFF1A\u516D\u627995\u6761\u52A8\u4F5C\u672A\u6709\u7247\u6BB5\u540C\u65F6\u901A\u8FC7\u6296\u52A8\u3001\u624B\u8155\u4E0E\u52A8\u4F5C\u8303\u56F4\u6570\u503C\u95E8\u69DB\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u5E94\u7528\u3002\u9010\u6761\u590D\u6838\u524D\u8BF7\u4FDD\u7559\u539F\u65B9\u6848\u6216\u539F\u59CB\u663E\u793A\u3002",optimizationDisplayProfile:"\u663E\u793A\u8FC7\u6EE4\u5BF9\u7167",optimizationAssetProfile:"\u539F\u6709\u914D\u7F6E\uFF08\u9ED8\u8BA4\uFF09",optimizationAdaptiveProfile:"\u5B9E\u9A8C\u5BF9\u7167\uFF1A\u5B64\u7ACB\u5C16\u5CF0\uFF0C\u975E\u63A8\u8350\u914D\u7F6E",workbenchCatalogCount:"\u5F53\u524D\u53EF\u9009 {count} \u6761\u3002\u5339\u914D\u8868\u793A\u6709\u52A8\u4F5C\u6570\u636E\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u542B\u4E49\u5DF2\u6838\u51C6\u3002",workbenchScope:"\u7814\u7A76\u6F14\u793A\uFF1A\u5F53\u524D\u64AD\u653E\u5DF2\u6709\u52A8\u4F5C\u3002\u672A\u8986\u76D6\u5185\u5BB9\u4F1A\u63D0\u793A\uFF1B\u52A8\u4F5C\u64AD\u653E\u4E0D\u4EE3\u8868\u6587\u5B57\u5DF2\u88AB\u7406\u89E3\u3002",workbenchServiceHandoff:"\u610F\u601D\u5206\u6790\u7531\u672C\u673A\u670D\u52A1\u63D0\u4F9B\u3002\u6309\u94AE\u4F1A\u5148\u68C0\u67E5\u670D\u52A1\u662F\u5426\u5DF2\u542F\u52A8\uFF1B\u8DF3\u8F6C\u4E0D\u643A\u5E26\u53E3\u4EE4\u6216\u8F93\u5165\u6587\u5B57\u3002",workbenchOpenService:"\u6253\u5F00\u672C\u673A\u670D\u52A1\u5206\u6790\u9875",workbenchCsl:"\u5F53\u524D\u652F\u6301\uFF1A\u4E2D\u56FD\u624B\u8BED",workbenchTextPreview:"\u6587\u5B57\u9884\u89C8",workbenchOpen:"\u6253\u5F00\u5DE5\u4F5C\u53F0",workbenchModelDemo:"\u6A21\u578B\u6F14\u793A Demo",workbenchSettings:"SignBridge \u8BBE\u7F6E",workbenchSettingsLead:"\u663E\u793A\u4E0E\u58F0\u97F3\u7EDF\u4E00\u8BBE\u7F6E\u3002\u7F51\u9875\u5B57\u5E55\u6309\u4E2D\u6587\u8BFB\u53D6\uFF0C\u58F0\u97F3\u8BC6\u522B\u53EF\u5355\u72EC\u914D\u7F6E\u8BED\u8A00\u3002",workbenchDisplay:"\u663E\u793A",workbenchSystemLanguage:"\u8DDF\u968F\u7CFB\u7EDF",workbenchChinese:"\u4E2D\u6587",workbenchLocaleChinese:"\u7B80\u4F53\u4E2D\u6587",workbenchLocaleEnglish:"English",workbenchLocaleJapanese:"\u65E5\u672C\u8A9E",workbenchAsrLead:"\u65E0\u5B57\u5E55\u65F6\u53EF\u5728\u63D2\u4EF6\u4E2D\u4E3B\u52A8\u5F00\u542F\u58F0\u97F3\u8BC6\u522B\u3002\u9ED8\u8BA4\u4F7F\u7528\u672C\u5730 Whisper\uFF1B\u4E0B\u8F7D\u6A21\u578B\u4E0D\u4F1A\u81EA\u52A8\u5F00\u59CB\u5F55\u97F3\u3002",workbenchAdvancedAsr:"\u9AD8\u7EA7\u58F0\u97F3\u8BBE\u7F6E\uFF1A\u8BC6\u522B\u65B9\u5F0F\u3001\u6A21\u578B\u4E0E\u97F3\u9891\u53C2\u6570",workbenchSettingsSaved:"\u663E\u793A\u548C\u58F0\u97F3\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002\u5DF2\u6253\u5F00\u7684\u865A\u62DF\u4EBA\u5927\u5C0F\u540C\u6B65\u66F4\u65B0\uFF1B\u754C\u9762\u8BED\u8A00\u91CD\u65B0\u6253\u5F00\u76F8\u5173\u9875\u9762\u540E\u751F\u6548\u3002",workbenchTasks:"\u5DE5\u4F5C\u53F0\u4EFB\u52A1",workbenchMotion:"\u52A8\u4F5C\u6F14\u793A",workbenchMeaning:"\u610F\u601D\u5206\u6790\uFF08\u8BAD\u7EC3\u6A21\u578B\uFF09",workbenchResearch:"\u7814\u7A76\u5DE5\u5177\u4E0E\u6280\u672F\u8BE6\u60C5",workbenchResearchLead:"\u5236\u4F5C\u548C\u6838\u9A8C\u5DF2\u6709\u52A8\u4F5C\uFF0C\u67E5\u770B\u6765\u6E90\u6216\u6BD4\u8F83\u89C4\u5219\u5206\u6790\u3002\u8FD9\u91CC\u7684\u5DE5\u5177\u4E0D\u4F1A\u81EA\u52A8\u4EA7\u751F\u4E2D\u56FD\u624B\u8BED\u6279\u51C6\u3002",workbenchTools:"\u52A8\u4F5C\u5236\u4F5C\u4E0E\u68C0\u67E5",workbenchExtensionTools:"\u52A8\u4F5C\u5236\u4F5C\u3001\u8986\u76D6\uFF0F\u8865\u8BCD\u4E0E\u9A8C\u6536\u5DE5\u5177\u9700\u8981 Chrome \u6269\u5C55\u73AF\u5883\u3002\u8BF7\u52A0\u8F7D\u672C\u6B21\u6784\u5EFA\u7684\u6269\u5C55\u76EE\u5F55\uFF0C\u518D\u4ECE\u63D2\u4EF6\u6253\u5F00\u5DE5\u4F5C\u53F0\u3002",workbenchAuthoring:"\u52A8\u4F5C\u5236\u4F5C",workbenchPose:"\u7F16\u8F91\u5355\u5E27\u59FF\u52BF",workbenchSequence:"\u7F16\u6392\u591A\u5E27\u52A8\u4F5C",workbenchRouting:"\u6765\u6E90\u9009\u62E9\u4E0E\u89C4\u5219\u5BF9\u7167",workbenchModeAutoDescription:"\u81EA\u52A8\u5339\u914D\uFF1A\u4F18\u5148\u4F7F\u7528\u5B8C\u6574\u53C2\u8003\u53E5\uFF0C\u518D\u6309\u53EF\u7528\u52A8\u4F5C\u8865\u9F50\u8BCD\u5E93\u7247\u6BB5\uFF1B\u7F3A\u5931\u5185\u5BB9\u4F1A\u6807\u51FA\uFF0C\u4E0D\u4F1A\u9759\u9ED8\u66FF\u6362\u3002",workbenchModeT08Description:"\u53C2\u8003\u4E0E\u5B9E\u9A8C\u52A8\u4F5C\uFF1A\u53EA\u7B5B\u9009\u5DF2\u6709 T08 \u53C2\u8003\u548C\u62DF\u5408\u5019\u9009\uFF0C\u4E0D\u56DE\u9000\u5230\u5185\u7F6E\u8BCD\u5E93\uFF1B\u5019\u9009\u4E0D\u4EE3\u8868\u8BED\u4E49\u6216\u52A8\u4F5C\u8D28\u91CF\u5DF2\u6279\u51C6\u3002",workbenchModeDictionaryDescription:"\u5185\u7F6E\u8BCD\u5E93\uFF1A\u4EC5\u4F7F\u7528\u5DF2\u6536\u5F55\u7684\u8BCD\u6761\u52A8\u4F5C\u3002\u5F53\u524D\u5DF2\u5207\u5230\u8BCD\u6761\u76EE\u5F55\uFF0C\u4E0D\u8C03\u7528 T08 \u53C2\u8003\u53E5\u3002",workbenchModeSemanticDescription:"\u89C4\u5219\u7814\u7A76\u4EC5\u663E\u793A\u4E2D\u6587\u89E3\u6790\u8349\u6848\uFF0C\u4E0D\u64AD\u653E\u52A8\u4F5C\uFF0C\u4E5F\u4E0D\u8C03\u7528\u8BAD\u7EC3\u89D2\u8272\u6A21\u578B\u3002",workbenchPresentation:"\u89C6\u89D2\u4E0E\u663E\u793A\u5904\u7406",workbenchRuleOnly:"\u5F53\u524D\u4E3A\u89C4\u5219\u5206\u6790\u5BF9\u7167\uFF0C\u53EA\u8F93\u51FA\u8349\u6848\uFF1B\u4E0D\u8FDE\u63A5\u8BAD\u7EC3\u6A21\u578B\uFF0C\u4E5F\u4E0D\u64AD\u653E\u52A8\u4F5C\u3002",workbenchForcedSource:"\u5F53\u524D\u9650\u5B9A\u4E86\u52A8\u4F5C\u6765\u6E90\u3002\u5173\u95ED\u7814\u7A76\u533A\u57DF\u5373\u53EF\u6062\u590D\u81EA\u52A8\u5339\u914D\u3002",workbenchStart:"\u5F00\u59CB\u5B57\u5E55\u8F85\u52A9",workbenchStop:"\u505C\u6B62\u8F85\u52A9",workbenchRunning:"\u5B57\u5E55\u8F85\u52A9\u4E2D"},Wh={corePlayableInstructions:"Choose a playable example below, then click Play motion.",coreGapExamplesTitle:"Unavailable examples (view reasons)",coreGapExamplesNote:"These examples show missing motions or unresolved direction. They do not play animation.",coreGapExampleLabel:"{text} \xB7 Analysis only, no playback",coreDirectionUnavailable:"The direction for \u201CI help you / you help me\u201D is unverified. Analysis only. Choose a playable example such as \u201C\u6211\u8DD1\u6B65\u201D.",coreReadyToPlay:"{count} motions available. Click Play motion to start.",coreMissingSource:"Missing motion \xB7 No authored fallback used",coreScenarioTitle:"Daily life and travel \xB7 Frozen scenario demo",coreScenePlayable:"Bounded Chinese draft with core motion support",coreSceneGap:"Missing motion or unverified direction: analysis only, no playback",coreReturn:"Core demo",coreCount:"{count} source-aligned candidate units",coreScope:"Core motions only. Assistant-proposed source intervals; meanings and boundaries are not human-approved. No legacy fallback.",coreResearchScope:"Research comparison: full candidates, legacy fits or authored units are outside the core boundary screen. Return to the core demo for the bounded scope.",coreModeDescription:"Match source-aligned core units only. Missing signs, direction or unsupported structure retain the entire input and block composition.",coreCatalog:"{count} source-bound core candidates; no whole-sentence lookup or authored fallback.",coreSource:"Source interval \xB7 Core candidate (meaning unapproved)",coreGap:"Missing core motions: {words}. Entire input retained; no legacy fallback.",coreBlocked:"Sentence structure or motion evidence is incomplete. Input retained; playback blocked.",coreExact:"Source-supported core interval found; candidate demo only, no semantic approval.",coreEvidenceHeading:"Source video and frame interval",coreOriginal:"{word}: original clip (source-clip frames {start}\u2013{end})",coreAlignment:"{word}: provenance record",coreIssueDirection:"Actor and recipient parsed, but directional help motion is unverified; playback blocked.",coreIssueScope:"Negation, modality or clause scope exceeds the bounded contract.",coreIssueQuestion:"Question or multiple-clause motion evidence is incomplete.",coreIssueUnknown:"Input is outside the bounded parser; the original is retained.",coreInvalidAsset:"Core motion provenance or frame-interval validation failed",nativeMode:"New skeleton candidates",nativeRepairSummary:"Motion repair build: {count} clips rebuilt with proportion-aware arms, finger denoising and penetration screening. Failed clips excluded; meanings unverified.",nativeCatalog:"{count} technical candidates; same-label variants retained. Candidate meanings are unverified.",nativeExactNote:"Complete video candidate matched by label; meaning remains unverified.",nativeUnitSources:"Demo draft unit sources: {sources}. No new semantic approval is inferred.",nativeModeDescription:"Technical candidates with bounded role drafts. Authored fallback units are labeled. Meaning, boundaries and CSL grammar remain unverified.",nativeCount:"New skeleton candidates",nativeSource:"Video fit \xB7 Technical candidate (meaning unverified)",nativeWarning:"Target-rig numeric checks do not guarantee jitter-free or semantically correct motion. Select candidates explicitly; missing he/we motions use labeled authored units.",nativeInvalidAsset:"Native candidate asset verification failed",nativeToken:"Video SMPL-X fit precompiled to avatar quaternions; no new model training.",optimizationAdaptiveWarning:"Adaptive filtering is comparison-only: 0 of 95 motions met the combined jitter, wrist and range gate. It is never applied automatically.",optimizationDisplayProfile:"Display filter comparison",optimizationAssetProfile:"Asset profile (default)",optimizationAdaptiveProfile:"Experimental isolated-spike filter",workbenchCatalogCount:"{count} entries available. Matching indicates motion data, not linguistic approval.",workbenchScope:"Research demo: plays existing motions and reports gaps. Meaning analysis and motion playback are separate tasks.",workbenchServiceHandoff:"Meaning analysis runs in the local service. Open its analysis page and enter the token there. Navigation carries no token or input text.",workbenchOpenService:"Open local analysis service",workbenchCsl:"Supported: Chinese Sign Language",workbenchTextPreview:"Text preview",workbenchOpen:"Open workspace",workbenchModelDemo:"Model Demo",workbenchSettings:"SignBridge settings",workbenchSettingsLead:"Display and audio in one place. Subtitles are read as Chinese; ASR language is configured separately.",workbenchDisplay:"Display",workbenchSystemLanguage:"Use system language",workbenchChinese:"Chinese",workbenchLocaleChinese:"\u7B80\u4F53\u4E2D\u6587",workbenchLocaleEnglish:"English",workbenchLocaleJapanese:"\u65E5\u672C\u8A9E",workbenchAsrLead:"Enable audio recognition from the extension when subtitles are unavailable. Local Whisper is the default; downloading a model does not start recording.",workbenchAdvancedAsr:"Advanced audio: provider, model and capture settings",workbenchSettingsSaved:"Display and audio settings saved. Open avatars resize now; reopen other pages to apply the interface language.",workbenchTasks:"Workspace tasks",workbenchMotion:"Motion preview",workbenchMeaning:"Meaning analysis (trained model)",workbenchResearch:"Research tools and technical details",workbenchResearchLead:"Create and review existing motions, inspect sources or compare rule analysis. These tools never grant CSL approval automatically.",workbenchTools:"Motion creation and checks",workbenchExtensionTools:"Motion creation, coverage and review require the Chrome extension. Load this build as an extension and open the workspace from its popup.",workbenchAuthoring:"Create motions",workbenchPose:"Edit a single pose",workbenchSequence:"Arrange motion frames",workbenchRouting:"Source selection and rule comparison",workbenchModeAutoDescription:"Automatic matching: prefer complete reference phrases, then fill gaps with available dictionary entries. Unsupported text remains visible.",workbenchModeT08Description:"Reference and experimental motions: use existing T08 references and fit candidates only; do not fall back to dictionary motions.",workbenchModeDictionaryDescription:"Built-in dictionary: use recorded word motions only. The catalog switches to word entries and excludes T08 phrase references.",workbenchModeSemanticDescription:"Rule research shows a Chinese analysis draft only; it does not play motion or call the trained role model.",workbenchPresentation:"View and display processing",workbenchRuleOnly:"Rule comparison produces a draft only. It does not connect to the trained model or play motion.",workbenchForcedSource:"Motion sources are restricted. Close research details to restore automatic matching.",workbenchStart:"Start subtitle assistance",workbenchStop:"Stop assistance",workbenchRunning:"Subtitle assistance active"},Xh={corePlayableInstructions:"\u4E0B\u306E\u518D\u751F\u53EF\u80FD\u306A\u4F8B\u6587\u3092\u9078\u3073\u3001\u300C\u52D5\u4F5C\u3092\u518D\u751F\u300D\u3092\u62BC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coreGapExamplesTitle:"\u518D\u751F\u3067\u304D\u306A\u3044\u4F8B\u6587\uFF08\u7406\u7531\u3092\u898B\u308B\uFF09",coreGapExamplesNote:"\u52D5\u4F5C\u306E\u4E0D\u8DB3\u3084\u65B9\u5411\u306E\u554F\u984C\u3092\u78BA\u8A8D\u3059\u308B\u4F8B\u6587\u3067\u3059\u3002\u30A2\u30CB\u30E1\u30FC\u30B7\u30E7\u30F3\u306F\u518D\u751F\u3055\u308C\u307E\u305B\u3093\u3002",coreGapExampleLabel:"{text}\u30FB\u89E3\u6790\u306E\u307F\u3001\u518D\u751F\u4E0D\u53EF",coreDirectionUnavailable:"\u300C\u79C1\u304C\u3042\u306A\u305F\u3092\u52A9\u3051\u308B\uFF0F\u3042\u306A\u305F\u304C\u79C1\u3092\u52A9\u3051\u308B\u300D\u306E\u65B9\u5411\u52D5\u4F5C\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002\u89E3\u6790\u306E\u307F\u3002\u300C\u6211\u8DD1\u6B65\u300D\u306A\u3069\u306E\u518D\u751F\u53EF\u80FD\u306A\u4F8B\u6587\u3092\u9078\u3093\u3067\u304F\u3060\u3055\u3044\u3002",coreReadyToPlay:"{count} \u500B\u306E\u52D5\u4F5C\u3092\u518D\u751F\u3067\u304D\u307E\u3059\u3002\u300C\u52D5\u4F5C\u3092\u518D\u751F\u300D\u3092\u62BC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coreMissingSource:"\u52D5\u4F5C\u4E0D\u8DB3\u30FB\u5185\u8535\u52D5\u4F5C\u3078\u306E\u4EE3\u66FF\u306A\u3057",coreScenarioTitle:"\u65E5\u5E38\u751F\u6D3B\u3068\u79FB\u52D5\u30FB\u56FA\u5B9A\u30B7\u30CA\u30EA\u30AA\u30C7\u30E2",coreScenePlayable:"\u30B3\u30A2\u52D5\u4F5C\u306B\u5BFE\u5FDC\u3057\u305F\u9650\u5B9A\u7684\u306A\u4E2D\u56FD\u8A9E\u8868\u73FE\u306E\u8349\u6848",coreSceneGap:"\u52D5\u4F5C\u4E0D\u8DB3\u307E\u305F\u306F\u65B9\u5411\u672A\u78BA\u8A8D\u3002\u89E3\u6790\u306E\u307F\u3067\u518D\u751F\u3057\u307E\u305B\u3093",coreReturn:"\u30B3\u30A2\u30C7\u30E2",coreCount:"\u539F\u52D5\u753B\u5BFE\u5FDC\u306E\u5019\u88DC {count} \u5358\u4F4D",coreScope:"\u30B3\u30A2\u52D5\u4F5C\u306E\u307F\u3002\u533A\u9593\u306F\u52A9\u624B\u306E\u5019\u88DC\u5224\u65AD\u3067\u3001\u610F\u5473\u3068\u8A9E\u5883\u754C\u306F\u4EBA\u306E\u627F\u8A8D\u306A\u3057\u3002\u65E7\u52D5\u4F5C\u3078\u81EA\u52D5\u79FB\u884C\u3057\u307E\u305B\u3093\u3002",coreResearchScope:"\u7814\u7A76\u6BD4\u8F03\uFF1A\u5168\u5019\u88DC\u30FB\u65E7\u52D5\u4F5C\u30FB\u5185\u8535\u52D5\u4F5C\u306F\u4ECA\u56DE\u306E\u30B3\u30A2\u5883\u754C\u691C\u67FB\u306E\u7BC4\u56F2\u5916\u3067\u3059\u3002\u30B3\u30A2\u30C7\u30E2\u3078\u623B\u308B\u3068\u7BC4\u56F2\u3092\u9650\u5B9A\u3057\u307E\u3059\u3002",coreModeDescription:"\u539F\u52D5\u753B\u306B\u5BFE\u5FDC\u3059\u308B\u30B3\u30A2\u5358\u4F4D\u3060\u3051\u3092\u4F7F\u7528\u3002\u4E0D\u8DB3\u3084\u65B9\u5411\u3001\u672A\u5BFE\u5FDC\u6587\u578B\u306F\u5168\u6587\u3092\u4FDD\u6301\u3057\u518D\u751F\u3092\u505C\u6B62\u3057\u307E\u3059\u3002",coreCatalog:"\u51FA\u5178\u4ED8\u304D\u30B3\u30A2\u5019\u88DC {count} \u4EF6\u3002\u6587\u5168\u4F53\u691C\u7D22\u3084\u5185\u8535\u52D5\u4F5C\u3078\u306E\u81EA\u52D5\u79FB\u884C\u306A\u3057\u3002",coreSource:"\u539F\u52D5\u753B\u533A\u9593\u30FB\u30B3\u30A2\u5019\u88DC\uFF08\u8A9E\u7FA9\u672A\u627F\u8A8D\uFF09",coreGap:"\u4E0D\u8DB3\u3059\u308B\u30B3\u30A2\u52D5\u4F5C\uFF1A{words}\u3002\u5168\u6587\u3092\u4FDD\u6301\u3057\u3001\u65E7\u52D5\u4F5C\u3078\u79FB\u884C\u3057\u307E\u305B\u3093\u3002",coreBlocked:"\u6587\u69CB\u9020\u307E\u305F\u306F\u52D5\u4F5C\u6839\u62E0\u304C\u4E0D\u8DB3\u3002\u539F\u6587\u3092\u4FDD\u6301\u3057\u3066\u518D\u751F\u3092\u505C\u6B62\u3057\u307E\u3059\u3002",coreExact:"\u539F\u52D5\u753B\u306B\u5BFE\u5FDC\u3059\u308B\u5019\u88DC\u533A\u9593\u3067\u3059\u3002\u610F\u5473\u306E\u627F\u8A8D\u3092\u793A\u3059\u3082\u306E\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",coreEvidenceHeading:"\u539F\u52D5\u753B\u3068\u30D5\u30EC\u30FC\u30E0\u533A\u9593",coreOriginal:"{word}\uFF1A\u539F\u52D5\u753B\uFF08\u5143\u30AF\u30EA\u30C3\u30D7\u306E {start}\u2013{end} \u30D5\u30EC\u30FC\u30E0\uFF09",coreAlignment:"{word}\uFF1A\u51FA\u5178\u8A18\u9332",coreIssueDirection:"\u52D5\u4F5C\u8005\u3068\u5BFE\u8C61\u306F\u89E3\u6790\u6E08\u307F\u3067\u3059\u304C\u3001\u52A9\u3051\u308B\u65B9\u5411\u306E\u52D5\u4F5C\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002",coreIssueScope:"\u5426\u5B9A\u30FB\u6CD5\u6027\u30FB\u7BC0\u306E\u7BC4\u56F2\u304C\u4ECA\u56DE\u306E\u5236\u7D04\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002",coreIssueQuestion:"\u7591\u554F\u3084\u8907\u6587\u306B\u5FC5\u8981\u306A\u52D5\u4F5C\u6839\u62E0\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u307E\u3059\u3002",coreIssueUnknown:"\u9650\u5B9A\u6587\u578B\u3067\u5168\u6587\u3092\u89E3\u6790\u3067\u304D\u307E\u305B\u3093\u3002\u539F\u6587\u306F\u4FDD\u6301\u3055\u308C\u307E\u3059\u3002",coreInvalidAsset:"\u30B3\u30A2\u52D5\u4F5C\u306E\u51FA\u5178\u307E\u305F\u306F\u30D5\u30EC\u30FC\u30E0\u533A\u9593\u691C\u8A3C\u306B\u5931\u6557\u3057\u307E\u3057\u305F",nativeMode:"\u65B0\u3057\u3044\u9AA8\u683C\u5019\u88DC",nativeRepairSummary:"\u52D5\u4F5C\u4FEE\u6B63\u7248\uFF1A{count} \u4EF6\u306E\u8155\u306E\u6BD4\u7387\u3001\u6307\u306E\u63FA\u308C\u3001\u4EA4\u5DEE\u3092\u518D\u691C\u67FB\u3002\u554F\u984C\u5019\u88DC\u306F\u9664\u5916\u3002\u8A9E\u7FA9\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002",nativeCatalog:"\u6280\u8853\u5019\u88DC {count} \u4EF6\u3002\u540C\u540D\u306E\u5225\u52D5\u4F5C\u3092\u4FDD\u6301\u3002\u8A9E\u7FA9\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002",nativeExactNote:"\u30E9\u30D9\u30EB\u3067\u52D5\u753B\u5168\u4F53\u306E\u5019\u88DC\u3092\u691C\u7D22\u3057\u307E\u3057\u305F\u3002\u8A9E\u7FA9\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002",nativeUnitSources:"\u30C7\u30E2\u8349\u6848\u306E\u5358\u4F4D\u3054\u3068\u306E\u51FA\u5178\uFF1A{sources}\u3002\u610F\u5473\u306E\u627F\u8A8D\u306F\u884C\u3044\u307E\u305B\u3093\u3002",nativeModeDescription:"\u6570\u5024\u691C\u67FB\u6E08\u307F\u5019\u88DC\u3068\u9650\u5B9A\u7684\u306A\u5F79\u5272\u8868\u73FE\u3002\u5185\u8535\u52D5\u4F5C\u306F\u660E\u793A\u3002\u8A9E\u7FA9\u3001\u5883\u754C\u3001\u4E2D\u56FD\u624B\u8A71\u6587\u6CD5\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002",nativeCount:"\u65B0\u3057\u3044\u9AA8\u683C\u5019\u88DC",nativeSource:"\u52D5\u753B\u30D5\u30A3\u30C3\u30C8\u30FB\u6280\u8853\u5019\u88DC\uFF08\u8A9E\u7FA9\u672A\u78BA\u8A8D\uFF09",nativeWarning:"\u9AA8\u683C\u306E\u6570\u5024\u691C\u67FB\u306F\u63FA\u308C\u306E\u5B8C\u5168\u9664\u53BB\u3084\u610F\u5473\u306E\u6B63\u3057\u3055\u3092\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002\u5019\u88DC\u306F\u660E\u793A\u7684\u306B\u9078\u629E\u3057\u3001\u4E0D\u8DB3\u3059\u308B\u4EE3\u540D\u8A5E\u306F\u5185\u8535\u52D5\u4F5C\u3068\u8868\u793A\u3057\u307E\u3059\u3002",nativeInvalidAsset:"\u9AA8\u683C\u5019\u88DC\u306E\u691C\u8A3C\u306B\u5931\u6557\u3057\u307E\u3057\u305F",nativeToken:"\u52D5\u753B\u306E SMPL-X \u30D5\u30A3\u30C3\u30C8\u304B\u3089\u4EBA\u7269\u56DB\u5143\u6570\u3092\u4E8B\u524D\u751F\u6210\u3002\u65B0\u3057\u3044\u30E2\u30C7\u30EB\u5B66\u7FD2\u306F\u3042\u308A\u307E\u305B\u3093\u3002",optimizationAdaptiveWarning:"\u9069\u5FDC\u578B\u30D5\u30A3\u30EB\u30BF\u30FC\u306F\u6BD4\u8F03\u5C02\u7528\u3067\u3059\u300295\u4EF6\u4E2D\u3001\u63FA\u308C\u30FB\u624B\u9996\u30FB\u52D5\u4F5C\u7BC4\u56F2\u306E\u57FA\u6E96\u3092\u3059\u3079\u3066\u6E80\u305F\u3057\u305F\u3082\u306E\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u81EA\u52D5\u9069\u7528\u3055\u308C\u307E\u305B\u3093\u3002",optimizationDisplayProfile:"\u8868\u793A\u30D5\u30A3\u30EB\u30BF\u30FC\u6BD4\u8F03",optimizationAssetProfile:"\u65E2\u5B58\u8A2D\u5B9A\uFF08\u65E2\u5B9A\uFF09",optimizationAdaptiveProfile:"\u5B9F\u9A13\uFF1A\u5B64\u7ACB\u30B9\u30D1\u30A4\u30AF\u9664\u53BB",workbenchCatalogCount:"\u9078\u629E\u53EF\u80FD\uFF1A{count} \u4EF6\u3002\u4E00\u81F4\u306F\u52D5\u4F5C\u30C7\u30FC\u30BF\u306E\u5B58\u5728\u3092\u793A\u3057\u3001\u624B\u8A71\u306E\u610F\u5473\u306E\u627F\u8A8D\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",workbenchScope:"\u7814\u7A76\u30C7\u30E2\uFF1A\u65E2\u5B58\u306E\u52D5\u4F5C\u3092\u518D\u751F\u3057\u3001\u672A\u5BFE\u5FDC\u306E\u5185\u5BB9\u3092\u8868\u793A\u3057\u307E\u3059\u3002\u610F\u5473\u5206\u6790\u3068\u52D5\u4F5C\u518D\u751F\u306F\u5225\u3005\u306E\u64CD\u4F5C\u3067\u3059\u3002",workbenchServiceHandoff:"\u30D6\u30E9\u30A6\u30B6\u30FC\u306E\u30C7\u30E2\u3068\u63A8\u8AD6\u30B5\u30FC\u30D3\u30B9\u306E\u30DD\u30FC\u30C8\u304C\u7570\u306A\u308B\u5834\u5408\u3001\u30B5\u30FC\u30D3\u30B9\u306E\u5206\u6790\u30DA\u30FC\u30B8\u3092\u958B\u3044\u3066\u53E3\u4EE4\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u79FB\u52D5\u6642\u306B\u53E3\u4EE4\u3084\u5165\u529B\u6587\u306F\u9001\u308A\u307E\u305B\u3093\u3002",workbenchOpenService:"\u30ED\u30FC\u30AB\u30EB\u5206\u6790\u30B5\u30FC\u30D3\u30B9\u3092\u958B\u304F",workbenchCsl:"\u5BFE\u5FDC\uFF1A \u4E2D\u56FD\u624B\u8A71",workbenchTextPreview:"\u30C6\u30AD\u30B9\u30C8\u306E\u30D7\u30EC\u30D3\u30E5\u30FC",workbenchOpen:"\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9\u3092\u958B\u304F",workbenchModelDemo:"\u30E2\u30C7\u30EB Demo",workbenchSettings:"SignBridge \u8A2D\u5B9A",workbenchSettingsLead:"Display and audio in one place. Subtitles are read as Chinese; ASR language is configured separately.",workbenchDisplay:"\u8868\u793A",workbenchSystemLanguage:"\u30B7\u30B9\u30C6\u30E0\u8A00\u8A9E\u306B\u5408\u308F\u305B\u308B",workbenchChinese:"\u4E2D\u56FD\u8A9E",workbenchLocaleChinese:"\u7B80\u4F53\u4E2D\u6587",workbenchLocaleEnglish:"English",workbenchLocaleJapanese:"\u65E5\u672C\u8A9E",workbenchAsrLead:"Enable audio recognition from the extension when subtitles are unavailable. Local Whisper is the default; downloading a model does not start recording.",workbenchAdvancedAsr:"Advanced audio: provider, model and capture settings",workbenchSettingsSaved:"Display and audio settings saved. Open avatars resize now; reopen other pages to apply the interface language.",workbenchTasks:"\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9\u306E\u64CD\u4F5C",workbenchMotion:"\u52D5\u4F5C\u30D7\u30EC\u30D3\u30E5\u30FC",workbenchMeaning:"\u610F\u5473\u5206\u6790\uFF08\u5B66\u7FD2\u6E08\u307F\u30E2\u30C7\u30EB\uFF09",workbenchResearch:"\u7814\u7A76\u30C4\u30FC\u30EB\u3068\u6280\u8853\u60C5\u5831",workbenchResearchLead:"Create and review existing motions, inspect sources or compare rule analysis. These tools never grant CSL approval automatically.",workbenchTools:"\u52D5\u4F5C\u306E\u4F5C\u6210\u3068\u78BA\u8A8D",workbenchExtensionTools:"Motion creation, coverage and review require the Chrome extension. Load this build as an extension and open the workspace from its popup.",workbenchAuthoring:"\u52D5\u4F5C\u3092\u4F5C\u6210",workbenchPose:"\u5358\u4E00\u59FF\u52E2\u306E\u7DE8\u96C6",workbenchSequence:"\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306E\u7DE8\u6210",workbenchRouting:"\u52D5\u4F5C\u30BD\u30FC\u30B9\u3068\u898F\u5247\u306E\u6BD4\u8F03",workbenchModeAutoDescription:"\u81EA\u52D5\u7167\u5408\uFF1A\u6587\u5168\u4F53\u306E\u53C2\u8003\u52D5\u4F5C\u3092\u512A\u5148\u3057\u3001\u4E0D\u8DB3\u5206\u3092\u5229\u7528\u53EF\u80FD\u306A\u8F9E\u66F8\u52D5\u4F5C\u3067\u88DC\u3044\u307E\u3059\u3002\u5BFE\u5FDC\u3067\u304D\u306A\u3044\u6587\u5B57\u306F\u8868\u793A\u3057\u307E\u3059\u3002",workbenchModeT08Description:"\u53C2\u8003\u30FB\u5B9F\u9A13\u52D5\u4F5C\uFF1A\u65E2\u5B58\u306ET08\u53C2\u8003\u52D5\u4F5C\u3068\u30D5\u30A3\u30C3\u30C8\u5019\u88DC\u306E\u307F\u3092\u4F7F\u3044\u3001\u8F9E\u66F8\u52D5\u4F5C\u306B\u306F\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u3057\u307E\u305B\u3093\u3002",workbenchModeDictionaryDescription:"\u5185\u8535\u8F9E\u66F8\uFF1A\u767B\u9332\u6E08\u307F\u5358\u8A9E\u52D5\u4F5C\u306E\u307F\u3092\u4F7F\u3044\u307E\u3059\u3002\u30AB\u30BF\u30ED\u30B0\u3092\u5358\u8A9E\u4E00\u89A7\u306B\u5207\u308A\u66FF\u3048\u3001T08\u6587\u5168\u4F53\u306E\u53C2\u8003\u52D5\u4F5C\u306F\u9664\u5916\u3057\u307E\u3059\u3002",workbenchModeSemanticDescription:"\u898F\u5247\u7814\u7A76\u306F\u4E2D\u56FD\u8A9E\u306E\u89E3\u6790\u6848\u3092\u8868\u793A\u3059\u308B\u3060\u3051\u3067\u3059\u3002\u52D5\u4F5C\u3092\u518D\u751F\u305B\u305A\u3001\u5B66\u7FD2\u6E08\u307F\u5F79\u5272\u30E2\u30C7\u30EB\u3082\u547C\u3073\u51FA\u3057\u307E\u305B\u3093\u3002",workbenchPresentation:"\u8996\u70B9\u3068\u8868\u793A\u51E6\u7406",workbenchRuleOnly:"Rule comparison produces a draft only. It does not connect to the trained model or play motion.",workbenchForcedSource:"Motion sources are restricted. Close research details to restore automatic matching.",workbenchStart:"\u5B57\u5E55\u652F\u63F4\u3092\u958B\u59CB",workbenchStop:"\u652F\u63F4\u3092\u505C\u6B62",workbenchRunning:"\u5B57\u5E55\u652F\u63F4\u4E2D"},qh={privateScopeExperiment:"\u4F5C\u7528\u57DF\u5BF9\u7167\u5B9E\u9A8C\uFF1A\u590D\u7528\u51BB\u7ED3\u89D2\u8272\u6743\u91CD\uFF0C\u4EC5\u52A0\u53D7\u9650\u4E8B\u4EF6\u7ED3\u6784\u7EA6\u675F\uFF1B\u8FD9\u662F\u5408\u6210\u4E2D\u6587\u5DE5\u7A0B\u8BC4\u4F30\uFF0C\u4E0D\u662F\u4E2D\u56FD\u624B\u8BED\u7406\u89E3\u6216\u51C6\u786E\u7387\u3002",privateScopeAnalyzed:"\u4F5C\u7528\u57DF\u7ED3\u6784\u5DF2\u89E3\u6790\uFF1B\u52A8\u4F5C\u4ECD\u9700\u4E2D\u56FD\u624B\u8BED\u8BCD\u7EA7\u3001\u7A7A\u95F4\u548C\u975E\u624B\u90E8\u5BF9\u9F50\u5BA1\u6838\u3002",privateEventStructure:"\u4E8B\u4EF6\u4E0E\u4F5C\u7528\u57DF\uFF08\u51BB\u7ED3\u6A21\u578B\uFF0B\u7ED3\u6784\u7EA6\u675F\u5B9E\u9A8C\uFF09",privatePlanEvidence:"\u8BED\u4E49\u7EC4\u6210\uFF1A{components}\u3002\u7F3A\u5C11\u5019\u9009\u8BC1\u636E\uFF1A{gaps}\u3002\u5019\u9009\u5747\u5F85\u624B\u8BED\u5BF9\u9F50\u590D\u6838\uFF0C\u4E0D\u751F\u6210\u6216\u64AD\u653E\u52A8\u4F5C\u3002",privatePlanReview:"\u5168\u90E8\u4ECD\u9700\u6838\u51C6",privateTitle:"SignBridge \xB7 \u4E2D\u56FD\u624B\u8BED\u7406\u89E3\u7814\u7A76\u7248",privateScope:"\u5F53\u524D\u5DF2\u8BAD\u7EC3\uFF1A\u53D7\u9650\u4E2D\u6587\u8BED\u4E49\u89D2\u8272\u89E3\u6790\u3002\u8BAD\u7EC3\u6807\u7B7E\u4E3A\u52A9\u624B\u5408\u6210\u4E2D\u6587\u793A\u4F8B\uFF0C\u5C1A\u672A\u8BAD\u7EC3\u51FA\u4E2D\u56FD\u624B\u8BED\u7FFB\u8BD1\u6216\u89C6\u9891\u8BC6\u522B\u80FD\u529B\u3002",privateEndpoint:"\u672C\u673A\u63A8\u7406\u670D\u52A1\u5730\u5740",privateToken:"\u672C\u6B21\u670D\u52A1\u7684\u4F1A\u8BDD\u53E3\u4EE4",privateTokenHelp:"\u53E3\u4EE4\u7531\u672C\u673A\u670D\u52A1\u7EC8\u7AEF\u751F\u6210\uFF0C\u4EC5\u5728\u672C\u9875\u9762\u5185\u5B58\u4E2D\u4F7F\u7528\uFF1B\u91CD\u542F\u670D\u52A1\u540E\u5931\u6548\u3002",privateSentence:"\u8F93\u5165\u4E00\u53E5\u4E2D\u6587\uFF08\u6700\u591A500\u5B57\uFF09",privateAnalyze:"\u89E3\u6790\u610F\u601D",privateDisconnect:"\u6E05\u7A7A\u4F1A\u8BDD",privateResult:"\u8BED\u4E49\u89E3\u6790\u7ED3\u679C",privateWaiting:"\u542F\u52A8\u672C\u673A\u670D\u52A1\u5E76\u586B\u5199\u4F1A\u8BDD\u53E3\u4EE4\u540E\u53EF\u89E3\u6790\u3002",privateAnalyzing:"\u6B63\u5728\u8C03\u7528\u672C\u673A\u8BAD\u7EC3\u6A21\u578B\u2026",privateParsed:"\u5DF2\u89E3\u6790\u89D2\u8272\uFF1B\u5C1A\u9700\u4E2D\u56FD\u624B\u8BED\u52A8\u4F5C\u5BF9\u9F50\u4E0E\u8868\u8FBE\u6838\u9A8C\u3002",privateAbstained:"\u8BE5\u53E5\u8D85\u51FA\u5DF2\u8BAD\u7EC3\u8303\u56F4\u6216\u5B58\u5728\u6B67\u4E49\uFF1B\u5DF2\u505C\u6B62\u89E3\u6790\uFF0C\u8BF7\u4FDD\u7559\u539F\u6587\u3002",privateMotionGap:"\u624B\u8BED\u8F93\u51FA\u6682\u672A\u542F\u7528\uFF1A\u8BCD\u7EA7\u52A8\u4F5C\u8FB9\u754C\u3001\u7A7A\u95F4\u6307\u4EE3\u548C\u975E\u624B\u90E8\u8868\u8FBE\u4ECD\u9700\u6838\u5BF9\u3002\u8FD9\u91CC\u4E0D\u4F1A\u7528\u6574\u53E5\u68C0\u7D22\u6216\u624B\u5DE5\u8BCD\u5E93\u64AD\u653E\u4EE3\u66FF\u7406\u89E3\u3002",privateProtectionScope:"\u6B64\u5BA2\u6237\u7AEF\u4E0D\u5305\u542B\u5B8C\u6574\u8BCD\u5E93\u3001\u52A8\u4F5C\u6570\u636E\u6216\u6A21\u578B\u6743\u91CD\u3002\u9875\u9762\u5C55\u793A\u7684\u7ED3\u679C\u4ECD\u53EF\u88AB\u590D\u5236\uFF1B\u5DF2\u53D1\u51FA\u7684\u65E7\u7248\u5B89\u88C5\u5305\u65E0\u6CD5\u64A4\u56DE\u3002",privateModel:"\u672C\u6B21\u6A21\u578B\uFF1A{model}",privateDisconnected:"\u4F1A\u8BDD\u5DF2\u6E05\u7A7A\u3002",privateEndpointInvalid:"\u8BF7\u4F7F\u7528\u660E\u786E\u7AEF\u53E3\u7684 http://127.0.0.1 \u672C\u673A\u670D\u52A1\u5730\u5740\u3002",privateTokenInvalid:"\u8BF7\u586B\u5199\u672C\u6B21\u7EC8\u7AEF\u751F\u6210\u7684\u5B8C\u6574\u4F1A\u8BDD\u53E3\u4EE4\u3002",privateTextInvalid:"\u8BF7\u8F93\u51651\u81F3500\u5B57\u7684\u4E2D\u6587\u3002",privateUnauthorized:"\u53E3\u4EE4\u65E0\u6548\u6216\u5DF2\u5931\u6548\uFF0C\u8BF7\u4F7F\u7528\u5F53\u524D\u670D\u52A1\u7EC8\u7AEF\u7684\u53E3\u4EE4\u3002",privateForbidden:"\u670D\u52A1\u62D2\u7EDD\u4E86\u6765\u6E90\uFF1B\u63D2\u4EF6\u9700\u5728\u542F\u52A8\u670D\u52A1\u65F6\u52A0\u5165\u5176\u51C6\u786E\u7684\u6269\u5C55\u6765\u6E90\u3002",privateRateLimited:"\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",privateBusy:"\u670D\u52A1\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",privateRequestFailed:"\u63A8\u7406\u8BF7\u6C42\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u672C\u673A\u670D\u52A1\u3002",privateResponseInvalid:"\u670D\u52A1\u8FD4\u56DE\u5185\u5BB9\u4E0D\u7B26\u5408\u5F53\u524D\u6A21\u578B\u63A5\u53E3\u3002",privateConnectionFailed:"\u65E0\u6CD5\u8FDE\u63A5\u672C\u673A\u670D\u52A1\u6216\u8BF7\u6C42\u5DF2\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5\u670D\u52A1\u5730\u5740\u548C\u8FD0\u884C\u72B6\u6001\u3002",privateServiceUnavailableStatus:"\u672C\u673A\u8BED\u4E49\u670D\u52A1\u672A\u8FD0\u884C\uFF0C\u5C1A\u672A\u79BB\u5F00\u5F53\u524D\u9875\u9762\u3002",privateServiceUnavailable:"\u6CA1\u6709\u68C0\u6D4B\u5230\u672C\u673A\u8BED\u4E49\u670D\u52A1\u3002\u8BF7\u5728\u9879\u76EE\u4ED3\u5E93\u6839\u76EE\u5F55\u6253\u5F00\u7EC8\u7AEF\u5E76\u8FD0\u884C\u4E0B\u9762\u7684\u547D\u4EE4\uFF1B\u670D\u52A1\u542F\u52A8\u540E\u56DE\u5230\u8FD9\u91CC\u91CD\u8BD5\u3002",privateServiceStartFromRoot:"\u542F\u52A8\u547D\u4EE4\uFF08\u5728 SignBridge \u9879\u76EE\u4ED3\u5E93\u6839\u76EE\u5F55\u8FD0\u884C\uFF09\uFF1A",privateServiceCommand:".venv-sign-data/bin/python signbridge/src/tools/sign-private-serve.py --model local-data/csl-understanding-20261017-rLaeiN/learned-roles-v3 --client local-data/existing-resources-optimization-20261019-v1/thin-client-v1.0.5 --port 8770 --scope-experiment --unit-candidates local-data/existing-resources-optimization-20261019-v1/unit-candidates-final/candidates.json",privateRoles:{actor:"\u8C01\uFF0F\u65BD\u4E8B",predicate:"\u52A8\u4F5C\uFF0F\u72B6\u6001",patient:"\u5BF9\u8C01\uFF0F\u53D7\u4E8B",goal:"\u76EE\u6807\u5730\u70B9",time:"\u65F6\u95F4",negation:"\u5426\u5B9A",modal:"\u610F\u613F\uFF0F\u80FD\u529B\uFF0F\u5FC5\u8981\u6027",question:"\u7591\u95EE",aspect:"\u4F53\u8C8C",politeness:"\u8BF7\u6C42",degree:"\u7A0B\u5EA6"}},Aa={privateScopeExperiment:"Scope comparison: frozen role weights with bounded event-structure constraints. Synthetic Chinese engineering evaluation only; not CSL understanding or accuracy.",privateScopeAnalyzed:"Event scope parsed; CSL lexical, spatial and nonmanual alignment still requires review.",privateEventStructure:"Event scope (frozen model + explicit constraints)",privatePlanEvidence:"Meaning components: {components}. Candidate evidence gaps: {gaps}. All candidates await CSL alignment; no motion generation or playback.",privatePlanReview:"all still require review",privateTitle:"SignBridge \xB7 CSL understanding research",privateScope:"Trained capability: bounded Chinese semantic roles, using assistant synthetic Chinese labels. CSL translation and video recognition are not trained.",privateEndpoint:"Local inference service",privateToken:"Session token",privateTokenHelp:"The local service prints a new token in its terminal. This page holds it in memory only; restart invalidates it.",privateSentence:"Chinese sentence (up to 500 characters)",privateAnalyze:"Analyze meaning",privateDisconnect:"Clear session",privateResult:"Semantic result",privateWaiting:"Start the local service and enter its session token.",privateAnalyzing:"Running the local trained model\u2026",privateParsed:"Roles parsed; CSL motion alignment and realization still require review.",privateAbstained:"Unsupported or ambiguous sentence. Parsing stopped; retain the original text.",privateMotionGap:"Signing output awaits word-level motion alignment, spatial reference and nonmanual review. No retrieval or dictionary playback substitutes for understanding here.",privateProtectionScope:"This client includes no complete lexicon, motion data or model weights. Displayed results can still be copied; previously distributed packages cannot be recalled.",privateModel:"Model: {model}",privateDisconnected:"Session cleared.",privateEndpointInvalid:"Use an http://127.0.0.1 address with an explicit local service port.",privateTokenInvalid:"Enter the complete token from the current service terminal.",privateTextInvalid:"Enter 1\u2013500 characters.",privateUnauthorized:"Invalid or expired token. Use the current service terminal token.",privateForbidden:"Origin rejected. Start the service with this exact extension origin allowed.",privateRateLimited:"Too many requests. Try again later.",privateBusy:"Service busy. Try again shortly.",privateRequestFailed:"Inference request failed. Check the local service.",privateResponseInvalid:"Unexpected model response.",privateConnectionFailed:"Local service unavailable or request timed out. Check the address and service.",privateServiceUnavailableStatus:"The local meaning service is not running. You have not left this page.",privateServiceUnavailable:"The local meaning service was not detected. Open a terminal at the SignBridge repository root, run the command below, then return here and retry.",privateServiceStartFromRoot:"Start command (run at the repository root):",privateServiceCommand:".venv-sign-data/bin/python signbridge/src/tools/sign-private-serve.py --model local-data/csl-understanding-20261017-rLaeiN/learned-roles-v3 --client local-data/existing-resources-optimization-20261019-v1/thin-client-v1.0.5 --port 8770 --scope-experiment --unit-candidates local-data/existing-resources-optimization-20261019-v1/unit-candidates-final/candidates.json",privateRoles:{actor:"Actor",predicate:"Action / state",patient:"Patient / recipient",goal:"Goal",time:"Time",negation:"Negation",modal:"Modality",question:"Question",aspect:"Aspect",politeness:"Request",degree:"Degree"}},Yh={cslMode:"\u4E2D\u6587\u610F\u601D\u5206\u6790\uFF08\u89C4\u5219\u7814\u7A76\uFF09",cslAnalysisOnly:"\u4EC5\u5206\u6790\u4E2D\u6587\u610F\u601D\uFF1A\u672A\u5B8C\u6210\u4E2D\u56FD\u624B\u8BED\u8BCD\u7EA7\u5BF9\u9F50\u4E0E\u8BED\u8A00\u590D\u6838\uFF0C\u4E0D\u64AD\u653E\u52A8\u4F5C\u3002",cslDemoPreviewReady:"Demo\u5DF2\u5B8C\u6210\u6709\u9650\u8BED\u4E49\u8DEF\u7531\u5E76\u64AD\u653E\u8BCD\u6761\u7EC4\u5408\uFF1B\u8FD9\u4E0D\u662F\u5DF2\u6838\u51C6\u7684\u4E2D\u56FD\u624B\u8BED\u8BED\u6CD5\u3002",cslTitle:"\u610F\u601D\u5206\u6790\u4E0E\u8868\u8FBE\u8349\u6848",cslScope:"\u6709\u9650\u89C4\u5219\u539F\u578B\uFF1A\u5148\u5206\u6790\u610F\u601D\uFF0C\u518D\u68C0\u67E5\u52A8\u4F5C\u3002\u4E0D\u662F\u5DF2\u8BAD\u7EC3\u7684\u4E2D\u56FD\u624B\u8BED\u7406\u89E3\u6A21\u578B\uFF1B\u8BCD\u5E8F\u3001\u624B\u578B\u3001\u7A7A\u95F4\u5173\u7CFB\u548C\u8868\u60C5\u4ECD\u9700\u6838\u5BF9\u3002",cslActor:"\u65BD\u4E8B / \u8C01",cslPredicate:"\u52A8\u4F5C / \u72B6\u6001",cslPatient:"\u53D7\u4E8B / \u5BF9\u8C01",cslGoal:"\u5730\u70B9 / \u76EE\u6807",cslTime:"\u65F6\u95F4",cslNegation:"\u5426\u5B9A\u53CA\u8303\u56F4",cslModality:"\u610F\u613F / \u80FD\u529B / \u5FC5\u8981\u6027",cslQuestion:"\u7591\u95EE",cslDegree:"\u7A0B\u5EA6",cslPoliteness:"\u8BF7\u6C42",cslUnset:"\u672A\u660E\u786E",cslDraft:"\u5019\u9009\u8868\u8FBE\u5355\u5143\uFF08\u975E\u56FA\u5B9A\u4E2D\u56FD\u624B\u8BED\u8BED\u5E8F\uFF09",cslNoDraft:"\u53E5\u6CD5\u8D85\u51FA\u539F\u578B\u8303\u56F4\uFF0C\u8BF7\u6838\u5BF9\u539F\u6587\u3002",cslGaps:"\u7F3A\u5C11\u52A8\u4F5C\u8BC1\u636E\uFF1A{words}",cslUnknown:"\u4FDD\u7559\u7684\u672A\u89E3\u6790\u5185\u5BB9\uFF1A{words}",cslMeaningKey:"\u673A\u5668\u8BED\u4E49\u8868\u793A\uFF08\u8349\u6848\uFF09",cslNoMatch:"\u8BE5\u8BED\u4E49\u8BA1\u5212\u4ECD\u6709\u8BC1\u636E\u7F3A\u53E3\uFF0C\u4E0D\u80FD\u64AD\u653E\u4E3A\u5B8C\u6574\u8868\u8FBE\u3002",cslSources:"\u8BCD\u7EA7ID\u4EC5\u4F5C\u4E3A\u8349\u6848\u5F15\u7528\uFF1B\u5206\u6790\u7ED3\u679C\u4E0D\u4F1A\u89E6\u53D1\u8BCD\u5E93\u6216\u89C6\u9891\u52A8\u4F5C\u64AD\u653E\u3002",cslIssues:{csl_alignment_unreviewed:"\u4E2D\u56FD\u624B\u8BED\u8BCD\u7EA7\u5BF9\u9F50\u3001\u7A7A\u95F4\u6307\u4EE3\u548C\u975E\u624B\u90E8\u8BED\u6CD5\u5C1A\u672A\u590D\u6838\u3002",empty_input:"\u8BF7\u8F93\u5165\u4E00\u53E5\u4E2D\u6587\u3002",unknown_input:"\u4ECD\u6709\u672A\u89E3\u6790\u7684\u8BCD\u6216\u7B26\u53F7\u3002",unsupported_predicate_structure:"\u591A\u4E2A\u52A8\u4F5C\u6216\u7F3A\u5C11\u8C13\u8BCD\uFF0C\u9700\u8FDB\u4E00\u6B65\u6807\u6CE8\u3002",ambiguous_scope:"\u5426\u5B9A\u3001\u60C5\u6001\u6216\u65F6\u95F4\u7684\u8303\u56F4\u6709\u6B67\u4E49\u3002",actor_unresolved:"\u53E5\u4E2D\u6267\u884C\u52A8\u4F5C\u7684\u4EBA\u5C1A\u672A\u660E\u786E\u3002",ambiguous_participants:"\u4EBA\u7269\u5173\u7CFB\u8D85\u51FA\u5F53\u524D\u7B80\u5355\u53E5\u8303\u56F4\u3002",unsupported_operator_order:"\u5426\u5B9A\u6216\u60C5\u6001\u4F4D\u7F6E\u8D85\u51FA\u5DF2\u652F\u6301\u7ED3\u6784\u3002",unsupported_predicate_arguments:"\u52A8\u4F5C\u7684\u53C2\u4E0E\u5173\u7CFB\u9700\u8FDB\u4E00\u6B65\u6838\u5BF9\u3002",goal_unresolved:"\u76EE\u6807\u5730\u70B9\u6216\u52A8\u4F5C\u53D7\u4E8B\u5C1A\u672A\u89E3\u6790\u6E05\u695A\u3002",question_role_unresolved:"\u7591\u95EE\u8BCD\u7684\u8BED\u4E49\u89D2\u8272\u5C1A\u672A\u786E\u8BA4\u3002",multiple_clauses:"\u5305\u542B\u591A\u5206\u53E5\uFF0C\u539F\u578B\u4E0D\u4F1A\u64C5\u81EA\u5408\u5E76\u3002",unassigned_meaning:"\u4ECD\u6709\u672A\u5F52\u5C5E\u7684\u8BED\u4E49\u5355\u5143\u3002",unsupported_degree_scope:"\u7A0B\u5EA6\u4FEE\u9970\u7684\u8303\u56F4\u5C1A\u672A\u786E\u8BA4\u3002",motion_evidence_missing:"\u90E8\u5206\u6982\u5FF5\u6CA1\u6709\u53EF\u9760\u7684\u72EC\u7ACB\u52A8\u4F5C\u8D44\u4EA7\u3002",nonmanual_question_unavailable:"\u7591\u95EE\u9700\u8981\u7684\u9762\u90E8\u6216\u5934\u90E8\u8868\u8FBE\u5C1A\u672A\u5B9E\u73B0\u3002",spatial_agreement_unavailable:"\u5E2E\u52A9\u7684\u65B9\u5411\u3001\u4EBA\u7269\u7A7A\u95F4\u6307\u4EE3\u5C1A\u672A\u6838\u9A8C\u3002",directional_agreement_approximated:"\u4EBA\u7269\u65B9\u5411\u6682\u7528 Demo \u8FD1\u4F3C\u5904\u7406\uFF0C\u5C1A\u672A\u5B8C\u6210\u4E2D\u56FD\u624B\u8BED\u7A7A\u95F4\u6307\u4EE3\u6838\u9A8C\u3002",modal_interpretation_unreviewed:"\u60C5\u6001\u542B\u4E49\u4E0D\u80FD\u76F4\u63A5\u7528\u4E00\u4E2A\u8BCD\u5E93\u52A8\u4F5C\u66FF\u4EE3\u3002",input_limit:"\u8D85\u8FC7500\u5B57\uFF0C\u5C3E\u90E8\u4FDD\u7559\u5E76\u505C\u6B62\u7EC4\u5408\u3002"}},Ra={cslMode:"Chinese meaning analysis (rules)",cslAnalysisOnly:"Chinese analysis only: CSL alignment and language review are incomplete. Motion playback is disabled.",cslDemoPreviewReady:"The demo routed a bounded semantic template and is playing dictionary units; this is not validated CSL grammar.",cslTitle:"Meaning and expression draft",cslScope:"Bounded rule prototype: analyze meaning, then check motion evidence. This is not a trained CSL understanding model. Order, handshape, spatial agreement and nonmanuals remain unverified.",cslActor:"Actor",cslPredicate:"Action / state",cslPatient:"Patient / recipient",cslGoal:"Location / goal",cslTime:"Time",cslNegation:"Negation and scope",cslModality:"Desire / ability / obligation",cslQuestion:"Question",cslDegree:"Degree",cslPoliteness:"Request",cslUnset:"Unspecified",cslDraft:"Candidate units (not a fixed CSL word order)",cslNoDraft:"Outside the supported syntax. Review the original input.",cslGaps:"Missing motion evidence: {words}",cslUnknown:"Unparsed content preserved: {words}",cslMeaningKey:"Machine meaning representation (draft)",cslNoMatch:"Evidence is missing; this plan cannot play as a complete expression.",cslSources:"Word IDs are draft references only. Analysis never triggers dictionary or video motion playback.",cslIssues:{csl_alignment_unreviewed:"CSL word alignment, spatial reference and nonmanual grammar remain unreviewed.",empty_input:"Enter one Chinese sentence.",unknown_input:"Some words or symbols remain unparsed.",unsupported_predicate_structure:"Multiple actions or a missing predicate require annotation.",ambiguous_scope:"Negation, modality or time scope is ambiguous.",actor_unresolved:"The actor is unresolved.",ambiguous_participants:"Participant relations exceed this simple-clause prototype.",unsupported_operator_order:"Negation or modality order is unsupported.",unsupported_predicate_arguments:"Predicate arguments require review.",goal_unresolved:"The goal or patient is unresolved.",question_role_unresolved:"The question role is unresolved.",multiple_clauses:"Multiple clauses cannot be silently merged.",unassigned_meaning:"Some meaning units have no assigned role.",unsupported_degree_scope:"Degree scope is unresolved.",motion_evidence_missing:"Some concepts have no reliable independent motion.",nonmanual_question_unavailable:"Question-related facial and head expressions are unavailable.",spatial_agreement_unavailable:"Direction and spatial reference for help remain unverified.",directional_agreement_approximated:"Participant direction uses a demo approximation; CSL spatial reference is unverified.",modal_interpretation_unreviewed:"Modal meaning cannot be replaced by one dictionary motion.",input_limit:"Input exceeds 500 characters; the tail is retained and composition stopped."}},Jh={...Ra,cslMode:"\u4E2D\u56FD\u8A9E\u306E\u610F\u5473\u5206\u6790\uFF08\u898F\u5247\u7814\u7A76\uFF09",cslAnalysisOnly:"\u4E2D\u56FD\u8A9E\u306E\u610F\u5473\u5206\u6790\u306E\u307F\u3067\u3059\u3002\u4E2D\u56FD\u624B\u8A71\u306E\u8A9E\u5358\u4F4D\u5BFE\u5FDC\u3068\u78BA\u8A8D\u306F\u672A\u5B8C\u4E86\u306E\u305F\u3081\u3001\u52D5\u4F5C\u306F\u518D\u751F\u3057\u307E\u305B\u3093\u3002",cslTitle:"\u610F\u5473\u5206\u6790\u3068\u8868\u73FE\u6848",cslScope:"\u9650\u5B9A\u3057\u305F\u898F\u5247\u306B\u3088\u308B\u8A66\u4F5C\u3067\u3059\u3002\u610F\u5473\u3092\u5206\u6790\u3057\u3066\u52D5\u4F5C\u8CC7\u6599\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u5B66\u7FD2\u6E08\u307F\u306E\u4E2D\u56FD\u624B\u8A71\u7406\u89E3\u30E2\u30C7\u30EB\u3067\u306F\u306A\u304F\u3001\u8A9E\u9806\u30FB\u624B\u5F62\u30FB\u7A7A\u9593\u8868\u73FE\u30FB\u8868\u60C5\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002",cslActor:"\u52D5\u4F5C\u4E3B",cslPredicate:"\u52D5\u4F5C\u30FB\u72B6\u614B",cslPatient:"\u5BFE\u8C61\u30FB\u53D7\u3051\u624B",cslGoal:"\u5834\u6240\u30FB\u76EE\u6A19",cslTime:"\u6642",cslNegation:"\u5426\u5B9A\u3068\u7BC4\u56F2",cslModality:"\u5E0C\u671B\u30FB\u80FD\u529B\u30FB\u5FC5\u8981\u6027",cslQuestion:"\u7591\u554F",cslDegree:"\u7A0B\u5EA6",cslPoliteness:"\u4F9D\u983C",cslUnset:"\u672A\u6307\u5B9A",cslDraft:"\u8868\u73FE\u5358\u4F4D\u6848\uFF08\u56FA\u5B9A\u3057\u305F\u4E2D\u56FD\u624B\u8A71\u306E\u8A9E\u9806\u3067\u306F\u3042\u308A\u307E\u305B\u3093\uFF09",cslNoDraft:"\u69CB\u6587\u304C\u8A66\u4F5C\u306E\u7BC4\u56F2\u5916\u3067\u3059\u3002\u539F\u6587\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",cslGaps:"\u52D5\u4F5C\u8CC7\u6599\u306E\u4E0D\u8DB3\uFF1A{words}",cslUnknown:"\u672A\u89E3\u6790\u306E\u5185\u5BB9\u3092\u4FDD\u6301\uFF1A{words}",cslMeaningKey:"\u610F\u5473\u306E\u6A5F\u68B0\u8868\u73FE\uFF08\u6848\uFF09",cslNoMatch:"\u8CC7\u6599\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u308B\u305F\u3081\u3001\u5B8C\u5168\u306A\u8868\u73FE\u3068\u3057\u3066\u518D\u751F\u3067\u304D\u307E\u305B\u3093\u3002",cslSources:"\u65E2\u5B58\u306E\u624B\u4F5C\u6210\u8F9E\u66F8\u3092\u4F7F\u3044\u307E\u3059\u3002\u52D5\u753B\u306E\u5019\u88DC\u306F\u81EA\u52D5\u7684\u306B\u6709\u52B9\u5316\u3057\u307E\u305B\u3093\u3002"},Kh={intakeRefinementTitle:"\u6765\u6E90 {name} \xB7 \u52A8\u4F5C\u8FB9\u754C\u590D\u6838",intakeRefinementPending:"\u6587\u5B57\u4E0E\u8FB9\u754C\u5EFA\u8BAE \xB7 \u672A\u4EBA\u5DE5\u786E\u8BA4",intakePrevious:"\u539F\u5019\u9009\u7A97\u53E3 {start}\u2013{end}s\uFF1A{text}",intakeBefore:"\u539F\u5019\u9009\u7A97\u53E3\uFF08\u4F9B\u5BF9\u6BD4\uFF09",intakeAfter:"\u8C03\u6574\u540E\u7684\u5019\u9009\u7A97\u53E3",intakeRefinedWindow:"\u8C03\u6574\u540E\u540D\u4E49\u533A\u95F4 {start}\u2013{end}s\uFF1B\u5B9E\u9645\u89E3\u7801 {frames} \u5E27 / {duration}s\u3002\u4E34\u8FD1\u89C6\u9891\u7ED3\u5C3E\u7684\u52A8\u4F5C\u4ECD\u9700\u6838\u5BF9\u662F\u5426\u5B8C\u6574\u3002",intakeCoverageComparison:"\u89C2\u6D4B\u5230\u81F3\u5C11\u4E00\u53EA\u624B\u7684\u5E27\u5360\u6BD4\uFF1A\u539F\u7A97\u53E3 {before}% \u2192 \u8C03\u6574\u540E {after}%\u3002\u8FD9\u662F\u4E0D\u540C\u7A97\u53E3\u7684\u53D6\u6750\u5BF9\u6BD4\uFF0C\u4E0D\u4EE3\u8868\u68C0\u6D4B\u5668\u51C6\u786E\u7387\u63D0\u5347\u3002",intakeTitle:"\u6765\u6E90 {name} \xB7 \u65B0\u89C6\u9891\u590D\u6838",intakeSummary:"{files} \u4E2A\u6587\u4EF6 / {unique} \u4EFD\u4E0D\u540C\u5185\u5BB9\uFF1B{screened} \u4E2A\u6765\u6E90\u5B8C\u6210 OCR\uFF0C{candidates} \u6761\u6587\u5B57\u5019\u9009\uFF1B{references} \u6BB5\u3001{frames} \u5E27\u5B8C\u6210 2D \u53C2\u8003\u3002",intakeLimits:"\u5B57\u5E55\u8BED\u4E49\u3001\u52A8\u4F5C\u8FB9\u754C\u3001\u955C\u50CF\u3001\u624B\u522B\u548C\u4EBA\u7269\u5206\u7EC4\u5F85\u786E\u8BA4\u3002\u8FD9\u91CC\u53EA\u5C55\u793A OCR \u5019\u9009\u53CA\u4E8C\u7EF4\u89C2\u6D4B\uFF0C\u6CA1\u6709\u751F\u6210\u65B0\u7684 SMPL-X \u52A8\u4F5C\u6216\u8BAD\u7EC3\u6A21\u578B\uFF1Btraining_ready=false\u3002",intakePending:"OCR\u5019\u9009 \xB7 \u672A\u590D\u6838",intakeWindow:"\u540D\u4E49\u533A\u95F4 {start}\u2013{end}s \xB7 OCR\u5747\u503C {confidence}",intakeOriginal:"\u67E5\u770B\u6388\u6743\u539F\u89C6\u9891\u533A\u95F4",intakeDuplicate:"\u4E0E\u65E7\u6279\u6B21\u5185\u5BB9\u91CD\u590D",catchupTitle:"\u624B\u8BED\u89C6\u9891\u7EED\u5904\u7406 \xB7 \u539F\u7247\u4E0E\u624B\u90E8\u53C2\u8003",catchupSummary:"{files} \u4E2A\u89C6\u9891\u6587\u4EF6 / {sources} \u4EFD\u4E0D\u540C\u5185\u5BB9 \xB7 \u65B0\u589E {windows} \u6BB5\u8FDE\u7EED\u53C2\u8003 / {frames} \u5E27 \xB7 \u53E6\u6709 {sampled} \u5E27\u72EC\u7ACB\u624B\u90E8\u89C2\u6D4B",catchupLimits:"\u672C\u9875\u662F\u6807\u6CE8\u5019\u9009\u548C\u6280\u672F\u89C2\u6D4B\u3002\u5B57\u5E55\u53EF\u80FD\u6709\u9519\u5B57\u6216\u591A\u53E5\u5BF9\u8BDD\uFF0C\u8FB9\u754C\u3001\u955C\u50CF\u548C\u4EBA\u7269\u5206\u7EC4\u5F85\u786E\u8BA4\uFF1B\u672A\u5F00\u59CB\u8BAD\u7EC3\uFF0C\u672A\u751F\u6210\u65B0\u7684 SMPL-X \u53C2\u6570\u30025\u5E27\u62BD\u6837\u4E0D\u4EE3\u8868\u6574\u6BB5\u5DF2\u6807\u6CE8\u3002",catchupReferences:"\u65B0\u589E\u8FDE\u7EED\u7247\u6BB5",catchupSources:"\u5168\u90E8\u89C6\u9891\u8FDB\u5EA6",catchupCaptions:"\u539F\u59CB\u5B57\u5E55\u5019\u9009",catchupIndex:"\u7A0B\u5E8F\u8C03\u7528\u7D22\u5F15",catchupRegistry:"\u5B8C\u6574\u6765\u6E90\u767B\u8BB0",catchupReport:"\u9636\u6BB5\u62A5\u544A",catchupSearch:"\u641C\u7D22\u53E5\u5B50\u3001\u89C6\u9891\u540D\u6216\u6765\u6E90 ID",catchupPage:"{count} \u9879 \xB7 \u7B2C {page}/{pages} \u9875",catchupPrevious:"\u4E0A\u4E00\u9875",catchupNext:"\u4E0B\u4E00\u9875",catchupOriginal:"\u539F\u7247\u5019\u9009\u7A97\u53E3",catchupOverlay:"\u5173\u952E\u70B9\u53E0\u52A0\u9884\u89C8",catchupSync:"\u540C\u6B65\u64AD\u653E / \u6682\u505C",catchupKeyframes:"\u5C55\u5F005\u5E27\u539F\u56FE\u4E0E\u624B\u90E8\u88C1\u526A",catchupKeyframeAlt:"{text} \u7684\u539F\u56FE\u4E0E\u4F30\u8BA1\u624B\u90E8\u69FD\u88C1\u526A",catchupIndependentAlt:"\u8BE5\u6765\u6E905\u4E2A\u72EC\u7ACB\u62BD\u6837\u5E27\u7684\u624B\u90E8\u89C2\u6D4B",catchupCoverage:"\u6280\u672F\u89C2\u6D4B\u53EF\u7528\u5E27\uFF1Aleft {left}/{frames}\uFF0Cright {right}/{frames}\uFF1B\u8FD9\u4E0D\u662F\u51C6\u786E\u7387\u6216\u89E3\u5256\u4FA7\u522B\u6838\u9A8C\u3002",catchupSourceStages:"\u65E7\u53C2\u8003 {prior} \u6BB5 \xB7 \u65E7\u8FDE\u7EED\u52A8\u4F5C {motions} \u6BB5 \xB7 \u65B0\u8FDE\u7EED\u53C2\u8003 {fresh} \u6BB5 \xB7 \u65B0\u72EC\u7ACB\u62BD\u6837 {sampled} \u5E27\uFF1B\u5B8C\u6574\u89C6\u9891\u5904\u7406\u4ECD\u89C1\u62A5\u544A\u3002",catchupHksl:"\u6807\u9898\u63D0\u793A\u9999\u6E2F\u624B\u8BED\uFF0C\u8BED\u8A00\u5C1A\u5F85\u6838\u9A8C\uFF1B\u72EC\u7ACB\u4FDD\u5B58\uFF0C\u672A\u7EB3\u5165\u4E2D\u56FD\u624B\u8BED\u53E5\u5B50\u8BAD\u7EC3\u3002",catchupEmptyCaption:"\u65E0\u53EF\u8BFB\u53D6\u5B57\u5E55",catchupMediaError:"\u5A92\u4F53\u64AD\u653E\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u672C\u5730\u6587\u4EF6\u5E76\u91CD\u8BD5\u3002",demoSample:"\u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",demoRetry:"\u91CD\u65B0\u52A0\u8F7D\u6F14\u793A",demoLimit:"\u6BCF\u6B21\u6700\u591A\u64AD\u653E40\u4E2A\u52A8\u4F5C\uFF0C\u5176\u4F59\u6587\u5B57\u5217\u5728\u6682\u4E0D\u652F\u6301\u5185\u5BB9\u4E2D\u3002",demoCheckpoint:"Checkpoint\uFF1A{hash} \xB7 {steps}\u6B65",demoWebGL:"3D\u6E32\u67D3\u73AF\u5883\u4E0D\u53EF\u7528",demoOpen:"\u6253\u5F00\u6F14\u793A\u5DE5\u4F5C\u53F0",demoLocal:"\u672C\u5730\u79BB\u7EBF\u6F14\u793A",demoExport:"\u5BFC\u51FA\u672C\u6B21\u7ED3\u679C",demoEyebrow:"\u8BA9\u624B\u8BED\u52A8\u8D77\u6765 \xB7 \u5B9E\u9A8C\u6F14\u793A",demoHeading:"\u4ECE\u6587\u5B57\uFF0C\u5230\u770B\u5F97\u89C1\u7684\u8868\u8FBE",demoLead:"\u9009\u62E9\u7247\u6BB5\u6216\u8F93\u5165\u6587\u5B57\uFF0C\u5728\u865A\u62DF\u4EBA\u4E0A\u64AD\u653E\u53C2\u8003\u52A8\u4F5C\u3001\u5B9E\u9A8C\u91CD\u5EFA\u4E0E\u8BCD\u5E93\u52A8\u4F5C\u3002",demoInput:"\u8F93\u5165\u6587\u5B57",demoMode:"\u52A8\u4F5C\u6765\u6E90\u6A21\u5F0F",demoAuto:"\u81EA\u52A8\u5339\u914D",demoT08:"\u53C2\u8003\u4E0E\u5B9E\u9A8C\u52A8\u4F5C",demoDictionary:"\u5185\u7F6E\u8BCD\u5E93",demoPlaceholder:"\u8BD5\u8BD5\uFF1A\u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",demoShortcut:"Ctrl / \u2318 + Enter \u64AD\u653E",demoPlay:"\u64AD\u653E\u52A8\u4F5C",demoPause:"\u6682\u505C",demoResume:"\u7EE7\u7EED",demoStop:"\u505C\u6B62",demoLoading:"\u6B63\u5728\u52A0\u8F7D\u89D2\u8272\u4E0E\u52A8\u4F5C\u2026",demoMatches:"\u5DF2\u8BC6\u522B\u5185\u5BB9",demoCatalog:"\u77ED\u53E5\u4E0E\u8BCD\u5E93",demoCatalogViews:"\u77ED\u53E5\u6216\u8BCD\u5E93\u52A8\u4F5C",demoPhraseTab:"\u77ED\u53E5\u4E0E\u7247\u6BB5",demoWordTab:"\u5355\u8BCD\u52A8\u4F5C",demoVocabTab:"\u57FA\u7840\u8BCD\u5E93",demoVocabNote:"\u5171 {total} \u6761\u5E38\u7528\u8BCD\uFF1A{native} \u6761\u6709\u539F\u751F\u52A8\u4F5C\u5019\u9009\uFF0C{pose} \u6761\u6709\u5185\u7F6E\u624B\u5DE5\u59FF\u52BF\uFF0C{none} \u6761\u6682\u65F6\u53EA\u6709\u8BCD\u8868\u3001\u6CA1\u6709\u52A8\u4F5C\u3002\u6240\u6709\u52A8\u4F5C\u5747\u672A\u7ECF\u4EBA\u5DE5\u5BA1\u6838\u3002",demoVocabNoMotion:"\u201C{text}\u201D\u6682\u65F6\u6CA1\u6709\u52A8\u4F5C\uFF0C\u53EA\u5728\u8BCD\u8868\u4E2D\u5C55\u793A\uFF0C\u4E0D\u4F1A\u7528\u522B\u7684\u52A8\u4F5C\u4EE3\u66FF\u3002",demoVocabStatusNative:"\u6709\u52A8\u4F5C\uFF08\u539F\u751F\u5019\u9009\uFF0C\u672A\u7ECF\u5BA1\u6838\uFF09",demoVocabStatusNativeReduced:"\u6709\u52A8\u4F5C\uFF08\u539F\u751F\u5019\u9009\uFF0C\u624B\u8155\u5E45\u5EA6\u7565\u51CF\uFF09",demoVocabStatusPose:"\u6709\u52A8\u4F5C\uFF08\u5185\u7F6E\u624B\u5DE5\u59FF\u52BF\uFF09",demoVocabStatusNone:"\u4EC5\u8BCD\u8868\uFF08\u6682\u65E0\u52A8\u4F5C\uFF09",demoPhraseSourceNote:"\u5171 {total} \u6761\uFF1A{reference} \u6761 T08 \u53C2\u8003\u3001{candidate} \u6761\u5019\u9009\u3001{experimental} \u6761\u5B9E\u9A8C\u91CD\u5EFA\u3001{composed} \u6761\u8BCD\u5E93\u7EC4\u5408\u3002",demoWordSourceNote:"\u5171 {count} \u4E2A\u5185\u7F6E\u8BCD\u6761\uFF1B\u8BCD\u6761\u52A8\u753B\u4E0D\u662F\u672C\u8F6E\u65B0\u589E\u7684\u53E5\u5B50\u8BAD\u7EC3\u7ED3\u679C\u3002",demoSearch:"\u641C\u7D22\u77ED\u53E5\u6216\u8BCD\u6761",demoAvatarLabel:"\u5F53\u524D\u9879\u76EE\u89D2\u8272 \xB7 Godette",demoStage:"\u865A\u62DF\u4EBA\u7269",demoReadyBadge:"\u51C6\u5907\u5C31\u7EEA",demoAtRest:"\u5F85\u673A",demoView:"\u89C6\u89D2",demoFront:"\u6B63\u9762",demoLeft:"\u5DE6\u4FA7",demoRight:"\u53F3\u4FA7",demoSpeed:"\u901F\u5EA6",demoSmoothing:"\u52A8\u4F5C\u5E73\u6ED1",demoExperimentalSmoothedBadge:"SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u5E73\u6ED1",demoAdaptiveFilteredBadge:"SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u9694\u79BB\u5C16\u5CF0\u5BF9\u7167",demoAdaptiveFilteredWarningBadge:"SMPL-X \xB7 \u5C16\u5CF0\u5BF9\u7167 \xB7 \u539F\u59CB\u98CE\u9669\u4ECD\u5728",demoExperimentalSmoothedWarningBadge:"SMPL-X \xB7 \u5B9E\u9A8C\u5E73\u6ED1 \xB7 \u539F\u59CB\u8DF3\u53D8\u8F83\u5927",demoExperimentalRawBadge:"SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u539F\u59CB",demoModel:"\u7814\u7A76\u6A21\u578B",demoLearned:"T08\u539F\u53C2\u8003\u53E5",demoWords:"\u5185\u7F6E\u8BCD\u5E93\u52A8\u4F5C",demoCandidates:"\u5019\u9009\u53C2\u8003\u52A8\u4F5C",demoExperimental:"\u5B9E\u9A8C\u91CD\u5EFA\u52A8\u4F5C",demoExperimentalBadge:"SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA",demoExperimentalWarningBadge:"SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u8DF3\u53D8\u8F83\u5927",demoExperimentalToken:"\u5F53\u524D\u4E3A\u89C6\u9891\u62DF\u5408\u7684 SMPL-X \u5B9E\u9A8C\u52A8\u4F5C\uFF0C\u672A\u7ECF\u8FC7 T08 token \u89E3\u7801\uFF0C\u672A\u66F4\u65B0\u6A21\u578B\u6743\u91CD\u3002",demoExperimentalWarning:"\u5B9E\u9A8C\u52A8\u4F5C\u4FDD\u7559\u672A\u7ECF\u52A8\u4F5C\u8D28\u91CF\u3001\u955C\u50CF\u548C\u4EBA\u7269\u6838\u9A8C\u7684\u72B6\u6001\uFF1B\u4EC5\u7528\u4E8E Demo\uFF0C\u53EF\u80FD\u51FA\u73B0\u624B\u578B\u8BEF\u5DEE\u3001\u8DF3\u53D8\u6216\u7A7F\u6A21\u3002",demoExperimentalApprovedWarning:"\u5F53\u524D\u62DF\u5408\u52A8\u4F5C\u5DF2\u901A\u8FC7\u52A8\u4F5C\u8D28\u91CF\u4EBA\u5DE5\u5BA1\u6838\uFF0C\u4EC5\u7528\u4E8E\u672C\u5730\u7814\u7A76\u6F14\u793A\u3002\u955C\u50CF\u65B9\u5411\u3001\u60EF\u7528\u624B\u3001\u4EBA\u7269\u8EAB\u4EFD\u3001\u4E2D\u6587\u542B\u4E49\u548C\u8BCD\u754C\u4ECD\u672A\u786E\u8BA4\uFF1B\u5B83\u4EEC\u4E0D\u662F\u8BAD\u7EC3\u6570\u636E\u3001\u672A\u66F4\u65B0\u6A21\u578B\u6743\u91CD\uFF0C\u6F14\u793A\u4ECD\u53EF\u80FD\u6709\u624B\u578B\u8BEF\u5DEE\u3001\u8DF3\u53D8\u6216\u7A7F\u6A21\u3002",demoExperimentalMixedWarning:"\u90E8\u5206\u62DF\u5408\u52A8\u4F5C\u5DF2\u901A\u8FC7\u52A8\u4F5C\u8D28\u91CF\u4EBA\u5DE5\u5BA1\u6838\uFF1B\u5176\u4F59\u52A8\u4F5C\u4ECD\u5F85\u5BA1\u6838\u3002\u5168\u90E8\u52A8\u4F5C\u4EC5\u7528\u4E8E\u7814\u7A76\u6F14\u793A\u3002\u955C\u50CF\u65B9\u5411\u3001\u60EF\u7528\u624B\u3001\u4EBA\u7269\u8EAB\u4EFD\u3001\u4E2D\u6587\u542B\u4E49\u548C\u8BCD\u754C\u4ECD\u672A\u786E\u8BA4\uFF0C\u4E5F\u672A\u7528\u4E8E\u8BAD\u7EC3\u6216\u66F4\u65B0\u6A21\u578B\u6743\u91CD\u3002",demoExperimentalPreviewWarning:"\u7B2C 6 \u6279\u4EBA\u7269\u9884\u89C8\uFF1A\u6587\u5B57\u548C\u52A8\u4F5C\u9996\u5C3E\u662F\u672A\u6838\u9A8C\u5019\u9009\uFF0C\u53EF\u80FD\u5939\u5E26\u76F8\u90BB\u6559\u5B66\u52A8\u4F5C\u3002\u8BF7\u5BF9\u7167\u539F\u7247\u68C0\u67E5\u624B\u578B\u3001\u65B9\u5411\u548C\u6296\u52A8\uFF1B\u955C\u50CF\u3001\u4EBA\u7269\u53CA\u52A8\u4F5C\u8D28\u91CF\u4ECD\u5F85\u786E\u8BA4\u3002\u663E\u793A\u5E73\u6ED1\u53EA\u6539\u53D8\u64AD\u653E\u6548\u679C\uFF0C\u672A\u8BAD\u7EC3\u6A21\u578B\u3002",demoInvalidExperimentalAsset:"\u5B9E\u9A8C\u52A8\u4F5C\u6587\u4EF6\u4E0D\u5B8C\u6574\u6216\u6765\u6E90\u6821\u9A8C\u5931\u8D25",demoCandidateBadge:"T08 tokenizer \xB7 \u5019\u9009\u91CD\u5EFA",demoCandidateDetail:"T08\u5019\u9009 \xB7 \u5F52\u4E00\u5316\u8BEF\u5DEE {mse}",demoInvalidCandidateAsset:"\u5019\u9009\u52A8\u4F5C\u6765\u6E90\u6216\u5BA1\u6838\u72B6\u6001\u4E0D\u7B26",demoCandidateWarning:"\u65B0\u589E3\u6761\u5019\u9009\u53E5\uFF1A\u7531\u73B0\u6709T08\u6743\u91CD\u7F16\u7801/\u89E3\u7801\uFF0C\u672A\u66F4\u65B0\u6743\u91CD\uFF1B\u91CD\u5EFA\u8BEF\u5DEE\u9AD8\u4E8E\u539F14\u6761\uFF0C\u955C\u50CF\u65B9\u5411\u548C\u4EBA\u7269\u5206\u7EC4\u672A\u786E\u8BA4\u3002\u4EC5\u4F9BDemo\u6BD4\u8F83\uFF0C\u4E0D\u4F5C\u4E3A\u51C6\u786E\u7FFB\u8BD1\u6216\u6B63\u5F0F\u8BAD\u7EC3\u6570\u636E\u3002",demoTokens:"\u67E5\u770B\u6700\u8FD1\u64AD\u653E\u7684\u52A8\u4F5C\u7F16\u7801",demoTokenNote:"\u4E0B\u65B9\u4E3A\u5B9E\u9645 T08 \u7F16\u7801\u7684 token\u3002\u64AD\u653E\u6765\u81EA\u8FD9\u4E9B token \u7684\u79BB\u7EBF\u89E3\u7801\u7ED3\u679C\uFF1B\u6D4F\u89C8\u5668\u4E0D\u6267\u884C PyTorch\u3002",demoEvidence:"\u91CD\u5EFA\u8BC1\u636E",demoComparison:"\u7814\u7A76\u5173\u952E\u5E27\u5BF9\u7167",demoReadonly:"\u53EA\u8BFB\u5019\u9009 \xB7 \u70B9\u51FB\u653E\u5927",demoClose:"\u6536\u8D77\u5BF9\u7167",demoScope:"\u5B9E\u9A8C\u6027\u5C55\u793A\uFF1AT08 \u8D1F\u8D23\u5DF2\u6709\u53C2\u8003\u52A8\u4F5C\u7684\u7F16\u7801/\u91CD\u5EFA\uFF1B\u6587\u5B57\u7528\u4E8E\u68C0\u7D22\uFF0C\u5185\u7F6E\u8BCD\u5E93\u7528\u4E8E\u8865\u5145\u3002\u672A\u8986\u76D6\u6587\u5B57\u4E0D\u4F1A\u81EA\u52A8\u751F\u6210\u624B\u8BED\uFF0C\u62FC\u63A5\u4E5F\u4E0D\u4EE3\u8868\u6B63\u786E\u7684\u624B\u8BED\u8BED\u6CD5\u3002",demoHow:"\u8FD9\u4EFD Demo \u600E\u6837\u5DE5\u4F5C\uFF1F",demoHowBody:"\u76EE\u5F55\u5408\u5E76\u4E86 T08 \u53C2\u8003\u4E0E\u5019\u9009\u3001\u89C6\u9891\u62DF\u5408\u7684\u5B9E\u9A8C\u52A8\u4F5C\u548C\u8BCD\u5E93\u7EC4\u5408\uFF1B\u91CD\u590D\u6587\u5B57\u53EA\u4FDD\u7559\u4E00\u4E2A\u5165\u53E3\u3002\u5B9E\u9A8C\u52A8\u4F5C\u672A\u66F4\u65B0\u6A21\u578B\u6743\u91CD\uFF1B\u8BCD\u5E93\u7EC4\u5408\u5E76\u975E\u53E5\u7EA7\u8BAD\u7EC3\u6216\u7ECF\u624B\u8BED\u8005\u6838\u9A8C\u7684\u7FFB\u8BD1\u3002",demoRetargetNote:"SMPL-X \u59FF\u6001\u901A\u8FC7\u6E90\u9AA8\u67B6\u4E0E\u89D2\u8272 REST \u6821\u51C6\u540E\u8F6C\u6362\u4E3A\u56DB\u5143\u6570\u3002\u6839\u90E8\u3001\u4E0B\u8EAB\u4FDD\u6301\u89D2\u8272\u5F85\u673A\uFF0C\u8868\u60C5\u7CFB\u6570\u5C1A\u672A\u5B8C\u6574\u6620\u5C04\u3002\u624B\u578B\u548C\u7A7F\u6A21\u4ECD\u4E3A\u5B9E\u9A8C\u6548\u679C\u3002",demoReady:"\u5DF2\u5C31\u7EEA\uFF0C\u8F93\u5165\u6587\u5B57\u6216\u9009\u62E9\u7247\u6BB5\u3002",demoNoMatch:"\u6682\u672A\u5339\u914D\u5230\u53EF\u7528\u52A8\u4F5C\uFF0C\u8BF7\u4ECE\u4E0B\u65B9\u9009\u62E9\u4E00\u4E2A\u4F8B\u5B50\u3002",demoUnknown:"\u6682\u4E0D\u652F\u6301\uFF1A{text}",demoAllMatched:"\u5DF2\u8986\u76D6\u5168\u90E8\u8F93\u5165\u5185\u5BB9\u3002",demoSemanticPreview:"\u5DF2\u6309\u4EBA\u7269\u3001\u52A8\u4F5C\u548C\u5173\u7CFB\u7EC4\u7EC7\u52A8\u4F5C\uFF1B\u8FD9\u662F Demo \u8BED\u4E49\u8FD1\u4F3C\uFF0C\u5C1A\u672A\u6838\u51C6\u4E2D\u56FD\u624B\u8BED\u8BED\u6CD5\u3002",demoCount:"{count} \u4E2A\u52A8\u4F5C",demoPlaying:"\u6B63\u5728\u64AD\u653E {index}/{count}\uFF1A{text}",demoPaused:"\u5DF2\u6682\u505C\uFF0C\u53EF\u7EE7\u7EED\u6216\u505C\u6B62\u3002",demoStopped:"\u5DF2\u505C\u6B62\u5E76\u56DE\u5230\u5F85\u673A\u3002",demoFinished:"\u672C\u6B21\u64AD\u653E\u5B8C\u6210\u3002",demoFailed:"\u52A0\u8F7D\u5931\u8D25\uFF1A{detail}\u3002\u8BF7\u91CD\u65B0\u52A0\u8F7D\u9875\u9762\u3002",demoTokenEmpty:"\u64AD\u653E\u4E00\u6BB5 T08 \u53C2\u8003\u77ED\u53E5\u540E\uFF0C\u53EF\u67E5\u770B\u4E09\u8DEF\u7F16\u7801\u3002",demoDictionaryToken:"\u5F53\u524D\u64AD\u653E\u5185\u7F6E\u8BCD\u5E93\u52A8\u4F5C\uFF0C\u4E0D\u4F7F\u7528 T08 token\u3002",demoSourceT08:"T08 \xB7 \u53C2\u8003\u52A8\u4F5C\u91CD\u5EFA",demoSourceSemantic:"\u8BED\u4E49\u8DEF\u7531 \xB7 \u8BCD\u6761\u7EC4\u5408\uFF08Demo\u8FD1\u4F3C\uFF09",demoSourceDictionary:"\u8BCD\u5E93 \xB7 \u5185\u7F6E\u52A8\u4F5C",demoSourceFallback:"\u8BCD\u5E93\u56DE\u9000 \xB7 \u53C2\u8003\u52A8\u4F5C\u52A0\u8F7D\u5931\u8D25",demoSourceComposition:"\u8BCD\u5E93\u7EC4\u5408 \xB7 \u9010\u8BCD\u64AD\u653E\uFF0C\u975E\u53E5\u7EA7\u8BAD\u7EC3",demoResearchLabel:"{text} \xB7 {series} \xB7 \u539F\u56FE / baseline / candidate",demoResearchMissing:"\u6B64\u5DE5\u4F5C\u533A\u5C1A\u672A\u6253\u5305\u7814\u7A76\u5BF9\u7167\u56FE\u3002",demoPartialAsset:"T08 \u8D44\u4EA7\u4E0D\u53EF\u7528\uFF0C\u73B0\u6709\u8BCD\u5E93\u4ECD\u53EF\u64AD\u653E\u3002",demoExported:"\u672C\u6B21\u5339\u914D\u4E0E\u6765\u6E90\u62A5\u544A\u5DF2\u4E0B\u8F7D\u3002",demoInvalidMode:"\u672A\u77E5\u52A8\u4F5C\u6A21\u5F0F",demoInvalidAsset:"T08\u8D44\u4EA7\u683C\u5F0F\u6216checkpoint\u6765\u6E90\u4E0D\u7B26",demoInvalidRotation:"\u65E0\u6548\u59FF\u6001\u65CB\u8F6C",demoMissingBone:"\u89D2\u8272\u7F3A\u5C11\u5FC5\u8981\u624B\u90E8\u9AA8\u9ABC",demoNotReady:"\u89D2\u8272\u5C1A\u672A\u52A0\u8F7D\u5B8C\u6210",demoTooLong:"\u8F93\u5165\u8FC7\u957F\uFF0C\u4EC5\u5339\u914D\u524D500\u4E2A\u5B57\u7B26\u3002"},Ea={intakeRefinementTitle:"Source {name} \xB7 Motion boundary review",intakeRefinementPending:"Text/boundary proposal \xB7 Not human-confirmed",intakePrevious:"Previous candidate window {start}\u2013{end}s: {text}",intakeBefore:"Previous candidate window",intakeAfter:"Revised candidate window",intakeRefinedWindow:"Revised nominal window {start}\u2013{end}s; {frames} decoded frames / {duration}s. Check completion near the original video end.",intakeCoverageComparison:"Frames with at least one observed hand: {before}% \u2192 {after}%. Different windows are compared; this is not improved detector accuracy.",intakeTitle:"Source {name} \xB7 New video review",intakeSummary:"{files} files / {unique} unique contents; {screened} sources screened, {candidates} caption candidates; {references} 2D references / {frames} frames.",intakeLimits:"Text meaning, boundaries, mirroring, handedness and signer groups are unverified. OCR candidates and 2D observations only; no new SMPL-X motions or model training. training_ready=false.",intakePending:"OCR candidate \xB7 Unreviewed",intakeWindow:"Nominal window {start}\u2013{end}s \xB7 Mean OCR confidence {confidence}",intakeOriginal:"Open authorized source interval",intakeDuplicate:"Same bytes as an earlier source",catchupTitle:"Video catch-up \xB7 Source clips and hand references",catchupSummary:"{files} video files / {sources} unique contents \xB7 {windows} new reference windows / {frames} frames \xB7 {sampled} independent hand observations",catchupLimits:"Caption candidates and estimated observations only. Text, boundaries, mirroring and signer groups are unverified; no new training or SMPL-X parameters. Five samples do not annotate an entire video.",catchupReferences:"New continuous windows",catchupSources:"All source progress",catchupCaptions:"Raw caption candidates",catchupIndex:"Fitting index",catchupRegistry:"Source registry",catchupReport:"Stage report",catchupSearch:"Search text, video name or source ID",catchupPage:"{count} items \xB7 Page {page}/{pages}",catchupPrevious:"Previous",catchupNext:"Next",catchupOriginal:"Source candidate window",catchupOverlay:"Landmark preview",catchupSync:"Play / pause together",catchupKeyframes:"Five source frames and hand crops",catchupKeyframeAlt:"Source images and estimated hand crops for {text}",catchupIndependentAlt:"Five independent hand observation samples",catchupCoverage:"Eligible estimated frames: left {left}/{frames}, right {right}/{frames}; this is not accuracy or anatomical verification.",catchupSourceStages:"{prior} prior references \xB7 {motions} prior motions \xB7 {fresh} new reference windows \xB7 {sampled} independent samples. Whole-video completion remains described in the report.",catchupHksl:"Title suggests Hong Kong Sign Language; unverified, stored separately and excluded from CSL sentence training.",catchupEmptyCaption:"No readable caption",catchupMediaError:"Media playback failed. Check the local files and retry.",demoOpen:"Open demo workspace",demoLocal:"Local offline demo",demoExport:"Export session",demoEyebrow:"Sign language in motion \xB7 Experimental demo",demoHeading:"Words you can see",demoLead:"Choose a clip or enter text to play reference motions, experimental fits and dictionary motions.",demoInput:"Text input",demoMode:"Motion source",demoAuto:"Automatic",demoT08:"Reference / experimental",demoDictionary:"Dictionary",demoPlaceholder:"Try: \u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",demoSample:"\u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",demoShortcut:"Ctrl / \u2318 + Enter to play",demoPlay:"Play",demoPause:"Pause",demoResume:"Resume",demoStop:"Stop",demoRetry:"Reload demo",demoLoading:"Loading avatar and motions\u2026",demoMatches:"Matched text",demoCatalog:"Phrases and dictionary",demoCatalogViews:"Phrase or dictionary view",demoPhraseTab:"Phrases / clips",demoWordTab:"Dictionary motions",demoVocabTab:"Basic vocabulary",demoVocabNote:"{total} common words: {native} with native motion candidates, {pose} with built-in hand-made poses, {none} listed only (no motion yet). No motion has been human-reviewed.",demoVocabNoMotion:"No motion exists for \u201C{text}\u201D yet. It is listed only and no other motion is substituted.",demoVocabStatusNative:"Has motion (native candidate, unreviewed)",demoVocabStatusNativeReduced:"Has motion (native candidate, reduced wrist amplitude)",demoVocabStatusPose:"Has motion (built-in hand-made pose)",demoVocabStatusNone:"Listed only (no motion yet)",demoPhraseSourceNote:"{total} entries: {reference} T08 references, {candidate} candidates, {experimental} experimental fits, {composed} dictionary compositions.",demoWordSourceNote:"{count} built-in entries. These word motions are not new sentence-training results.",demoSearch:"Search phrases or dictionary entries",demoAvatarLabel:"Project avatar \xB7 Godette",demoStage:"Avatar",demoReadyBadge:"Ready",demoAtRest:"Idle",demoView:"View",demoFront:"Front",demoLeft:"Left",demoRight:"Right",demoSpeed:"Speed",demoSmoothing:"Motion smoothing",demoExperimentalSmoothedBadge:"SMPL-X \xB7 Experimental fit \xB7 Smoothed",demoAdaptiveFilteredBadge:"SMPL-X \xB7 Experimental fit \xB7 isolated-spike comparison",demoAdaptiveFilteredWarningBadge:"SMPL-X \xB7 Spike comparison \xB7 raw risk remains",demoExperimentalSmoothedWarningBadge:"SMPL-X \xB7 Experimental \xB7 Smoothed \xB7 Raw jitter flagged",demoExperimentalRawBadge:"SMPL-X \xB7 Experimental fit \xB7 Raw",demoModel:"Research model",demoLearned:"Original T08 phrases",demoWords:"Dictionary motions",demoCandidates:"Motion candidates",demoExperimental:"Experimental fits",demoExperimentalBadge:"SMPL-X \xB7 Experimental fit",demoExperimentalWarningBadge:"SMPL-X \xB7 Experimental fit \xB7 High jitter",demoExperimentalToken:"Video-fitted SMPL-X motion, not T08 token decoding. No model weights were updated.",demoExperimentalWarning:"Experimental motions have unreviewed motion quality, mirroring and signer identity. Demo only; hand errors, jitter and mesh intersections may occur.",demoExperimentalApprovedWarning:"Fitted motions passed human motion-quality review for local research demos only. Mirroring, handedness, signer identity, Chinese meaning and boundaries remain unverified. These are not training data; no model weights were updated, and hand errors, jitter or mesh intersections may still occur.",demoExperimentalMixedWarning:"Some fitted motions passed human motion-quality review; others remain unreviewed. All are research-demo only. Mirroring, handedness, signer identity, Chinese meaning and boundaries remain unverified; no training or weight updates occurred.",demoExperimentalPreviewWarning:"Source-6 avatar preview: text and motion boundaries are unverified proposals and may include adjacent teaching demonstrations. Compare with the source for hand shapes, direction and jitter. Mirror, signer and motion quality remain unreviewed. Display smoothing changes playback only; no model was trained.",demoInvalidExperimentalAsset:"Incomplete experimental motion or provenance mismatch",demoCandidateBadge:"T08 tokenizer \xB7 Candidate reconstruction",demoCandidateDetail:"T08 candidate \xB7 normalized error {mse}",demoInvalidCandidateAsset:"Candidate motion provenance or review contract differs",demoCandidateWarning:"Three added phrase candidates are encoded/decoded with the existing T08 weights; weights were not updated. Reconstruction error is higher than for the original 14, and mirroring/signer grouping remain unconfirmed. Demo comparison only; not approved translation or training data.",demoTokens:"Last played motion tokens",demoTokenNote:"Actual T08 tokens are shown below. Playback uses their offline decoded motions; the browser does not run PyTorch.",demoEvidence:"Reconstruction evidence",demoComparison:"Research keyframe comparisons",demoReadonly:"Read-only candidates \xB7 Click to enlarge",demoClose:"Close comparison",demoScope:"Experimental showcase: T08 encodes and reconstructs existing reference motions. Text retrieves clips; dictionary entries supplement coverage. Unsupported text is reported. Concatenation does not establish correct sign language grammar.",demoHow:"How does this demo work?",demoHowBody:"The catalog merges T08 references and candidates, video-fitted experimental motions and dictionary compositions. Duplicate text has one entry. Experimental fits do not update model weights; dictionary compositions are not sentence-trained or sign-expert reviewed.",demoRetargetNote:"SMPL-X poses are calibrated to the avatar skeleton and played as quaternions. The root and lower body remain at rest; facial coefficients are not mapped. Hand shapes and mesh contact remain experimental.",demoReady:"Ready. Enter text or choose an example.",demoNoMatch:"No motion matched. Choose an example below.",demoUnknown:"Not supported: {text}",demoAllMatched:"All input text is covered.",demoSemanticPreview:"Motion was organized by person, action and relation; this is an unverified demo approximation, not validated CSL grammar.",demoCount:"{count} motions",demoPlaying:"Playing {index}/{count}: {text}",demoPaused:"Paused. Resume or stop.",demoStopped:"Stopped and reset to idle.",demoFinished:"Playback complete.",demoFailed:"Playback unavailable: {detail}. Reload to retry.",demoTokenEmpty:"Play a T08 reference phrase to inspect its three token streams.",demoDictionaryToken:"The last played dictionary motion does not use T08 tokens.",demoSourceT08:"T08 \xB7 Reference reconstruction",demoSourceSemantic:"Semantic route \xB7 dictionary composition (demo approximation)",demoSourceDictionary:"Dictionary \xB7 Built-in motion",demoSourceFallback:"Dictionary fallback \xB7 Reference unavailable",demoSourceComposition:"Dictionary composition \xB7 Word-by-word, not sentence-trained",demoResearchLabel:"{text} \xB7 {series} \xB7 Original / baseline / candidate",demoResearchMissing:"No research comparisons were packaged in this workspace.",demoPartialAsset:"T08 assets unavailable. Dictionary motions can still play.",demoExported:"Session matching and provenance report downloaded.",demoInvalidMode:"Unknown motion mode",demoInvalidAsset:"Invalid T08 asset or checkpoint provenance",demoInvalidRotation:"Invalid pose rotation",demoMissingBone:"Required avatar hand bones are missing",demoNotReady:"Avatar is still loading",demoTooLong:"Only the first 500 characters are matched.",demoLimit:"Up to 40 motions per playback; the remaining text is listed as unsupported.",demoCheckpoint:"Checkpoint: {hash} \xB7 {steps} steps",demoWebGL:"3D rendering context unavailable"},Zh={postFitBrand:"SignBridge \xB7 \u624B\u8BED\u7814\u7A76",postFitTitle:"\u91CD\u5EFA\u540E\u5019\u9009\u79BB\u7EBF\u590D\u6838",postFitIntro:"\u9010\u6761\u67E5\u770B\u539F\u59CB\u7247\u6BB5\u3001\u7CBE\u786E\u8F93\u5165 JPEG \u4E0E\u539F\u751F SMPL-X \u6E32\u67D3\u3002\u6807\u7B7E\u4E0E\u8D28\u91CF\u6807\u8BB0\u5747\u4EC5\u4E3A\u5019\u9009\u8D44\u6599\u3002",postFitLanguage:"\u754C\u9762\u8BED\u8A00",postFitChinese:"\u7B80\u4F53\u4E2D\u6587",postFitEnglish:"English",postFitJapanese:"\u65E5\u672C\u8A9E",postFitCandidateStatus:"\u4EC5\u5019\u9009 \xB7 \u8D28\u91CF\u5F85\u590D\u6838",postFitCandidateOnly:"\u4EC5\u5019\u9009\u4E0E\u8D28\u91CF\u6807\u8BB0\u3002\u672A\u7ECF\u4EBA\u5DE5\u3001\u8BED\u4E49\u6216\u8BAD\u7EC3\u6279\u51C6\uFF1B\u4E0D\u5177\u5907\u8BAD\u7EC3\u6216\u6A21\u578B\u8BAD\u7EC3\u5C31\u7EEA\u72B6\u6001\u3002",postFitLimits:"\u7ED3\u6784\u4E0E\u539F\u59CB\u65CB\u8F6C\u7B5B\u67E5\u4E0D\u4EE3\u8868\u4EBA\u5DE5\u89C6\u89C9\u6279\u51C6\u3002\u78B0\u649E\u3001\u8BED\u4E49\u8D28\u91CF\u53CA\u4EBA\u5DE5\u89C6\u89C9\u8D28\u91CF\u5747\u672A\u8BC4\u4F30\u3002\u7F3A\u5931\u68C0\u6D4B\u4FDD\u7559\u5B9E\u9645\u6E32\u67D3\u56FE\u50CF\u5E76\u9694\u79BB\uFF0C\u4E0D\u586B\u5145\u59FF\u52BF\u3001\u4E0D\u63D2\u503C\u3001\u4E0D\u81EA\u52A8\u6279\u51C6\u3002",postFitSummary:"\u5019\u9009\u5A92\u4F53\u6784\u5EFA\u6C47\u603B",postFitCandidates:"\u5168\u90E8\u5019\u9009",postFitSearch:"\u641C\u7D22\u5019\u9009\u6807\u7B7E\u3001ID \u6216\u6765\u6E90",postFitQuality:"\u5BA1\u8BA1\u8D28\u91CF\u6807\u8BB0",postFitAllQuality:"\u5168\u90E8\u8D28\u91CF\u6807\u8BB0",postFitUnknown:"\u672A\u77E5",postFitNoneReported:"\u5BA1\u8BA1\u672A\u62A5\u544A",postFitQuarantined:"\u9694\u79BB\u5019\u9009 \xB7 \u4ECD\u9700\u590D\u6838",postFitReviewFrames:"\u8054\u7CFB\u8868\u5E27\u53F7\uFF08\u4ECE 1 \u5F00\u59CB\uFF0C\u6309\u6240\u5217\u987A\u5E8F\uFF09",postFitMissingDetections:"\u7F3A\u5931\u68C0\u6D4B\u5E27\u53F7",postFitMetrics:"\u539F\u59CB\u65CB\u8F6C\u6307\u6807\uFF08\u975E\u8BED\u4E49\u6216\u89C6\u89C9\u6279\u51C6\uFF09",postFitMediaLegend:"\u5DE6\uFF1A\u539F\u59CB\u8F93\u5165\uFF1B\u53F3\uFF1A\u539F\u751F SMPL-X \u6E32\u67D3\u3002\u8054\u7CFB\u8868\u6309\u6240\u5217\u5E27\u987A\u5E8F\uFF1B\u5BF9\u7167\u89C6\u9891\u5DE6\u4FA7\u4E3A\u539F\u59CB\u7247\u6BB5\u3002",postFitContactAlt:"{label} \u7684\u5019\u9009\u539F\u59CB\u8F93\u5165\u4E0E\u539F\u751F\u6E32\u67D3\u8054\u7CFB\u8868",postFitOpenContact:"\u6253\u5F00\u5019\u9009\u8054\u7CFB\u8868",postFitMediaUnavailable:"\u672A\u63D0\u4F9B\u53EF\u5B89\u5168\u6253\u5F00\u7684\u5019\u9009\u8054\u7CFB\u8868\u3002\u8BF7\u67E5\u770B\u5A92\u4F53\u6784\u5EFA\u5931\u8D25\u8BB0\u5F55\u3002",postFitMediaError:"\u672C\u5730\u5019\u9009\u5A92\u4F53\u8BFB\u53D6\u5931\u8D25\u3002\u8BF7\u67E5\u770B\u62A5\u544A\u4E0E\u6587\u4EF6\u5B8C\u6574\u6027\u3002",postFitShowOriginal:"\u6309\u9700\u6253\u5F00\u539F\u59CB\u7247\u6BB5\uFF08\u539F\u5B57\u8282\u526F\u672C\uFF09",postFitShowComparison:"\u6309\u9700\u6253\u5F00\u5B8C\u6574\u5E76\u6392\u5BF9\u7167",postFitHideMedia:"\u5173\u95ED\u6B64\u89C6\u9891",postFitProvenance:"\u6765\u6E90\u3001\u8D28\u91CF\u6807\u8BB0\u4E0E\u5A92\u4F53\u5931\u8D25\u8BB0\u5F55",postFitAnnotation:"\u6807\u6CE8 ID",postFitChunk:"\u5206\u5757",postFitSource:"\u6765\u6E90 ID",postFitSourceHash:"\u6765\u6E90 SHA-256\uFF08\u53EF\u80FD\u4E0D\u662F\u6B64\u7247\u6BB5\u54C8\u5E0C\uFF09",postFitAuditStatus:"\u5BA1\u8BA1\u8BB0\u5F55\u72B6\u6001",postFitFps:"\u63D0\u4F9B\u7684\u5E27\u7387",postFitExpectedFrames:"\u9884\u671F\u5E27\u6570",postFitProcessedFrames:"\u5DF2\u9A8C\u8BC1\u5BF9\u7167\u5E27\u6570",postFitClipPath:"\u539F\u59CB\u7247\u6BB5\u8DEF\u5F84",postFitInputDirectory:"\u539F\u59CB\u8F93\u5165\u76EE\u5F55",postFitRenderDirectory:"\u539F\u751F\u6E32\u67D3\u76EE\u5F55",postFitFitDirectory:"\u62DF\u5408\u76EE\u5F55",postFitTechnicalErrors:"\u5BA1\u8BA1\u6280\u672F\u9519\u8BEF",postFitFailures:"\u5A92\u4F53\u6784\u5EFA\u5931\u8D25\u8BB0\u5F55",postFitMediaHashes:"\u5A92\u4F53 SHA-256",postFitPageCount:"\u7B2C {start}\u2013{end} \u6761\uFF0C\u5171 {count} \u6761\u5019\u9009 \xB7 \u7B2C {page}/{pages} \u9875",postFitPrevious:"\u4E0A\u4E00\u9875",postFitNext:"\u4E0B\u4E00\u9875",postFitEmpty:"\u6CA1\u6709\u7B26\u5408\u5F53\u524D\u641C\u7D22\u4E0E\u8D28\u91CF\u7B5B\u9009\u6761\u4EF6\u7684\u5019\u9009\u3002",postFitTotalCandidates:"\u5BA1\u8BA1\u603B\u5019\u9009\u6570",postFitSuccessfulMedia:"\u5DF2\u9A8C\u8BC1\u5A92\u4F53\u6587\u4EF6\u6570",postFitFailedCandidates:"\u5A92\u4F53\u672A\u9F50\u5168\u7684\u5019\u9009\u6570",postFitFailureCount:"\u5931\u8D25\u8BB0\u5F55\u6570",postFitMissingData:"\u7F3A\u5C11\u672C\u5730\u5019\u9009\u6570\u636E\u3002\u8BF7\u5C06\u751F\u6210\u7684 review-data.js \u4FDD\u7559\u5728\u6B64\u9875\u65C1\u3002",postFitOffline:"\u79BB\u7EBF\u5019\u9009\u590D\u6838 \xB7 \u6BCF\u9875\u6700\u591A 24 \u6761 \xB7 \u89C6\u9891\u4EC5\u6309\u9700\u6253\u5F00 \xB7 \u4E0D\u8FDE\u63A5\u7F51\u7EDC\u6216\u5199\u5165\u6279\u51C6\u72B6\u6001\u3002",postFitUnassessedQuality:"\u78B0\u649E\u3001\u8BED\u4E49\u8D28\u91CF\u3001\u4EBA\u5DE5\u89C6\u89C9\u8D28\u91CF\uFF1A\u5747\u672A\u8BC4\u4F30\u3002"},$h={postFitBrand:"SignBridge \xB7 Sign language research",postFitTitle:"Post-reconstruction candidate review",postFitIntro:"Inspect every original clip, exact input JPEG and native SMPL-X render offline. Labels and quality flags remain candidate evidence.",postFitLanguage:"Interface language",postFitChinese:"Simplified Chinese",postFitEnglish:"English",postFitJapanese:"Japanese",postFitCandidateStatus:"Candidate only \xB7 quality review pending",postFitCandidateOnly:"Candidate and quality flags only. No human, semantic or training approval; neither training-ready nor model-training-ready.",postFitLimits:"Structural and raw rotational screening is not human visual approval. Collision, semantic quality and human visual quality are unassessed. Missing detections retain actual render images in quarantine; no pose filling, interpolation or automatic approval.",postFitSummary:"Candidate media build summary",postFitCandidates:"All candidates",postFitSearch:"Search candidate labels, IDs or sources",postFitQuality:"Audit quality flag",postFitAllQuality:"All quality flags",postFitUnknown:"Unknown",postFitNoneReported:"None reported by the audit",postFitQuarantined:"Quarantined candidate \xB7 review pending",postFitReviewFrames:"Contact frame indices (one-based, in listed order)",postFitMissingDetections:"Missing detection frame indices",postFitMetrics:"Raw rotation metrics (not semantic or visual approval)",postFitMediaLegend:"Left: original input. Right: native SMPL-X render. Contact rows follow the listed indices; the comparison video uses the original clip on the left.",postFitContactAlt:"Candidate original input versus native render contact sheet for {label}",postFitOpenContact:"Open candidate contact sheet",postFitMediaUnavailable:"No safe candidate contact sheet is available. Inspect media build failures.",postFitMediaError:"Local candidate media could not load. Check the report and file integrity.",postFitShowOriginal:"Open original clip on demand (byte-for-byte copy)",postFitShowComparison:"Open full side-by-side comparison on demand",postFitHideMedia:"Close this video",postFitProvenance:"Provenance, quality flags and media failures",postFitAnnotation:"Annotation ID",postFitChunk:"Chunk",postFitSource:"Source ID",postFitSourceHash:"Source SHA-256 (may differ from the clip hash)",postFitAuditStatus:"Audit record status",postFitFps:"Provided frame rate",postFitExpectedFrames:"Expected frames",postFitProcessedFrames:"Verified comparison frames",postFitClipPath:"Original clip path",postFitInputDirectory:"Original input directory",postFitRenderDirectory:"Native render directory",postFitFitDirectory:"Fit directory",postFitTechnicalErrors:"Audit technical errors",postFitFailures:"Media build failures",postFitMediaHashes:"Media SHA-256",postFitPageCount:"Candidates {start}\u2013{end} of {count} \xB7 page {page}/{pages}",postFitPrevious:"Previous",postFitNext:"Next",postFitEmpty:"No candidates match the current search and quality filter.",postFitTotalCandidates:"Total audit candidates",postFitSuccessfulMedia:"Verified media files",postFitFailedCandidates:"Candidates with incomplete media",postFitFailureCount:"Failure records",postFitMissingData:"Local candidate data is missing. Keep the generated review-data.js beside this page.",postFitOffline:"Offline candidate review \xB7 at most 24 per page \xB7 videos open on demand \xB7 no network or approval-state writes.",postFitUnassessedQuality:"Collision, semantic quality and human visual quality: all unassessed."},jh={postFitBrand:"SignBridge \xB7 \u624B\u8A71\u7814\u7A76",postFitTitle:"\u518D\u69CB\u7BC9\u5F8C\u306E\u5019\u88DC\u306E\u30AA\u30D5\u30E9\u30A4\u30F3\u78BA\u8A8D",postFitIntro:"\u5404\u5019\u88DC\u306E\u5143\u52D5\u753B\u3001\u6B63\u78BA\u306A\u5165\u529B JPEG\u3001\u30CD\u30A4\u30C6\u30A3\u30D6 SMPL-X \u63CF\u753B\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u30E9\u30D9\u30EB\u3068\u54C1\u8CEA\u30D5\u30E9\u30B0\u306F\u5019\u88DC\u8CC7\u6599\u3067\u3059\u3002",postFitLanguage:"\u8868\u793A\u8A00\u8A9E",postFitChinese:"\u7C21\u4F53\u5B57\u4E2D\u56FD\u8A9E",postFitEnglish:"English",postFitJapanese:"\u65E5\u672C\u8A9E",postFitCandidateStatus:"\u5019\u88DC\u306E\u307F \xB7 \u54C1\u8CEA\u78BA\u8A8D\u5F85\u3061",postFitCandidateOnly:"\u5019\u88DC\u3068\u54C1\u8CEA\u30D5\u30E9\u30B0\u306E\u307F\u3067\u3059\u3002\u4EBA\u306B\u3088\u308B\u78BA\u8A8D\u30FB\u610F\u5473\u30FB\u5B66\u7FD2\u306E\u627F\u8A8D\u306F\u306A\u304F\u3001\u5B66\u7FD2\u304A\u3088\u3073\u30E2\u30C7\u30EB\u5B66\u7FD2\u306E\u6E96\u5099\u5B8C\u4E86\u3092\u793A\u3057\u307E\u305B\u3093\u3002",postFitLimits:"\u69CB\u9020\u3068\u751F\u306E\u56DE\u8EE2\u5024\u306E\u691C\u67FB\u306F\u76EE\u8996\u306B\u3088\u308B\u627F\u8A8D\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u885D\u7A81\u30FB\u610F\u5473\u306E\u54C1\u8CEA\u30FB\u4EBA\u306B\u3088\u308B\u8996\u899A\u54C1\u8CEA\u306F\u672A\u8A55\u4FA1\u3067\u3059\u3002\u691C\u51FA\u6B20\u843D\u306F\u5B9F\u969B\u306E\u63CF\u753B\u753B\u50CF\u306E\u307E\u307E\u9694\u96E2\u3057\u3001\u59FF\u52E2\u88DC\u5B8C\u30FB\u88DC\u9593\u30FB\u81EA\u52D5\u627F\u8A8D\u306F\u884C\u3044\u307E\u305B\u3093\u3002",postFitSummary:"\u5019\u88DC\u30E1\u30C7\u30A3\u30A2\u751F\u6210\u306E\u96C6\u8A08",postFitCandidates:"\u3059\u3079\u3066\u306E\u5019\u88DC",postFitSearch:"\u5019\u88DC\u30E9\u30D9\u30EB\u30FBID\u30FB\u51FA\u5178\u3092\u691C\u7D22",postFitQuality:"\u76E3\u67FB\u54C1\u8CEA\u30D5\u30E9\u30B0",postFitAllQuality:"\u3059\u3079\u3066\u306E\u54C1\u8CEA\u30D5\u30E9\u30B0",postFitUnknown:"\u4E0D\u660E",postFitNoneReported:"\u76E3\u67FB\u3067\u306F\u5831\u544A\u306A\u3057",postFitQuarantined:"\u9694\u96E2\u5019\u88DC \xB7 \u78BA\u8A8D\u5F85\u3061",postFitReviewFrames:"\u4E00\u89A7\u306E\u30D5\u30EC\u30FC\u30E0\u756A\u53F7\uFF081 \u59CB\u307E\u308A\u3001\u8A18\u8F09\u9806\uFF09",postFitMissingDetections:"\u691C\u51FA\u6B20\u843D\u30D5\u30EC\u30FC\u30E0\u756A\u53F7",postFitMetrics:"\u751F\u306E\u56DE\u8EE2\u6307\u6A19\uFF08\u610F\u5473\u3084\u76EE\u8996\u306E\u627F\u8A8D\u3067\u306F\u3042\u308A\u307E\u305B\u3093\uFF09",postFitMediaLegend:"\u5DE6\uFF1A\u5143\u306E\u5165\u529B\u3002\u53F3\uFF1A\u30CD\u30A4\u30C6\u30A3\u30D6 SMPL-X \u63CF\u753B\u3002\u4E00\u89A7\u306F\u8A18\u8F09\u3055\u308C\u305F\u30D5\u30EC\u30FC\u30E0\u9806\u3067\u3059\u3002\u6BD4\u8F03\u52D5\u753B\u306E\u5DE6\u5074\u306F\u5143\u52D5\u753B\u3067\u3059\u3002",postFitContactAlt:"{label} \u306E\u5143\u5165\u529B\u3068\u30CD\u30A4\u30C6\u30A3\u30D6\u63CF\u753B\u306E\u5019\u88DC\u30B3\u30F3\u30BF\u30AF\u30C8\u30B7\u30FC\u30C8",postFitOpenContact:"\u5019\u88DC\u30B3\u30F3\u30BF\u30AF\u30C8\u30B7\u30FC\u30C8\u3092\u958B\u304F",postFitMediaUnavailable:"\u5B89\u5168\u306B\u958B\u3051\u308B\u5019\u88DC\u30B3\u30F3\u30BF\u30AF\u30C8\u30B7\u30FC\u30C8\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u751F\u6210\u5931\u6557\u306E\u8A18\u9332\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",postFitMediaError:"\u5019\u88DC\u30E1\u30C7\u30A3\u30A2\u3092\u8AAD\u307F\u8FBC\u3081\u307E\u305B\u3093\u3002\u30EC\u30DD\u30FC\u30C8\u3068\u30D5\u30A1\u30A4\u30EB\u306E\u6574\u5408\u6027\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",postFitShowOriginal:"\u5143\u52D5\u753B\u3092\u5FC5\u8981\u6642\u306B\u958B\u304F\uFF08\u30D0\u30A4\u30C8\u5358\u4F4D\u306E\u30B3\u30D4\u30FC\uFF09",postFitShowComparison:"\u5168\u30D5\u30EC\u30FC\u30E0\u306E\u4E26\u5217\u6BD4\u8F03\u3092\u5FC5\u8981\u6642\u306B\u958B\u304F",postFitHideMedia:"\u3053\u306E\u52D5\u753B\u3092\u9589\u3058\u308B",postFitProvenance:"\u51FA\u5178\u30FB\u54C1\u8CEA\u30D5\u30E9\u30B0\u30FB\u30E1\u30C7\u30A3\u30A2\u751F\u6210\u5931\u6557",postFitAnnotation:"\u6CE8\u91C8 ID",postFitChunk:"\u30C1\u30E3\u30F3\u30AF",postFitSource:"\u51FA\u5178 ID",postFitSourceHash:"\u51FA\u5178 SHA-256\uFF08\u52D5\u753B\u30CF\u30C3\u30B7\u30E5\u3068\u7570\u306A\u308B\u5834\u5408\u304C\u3042\u308A\u307E\u3059\uFF09",postFitAuditStatus:"\u76E3\u67FB\u8A18\u9332\u306E\u72B6\u614B",postFitFps:"\u6307\u5B9A\u30D5\u30EC\u30FC\u30E0\u30EC\u30FC\u30C8",postFitExpectedFrames:"\u60F3\u5B9A\u30D5\u30EC\u30FC\u30E0\u6570",postFitProcessedFrames:"\u691C\u8A3C\u6E08\u307F\u6BD4\u8F03\u30D5\u30EC\u30FC\u30E0\u6570",postFitClipPath:"\u5143\u52D5\u753B\u306E\u30D1\u30B9",postFitInputDirectory:"\u5143\u5165\u529B\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA",postFitRenderDirectory:"\u30CD\u30A4\u30C6\u30A3\u30D6\u63CF\u753B\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA",postFitFitDirectory:"\u30D5\u30A3\u30C3\u30C8\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA",postFitTechnicalErrors:"\u76E3\u67FB\u306E\u6280\u8853\u30A8\u30E9\u30FC",postFitFailures:"\u30E1\u30C7\u30A3\u30A2\u751F\u6210\u5931\u6557",postFitMediaHashes:"\u30E1\u30C7\u30A3\u30A2 SHA-256",postFitPageCount:"\u5019\u88DC {start}\u2013{end} / {count} \u4EF6 \xB7 {page}/{pages} \u30DA\u30FC\u30B8",postFitPrevious:"\u524D\u3078",postFitNext:"\u6B21\u3078",postFitEmpty:"\u73FE\u5728\u306E\u691C\u7D22\u30FB\u54C1\u8CEA\u6761\u4EF6\u306B\u4E00\u81F4\u3059\u308B\u5019\u88DC\u306F\u3042\u308A\u307E\u305B\u3093\u3002",postFitTotalCandidates:"\u76E3\u67FB\u5019\u88DC\u306E\u7DCF\u6570",postFitSuccessfulMedia:"\u691C\u8A3C\u6E08\u307F\u30E1\u30C7\u30A3\u30A2\u6570",postFitFailedCandidates:"\u30E1\u30C7\u30A3\u30A2\u672A\u5B8C\u5099\u306E\u5019\u88DC\u6570",postFitFailureCount:"\u5931\u6557\u8A18\u9332\u6570",postFitMissingData:"\u5019\u88DC\u30C7\u30FC\u30BF\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u751F\u6210\u3055\u308C\u305F review-data.js \u3092\u3053\u306E\u30DA\u30FC\u30B8\u3068\u540C\u3058\u5834\u6240\u306B\u7F6E\u3044\u3066\u304F\u3060\u3055\u3044\u3002",postFitOffline:"\u30AA\u30D5\u30E9\u30A4\u30F3\u5019\u88DC\u78BA\u8A8D \xB7 1 \u30DA\u30FC\u30B8\u6700\u5927 24 \u4EF6 \xB7 \u52D5\u753B\u306F\u5FC5\u8981\u6642\u306E\u307F \xB7 \u901A\u4FE1\u3084\u627F\u8A8D\u72B6\u614B\u306E\u66F8\u304D\u8FBC\u307F\u306F\u3042\u308A\u307E\u305B\u3093\u3002",postFitUnassessedQuality:"\u885D\u7A81\u30FB\u610F\u5473\u306E\u54C1\u8CEA\u30FB\u4EBA\u306B\u3088\u308B\u8996\u899A\u54C1\u8CEA\uFF1A\u3059\u3079\u3066\u672A\u8A55\u4FA1\u3002"},Qh={wordMotionBrand:"SignBridge \xB7 \u624B\u8BED\u52A8\u4F5C\u7814\u7A76",wordMotionTitle:"\u8BCD\u8BED\u52A8\u4F5C\u5019\u9009\u5BA1\u9605",wordMotionIntro:"\u79BB\u7EBF\u67E5\u770B\u8BCD\u8BED\u7EA7\u5019\u9009\u89C6\u9891\u3001\u5173\u952E\u5E27\u548C\u6765\u6E90\u8BB0\u5F55\u3002\u539F\u59CB\u6807\u7B7E\u53EA\u662F\u5F85\u6838\u9A8C\u7EBF\u7D22\u3002",wordMotionLanguage:"\u754C\u9762\u8BED\u8A00",wordMotionChinese:"\u7B80\u4F53\u4E2D\u6587",wordMotionEnglish:"English",wordMotionJapanese:"\u65E5\u672C\u8A9E",wordMotionUnverified:"\u5019\u9009\u8D44\u6599\uFF0C\u5C1A\u672A\u6838\u5B9E",wordMotionCandidateUnverified:"\u4EC5\u4E3A\u5019\u9009\u3002\u624B\u8BED\u8BED\u4E49\u548C\u8BCD\u8BED\u8FB9\u754C\u5747\u672A\u7ECF\u6838\u5B9E\u3002",wordMotionLimits:"\u5019\u9009\u6807\u7B7E\u4E0D\u4EE3\u8868\u5DF2\u6838\u51C6\u7684\u624B\u8BED\u542B\u4E49\uFF1B\u8BCD\u8BED\u8FB9\u754C\u4E0E\u4EBA\u5DE5\u6279\u51C6\u72B6\u6001\u4E0D\u7531\u6B64\u9875\u9762\u786E\u8BA4\u3002\u5DF2\u6709 3D \u6587\u4EF6\u4EC5\u662F\u4E0A\u534A\u8EAB\u5C55\u793A\u6295\u5F71\uFF0C\u4E0D\u662F\u5B8C\u6574 SMPL-X \u52A8\u4F5C\uFF0C\u4E5F\u4E0D\u662F\u7ECF\u6838\u9A8C\u7684\u624B\u8BED\u52A8\u4F5C\uFF1B\u6CA1\u6709\u539F\u751F\u4EE3\u8BCD\u52A8\u4F5C\u3002\u8BAD\u7EC3\u548C\u6A21\u578B\u8BAD\u7EC3\u5C31\u7EEA\u72B6\u6001\u4E5F\u4E0D\u4F1A\u5728\u6B64\u786E\u8BA4\u3002\u6458\u8981\u6570\u5B57\u4EC5\u662F\u6570\u636E\u751F\u6210\u65B9\u63D0\u4F9B\u7684\u7EDF\u8BA1\uFF0C\u4E0D\u8868\u793A\u6765\u6E90\u5B8C\u6574\u6216\u5019\u9009\u5DF2\u5BA1\u5B8C\u3002",wordMotionSummary:"\u6570\u636E\u6458\u8981",wordMotionVideos:"\u89C6\u9891\u6570",wordMotionUniqueSources:"\u552F\u4E00\u6765\u6E90",wordMotionCandidateCount:"\u5019\u9009\u6570",wordMotionMaterialized:"\u5DF2\u751F\u6210\u5019\u9009\u8BB0\u5F55",wordMotionUniqueLabels:"\u552F\u4E00\u6807\u7B7E",wordMotionNativeCount:"\u5DF2\u6709 3D \u5C55\u793A\u6295\u5F71",wordMotionUnknown:"\u672A\u77E5",wordMotionSummaryNote:"\u5F53\u524D\u9875\u9762\u8F7D\u5165 {count} \u6761\u5019\u9009\u8BB0\u5F55\uFF1B\u7EDF\u8BA1\u6570\u5B57\u6309\u6570\u636E\u6587\u4EF6\u539F\u6837\u663E\u793A\u3002",wordMotionMissingData:"\u672A\u627E\u5230\u6709\u6548\u5019\u9009\u6570\u636E\u3002\u8BF7\u5C06 review-data.js \u653E\u5728\u672C\u9875\u65C1\u8FB9\uFF0C\u5E76\u5728\u5176\u4E4B\u524D\u5B9A\u4E49 SIGNBRIDGE_WORD_MOTIONS\u3002",wordMotionCandidates:"\u5019\u9009\u8BB0\u5F55",wordMotionSearch:"\u641C\u7D22\u6587\u5B57\u3001\u6279\u6B21\u3001\u6765\u6E90\u6216\u5907\u6CE8",wordMotionKind:"\u8BC1\u636E\u7C7B\u578B",wordMotionAllEvidence:"\u5168\u90E8\u8BC1\u636E",wordMotionNativeFilter:"\u542B\u5DF2\u6709\u5C55\u793A\u6295\u5F71",wordMotion2dFilter:"\u4EC5 2D / \u89C6\u9891",wordMotionBatch:"\u6765\u6E90\u6279\u6B21",wordMotionAllBatches:"\u5168\u90E8\u6279\u6B21",wordMotionScope:"\u6765\u6E90\u8BED\u8A00\u8303\u56F4",wordMotionAllScopes:"\u5168\u90E8\u8BED\u8A00\u8303\u56F4",wordMotionScopeCslUnconfirmed:"CSL \u6765\u6E90\u8303\u56F4\u672A\u786E\u8BA4 \xB7 \u975E\u5DF2\u9A8C\u8BC1\u6807\u51C6 CSL",wordMotionScopeRegional:"\u533A\u57DF\u53D8\u4F53\u5019\u9009 \xB7 \u5355\u72EC\u5BA1\u9605\uFF0C\u975E\u5DF2\u9A8C\u8BC1\u6807\u51C6 CSL",wordMotionScopeFingerspelling:"\u5B57\u6BCD\uFF0F\u6307\u62FC\u5019\u9009 \xB7 \u5355\u72EC\u5BA1\u9605\uFF0C\u975E\u5DF2\u9A8C\u8BC1\u6807\u51C6 CSL",wordMotionScopeUnknown:"\u6765\u6E90\u8BED\u8A00\u8303\u56F4\u672A\u77E5 \xB7 \u975E\u5DF2\u9A8C\u8BC1\u6807\u51C6 CSL",wordMotionScopeStatus:"\u539F\u59CB\u8BED\u8A00\u8303\u56F4\u72B6\u6001",wordMotionFocus:"\u5E38\u7528\u8BCD\u8BED",wordMotionAllWords:"\u5168\u90E8",wordMotionFocusI:"\u6211",wordMotionFocusYou:"\u4F60",wordMotionFocusHe:"\u4ED6",wordMotionFocusWe:"\u6211\u4EEC",wordMotionPage:"{count} \u6761\u5019\u9009 \xB7 \u663E\u793A {start}\u2013{end} \xB7 \u7B2C {page}/{pages} \u9875",wordMotionCoverage:"\u6765\u6E90\u8986\u76D6\u8BB0\u5F55",wordMotionCoverageHelp:"\u8986\u76D6\u8BB0\u5F55\u4EC5\u5C55\u793A\u751F\u6210\u65B9\u63D0\u4F9B\u7684\u6765\u6E90\u72B6\u6001\uFF0C\u4E0D\u63A8\u65AD\u672A\u5217\u5165\u6765\u6E90\uFF0C\u4E5F\u4E0D\u8868\u793A\u5019\u9009\u5BA1\u9605\u5B8C\u6210\u3002",wordMotionCoveragePage:"{count} \u6761\u6765\u6E90 \xB7 \u663E\u793A {start}\u2013{end} \xB7 \u7B2C {page}/{pages} \u9875",wordMotionCoverageCaption:"\u6765\u6E90\u6279\u6B21\u4E0E\u5019\u9009\u6570\u91CF",wordMotionSourceId:"\u6765\u6E90 ID",wordMotionOriginalPath:"\u539F\u59CB\u8DEF\u5F84\uFF08\u4EC5\u6587\u672C\uFF09",wordMotionSourceStatus:"\u6765\u6E90\u72B6\u6001",wordMotionSeconds:"\u6765\u6E90\u7A97\u53E3 {start}\u2013{end} \u79D2",wordMotionClip:"\u5019\u9009\u539F\u59CB\u7247\u6BB5",wordMotionClipAlt:"{text} \u7684\u5019\u9009\u6765\u6E90\u7247\u6BB5",wordMotionMediaError:"\u5A92\u4F53\u65E0\u6CD5\u8BFB\u53D6\uFF1B\u8BF7\u68C0\u67E5\u672C\u5730\u6587\u4EF6\u548C\u76F8\u5BF9\u8DEF\u5F84\u3002",wordMotionClipUnavailable:"\u672A\u63D0\u4F9B\u53EF\u5B89\u5168\u6253\u5F00\u7684\u672C\u5730\u7247\u6BB5\u3002",wordMotionSheet:"\u5C55\u5F00\u5173\u952E\u5E27\u8054\u7CFB\u8868",wordMotionSheetAlt:"{text} \u7684\u5019\u9009\u5173\u952E\u5E27\u8054\u7CFB\u8868",wordMotionSheetUnavailable:"\u672A\u63D0\u4F9B\u53EF\u5B89\u5168\u6253\u5F00\u7684\u8054\u7CFB\u8868\u3002",wordMotionNativeAsset:"\u6253\u5F00\u672C\u5730 3D \u5C55\u793A\u6295\u5F71\u6587\u4EF6",wordMotionNativeUnavailable:"\u6570\u636E\u6807\u8BB0\u4E3A\u5DF2\u6709\u5C55\u793A\u6295\u5F71\uFF0C\u4F46\u6CA1\u6709\u53EF\u5B89\u5168\u6253\u5F00\u7684\u6295\u5F71\u6587\u4EF6\u3002",wordMotionRawLabel:"\u63D0\u8BAE\u6807\u7B7E \xB7 \u672A\u6838\u9A8C",wordMotionNoLabel:"\u672A\u63D0\u4F9B\u63D0\u8BAE\u6807\u7B7E",wordMotionNativeReported:"\u6570\u636E\u6807\u8BB0\uFF1A\u5DF2\u6709\u5C55\u793A\u6295\u5F71\uFF1B\u975E\u5B8C\u6574\u52A8\u4F5C\u3001\u5DF2\u6838\u9A8C\u624B\u8BED\u52A8\u4F5C\u6216\u4EE3\u8BCD\u539F\u751F\u52A8\u4F5C",wordMotion2dReported:"\u6570\u636E\u6807\u8BB0\uFF1A2D / \u89C6\u9891\u8BC1\u636E\uFF08\u672A\u7ECF\u5185\u5BB9\u6838\u9A8C\uFF09",wordMotionProvenance:"\u6765\u6E90\u4E0E\u5019\u9009\u5143\u6570\u636E",wordMotionCandidateId:"\u5019\u9009 ID",wordMotionSourceHash:"\u6765\u6E90 SHA-256",wordMotionWindow:"\u6765\u6E90\u7247\u6BB5\u7A97\u53E3",wordMotionEvidenceKind:"\u8BC1\u636E\u7C7B\u522B",wordMotionLabelStatus:"\u6807\u7B7E\u72B6\u6001",wordMotionFlags:"\u590D\u6838\u6807\u8BB0",wordMotionNotes:"\u5907\u6CE8",wordMotionEmpty:"\u6CA1\u6709\u7B26\u5408\u5F53\u524D\u641C\u7D22\u4E0E\u7B5B\u9009\u6761\u4EF6\u7684\u5019\u9009\u3002",wordMotionPrevious:"\u4E0A\u4E00\u9875",wordMotionNext:"\u4E0B\u4E00\u9875",wordMotionOffline:"\u672C\u5730\u79BB\u7EBF\u5BA1\u9605 \xB7 \u4E0D\u8FDE\u63A5\u7F51\u7EDC\u3001\u4E0D\u6279\u51C6\u5019\u9009\u3001\u4E0D\u5199\u5165\u8BAD\u7EC3\u72B6\u6001\u3002"},eu={wordMotionBrand:"SignBridge \xB7 Sign language research",wordMotionTitle:"Word-motion candidate review",wordMotionIntro:"Review word-level candidate clips, contact sheets and source records offline. Proposed labels are unverified leads.",wordMotionLanguage:"Interface language",wordMotionChinese:"Simplified Chinese",wordMotionEnglish:"English",wordMotionJapanese:"Japanese",wordMotionUnverified:"Candidate material \xB7 not verified",wordMotionCandidateUnverified:"Candidate only. Sign meaning and word boundaries are unverified.",wordMotionLimits:"A proposed label is not an approved sign meaning. This page does not verify word boundaries or human approval, and does not confirm training or model-training readiness. Existing 3D files are upper-body display projections, not full SMPL-X motion or verified sign actions; none are pronoun-native. Summary figures are supplied by the data producer; they do not establish source completeness or completed review.",wordMotionSummary:"Data summary",wordMotionVideos:"Videos",wordMotionUniqueSources:"Unique sources",wordMotionCandidateCount:"Candidates",wordMotionMaterialized:"Materialized candidate records",wordMotionUniqueLabels:"Unique labels",wordMotionNativeCount:"Existing 3D display projections",wordMotionUnknown:"Unknown",wordMotionSummaryNote:"This page loaded {count} candidate records; summary figures are shown as provided.",wordMotionMissingData:"No valid candidate data found. Place review-data.js beside this page and define SIGNBRIDGE_WORD_MOTIONS before it loads.",wordMotionCandidates:"Candidate records",wordMotionSearch:"Search text, batch, source or notes",wordMotionKind:"Evidence type",wordMotionAllEvidence:"All evidence",wordMotionNativeFilter:"With existing projection",wordMotion2dFilter:"2D / video only",wordMotionBatch:"Source batch",wordMotionAllBatches:"All batches",wordMotionScope:"Source language scope",wordMotionAllScopes:"All language scopes",wordMotionScopeCslUnconfirmed:"CSL source scope unconfirmed \xB7 not verified standard CSL",wordMotionScopeRegional:"Regional variant candidate \xB7 separate review, not verified standard CSL",wordMotionScopeFingerspelling:"Alphabet / fingerspelling candidate \xB7 separate review, not verified standard CSL",wordMotionScopeUnknown:"Source scope unknown \xB7 not verified standard CSL",wordMotionScopeStatus:"Raw language-scope status",wordMotionFocus:"Common words",wordMotionAllWords:"All",wordMotionFocusI:"\u6211",wordMotionFocusYou:"\u4F60",wordMotionFocusHe:"\u4ED6",wordMotionFocusWe:"\u6211\u4EEC",wordMotionPage:"{count} candidates \xB7 showing {start}\u2013{end} \xB7 page {page}/{pages}",wordMotionCoverage:"Source coverage records",wordMotionCoverageHelp:"Coverage rows show source status supplied by the data producer. They do not infer unlisted sources or indicate that candidates were fully reviewed.",wordMotionCoveragePage:"{count} sources \xB7 showing {start}\u2013{end} \xB7 page {page}/{pages}",wordMotionCoverageCaption:"Source batches and candidate counts",wordMotionSourceId:"Source ID",wordMotionOriginalPath:"Original path (text only)",wordMotionSourceStatus:"Source status",wordMotionSeconds:"Source window {start}\u2013{end} seconds",wordMotionClip:"Candidate source clip",wordMotionClipAlt:"Candidate source clip for {text}",wordMotionMediaError:"Media could not be read. Check the local file and relative path.",wordMotionClipUnavailable:"No safe local clip was provided.",wordMotionSheet:"Expand contact sheet",wordMotionSheetAlt:"Candidate contact sheet for {text}",wordMotionSheetUnavailable:"No safe contact sheet was provided.",wordMotionNativeAsset:"Open local 3D display projection",wordMotionNativeUnavailable:"An existing display projection is reported, but no safe local projection file is available.",wordMotionRawLabel:"Proposed label \xB7 unverified",wordMotionNoLabel:"No proposed label provided",wordMotionNativeReported:"Existing display projection; not full motion, verified action, or pronoun-native motion",wordMotion2dReported:"Data reports 2D / video evidence (content not verified)",wordMotionProvenance:"Source and candidate metadata",wordMotionCandidateId:"Candidate ID",wordMotionSourceHash:"Source SHA-256",wordMotionWindow:"Source clip window",wordMotionEvidenceKind:"Evidence kind",wordMotionLabelStatus:"Label status",wordMotionFlags:"Review flags",wordMotionNotes:"Notes",wordMotionEmpty:"No candidates match the current search and filters.",wordMotionPrevious:"Previous",wordMotionNext:"Next",wordMotionOffline:"Offline local review \xB7 no network, candidate approval or training-state writes."},tu={wordMotionBrand:"SignBridge \xB7 \u624B\u8A71\u7814\u7A76",wordMotionTitle:"\u5358\u8A9E\u52D5\u4F5C\u5019\u88DC\u306E\u78BA\u8A8D",wordMotionIntro:"\u5358\u8A9E\u30EC\u30D9\u30EB\u306E\u5019\u88DC\u52D5\u753B\u3001\u30B3\u30F3\u30BF\u30AF\u30C8\u30B7\u30FC\u30C8\u3001\u51FA\u5178\u8A18\u9332\u3092\u30AA\u30D5\u30E9\u30A4\u30F3\u3067\u78BA\u8A8D\u3057\u307E\u3059\u3002\u63D0\u6848\u30E9\u30D9\u30EB\u306F\u672A\u691C\u8A3C\u306E\u624B\u639B\u304B\u308A\u3067\u3059\u3002",wordMotionLanguage:"\u8868\u793A\u8A00\u8A9E",wordMotionChinese:"\u7C21\u4F53\u5B57\u4E2D\u56FD\u8A9E",wordMotionEnglish:"\u82F1\u8A9E",wordMotionJapanese:"\u65E5\u672C\u8A9E",wordMotionUnverified:"\u5019\u88DC\u8CC7\u6599 \xB7 \u672A\u691C\u8A3C",wordMotionCandidateUnverified:"\u5019\u88DC\u306E\u307F\u3067\u3059\u3002\u624B\u8A71\u306E\u610F\u5473\u3068\u5358\u8A9E\u5883\u754C\u306F\u672A\u691C\u8A3C\u3067\u3059\u3002",wordMotionLimits:"\u63D0\u6848\u30E9\u30D9\u30EB\u306F\u627F\u8A8D\u6E08\u307F\u306E\u624B\u8A71\u306E\u610F\u5473\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u3053\u306E\u30DA\u30FC\u30B8\u3067\u306F\u5358\u8A9E\u5883\u754C\u3084\u4EBA\u306B\u3088\u308B\u627F\u8A8D\u3092\u691C\u8A3C\u305B\u305A\u3001\u5B66\u7FD2\u3084\u30E2\u30C7\u30EB\u5B66\u7FD2\u306E\u6E96\u5099\u72B6\u6CC1\u3082\u78BA\u8A8D\u3057\u307E\u305B\u3093\u3002\u65E2\u5B58\u306E3D\u30D5\u30A1\u30A4\u30EB\u306F\u4E0A\u534A\u8EAB\u306E\u8868\u793A\u6295\u5F71\u3067\u3042\u308A\u3001\u5168\u8EAB\u306ESMPL-X\u52D5\u4F5C\u3084\u691C\u8A3C\u6E08\u307F\u306E\u624B\u8A71\u52D5\u4F5C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u4EE3\u540D\u8A5E\u306E\u30CD\u30A4\u30C6\u30A3\u30D6\u52D5\u4F5C\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u96C6\u8A08\u5024\u306F\u30C7\u30FC\u30BF\u4F5C\u6210\u8005\u304C\u63D0\u4F9B\u3057\u305F\u5024\u3067\u3042\u308A\u3001\u51FA\u5178\u306E\u7DB2\u7F85\u6027\u3084\u78BA\u8A8D\u306E\u5B8C\u4E86\u3092\u793A\u3057\u307E\u305B\u3093\u3002",wordMotionSummary:"\u30C7\u30FC\u30BF\u6982\u8981",wordMotionVideos:"\u52D5\u753B\u6570",wordMotionUniqueSources:"\u4E00\u610F\u306E\u51FA\u5178",wordMotionCandidateCount:"\u5019\u88DC\u6570",wordMotionMaterialized:"\u751F\u6210\u6E08\u307F\u5019\u88DC\u30EC\u30B3\u30FC\u30C9",wordMotionUniqueLabels:"\u4E00\u610F\u306E\u30E9\u30D9\u30EB",wordMotionNativeCount:"\u65E2\u5B58\u306E3D\u8868\u793A\u6295\u5F71",wordMotionUnknown:"\u4E0D\u660E",wordMotionSummaryNote:"\u3053\u306E\u30DA\u30FC\u30B8\u306B\u8AAD\u307F\u8FBC\u307E\u308C\u305F\u5019\u88DC\u30EC\u30B3\u30FC\u30C9\u306F {count} \u4EF6\u3067\u3059\u3002\u96C6\u8A08\u5024\u306F\u63D0\u4F9B\u3055\u308C\u305F\u307E\u307E\u8868\u793A\u3057\u307E\u3059\u3002",wordMotionMissingData:"\u6709\u52B9\u306A\u5019\u88DC\u30C7\u30FC\u30BF\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u3053\u306E\u30DA\u30FC\u30B8\u3068\u540C\u3058\u5834\u6240\u306B review-data.js \u3092\u7F6E\u304D\u3001\u8AAD\u307F\u8FBC\u307F\u524D\u306B SIGNBRIDGE_WORD_MOTIONS \u3092\u5B9A\u7FA9\u3057\u3066\u304F\u3060\u3055\u3044\u3002",wordMotionCandidates:"\u5019\u88DC\u30EC\u30B3\u30FC\u30C9",wordMotionSearch:"\u30C6\u30AD\u30B9\u30C8\u3001\u30D0\u30C3\u30C1\u3001\u51FA\u5178\u3001\u30E1\u30E2\u3092\u691C\u7D22",wordMotionKind:"\u8A3C\u62E0\u306E\u7A2E\u985E",wordMotionAllEvidence:"\u3059\u3079\u3066\u306E\u8A3C\u62E0",wordMotionNativeFilter:"\u65E2\u5B58\u306E\u8868\u793A\u6295\u5F71\u3042\u308A",wordMotion2dFilter:"2D / \u52D5\u753B\u306E\u307F",wordMotionBatch:"\u51FA\u5178\u30D0\u30C3\u30C1",wordMotionAllBatches:"\u3059\u3079\u3066\u306E\u30D0\u30C3\u30C1",wordMotionScope:"\u51FA\u5178\u306E\u8A00\u8A9E\u7BC4\u56F2",wordMotionAllScopes:"\u3059\u3079\u3066\u306E\u8A00\u8A9E\u7BC4\u56F2",wordMotionScopeCslUnconfirmed:"CSL \u306E\u51FA\u5178\u7BC4\u56F2\u306F\u672A\u78BA\u8A8D \xB7 \u6A19\u6E96 CSL \u3068\u3057\u3066\u672A\u691C\u8A3C",wordMotionScopeRegional:"\u5730\u57DF\u5909\u7A2E\u306E\u5019\u88DC \xB7 \u5225\u9014\u78BA\u8A8D\u3001\u6A19\u6E96 CSL \u3068\u3057\u3066\u672A\u691C\u8A3C",wordMotionScopeFingerspelling:"\u30A2\u30EB\u30D5\u30A1\u30D9\u30C3\u30C8\uFF0F\u6307\u6587\u5B57\u306E\u5019\u88DC \xB7 \u5225\u9014\u78BA\u8A8D\u3001\u6A19\u6E96 CSL \u3068\u3057\u3066\u672A\u691C\u8A3C",wordMotionScopeUnknown:"\u51FA\u5178\u306E\u8A00\u8A9E\u7BC4\u56F2\u306F\u4E0D\u660E \xB7 \u6A19\u6E96 CSL \u3068\u3057\u3066\u672A\u691C\u8A3C",wordMotionScopeStatus:"\u5143\u306E\u8A00\u8A9E\u7BC4\u56F2\u30B9\u30C6\u30FC\u30BF\u30B9",wordMotionFocus:"\u3088\u304F\u4F7F\u3046\u5358\u8A9E",wordMotionAllWords:"\u3059\u3079\u3066",wordMotionFocusI:"\u6211",wordMotionFocusYou:"\u4F60",wordMotionFocusHe:"\u4ED6",wordMotionFocusWe:"\u6211\u4EEC",wordMotionPage:"\u5019\u88DC {count} \u4EF6 \xB7 {start}\uFF5E{end} \u4EF6 \xB7 {page}/{pages} \u30DA\u30FC\u30B8",wordMotionCoverage:"\u51FA\u5178\u30AB\u30D0\u30EC\u30C3\u30B8\u8A18\u9332",wordMotionCoverageHelp:"\u5404\u884C\u306B\u306F\u30C7\u30FC\u30BF\u4F5C\u6210\u8005\u304C\u63D0\u4F9B\u3057\u305F\u51FA\u5178\u72B6\u614B\u3092\u8868\u793A\u3057\u307E\u3059\u3002\u672A\u8A18\u8F09\u306E\u51FA\u5178\u3092\u63A8\u6E2C\u305B\u305A\u3001\u5019\u88DC\u306E\u78BA\u8A8D\u5B8C\u4E86\u3082\u793A\u3057\u307E\u305B\u3093\u3002",wordMotionCoveragePage:"\u51FA\u5178 {count} \u4EF6 \xB7 {start}\uFF5E{end} \u4EF6 \xB7 {page}/{pages} \u30DA\u30FC\u30B8",wordMotionCoverageCaption:"\u51FA\u5178\u30D0\u30C3\u30C1\u3068\u5019\u88DC\u6570",wordMotionSourceId:"\u51FA\u5178 ID",wordMotionOriginalPath:"\u5143\u306E\u30D1\u30B9\uFF08\u30C6\u30AD\u30B9\u30C8\u306E\u307F\uFF09",wordMotionSourceStatus:"\u51FA\u5178\u72B6\u614B",wordMotionSeconds:"\u51FA\u5178\u533A\u9593 {start}\uFF5E{end} \u79D2",wordMotionClip:"\u5019\u88DC\u306E\u51FA\u5178\u52D5\u753B",wordMotionClipAlt:"{text} \u306E\u5019\u88DC\u51FA\u5178\u52D5\u753B",wordMotionMediaError:"\u30E1\u30C7\u30A3\u30A2\u3092\u8AAD\u307F\u8FBC\u3081\u307E\u305B\u3093\u3002\u30ED\u30FC\u30AB\u30EB\u30D5\u30A1\u30A4\u30EB\u3068\u76F8\u5BFE\u30D1\u30B9\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",wordMotionClipUnavailable:"\u5B89\u5168\u306A\u30ED\u30FC\u30AB\u30EB\u52D5\u753B\u306F\u3042\u308A\u307E\u305B\u3093\u3002",wordMotionSheet:"\u30B3\u30F3\u30BF\u30AF\u30C8\u30B7\u30FC\u30C8\u3092\u958B\u304F",wordMotionSheetAlt:"{text} \u306E\u5019\u88DC\u30B3\u30F3\u30BF\u30AF\u30C8\u30B7\u30FC\u30C8",wordMotionSheetUnavailable:"\u5B89\u5168\u306A\u30B3\u30F3\u30BF\u30AF\u30C8\u30B7\u30FC\u30C8\u306F\u3042\u308A\u307E\u305B\u3093\u3002",wordMotionNativeAsset:"\u30ED\u30FC\u30AB\u30EB\u306E3D\u8868\u793A\u6295\u5F71\u3092\u958B\u304F",wordMotionNativeUnavailable:"\u65E2\u5B58\u306E\u8868\u793A\u6295\u5F71\u3042\u308A\u3068\u8A18\u9332\u3055\u308C\u3066\u3044\u307E\u3059\u304C\u3001\u5B89\u5168\u306A\u30ED\u30FC\u30AB\u30EB\u6295\u5F71\u30D5\u30A1\u30A4\u30EB\u306F\u3042\u308A\u307E\u305B\u3093\u3002",wordMotionRawLabel:"\u63D0\u6848\u30E9\u30D9\u30EB \xB7 \u672A\u691C\u8A3C",wordMotionNoLabel:"\u63D0\u6848\u30E9\u30D9\u30EB\u306A\u3057",wordMotionNativeReported:"\u65E2\u5B58\u306E\u8868\u793A\u6295\u5F71\u3067\u3059\u3002\u5168\u8EAB\u52D5\u4F5C\u3001\u691C\u8A3C\u6E08\u307F\u306E\u624B\u8A71\u52D5\u4F5C\u3001\u4EE3\u540D\u8A5E\u306E\u30CD\u30A4\u30C6\u30A3\u30D6\u52D5\u4F5C\u3067\u306F\u3042\u308A\u307E\u305B\u3093",wordMotion2dReported:"\u30C7\u30FC\u30BF\u4E0A\u306F2D / \u52D5\u753B\u306E\u8A3C\u62E0\u3042\u308A\uFF08\u5185\u5BB9\u672A\u691C\u8A3C\uFF09",wordMotionProvenance:"\u51FA\u5178\u3068\u5019\u88DC\u306E\u30E1\u30BF\u30C7\u30FC\u30BF",wordMotionCandidateId:"\u5019\u88DC ID",wordMotionSourceHash:"\u51FA\u5178 SHA-256",wordMotionWindow:"\u51FA\u5178\u52D5\u753B\u533A\u9593",wordMotionEvidenceKind:"\u8A3C\u62E0\u306E\u7A2E\u985E",wordMotionLabelStatus:"\u30E9\u30D9\u30EB\u72B6\u614B",wordMotionFlags:"\u78BA\u8A8D\u30D5\u30E9\u30B0",wordMotionNotes:"\u30E1\u30E2",wordMotionEmpty:"\u73FE\u5728\u306E\u691C\u7D22\u6761\u4EF6\u306B\u4E00\u81F4\u3059\u308B\u5019\u88DC\u306F\u3042\u308A\u307E\u305B\u3093\u3002",wordMotionPrevious:"\u524D\u3078",wordMotionNext:"\u6B21\u3078",wordMotionOffline:"\u30AA\u30D5\u30E9\u30A4\u30F3\u306E\u30ED\u30FC\u30AB\u30EB\u78BA\u8A8D \xB7 \u901A\u4FE1\u3001\u5019\u88DC\u306E\u627F\u8A8D\u3001\u5B66\u7FD2\u72B6\u614B\u306E\u5909\u66F4\u306F\u3042\u308A\u307E\u305B\u3093\u3002"},Ia={nativeTitle:"SignBridge \u6F14\u793A\u7248",nativeLoading:"\u6B63\u5728\u542F\u52A8\u672C\u673A\u6A21\u578B\uFF0C\u9996\u6B21\u6253\u5F00\u8BF7\u7A0D\u5019\u2026",nativeReady:"\u6A21\u578B\u5DF2\u5C31\u7EEA \xB7 \u5168\u7A0B\u672C\u673A\u63A8\u7406",nativeOpen:"\u6253\u5F00\u6F14\u793A",nativePlugin:"\u6253\u5F00\u63D2\u4EF6\u6587\u4EF6\u5939",nativeQuit:"\u9000\u51FA\u5E76\u505C\u6B62\u670D\u52A1",nativeNote:"\u5185\u7F6E\u6A21\u578B\u548C\u52A8\u4F5C\uFF0C\u5168\u7A0B\u672C\u673A\u8FD0\u884C\uFF1B\u9000\u51FA\u6B64\u7A0B\u5E8F\u4F1A\u505C\u6B62\u670D\u52A1\u3002",nativeFailed:"\u6A21\u578B\u542F\u52A8\u5931\u8D25\uFF0C\u8BF7\u67E5\u770B\u8FD0\u884C\u8BB0\u5F55\u3002",nativeLog:"\u67E5\u770B\u8FD0\u884C\u8BB0\u5F55",nativePluginGuide:"\u5728 Chrome \u6269\u5C55\u7BA1\u7406\u9875\u542F\u7528\u5F00\u53D1\u8005\u6A21\u5F0F\uFF0C\u9009\u62E9\u201C\u52A0\u8F7D\u5DF2\u89E3\u538B\u7684\u6269\u5C55\u7A0B\u5E8F\u201D\uFF0C\u52A0\u8F7D\u4E0B\u9762\u5DF2\u6821\u9A8C\u5E76\u5BFC\u51FA\u7684 chrome-extension \u6587\u4EF6\u5939\u3002\u70B9\u51FB\u201C\u590D\u5236\u63D2\u4EF6\u8DEF\u5F84\u201D\u540E\uFF0C\u53EF\u5728\u6587\u4EF6\u9009\u62E9\u6846\u6309\u2318\u21E7G\u5E76\u7C98\u8D34\u8DEF\u5F84\u3002\u6A21\u578B\u6F14\u793A\u670D\u52A1\u5730\u5740\uFF1A",nativeOK:"\u77E5\u9053\u4E86",nativeCopyPluginPath:"\u590D\u5236\u63D2\u4EF6\u8DEF\u5F84",nativeChangePlugin:"\u66F4\u6539\u63D2\u4EF6\u4F4D\u7F6E",nativePluginLocation:"\u63D2\u4EF6\u4F4D\u7F6E\uFF1A",nativePluginUnset:"\u5C1A\u672A\u9009\u62E9\uFF0C\u8BF7\u70B9\u51FB\u201C\u66F4\u6539\u63D2\u4EF6\u4F4D\u7F6E\u201D\u3002",nativeChoosePlugin:"\u9009\u62E9\u63D2\u4EF6\u4FDD\u5B58\u6587\u4EF6\u5939",nativeChoosePluginHelp:"\u8BF7\u9009\u62E9\u65B0\u5EFA\u7684\u7A7A\u6587\u4EF6\u5939\uFF1B\u63D2\u4EF6\u6587\u4EF6\u4F1A\u76F4\u63A5\u4FDD\u5B58\u5728\u8FD9\u91CC\u3002\u4E0D\u8981\u9009\u62E9\u5305\u542B\u4E2A\u4EBA\u6587\u4EF6\u7684\u76EE\u5F55\u3002",nativeChoose:"\u9009\u62E9\u6B64\u6587\u4EF6\u5939",nativeChooseInstaller:"\u9009\u62E9\u2026",nativeWizardTitle:"SignBridge \u5B89\u88C5\u5411\u5BFC",nativeQuitInstaller:"\u9000\u51FA\u5B89\u88C5\u5411\u5BFC",nativeWizardLead:"\u5148\u9009\u62E9\u63D2\u4EF6\u6587\u4EF6\u5939\uFF0C\u518D\u5B89\u88C5\u684C\u9762\u6F14\u793A\u7A0B\u5E8F\u3002\u4EE5\u540E\u7A0B\u5E8F\u4F1A\u76F4\u63A5\u6253\u5F00\u4F60\u9009\u7684\u6587\u4EF6\u5939\u3002",nativeWizardFolder:"\u63D2\u4EF6\u4FDD\u5B58\u5230",nativeWizardContinue:"\u4FDD\u5B58\u63D2\u4EF6\u4F4D\u7F6E",nativeWizardBusy:"\u6B63\u5728\u6821\u9A8C\u5E76\u4FDD\u5B58\u63D2\u4EF6\u2026",nativeWizardReady:"\u63D2\u4EF6\u4F4D\u7F6E\u5DF2\u4FDD\u5B58\u3002\u70B9\u51FB\u201C\u5B8C\u6210\u201D\u5173\u95ED\u5411\u5BFC\uFF0C\u518D\u53CC\u51FB\u672C\u5411\u5BFC\u65C1\u7684 SignBridge-Demo.pkg \u5B8C\u6210\u684C\u9762\u5B89\u88C5\u3002",nativeWizardFinish:"\u5B8C\u6210",nativeWizardFailed:"\u6240\u9009\u4F4D\u7F6E\u4E0D\u53EF\u7528\u6216\u542B\u6709\u5176\u4ED6\u6587\u4EF6\u3002\u8BF7\u9009\u62E9\u7A7A\u6587\u4EF6\u5939\uFF0C\u672A\u6539\u52A8\u539F\u76EE\u5F55\u3002",nativeWizardNote:"Chrome\u4ECD\u9700\u624B\u52A8\u52A0\u8F7D\u6B64\u6587\u4EF6\u5939\u3002\u5173\u95ED\u7CFB\u7EDF\u5B89\u88C5\u7A97\u53E3\u4E0D\u4F1A\u5220\u9664\u5DF2\u4FDD\u5B58\u7684\u63D2\u4EF6\u3002",nativeWizardOpenFolder:"\u6253\u5F00\u5DF2\u4FDD\u5B58\u63D2\u4EF6",nativePluginFailed:"\u63D2\u4EF6\u6587\u4EF6\u5939\u6253\u5F00\u5931\u8D25",nativePluginFailureHelp:"\u63D2\u4EF6\u6587\u4EF6\u672A\u901A\u8FC7\u6821\u9A8C\u6216\u5BFC\u51FA\u76EE\u5F55\u4E0D\u53EF\u7528\uFF0C\u8BF7\u91CD\u65B0\u5B89\u88C5\u6B64\u7248\u672C\u540E\u518D\u8BD5\u3002",nativeInstallName:"SignBridge \u6F14\u793A\u7248\uFF08Apple \u82AF\u7247 Mac\uFF09",nativeLiteStartFailed:"\u542F\u52A8\u5931\u8D25\uFF0C\u8BF7\u9000\u51FA\u540E\u91CD\u65B0\u6253\u5F00\u3002",nativeLiteInstallPlugin:"\u5B89\u88C5\u6D4F\u89C8\u5668\u63D2\u4EF6",nativeLiteInstallHelp:"\u8BF7\u9009\u62E9\u4E00\u4E2A\u7A7A\u6587\u4EF6\u5939\uFF0C\u7A0B\u5E8F\u4F1A\u628A\u63D2\u4EF6\u4FDD\u5B58\u8FDB\u53BB\u5E76\u4E3A\u4F60\u6253\u5F00\u3002\u4E4B\u540E\u5728 Chrome \u6253\u5F00\u6269\u5C55\u9875\uFF0C\u6253\u5F00\u53F3\u4E0A\u89D2\u7684\u5F00\u53D1\u8005\u6A21\u5F0F\uFF0C\u70B9\u51FB\u52A0\u8F7D\u5DF2\u89E3\u538B\u7684\u6269\u5C55\u7A0B\u5E8F\uFF0C\u518D\u9009\u62E9\u8FD9\u4E2A\u6587\u4EF6\u5939\u3002",nativeLiteInstallDone:"\u63D2\u4EF6\u5DF2\u4FDD\u5B58\uFF0C\u6587\u4EF6\u5939\u5DF2\u6253\u5F00\u3002",nativeLiteOpenExtensions:"\u6253\u5F00 Chrome \u6269\u5C55\u9875",nativeLiteChromeMissing:"\u6CA1\u6709\u627E\u5230 Chrome\uFF0C\u8BF7\u5148\u5B89\u88C5 Chrome \u6D4F\u89C8\u5668\u3002",connectionTitle:"\u8FDE\u63A5\u672C\u673A\u6A21\u578B\u670D\u52A1",connectionHelp:"\u5148\u53CC\u51FB\u5B89\u88C5\u5305\u4E2D\u7684\u201C\u542F\u52A8\u6A21\u578BDemo.command\u201D\uFF0C\u4FDD\u6301\u7EC8\u7AEF\u5F00\u542F\uFF0C\u518D\u70B9\u51FB\u8FDE\u63A5\u3002\u53EA\u6388\u6743\u672C\u673A\u5730\u5740\uFF0C\u4E0D\u4E0A\u4F20\u8F93\u5165\u3002",endpoint:"\u672C\u673A\u670D\u52A1\u5730\u5740",connect:"\u6388\u6743\u5E76\u8FDE\u63A5",invalidEndpoint:"\u4EC5\u652F\u6301 http://127.0.0.1:\u7AEF\u53E3\uFF0C\u8BF7\u68C0\u67E5\u672C\u673A\u670D\u52A1\u5730\u5740\u3002",permissionRequired:"\u70B9\u51FB\u201C\u6388\u6743\u5E76\u8FDE\u63A5\u201D\uFF0C\u5141\u8BB8\u63D2\u4EF6\u8BBF\u95EE\u672C\u673A\u6A21\u578B\u670D\u52A1\u3002",permissionDenied:"\u672A\u83B7\u5F97\u672C\u673A\u8BBF\u95EE\u6388\u6743\uFF0C\u8BF7\u70B9\u51FB\u201C\u6388\u6743\u5E76\u8FDE\u63A5\u201D\u91CD\u8BD5\u3002",incompatible:"\u672C\u673A\u670D\u52A1\u7684\u6A21\u578B\u6216\u52A8\u4F5C\u7248\u672C\u4E0D\u5339\u914D\uFF0C\u8BF7\u542F\u52A8\u540C\u4E00\u5B89\u88C5\u5305\u4E2D\u7684\u670D\u52A1\u3002",badge:"\u7814\u7A76 Demo",avatarLabel:"\u624B\u8BED\u4EBA\u7269\u53C2\u8003\u64AD\u653E\u5668",title:"SignBridge \xB7 \u672C\u673A\u6A21\u578B\u6F14\u793A",label:"\u771F\u5B9E\u6A21\u578B \xB7 \u6709\u9650\u4E2D\u6587\u8BED\u4E49",heading:"\u770B\u89C1\u53E5\u5B50\u91CC\u7684\u5173\u7CFB",lead:"\u8F93\u5165\u4E2D\u6587\uFF0C\u67E5\u770B\u6A21\u578B\u5B66\u5230\u7684\u4EBA\u7269\u3001\u4E8B\u4EF6\u4E0E\u5426\u5B9A\u8303\u56F4\uFF0C\u518D\u68C0\u67E5\u73B0\u6709\u52A8\u4F5C\u662F\u5426\u8986\u76D6\u3002",scope:"\u7814\u7A76 Demo\uFF1A\u4E2D\u6587\u8BED\u4E49\u3001\u52A8\u4F5C\u9884\u89C8\u548C\u6B63\u786E\u4E2D\u56FD\u624B\u8BED\u8868\u8FBE\u5206\u522B\u9A8C\u8BC1\u3002\u4EBA\u7269\u9884\u89C8\u4E0D\u4EE3\u8868\u624B\u8BED\u8BED\u4E49\u5DF2\u6279\u51C6\u3002",input:"\u8F93\u5165\u4E00\u53E5\u4E2D\u6587",placeholder:"\u8BD5\u8BD5\uFF1A\u6211\u5E2E\u4F60\u3001\u4F60\u5E2E\u6211\u3001\u6211\u4E0D\u60F3\u53BB\u3001\u6211\u60F3\u4E0D\u53BB",analyze:"\u5206\u6790\u610F\u601D",loading:"\u6B63\u5728\u8FDE\u63A5\u672C\u673A\u6A21\u578B\u2026",ready:"\u6A21\u578B\u5DF2\u5C31\u7EEA \xB7 \u5168\u7A0B\u672C\u673A\u63A8\u7406",working:"\u6A21\u578B\u6B63\u5728\u5206\u6790\u2026",disconnected:"\u672C\u673A\u6A21\u578B\u670D\u52A1\u4E0D\u53EF\u7528\uFF0C\u8BF7\u7528\u4EA4\u4ED8\u76EE\u5F55\u7684\u201C\u542F\u52A8\u6A21\u578BDemo.command\u201D\u6253\u5F00\u3002",retry:"\u91CD\u65B0\u8FDE\u63A5",parsed:"\u5DF2\u89E3\u6790\u6709\u9650\u4E2D\u6587\u7ED3\u6784",refused:"\u8D85\u51FA\u5F53\u524D\u8303\u56F4\uFF0C\u5DF2\u4FDD\u7559\u62D2\u7EDD",idle:"\u9009\u62E9\u4F8B\u53E5\u6216\u8F93\u5165\u4E2D\u6587\uFF0C\u67E5\u770B\u771F\u5B9E\u6A21\u578B\u8F93\u51FA\u3002",meaning:"\u8FD9\u53E5\u8BDD\u7684\u610F\u601D\u7ED3\u6784",operators:"\u4F5C\u7528\u8303\u56F4\uFF08\u4ECE\u5916\u5230\u5185\uFF09",none:"\u65E0",empty:"\u6682\u65E0\u7ED3\u679C",rule:"\u5305\u542B\u663E\u5F0F\u7C7B\u578B\u4E00\u81F4\u6027\u5904\u7406\uFF0C\u539F\u59CB\u89D2\u8272\u672A\u6539\u3002",learned:"\u5B66\u4E60\u6A21\u578B\u8F93\u51FA\uFF0C\u7ECF\u8FC7\u663E\u5F0F\u5408\u540C\u68C0\u67E5\u3002",raw:"\u539F\u59CB\u6A21\u578B\u4E0E\u6280\u672F\u4F9D\u636E",performance:"\u672C\u6B21\u6A21\u578B\u63A8\u7406 {ms} \u6BEB\u79D2",model:"\u8BED\u4E49\u68C0\u67E5\u70B9 {hash}",stage:"\u4EBA\u7269\u52A8\u4F5C\u53C2\u8003",play:"\u64AD\u653E\u5339\u914D\u53C2\u8003",pause:"\u6682\u505C",resume:"\u7EE7\u7EED",stop:"\u505C\u6B62",speed:"\u64AD\u653E\u901F\u5EA6",front:"\u6B63\u9762",left:"\u5DE6\u4FA7",right:"\u53F3\u4FA7",idleMotion:"\u4EBA\u7269\u5DF2\u5C31\u7EEA\uFF0C\u7B49\u5F85\u9009\u62E9\u52A8\u4F5C\u3002",avatarLoading:"\u6B63\u5728\u52A0\u8F7D\u4EBA\u7269\u4E0E\u52A8\u4F5C\u2026",playing:"\u6B63\u5728\u64AD\u653E\uFF1A{text}",finished:"\u64AD\u653E\u7ED3\u675F\uFF0C\u53EF\u91CD\u64AD\u6216\u5207\u6362\u3002",stopped:"\u5DF2\u505C\u6B62",paused:"\u5DF2\u6682\u505C",unavailable:"\u5F53\u524D\u610F\u601D\u6CA1\u6709\u5B8C\u6574\u3001\u5DF2\u5BA1\u9605\u7684\u5BF9\u5E94\u52A8\u4F5C\u3002\u672A\u4F7F\u7528\u5185\u7F6E\u8BCD\u5E93\u6216\u62FC\u63A5\u540E\u5907\u3002",gapDirection:"\u4EBA\u7269\u65B9\u5411\u5C1A\u672A\u786E\u8BA4\uFF0C\u53EA\u5C55\u793A\u8BED\u4E49\uFF0C\u4E0D\u64AD\u653E\u201C\u5E2E\u52A9\u201D\u65B9\u5411\u52A8\u4F5C\u3002",gapOperator:"\u5426\u5B9A\uFF0F\u60C5\u6001\u7684\u52A8\u4F5C\u4E0E\u975E\u624B\u90E8\u8868\u8FBE\u8BC1\u636E\u4E0D\u8DB3\uFF0C\u6682\u4E0D\u7EC4\u5408\u3002",gapRefused:"\u6A21\u578B\u62D2\u7EDD\u7684\u8F93\u5165\u4E0D\u4F1A\u81EA\u52A8\u64AD\u653E\u52A8\u4F5C\u3002",matched:"\u4EC5\u5339\u914D\u5DF2\u6709\u5B8C\u6574\u6807\u7B7E\u53C2\u8003\uFF1B\u6CA1\u6709\u786E\u8BA4\u8BCD\u754C\u6216\u624B\u8BED\u8BED\u4E49\u3002",catalog:"\u5DF2\u6709\u62DF\u5408\u52A8\u4F5C \xB7 \u72EC\u7ACB\u53C2\u8003\u9884\u89C8",catalogNote:"\u4EE5\u4E0B\u7247\u6BB5\u5177\u6709\u5386\u53F2\u201C\u52A8\u4F5C\u8D28\u91CF\u201D\u4EBA\u5DE5\u5BA1\u9605\u8BB0\u5F55\u5E76\u901A\u8FC7\u672C\u6B21\u6280\u672F\u7B5B\u9009\u3002\u70B9\u51FB\u4EC5\u9884\u89C8\u539F\u7247\u62DF\u5408\uFF0C\u4E0D\u4EE3\u8868\u6A21\u578B\u7406\u89E3\u4E86\u8FD9\u4E9B\u6807\u7B7E\u3002",reference:"\u72EC\u7ACB\u53C2\u8003\u9884\u89C8\uFF1A{text}\uFF0C\u4E0D\u662F\u672C\u6B21\u6A21\u578B\u7FFB\u8BD1\u3002",evidence:"\u52A8\u4F5C\u6765\u6E90\u4E0E\u8D28\u91CF\u8BB0\u5F55",approval:"\u5386\u53F2\u5BA1\u9605\u8303\u56F4\uFF1A\u52A8\u4F5C\u8D28\u91CF\uFF1B\u8BCD\u4E49\u4E0E\u8BCD\u754C\u672A\u6279\u51C6\u3002",source:"\u539F\u89C6\u9891 SMPL-X \u62DF\u5408 \xB7 {seconds} \u79D2 \xB7 \u7A33\u5B9A\u663E\u793A\u914D\u7F6E",noPromise:"\u663E\u793A\u5C42\u5E73\u6ED1\u4F1A\u4FDD\u7559\u539F\u6570\u636E\uFF1B\u6570\u503C\u7B5B\u9009\u4E0D\u4FDD\u8BC1\u96F6\u6296\u52A8\u6216\u96F6\u7A7F\u63D2\u3002",error:"\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\uFF1A{reason}",serviceError:"\u670D\u52A1\u6682\u65F6\u7E41\u5FD9\u6216\u8FDE\u63A5\u4E2D\u65AD",assetError:"\u52A8\u4F5C\u8D44\u6E90\u52A0\u8F7D\u5931\u8D25\uFF0C\u5DF2\u505C\u6B62\u64AD\u653E\u3002",oldWorkbench:"\u539F\u52A8\u4F5C\u5DE5\u4F5C\u53F0",local:"\u4EC5\u672C\u673A \xB7 \u4E0D\u4E0A\u4F20\u8F93\u5165",sampleLabel:"\u8BED\u4E49\u5BF9\u7167\u4F8B\u53E5",shortcuts:"Ctrl / \u2318 + Enter \u5206\u6790\uFF1B\u4FEE\u6539\u8F93\u5165\u7ACB\u5373\u505C\u6B62\u65E7\u52A8\u4F5C\u3002",role:{actor:"\u4EBA\u7269\uFF0F\u65BD\u4E8B",predicate:"\u4E8B\u4EF6",patient:"\u5BF9\u8C61\uFF0F\u53D7\u4E8B",goal:"\u76EE\u6807",time:"\u65F6\u95F4",negation:"\u5426\u5B9A",modal:"\u60C5\u6001",aspect:"\u4E8B\u4EF6\u72B6\u6001"}},Ca={...Ia,connectionTitle:"Connect local model service",connectionHelp:"Run the packaged model Demo launcher, keep its terminal open, then connect. Inputs stay on this computer.",endpoint:"Local service address",connect:"Allow and connect",invalidEndpoint:"Use http://127.0.0.1:port only.",permissionRequired:"Allow loopback access to connect the model service.",permissionDenied:"Loopback access was declined. Click Allow and connect to retry.",incompatible:"The model or motion assets differ. Start the service from this package.",title:"SignBridge \xB7 Local model demo",label:"Real model \xB7 bounded Chinese semantics",heading:"See the relationships in a sentence",lead:"Inspect learned Chinese roles and scope, then check motion coverage.",input:"Enter one Chinese sentence",analyze:"Analyze meaning",loading:"Connecting to local model\u2026",ready:"Model ready \xB7 local inference",scope:"Research demo: Chinese analysis, motion preview and CSL correctness are evaluated separately.",disconnected:"Local service unavailable. Open the packaged model Demo launcher.",retry:"Reconnect",working:"Analyzing\u2026",parsed:"Bounded Chinese structure parsed",refused:"Outside supported scope; abstained",meaning:"Meaning structure",operators:"Scope, outside to inside",stage:"Motion reference",play:"Play matched reference",pause:"Pause",resume:"Resume",stop:"Stop",speed:"Playback speed",front:"Front",left:"Left",right:"Right",catalog:"Existing fits \xB7 independent reference previews",raw:"Raw model output and evidence",oldWorkbench:"Original motion workbench",local:"Local only \xB7 no input upload"},Fi={"zh-CN":{...Zh,...Qh,...Kh,...Yh,...qh,...Gh,modelDemo:Ia,batchTitle:"\u672C\u6279\u8865\u8BCD\u6E05\u5355 \xB7 \u6700\u591A 8 \u4E2A",batchManual:"\u624B\u52A8\u52A0\u5165\u5B8C\u6574\u8BCD\u7EC4\uFF08\u53EF\u9009\uFF0C\u907F\u514D\u5206\u8BCD\u8BEF\u62C6\uFF09",batchInvalidWord:"\u8BF7\u8F93\u5165 1\u2013100 \u4E2A\u5B57\u7B26\u7684\u6709\u6548\u8BCD\u8BED\u6216\u8BCD\u7EC4\uFF0C\u4E0D\u80FD\u53EA\u6709\u7A7A\u767D\u6216\u6807\u70B9\u3002",batchIntro:"\u5728\u5206\u6790\u7ED3\u679C\u4E2D\u6311\u9009\u9AD8\u9891\u7F3A\u8BCD\u52A0\u5165\u6E05\u5355\u3002\u5148\u5236\u4F5C\u5E76\u4FDD\u5B58\u8349\u7A3F\uFF0C\u518D\u53BB\u201C\u52A8\u4F5C\u9A8C\u6536\u201D\u68C0\u67E5\uFF0C\u6700\u540E\u5728\u7F16\u8F91\u5668\u6216\u5F55\u5236\u5DE5\u5177\u4E2D\u4EBA\u5DE5\u786E\u8BA4\u542F\u7528\u3002\u53EF\u5339\u914D\u53EA\u8868\u793A\u8BCD\u5E93\u6709\u5BF9\u5E94\u6570\u636E\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u542B\u4E49\u6B63\u786E\uFF1B\u6B64\u6E05\u5355\u4E0D\u4F1A\u751F\u6210\u3001\u4FEE\u6539\u6216\u81EA\u52A8\u542F\u7528\u52A8\u4F5C\u3002",batchAdd:"\u52A0\u5165\u672C\u6279",batchRefresh:"\u5237\u65B0\u8865\u8BCD\u72B6\u6001",batchExport:"\u4E0B\u8F7D\u8865\u8BCD\u8FDB\u5EA6 JSON",batchClear:"\u6E05\u7A7A\u672C\u6279\u6E05\u5355",batchClearConfirm:"\u53EA\u6E05\u7A7A\u8865\u8BCD\u6E05\u5355\uFF1F\u4E0D\u4F1A\u5220\u9664\u4EFB\u4F55\u52A8\u4F5C\u6216\u89C6\u89C9\u57FA\u51C6\u3002",batchRemove:"\u79FB\u51FA\u672C\u6279",batchState:"\u5B9E\u9645\u5339\u914D\u72B6\u6001 / \u52A8\u4F5C ID",batchLoading:"\u6B63\u5728\u6838\u5BF9\u5F53\u524D\u52A8\u4F5C\u5E93\u2026",batchEmpty:"\u6E05\u5355\u4E3A\u7A7A\u3002\u5206\u6790\u6750\u6599\u540E\uFF0C\u5728\u672A\u8986\u76D6\u8BCD\u65C1\u70B9\u51FB\u201C\u52A0\u5165\u672C\u6279\u201D\u3002",batchMissing:"\u5F85\u5236\u4F5C \xB7 \u5C1A\u672A\u5B8C\u5168\u5339\u914D",batchDraft:"\u5DF2\u4FDD\u5B58\u5019\u9009 \xB7 \u5C1A\u672A\u542F\u7528\u6216\u5B8C\u5168\u5339\u914D",batchMatched:"\u53EF\u5B8C\u5168\u5339\u914D \xB7 \u624B\u8BED\u4ECD\u9700\u4EBA\u5DE5\u6838\u9A8C",batchUnverified:"\u72B6\u6001\u672A\u6838\u9A8C\uFF0C\u8BF7\u91CD\u8BD5",batchSummary:"\u672C\u6279 {count}/{max} \u4E2A \xB7 \u53EF\u5B8C\u5168\u5339\u914D {matched} \u4E2A \xB7 \u65E0\u6548\u5E93\u8BB0\u5F55 {invalid} \u4E2A\u3002\u4FEE\u6539\u52A8\u4F5C\u540E\u4F1A\u81EA\u52A8\u91CD\u65B0\u6838\u5BF9\u3002",batchPrivacy:"\u53EA\u6709\u4E3B\u52A8\u52A0\u5165\u7684\u8BCD\u4F1A\u4FDD\u5B58\u5230\u672C\u6269\u5C55\u672C\u5730\u5B58\u50A8\uFF08\u5237\u65B0\u540E\u4FDD\u7559\uFF09\uFF0C\u4E0D\u4FDD\u5B58\u539F\u6587\u6216\u4F8B\u53E5\u3001\u4E0D\u4E0A\u4F20\u3002\u6E05\u5355\u4E0D\u5C5E\u4E8E\u52A8\u4F5C\u5305\uFF0C\u4E0B\u8F7D\u7684\u8FDB\u5EA6\u5305\u542B\u6240\u9009\u8BCD\u53CA\u5339\u914D ID\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u9690\u79C1\u3002",batchFailure:"\u8865\u8BCD\u6E05\u5355\u64CD\u4F5C\u5931\u8D25\uFF1A{detail}",batchFull:"\u672C\u6279\u5DF2\u6EE1 8 \u4E2A\uFF0C\u8BF7\u5148\u5B8C\u6210\u6216\u79FB\u9664\u90E8\u5206\u8BCD\u3002",batchInvalid:"\u8865\u8BCD\u6E05\u5355\u6570\u636E\u65E0\u6548\uFF0C\u539F\u8BB0\u5F55\u672A\u88AB\u8986\u76D6\u3002\u53EF\u660E\u786E\u6E05\u7A7A\u540E\u91CD\u65B0\u52A0\u5165\u3002",batchLockUnavailable:"\u8DE8\u9875\u9762\u5199\u5165\u9501\u4E0D\u53EF\u7528\uFF0C\u5DF2\u505C\u6B62\u4FEE\u6539\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u6253\u5F00\u6B64\u9875\u3002",reviewTitle:"\u52A8\u4F5C\u9A8C\u6536",reviewIntro:"\u6279\u91CF\u56DE\u653E\u5DF2\u4FDD\u5B58\u7684\u52A8\u4F5C\uFF0C\u4EE5\u56FA\u5B9A\u6B63\u9762\u3001\u53F3\u4FA7\u3001\u5DE6\u4FA7\u622A\u56FE\u5BF9\u7167\u81EA\u5DF1\u786E\u8BA4\u7684\u57FA\u51C6\u3002\u4E0D\u6539\u9AA8\u9ABC\u53C2\u6570\uFF0C\u4E5F\u4E0D\u81EA\u52A8\u542F\u7528\u7FFB\u8BD1\u3002",reviewLimits:"\u6BCF\u6279\u6700\u591A 8 \u4E2A\u52A8\u4F5C\uFF0C\u6BCF\u4E2A\u6700\u591A\u62BD\u53D6 12 \u4E2A\u5173\u952E\u5E27\uFF0C\u5305\u542B\u9996\u5C3E\u5E27\u3002\u622A\u56FE\u4EC5\u68C0\u67E5\u76EE\u6807\u59FF\u6001\uFF0C\u4E0D\u8986\u76D6\u6240\u6709\u8FC7\u6E21\u3001\u78B0\u649E\u3001\u5B57\u5E55\u53E5\u7EA7\u64AD\u653E\u6216\u624B\u8BED\u542B\u4E49\uFF1B\u89C6\u89C9\u53D8\u5316\u9700\u4EBA\u5DE5\u590D\u6838\u3002\u5185\u7F6E\u5217\u8868\u4F7F\u7528 SIGNS\uFF0C\u4E0D\u5305\u542B CHARS \u5355\u5B57\u56DE\u9000\u3002",reviewHelp:"\u63A7\u5236\u9762\u677F \u2192 \u52A8\u4F5C\u9A8C\u6536\u3002\u52FE\u9009\u52A8\u4F5C\u540E\u53EF\u81EA\u52A8\u4F9D\u6B21\u56DE\u653E\u6216\u751F\u6210\u4E09\u89C6\u56FE\uFF1B\u67E5\u770B\u624B\u5F62\u3001\u65B9\u5411\u548C\u7A7F\u6A21\uFF0C\u786E\u8BA4\u540E\u70B9\u51FB\u201C\u4FDD\u5B58 / \u66FF\u6362\u89C6\u89C9\u57FA\u51C6\u201D\u3002\u4EE5\u540E\u91CD\u65B0\u622A\u56FE\u53EF\u5E76\u6392\u5BF9\u6BD4\u3002\u52A8\u4F5C\u6570\u636E\u6539\u53D8\u4F1A\u63D0\u793A\u91CD\u65B0\u6838\u9A8C\uFF0C\u6A21\u578B/\u6D4F\u89C8\u5668/\u6E32\u67D3\u73AF\u5883\u6539\u53D8\u65F6\u4E0D\u8FDB\u884C\u6570\u503C\u5BF9\u6BD4\u3002\u4FDD\u5B58\u57FA\u51C6\u4E0D\u7B49\u4E8E\u786E\u8BA4\u624B\u8BED\u6B63\u786E\uFF0C\u4E0D\u4F1A\u4FEE\u6539\u52A8\u4F5C\u5E93\u7684\u8349\u7A3F\u6216\u542F\u7528\u72B6\u6001\u3002",reviewStorageHelp:"\u89C6\u89C9\u57FA\u51C6\u53EA\u5B58\u4E8E\u5F53\u524D\u6269\u5C55\u7684 IndexedDB\uFF0C\u4E0E\u52A8\u4F5C\u5E93\u5206\u5F00\uFF0C\u6700\u591A 100 \u4E2A / 64 MiB\u3002\u4E0D\u5305\u542B\u5728\u52A8\u4F5C\u5305\u5907\u4EFD\u4E2D\uFF1B\u5378\u8F7D\u524D\u8BF7\u4E0B\u8F7D PNG \u548C JSON \u62A5\u544A\u7559\u5B58\uFF08\u672C\u8F6E\u4E0D\u652F\u6301\u91CD\u65B0\u5BFC\u5165\u57FA\u51C6\uFF09\u3002\u622A\u56FE\u548C\u62A5\u544A\u4EC5\u5728\u4F60\u70B9\u51FB\u4E0B\u8F7D\u65F6\u5BFC\u51FA\uFF0C\u4E0D\u53D1\u9001\u5230\u7F51\u7EDC\u3002",reviewReload:"\u91CD\u65B0\u52A0\u8F7D\u6A21\u578B / \u91CD\u8BD5",reviewSelect:"1 \xB7 \u9009\u62E9\u52A8\u4F5C",reviewSearch:"\u6309\u540D\u79F0\u3001ID \u6216\u72B6\u6001\u7B5B\u9009\uFF08\u4E0D\u4F1A\u53D6\u6D88\u5DF2\u52FE\u9009\u52A8\u4F5C\uFF09",reviewCatalogCount:"\u53EF\u7528 {total} \u4E2A \xB7 \u5DF2\u9009 {count}/{max} \xB7 \u65E0\u6548\u5E93\u8BB0\u5F55 {invalid} \u4E2A",reviewPlay:"\u4F9D\u6B21\u56DE\u653E\u5168\u90E8\u5E27",reviewCapture:"\u751F\u6210\u5173\u952E\u5E27\u4E09\u89C6\u56FE",reviewStop:"\u505C\u6B62\u5F53\u524D\u4EFB\u52A1",reviewPreview:"\u56FA\u5B9A\u89C6\u89D2\u9884\u89C8",reviewView:"\u56DE\u653E\u89C6\u89D2",reviewFront:"\u6B63\u9762",reviewRight:"\u4EBA\u7269\u53F3\u4FA7",reviewLeft:"\u4EBA\u7269\u5DE6\u4FA7",reviewPreviewHelp:"\u89C6\u89D2\u53EA\u7528\u4E8E\u68C0\u67E5\uFF0C\u4E0D\u6539\u53D8\u6D6E\u7A97\u4F4D\u7F6E\u6216\u5927\u5C0F\u3002\u56DE\u653E\u6BCF\u4E2A\u52A8\u4F5C\u524D\u6062\u590D REST\uFF1B\u622A\u56FE\u5B8C\u6210\u540E\u6062\u590D\u6B63\u9762\u3002",reviewResults:"2 \xB7 \u4EBA\u5DE5\u6838\u9A8C\u4E0E\u57FA\u51C6\u5BF9\u6BD4",reviewExport:"\u4E0B\u8F7D\u672C\u6279 JSON \u62A5\u544A",reviewBuiltin:"\u5185\u7F6E \xB7 \u5F85\u4EBA\u5DE5\u6838\u9A8C",reviewEnabled:"\u81EA\u5B9A\u4E49 \xB7 \u5DF2\u542F\u7528",reviewDraft:"\u81EA\u5B9A\u4E49 \xB7 \u8349\u7A3F",reviewLoading:"\u6B63\u5728\u52A0\u8F7D\u5B9E\u9645\u6A21\u578B\u3001\u9AA8\u9ABC\u548C\u52A8\u4F5C\u5E93\u2026",reviewReady:"\u5DF2\u5C31\u7EEA\uFF0C\u5171 {total} \u4E2A\u52A8\u4F5C\u3002\u9009\u62E9\u52A8\u4F5C\u540E\u56DE\u653E\u6216\u622A\u56FE\u3002",reviewFailure:"\u9A8C\u6536\u5931\u8D25\uFF1A{detail}",reviewCatalogChanged:"\u52A8\u4F5C\u5E93\u5DF2\u53D8\u5316\uFF0C\u672C\u6279\u7ED3\u679C\u5931\u6548\u3002\u8BF7\u91CD\u65B0\u9009\u62E9\u5E76\u622A\u56FE\uFF0C\u65E7\u57FA\u51C6\u4E0D\u4F1A\u81EA\u52A8\u8986\u76D6\u3002",reviewPlaying:"\u6B63\u5728\u56DE\u653E {index}/{total}\uFF1A{name}",reviewCapturing:"\u6B63\u5728\u622A\u56FE {index}/{total}\uFF1A{name}",reviewFinished:"\u672C\u6279\u5B8C\u6210 {count} \u4E2A\uFF0C\u7ED3\u6784\u9519\u8BEF {failures} \u4E2A\uFF1B\u7ED3\u679C\u4ECD\u9700\u4EBA\u5DE5\u68C0\u67E5\u3002",reviewCancelled:"\u5DF2\u505C\u6B62\uFF1B\u672A\u5B8C\u6210\u6279\u6B21\u4E0D\u4FDD\u7559\u622A\u56FE\u7ED3\u679C\uFF0C\u4E0D\u4FEE\u6539\u57FA\u51C6\u3002",reviewDiagnostics:"\u5171 {frames} \u5E27 / {duration} \u79D2\uFF0C\u4F7F\u7528 {bones} \u4E2A\u9AA8\u9ABC\u3002\u622A\u56FE\u884C\u5BF9\u5E94\u5E27\uFF1A{indices}\uFF1B\u672A\u622A\u56FE {omitted} \u5E27\u3002",reviewSheetOrder:"\u6BCF\u884C\u4ECE\u5DE6\u5230\u53F3\uFF1A\u6B63\u9762 \u2192 \u4EBA\u7269\u53F3\u4FA7 \u2192 \u4EBA\u7269\u5DE6\u4FA7\uFF1B\u884C\u987A\u5E8F\u6309\u5E27\u53F7\u3002\u4E0B\u8F7D PNG \u53EF\u653E\u5927\u68C0\u67E5\u3002",reviewCurrent:"\u5F53\u524D\u622A\u56FE",reviewBaseline:"\u5DF2\u786E\u8BA4\u7684\u89C6\u89C9\u57FA\u51C6",reviewNoBaseline:"\u5C1A\u65E0\u89C6\u89C9\u57FA\u51C6\u3002\u5148\u68C0\u67E5\u52A8\u4F5C\uFF0C\u518D\u624B\u52A8\u4FDD\u5B58\u3002",reviewCompared:"\u57FA\u51C6\u65F6\u95F4 {date}\u3002RGB \u5355\u901A\u9053\u5DEE\u5F02 >16 \u7684\u50CF\u7D20\u5360 {ratio}%\uFF0C\u5E73\u5747\u901A\u9053\u5DEE\u5F02 {mean}/255\u3002\u4EC5\u4F9B\u4EBA\u5DE5\u590D\u6838\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u6B63\u786E\u6216\u4E0D\u5B58\u5728\u7A7F\u6A21\u3002",reviewMotionChanged:"\u52A8\u4F5C\u6570\u636E\u5DF2\u6539\u53D8\uFF08\u5305\u62EC\u65F6\u957F\u6216\u540D\u79F0\uFF09\uFF0C\u65E7\u57FA\u51C6\u4ECD\u4FDD\u7559\u3002\u6570\u503C\u5BF9\u6BD4\u5DF2\u505C\u6B62\uFF0C\u8BF7\u91CD\u65B0\u6838\u9A8C\u3002",reviewIncompatible:"\u6A21\u578B\u3001\u9AA8\u9ABC\u3001\u6D4F\u89C8\u5668\u6216\u6E32\u67D3\u73AF\u5883\u4E0E\u65E7\u57FA\u51C6\u4E0D\u540C\uFF0C\u4E0D\u80FD\u53EF\u9760\u8FDB\u884C\u6570\u503C\u5BF9\u6BD4\u3002\u65E7\u56FE\u53EA\u4F9B\u53C2\u8003\u3002",reviewUnavailable:"\u57FA\u51C6\u8BFB\u53D6 / \u5BF9\u6BD4\u5931\u8D25\uFF1A{detail}\u3002\u5F53\u524D\u622A\u56FE\u4ECD\u53EF\u4E0B\u8F7D\uFF0C\u4FDD\u5B58\u5C06\u518D\u6B21\u5C1D\u8BD5\u3002",reviewSaveBaseline:"\u4FDD\u5B58 / \u66FF\u6362\u89C6\u89C9\u57FA\u51C6",reviewDeleteBaseline:"\u5220\u9664\u6B64\u52A8\u4F5C\u57FA\u51C6",reviewDownloadImage:"\u4E0B\u8F7D\u5F53\u524D PNG",reviewSaveConfirm:"\u786E\u8BA4\u5DF2\u68C0\u67E5\u201C{name}\u201D\u7684\u4E09\u89C6\u56FE\uFF1F\u5C06\u4FDD\u5B58\u5F53\u524D\u622A\u56FE\u5E76\u66FF\u6362\u5DF2\u6709\u89C6\u89C9\u57FA\u51C6\uFF0C\u4EC5\u7528\u4E8E\u56DE\u5F52\u6BD4\u8F83\uFF1B\u4E0D\u4F1A\u542F\u7528\u7FFB\u8BD1\u6216\u8BA4\u8BC1\u624B\u8BED\u6B63\u786E\u6027\u3002",reviewDeleteConfirm:"\u5220\u9664\u201C{name}\u201D\u7684\u89C6\u89C9\u57FA\u51C6\uFF1F\u6B64\u64CD\u4F5C\u4E0D\u5220\u9664\u52A8\u4F5C\u5E93\u4E2D\u7684\u52A8\u4F5C\u3002",reviewSaved:"\u89C6\u89C9\u57FA\u51C6\u5DF2\u4FDD\u5B58\uFF1B\u52A8\u4F5C\u5E93\u4E0E\u7FFB\u8BD1\u542F\u7528\u72B6\u6001\u672A\u6539\u53D8\u3002",reviewDeleted:"\u6B64\u52A8\u4F5C\u7684\u89C6\u89C9\u57FA\u51C6\u5DF2\u5220\u9664\uFF0C\u52A8\u4F5C\u6570\u636E\u672A\u6539\u53D8\u3002",reviewStorageError:"\u65E0\u6CD5\u8BBF\u95EE\u672C\u5730\u57FA\u51C6\u5B58\u50A8\u3002\u8BF7\u68C0\u67E5\u6D4F\u89C8\u5668\u53EF\u7528\u7A7A\u95F4\u5E76\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u91CD\u5F00\u3002",reviewStorageFull:"\u89C6\u89C9\u57FA\u51C6\u8FBE\u5230 100 \u4E2A\u6216 64 MiB \u4E0A\u9650\u3002\u8BF7\u5148\u4E0B\u8F7D\u7559\u5B58\uFF0C\u518D\u5220\u9664\u4E0D\u9700\u8981\u7684\u57FA\u51C6\u3002",reviewBaselineChanged:"\u53E6\u4E00\u9875\u9762\u5DF2\u66F4\u65B0\u57FA\u51C6\uFF0C\u672A\u8986\u76D6\u3002\u8BF7\u91CD\u65B0\u622A\u56FE\u8BFB\u53D6\u6700\u65B0\u57FA\u51C6\u540E\u518D\u786E\u8BA4\u3002",reviewModelError:"\u6A21\u578B\u52A0\u8F7D\u5931\u8D25\u6216\u5C3A\u5BF8\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u6784\u5EFA\u6269\u5C55\u5E76\u91CD\u8BD5\u3002",reviewMissingBones:"\u6A21\u578B\u7F3A\u5C11\u624B\u8BED\u5FC5\u9700\u9AA8\u9ABC\uFF0C\u5DF2\u963B\u6B62\u9A8C\u6536\u3002",reviewRenderError:"\u6E32\u67D3\u5931\u8D25\u6216 WebGL \u4E0A\u4E0B\u6587\u4E22\u5931\uFF0C\u505C\u6B62\u4EFB\u52A1\u540E\u8BF7\u70B9\u51FB\u91CD\u65B0\u52A0\u8F7D\u3002",reviewInvalidSamples:"\u5173\u952E\u5E27\u62BD\u6837\u53C2\u6570\u65E0\u6548\u3002",reviewImageMismatch:"\u57FA\u51C6\u56FE\u7247\u635F\u574F\u6216\u5C3A\u5BF8\u4E0D\u4E00\u81F4\uFF0C\u4E0D\u80FD\u8FDB\u884C\u5BF9\u6BD4\u3002",motionPackTitle:"\u52A8\u4F5C\u5E93\u5907\u4EFD / \u6279\u91CF\u5BFC\u5165",motionPackHelp:"\u5BFC\u51FA\u5F53\u524D\u6A21\u578B\u4E0B\u5168\u90E8\u5DF2\u4FDD\u5B58\u7684\u81EA\u5B9A\u4E49\u52A8\u4F5C\uFF08\u4E0D\u542B\u672A\u4FDD\u5B58\u7F16\u8F91\u6216\u5185\u7F6E\u8BCD\u5178\uFF09\u3002\u9009\u6587\u4EF6\u53EA\u505A\u9884\u68C0\uFF0C\u786E\u8BA4\u540E\u65B0\u589E\u8349\u7A3F\uFF1B\u540C ID \u540C\u5185\u5BB9\u8DF3\u8FC7\uFF0C\u4E0D\u540C\u5185\u5BB9\u62D2\u7EDD\u6574\u5305\u5BFC\u5165\u3002\u65B0\u52A8\u4F5C\u4ECD\u987B\u9010\u6761\u8F7D\u5165\u3001\u9884\u89C8\u3001\u786E\u8BA4\u542F\u7528\u3002",motionPackPrivacy:"\u6587\u4EF6\u53EA\u5305\u542B\u52A8\u4F5C\u540D\u79F0\u3001\u5339\u914D\u6587\u5B57\u3001\u6807\u7B7E\u3001\u9AA8\u9ABC\u7ED1\u5B9A\u3001\u5E27\u6570\u636E\u53CA\u5BFC\u51FA\u65F6\u542F\u7528\u6807\u8BB0\uFF0C\u4E0D\u542B\u5BC6\u94A5\u6216\u5B57\u5E55\u3002\u540D\u79F0\u548C\u6807\u7B7E\u4E5F\u53EF\u80FD\u542B\u9690\u79C1\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u3002\u5BFC\u5165\u4E0D\u4F1A\u7EE7\u627F\u5BA1\u6838\u8BB0\u5F55\uFF0C\u4E5F\u4E0D\u4E0A\u4F20\u6587\u4EF6\u3002",motionPackExport:"\u5907\u4EFD\u5168\u90E8\u5DF2\u4FDD\u5B58\u52A8\u4F5C",motionPackFile:"\u9009\u62E9\u52A8\u4F5C\u5305 JSON\uFF08\u4E0D\u662F\u5355\u52A8\u4F5C JSON\uFF09",motionPackLimits:"\u6BCF\u5305\u6700\u591A 500 \u4E2A\u52A8\u4F5C\u30018 MiB\uFF1B\u5355\u52A8\u4F5C\u6700\u591A 2 MiB\u3002\u6A21\u578B\u4E0E REST \u5FC5\u987B\u4E00\u81F4\u3002",motionPackInspect:"\u91CD\u65B0\u9884\u68C0",motionPackImport:"\u786E\u8BA4\u5BFC\u5165\u65B0\u8349\u7A3F",motionPackClear:"\u53D6\u6D88\u5F85\u5BFC\u5165\u6587\u4EF6",motionPackSummary:"\u9884\u68C0\uFF1A\u65B0\u589E {new}\uFF0C\u5DF2\u5B58\u5728 {existing}\uFF0CID \u51B2\u7A81 {conflict}\u3002\u5C1A\u672A\u5199\u5165\u52A8\u4F5C\u5E93\u3002",motionPackName:"\u52A8\u4F5C / ID",motionPackState:"\u5904\u7406\u65B9\u5F0F",motionPackWarnings:"\u9700\u8981\u6CE8\u610F",motionPackNew:"\u65B0\u589E\u8349\u7A3F",motionPackExisting:"\u76F8\u540C\u5185\u5BB9\uFF0C\u8DF3\u8FC7",motionPackIdConflict:"ID \u51B2\u7A81\uFF0C\u4E0D\u8986\u76D6",motionPackWasEnabled:"\u5305\u5185\u6807\u8BB0\u66FE\u542F\u7528\uFF1B\u53EA\u662F\u6765\u6E90\u4FE1\u606F\uFF0C\u4E0D\u4EE3\u8868\u5BA1\u6838\u53EF\u4FE1\u3002",motionPackAliases:"\u5339\u914D\u6587\u5B57\u53EF\u80FD\u91CD\u590D\uFF1A{aliases}\u3002\u8349\u7A3F\u53EF\u4FDD\u5B58\uFF0C\u542F\u7528\u524D\u9700\u68C0\u67E5\uFF08\u542B\u672A\u542F\u7528\u6761\u76EE\uFF09\u3002",motionPackMaterial:"\u65E0\u5339\u914D\u6587\u5B57\uFF0C\u53EA\u4F5C\u59FF\u52BF\u7D20\u6750\uFF0C\u4E0D\u80FD\u542F\u7528\u7FFB\u8BD1\u3002",motionPackReady:"\u9884\u68C0\u5B8C\u6210\u3002\u53EA\u4F1A\u65B0\u589E\u8349\u7A3F\uFF0C\u4E0D\u6539\u53D8\u5F53\u524D\u59FF\u52BF\u6216\u5DF2\u6709\u52A8\u4F5C\u7684\u542F\u7528\u72B6\u6001\u3002",motionPackChecking:"\u6B63\u5728\u6838\u5BF9\u6A21\u578B\u548C\u672C\u5730\u52A8\u4F5C\u5E93\u2026",motionPackCleared:"\u5DF2\u53D6\u6D88\uFF0C\u52A8\u4F5C\u5E93\u6CA1\u6709\u6539\u53D8\u3002",motionPackConfirm:"\u5C06\u65B0\u589E {count} \u4E2A\u8349\u7A3F\uFF0C\u4E0D\u8986\u76D6\u65E7\u52A8\u4F5C\u3001\u4E0D\u81EA\u52A8\u542F\u7528\u3002\u8BF7\u786E\u8BA4\u6765\u6E90\u6388\u6743\uFF0C\u5BFC\u5165\u540E\u9010\u6761\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u548C\u542B\u4E49\u3002\u7EE7\u7EED\uFF1F",motionPackImported:"\u5DF2\u65B0\u589E {imported} \u4E2A\u8349\u7A3F\uFF0C\u8DF3\u8FC7 {skipped} \u4E2A\u5DF2\u6709\u52A8\u4F5C\u3002\u8BF7\u4ECE\u5217\u8868\u8F7D\u5165\u3001\u9884\u89C8\u5E76\u9010\u6761\u786E\u8BA4\u3002",motionPackExported:"\u5DF2\u53D1\u8D77 {count} \u4E2A\u5DF2\u4FDD\u5B58\u52A8\u4F5C\u7684\u4E0B\u8F7D\uFF0C\u8BF7\u68C0\u67E5\u4E0B\u8F7D\u7ED3\u679C\uFF1B\u4E0D\u542B\u5C1A\u672A\u4FDD\u5B58\u7684\u7F16\u8F91\u3002",motionPackInvalid:"\u4E0D\u662F\u6709\u6548\u7684 v1 \u52A8\u4F5C\u5305 JSON\uFF1B\u5355\u52A8\u4F5C\u6587\u4EF6\u8BF7\u4F7F\u7528\u4E0A\u65B9\u201C\u5BFC\u5165\u52A8\u4F5C JSON\u201D\u3002",motionPackEmpty:"\u52A8\u4F5C\u5305\u4E3A\u7A7A\uFF0C\u6216\u5F53\u524D\u6CA1\u6709\u53EF\u5907\u4EFD\u7684\u5DF2\u4FDD\u5B58\u52A8\u4F5C\u3002",motionPackTooLarge:"\u8D85\u8FC7\u9650\u5236\uFF1A\u52A8\u4F5C\u5305 8 MiB / 500 \u4E2A\u52A8\u4F5C\uFF0C\u5355\u52A8\u4F5C 2 MiB\u3002\u6CA1\u6709\u5199\u5165\u3002",motionPackDuplicateId:"\u5305\u5185\u5B58\u5728\u91CD\u590D ID\uFF0C\u65E0\u6CD5\u786E\u5B9A\u5E94\u4FDD\u7559\u54EA\u4E2A\u52A8\u4F5C\uFF0C\u5DF2\u62D2\u7EDD\u5BFC\u5165\u3002",motionPackInvalidStored:"\u672C\u5730\u5E93\u6709\u635F\u574F\u6216\u4E0E\u5F53\u524D\u6A21\u578B\u4E0D\u517C\u5BB9\u7684\u8BB0\u5F55\uFF0C\u672A\u751F\u6210\u4E0D\u5B8C\u6574\u5907\u4EFD\uFF1B\u539F\u6570\u636E\u4FDD\u7559\uFF0C\u8BF7\u5148\u68C0\u67E5\u8FD9\u4E9B\u8BB0\u5F55\u3002",motionPackConflict:"\u540C ID \u7684\u672C\u5730\u5185\u5BB9\u4E0D\u540C\u6216\u635F\u574F\uFF0C\u6574\u5305\u5BFC\u5165\u5DF2\u963B\u6B62\uFF0C\u4E0D\u4F1A\u8986\u76D6\u3002\u9700\u8981\u53E6\u5B58\u65F6\u8BF7\u4F7F\u7528\u5355\u52A8\u4F5C\u5BFC\u5165\u521B\u5EFA\u526F\u672C\u3002",motionPackStale:"\u52A8\u4F5C\u5E93\u5DF2\u6539\u53D8\uFF0C\u65E7\u9884\u68C0\u5931\u6548\u3002\u8BF7\u70B9\u51FB\u201C\u91CD\u65B0\u9884\u68C0\u201D\uFF0C\u786E\u8BA4\u6E05\u5355\u540E\u518D\u5BFC\u5165\u3002",motionPackLockUnavailable:"\u8DE8\u9875\u9762\u5199\u5165\u9501\u4E0D\u53EF\u7528\uFF0C\u5DF2\u505C\u6B62\u6279\u91CF\u5BFC\u5165\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u91CD\u65B0\u6253\u5F00\u5DE5\u5177\u9875\u3002",motionPackEncoding:"\u6587\u4EF6\u4E0D\u662F\u6709\u6548\u7684 UTF-8 JSON\uFF0C\u8BF7\u8F6C\u6362\u7F16\u7801\u540E\u91CD\u8BD5\u3002",coverageTitle:"\u8BCD\u5E93\u8986\u76D6\u5206\u6790",coverageHelpWorkflow:"\u5728\u63A7\u5236\u9762\u677F\u6253\u5F00\u201C\u8BCD\u5E93\u8986\u76D6\u5206\u6790\u201D\uFF0C\u7C98\u8D34\u6587\u5B57\u6216\u5BFC\u5165 UTF-8 TXT / SRT / VTT\uFF0C\u5206\u6790\u672A\u8986\u76D6\u8BCD\u7684\u9891\u6B21\u4E0E\u8BED\u5883\u3002\u70B9\u51FB\u8BCD\u6761\u65C1\u7684\u59FF\u52BF\u7F16\u8F91\u5668\u6216\u5F55\u5236\u5DE5\u5177\u53EA\u4F1A\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\uFF1B\u5236\u4F5C\u5E76\u4EBA\u5DE5\u786E\u8BA4\u52A8\u4F5C\u540E\u56DE\u5230\u5206\u6790\u9875\u91CD\u65B0\u5206\u6790\uFF0C\u53EF\u6838\u5BF9\u662F\u5426\u5B9E\u9645\u751F\u6548\u3002",coverageIntro:"\u5148\u627E\u51FA\u771F\u5B9E\u8BED\u6599\u91CC\u7F3A\u5C11\u7684\u8BCD\uFF0C\u518D\u5236\u4F5C\u5E76\u9A8C\u8BC1\u52A8\u4F5C\u3002\u4E0D\u4F1A\u81EA\u52A8\u751F\u6210\u624B\u8BED\uFF0C\u4E5F\u4E0D\u4F1A\u6539\u52A8\u73B0\u6709\u59FF\u52BF\u3002",coverageInput:"1 \xB7 \u9009\u62E9\u5206\u6790\u6750\u6599",coverageTextLabel:"\u7C98\u8D34\u6587\u5B57\uFF08\u6BCF\u884C\u4E00\u6BB5\uFF09\uFF0C\u6216\u5BFC\u5165 UTF-8 \u5B57\u5E55",coverageLimits:"\u4E0A\u9650\uFF1A256 KiB \u6587\u4EF6\u300150,000 \u5B57\u7B26\u30011,000 \u6BB5\u3001\u6BCF\u6BB5 2,000 \u5B57\u7B26\u3002SRT / WebVTT \u6309\u5B57\u5E55\u6761\u76EE\u5206\u6790\u3002",coverageFormat:"\u683C\u5F0F",coveragePlainText:"\u7EAF\u6587\u5B57 \xB7 \u6BCF\u884C\u4E00\u6BB5",coverageImport:"\u5BFC\u5165\u6587\u4EF6",coverageAnalyze:"\u5206\u6790\u5F53\u524D\u8BCD\u5E93",coverageClear:"\u6E05\u7A7A",coverageResults:"2 \xB7 \u627E\u5230\u8865\u8BCD\u4F18\u5148\u7EA7",coverageMetricHelp:"\u8986\u76D6\u7387 = \u547D\u4E2D\u7684\u5206\u8BCD\u6570 \xF7\uFF08\u547D\u4E2D\u5206\u8BCD\u6570 + \u672A\u8986\u76D6\u5206\u8BCD\u6570\uFF09\uFF0C\u8DF3\u8FC7\u7684\u865A\u8BCD\u4E0E\u6807\u70B9\u4E0D\u8BA1\u5165\u3002\u7EDF\u8BA1\u7684\u662F\u6574\u6BB5\u8BCD\u5E93\u8986\u76D6\uFF0C\u4E0D\u662F\u624B\u8BED\u51C6\u786E\u7387\uFF0C\u4E5F\u4E0D\u4FDD\u8BC1\u53E5\u610F\u5B8C\u6574\u6216\u5168\u90E8\u52A8\u4F5C\u4F1A\u64AD\u5B8C\u3002",coverageUnknownTitle:"\u672A\u8986\u76D6\u8BCD \xB7 \u6309\u51FA\u73B0\u6B21\u6570\u6392\u5E8F",coverageDraftHelp:"\u4F18\u5148\u7EA7\u53EA\u662F\u5206\u8BCD\u7ED3\u679C\uFF0C\u5148\u7ED3\u5408\u8BED\u5883\u5224\u65AD\u662F\u5426\u5E94\u5236\u4F5C\u5B8C\u6574\u8BCD\u7EC4\u3002\u8FDB\u5165\u5DE5\u5177\u53EA\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\uFF0C\u4E5F\u4E0D\u4F1A\u628A\u5F53\u524D\u59FF\u52BF\u5F53\u6210\u8BE5\u8BCD\u7684\u6B63\u786E\u624B\u8BED\u3002",coverageWord:"\u672A\u8986\u76D6\u8BCD",coverageFrequency:"\u6B21\u6570 / \u6BB5\u6570",coverageExamples:"\u4F8B\u53E5\u6BB5\u53F7",coverageMake:"\u5236\u4F5C\u4E0E\u4EBA\u5DE5\u9A8C\u8BC1",coverageDetailsTitle:"3 \xB7 \u9010\u6BB5\u6838\u5BF9\u5B9E\u9645\u547D\u4E2D",coverageDisplayLimit:"\u9875\u9762\u6700\u591A\u663E\u793A\u524D 100 \u4E2A\u672A\u8986\u76D6\u8BCD\u548C\u524D 200 \u6BB5\uFF1B\u7EDF\u8BA1\u5305\u542B\u5168\u90E8\u8F93\u5165\u3002\u5BFC\u51FA\u62A5\u544A\u53EF\u4FDD\u7559\u5168\u90E8\u7ED3\u679C\u3002",coverageIncludeText:"\u5BFC\u51FA\u65F6\u5305\u542B\u539F\u6587\u548C\u9010\u6BB5\u660E\u7EC6\uFF08\u53EF\u80FD\u542B\u9690\u79C1\uFF09",coverageExport:"\u5BFC\u51FA\u5206\u6790\u62A5\u544A JSON",coveragePrivacy:"\u6750\u6599\u4EC5\u5728\u672C\u9875\u5185\u5B58\u5206\u6790\uFF0C\u4E0D\u4E0A\u4F20\u3001\u4E0D\u81EA\u52A8\u4FDD\u5B58\uFF0C\u5173\u95ED\u9875\u9762\u5373\u4E22\u5F03\u3002\u9ED8\u8BA4\u62A5\u544A\u4E0D\u542B\u539F\u6587\uFF0C\u4F46\u4ECD\u5305\u542B\u672A\u8986\u76D6\u8BCD\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u3002",coverageSummary:"\u8986\u76D6 {ratio} \xB7 {segments} \u6BB5 \xB7 \u547D\u4E2D {matched} / \u672A\u8986\u76D6 {unknown} / \u8DF3\u8FC7 {skipped}",coverageNoTokens:"\u4E0D\u9002\u7528\uFF08\u65E0\u5F85\u7FFB\u8BD1\u8BCD\uFF09",coverageTruncation:"{count} \u6BB5\u89E6\u53CA\u5B9E\u65F6\u64AD\u653E\u6BCF\u6BB5 12 \u4E2A\u52A8\u4F5C\u4E0A\u9650\uFF1B\u8FD9\u90E8\u5206\u53EF\u80FD\u672A\u64AD\u653E\uFF0C\u8BF7\u67E5\u770B\u9010\u6BB5\u5269\u4F59\u6587\u672C\u3002",coverageOccurrences:"{count} \u6B21 / {segments} \u6BB5",coverageUniqueUnknown:"\u5171 {count} \u4E2A\u4E0D\u540C\u7684\u672A\u8986\u76D6\u8BCD\u3002\u8FC7\u957F\u7684\u8BCD\u8BF7\u5148\u62C6\u5206\u6216\u91CD\u65B0\u5224\u65AD\u5206\u8BCD\u3002",coverageNoUnknown:"\u672A\u53D1\u73B0\u672A\u8986\u76D6\u8BCD\uFF1B\u4ECD\u9700\u4EBA\u5DE5\u6838\u5BF9\u624B\u8BED\u542B\u4E49\u4E0E\u52A8\u4F5C\u3002",coverageMatches:"\u547D\u4E2D\uFF1A{value}",coverageUnmatched:"\u672A\u8986\u76D6\uFF1A{value}",coverageSkipped:"\u8DF3\u8FC7\uFF1A{value}",coverageRemaining:"\u8FBE\u5230\u64AD\u653E\u4E0A\u9650\u540E\u7684\u5269\u4F59\u6587\u672C\uFF1A{value}",coverageCatalog:"\u5F53\u524D\u8BCD\u5E93\uFF1A{signs} \u5185\u7F6E\u8BCD\u6761 / {aliases} \u67E5\u627E\u522B\u540D / {chars} \u5355\u5B57\uFF1B\u5DF2\u542F\u7528\u81EA\u5B9A\u4E49 {enabled}\uFF1B\u672A\u751F\u6548 {drafts}\uFF1B\u65E0\u6548\u6216\u6A21\u578B\u4E0D\u5339\u914D {invalid}\uFF08\u539F\u6570\u636E\u4FDD\u7559\uFF09\u3002",coverageReady:"\u7C98\u8D34\u6216\u5BFC\u5165\u6750\u6599\u540E\u70B9\u51FB\u5206\u6790\u3002\u9996\u6B21\u5206\u6790\u4F1A\u8BFB\u53D6\u5F53\u524D\u6A21\u578B\uFF0C\u6838\u9A8C\u81EA\u5B9A\u4E49\u52A8\u4F5C\u7ED1\u5B9A\u3002",coverageLoading:"\u6B63\u5728\u6838\u9A8C\u6A21\u578B\u4E0E\u52A8\u4F5C\u5E93\u5E76\u5206\u6790\u2026",coverageDone:"\u5206\u6790\u5B8C\u6210\u3002\u53EF\u5236\u4F5C\u7F3A\u5931\u52A8\u4F5C\uFF0C\u4EBA\u5DE5\u786E\u8BA4\u542F\u7528\u540E\u56DE\u5230\u6B64\u9875\u518D\u6B21\u5206\u6790\u3002",coverageChanged:"\u6750\u6599\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u5206\u6790\uFF1B\u65E7\u62A5\u544A\u4E0D\u53EF\u5BFC\u51FA\u3002",coverageCatalogChanged:"\u5171\u4EAB\u52A8\u4F5C\u5E93\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u5206\u6790\u4EE5\u67E5\u770B\u6700\u65B0\u8986\u76D6\uFF1B\u65E7\u62A5\u544A\u4E0D\u53EF\u5BFC\u51FA\u3002",coverageImported:"\u6750\u6599\u5DF2\u5BFC\u5165\u3002\u70B9\u51FB\u5206\u6790\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u64AD\u653E\u6216\u4FDD\u5B58\u3002",coverageFailure:"\u5206\u6790\u672A\u5B8C\u6210\uFF1A{detail}",coverageTooLarge:"\u8D85\u8FC7\u6750\u6599\u5927\u5C0F\u3001\u6BB5\u6570\u6216\u5355\u6BB5\u957F\u5EA6\u4E0A\u9650\uFF0C\u8BF7\u62C6\u5206\u540E\u5206\u6790\u3002",coverageEmpty:"\u8BF7\u63D0\u4F9B\u81F3\u5C11\u4E00\u6BB5\u975E\u7A7A\u6587\u5B57\u3002",coverageInvalidFormat:"\u4EC5\u652F\u6301 TXT\u3001SRT\u3001WebVTT\uFF0C\u8BF7\u9009\u62E9\u6B63\u786E\u683C\u5F0F\u3002",coverageInvalidSubtitles:"\u5B57\u5E55\u683C\u5F0F\u65E0\u6548\u3002\u8BF7\u68C0\u67E5\u7A7A\u884C\u3001\u65F6\u95F4\u8F74\u3001\u8D77\u6B62\u987A\u5E8F\u53CA WebVTT \u6587\u4EF6\u5934\uFF1B\u4E0D\u4F1A\u628A\u65F6\u95F4\u8F74\u5F53\u6B63\u6587\u7EDF\u8BA1\u3002",coverageEncoding:"\u6587\u4EF6\u4E0D\u662F\u6709\u6548 UTF-8\uFF0C\u8BF7\u8F6C\u6362\u7F16\u7801\u540E\u91CD\u8BD5\u3002",coverageModelError:"\u65E0\u6CD5\u6838\u9A8C\u5F53\u524D\u6A21\u578B\u6216\u5171\u4EAB\u52A8\u4F5C\u5E93\uFF0C\u8BF7\u786E\u8BA4\u4ECE\u63D2\u4EF6\u6253\u5F00\u4E14\u6A21\u578B\u53EF\u52A0\u8F7D\uFF0C\u7136\u540E\u91CD\u8BD5\u3002\u6CA1\u6709\u9000\u56DE\u5230\u4E0D\u5B8C\u6574\u7684\u7EDF\u8BA1\u3002",coverageOpenFailed:"\u5DE5\u5177\u9875\u9762\u672A\u80FD\u6253\u5F00\uFF0C\u8BF7\u4ECE\u63D2\u4EF6\u63A7\u5236\u9762\u677F\u91CD\u8BD5\u3002",coveragePrefilled:"\u5DF2\u4ECE\u8986\u76D6\u5206\u6790\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\u3002\u5F53\u524D\u59FF\u52BF\u4E0D\u662F\u8BE5\u8BCD\u7684\u5DF2\u9A8C\u8BC1\u52A8\u4F5C\uFF1B\u8BF7\u5236\u4F5C\u3001\u4FDD\u5B58\u3001\u9884\u89C8\u5E76\u4EBA\u5DE5\u786E\u8BA4\u3002",motionLibraryTitle:"\u5171\u4EAB\u52A8\u4F5C\u5E93 \xB7 \u7B2C\u4E8C\u9636\u6BB5",motionLibraryHelp:"\u7F16\u8F91\u5668\u3001\u5F55\u5236\u5668\u3001\u6D6E\u7A97\u4F7F\u7528\u540C\u4E00\u4EFD\u5F27\u5EA6\u6570\u636E\u3002\u4FDD\u5B58\u7684\u662F\u8349\u7A3F\uFF1B\u9884\u89C8\u5E76\u786E\u8BA4\u542F\u7528\u540E\uFF0C\u5339\u914D\u6587\u5B57\u624D\u53C2\u4E0E\u7FFB\u8BD1\u3002",motionName:"\u52A8\u4F5C\u540D\u79F0\uFF08\u5FC5\u586B\uFF09",motionTexts:"\u5339\u914D\u6587\u5B57\uFF08\u591A\u4E2A\u7528\u9017\u53F7\u5206\u9694\uFF1B\u7559\u7A7A\u4EC5\u4F5C\u59FF\u52BF\u7D20\u6750\uFF09",motionTags:"\u5206\u7C7B\u6807\u7B7E\uFF08\u9017\u53F7\u5206\u9694\uFF09",motionNew:"\u65B0\u5EFA\u526F\u672C",motionNewHelp:"\u5F53\u524D\u59FF\u52BF\u4FDD\u7559\uFF0C\u8BF7\u586B\u5199\u65B0\u7684\u52A8\u4F5C\u540D\u79F0\u3002",motionSave:"\u4FDD\u5B58\u8349\u7A3F",motionSaved:"\u5DF2\u4FDD\u5B58\u8349\u7A3F\uFF0C\u9700\u91CD\u65B0\u9884\u89C8\u3001\u786E\u8BA4\u540E\u542F\u7528\u3002",motionLoad:"\u8F7D\u5165\u9009\u4E2D",motionLoaded:"\u5DF2\u8F7D\u5165\u3002\u5BFC\u5165\u6587\u4EF6\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\uFF0C\u8BF7\u68C0\u67E5\u540E\u4FDD\u5B58\u8349\u7A3F\u3002",motionChoose:"\u9009\u62E9\u5DF2\u4FDD\u5B58\u7684\u52A8\u4F5C\u2026",motionDraft:"\u8349\u7A3F / \u672A\u542F\u7528",motionEnabled:"\u5DF2\u786E\u8BA4\u542F\u7528",motionPreview:"\u9884\u89C8\u5F53\u524D\u52A8\u4F5C",motionPreviewHelp:"\u6B63\u5728\u4F7F\u7528\u4E0E\u6D6E\u7A97\u76F8\u540C\u7684\u64AD\u653E\u5668\u3002\u8BF7\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u542B\u4E49\uFF1B\u4FEE\u6539\u540E\u9700\u91CD\u65B0\u4FDD\u5B58\u3002",motionEnable:"\u786E\u8BA4\u540E\u7528\u4E8E\u7FFB\u8BD1",motionDisable:"\u505C\u7528\u9009\u4E2D\u52A8\u4F5C",motionConfirm:"\u6211\u5DF2\u5B8C\u6574\u9884\u89C8\u5E76\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u6587\u5B57\u542B\u4E49\uFF0C\u786E\u8BA4\u5C06\u8FD9\u4E2A\u52A8\u4F5C\u7528\u4E8E\u7FFB\u8BD1\u3002\u6B64\u786E\u8BA4\u4E0D\u662F\u4E13\u4E1A\u624B\u8BED\u8BA4\u8BC1\u3002\u662F\u5426\u542F\u7528\uFF1F",motionEnabledHelp:"\u5DF2\u542F\u7528\uFF1B\u5DF2\u6253\u5F00\u7684\u6D6E\u7A97\u4F1A\u81EA\u52A8\u8BFB\u53D6\uFF0C\u65B0\u8F93\u5165\u7684\u5339\u914D\u6587\u5B57\u4F7F\u7528\u6B64\u52A8\u4F5C\u3002",motionDisabledHelp:"\u5DF2\u505C\u7528\uFF0C\u8349\u7A3F\u4FDD\u7559\u3002\u6D6E\u7A97\u53D6\u6D88\u6B63\u5728\u6392\u961F\u7684\u81EA\u5B9A\u4E49\u52A8\u4F5C\u3002",motionRefresh:"\u5237\u65B0\u52A8\u4F5C\u5217\u8868",motionExport:"\u4E0B\u8F7D\u7EDF\u4E00 JSON",motionExportCode:"\u5BFC\u51FA\u4EE3\u7801\uFF08\u4E0D\u4FDD\u5B58\uFF09",motionImport:"\u5BFC\u5165\u52A8\u4F5C JSON",motionImportFormat:"\u5BFC\u5165\u6587\u4EF6\u7684\u5355\u4F4D\u548C\u683C\u5F0F",motionFormat:"\u7EDF\u4E00\u683C\u5F0F \xB7 \u5F27\u5EA6 / REST \u589E\u91CF",motionLegacyEditor:"\u65E7\u7F16\u8F91\u5668 delta \xB7 \u5EA6\u6570\uFF08\u4EC5\u59FF\u52BF\u5BF9\u8C61\uFF09",motionLegacyRecorder:"\u65E7\u5F55\u5236\u5668 frames.pose \xB7 \u5EA6\u6570",motionLegacyAbsolute:"\u65E7\u7F16\u8F91\u5668\u7EDD\u5BF9\u65CB\u8F6C \xB7 \u5F27\u5EA6",motionMigrate:"\u8FC1\u79FB\u672C\u9875\u65E7\u52A8\u4F5C\u5E93",motionLegacyConfirm:"\u65E7\u6587\u4EF6\u6CA1\u6709\u6A21\u578B\u7ED1\u5B9A\u4FE1\u606F\u3002\u4EC5\u5F53\u5B83\u6765\u81EA\u5F53\u524D\u6A21\u578B\u4E14\u6240\u9009\u683C\u5F0F\u4E0E\u5355\u4F4D\u6B63\u786E\u65F6\u624D\u7EE7\u7EED\uFF1B\u8F6C\u6362\u540E\u5FC5\u987B\u9010\u4E2A\u68C0\u67E5\u3002\u539F\u59CB\u672C\u5730\u52A8\u4F5C\u5E93\u4E0D\u4F1A\u5220\u9664\u3002\u662F\u5426\u7EE7\u7EED\uFF1F",motionMigrated:"\u5DF2\u8FC1\u79FB {count} \u4E2A\u8349\u7A3F\uFF1B\u65E7\u5E93\u4FDD\u7559\uFF0C\u5C1A\u672A\u542F\u7528\u3002\u91CD\u590D\u8FC1\u79FB\u4F1A\u751F\u6210\u526F\u672C\u3002",motionIgnored:"\u6709 {count} \u4E2A\u635F\u574F\u6216\u6A21\u578B\u4E0D\u5339\u914D\u7684\u6761\u76EE\u672A\u8F7D\u5165\uFF1B\u539F\u6570\u636E\u4FDD\u7559\u3002",motionFailure:"\u672A\u5B8C\u6210\uFF1A{detail}",motionInvalidData:"\u52A8\u4F5C\u683C\u5F0F\u6216\u53C2\u6570\u65E0\u6548\uFF1A{detail}",motionModelNotReady:"\u6A21\u578B\u5C1A\u672A\u52A0\u8F7D\u5B8C\u6210\u3002",motionRigMismatch:"\u6A21\u578B\u9AA8\u9ABC\u6216 REST \u521D\u59CB\u59FF\u52BF\u4E0D\u4E00\u81F4\uFF0C\u5DF2\u62D2\u7EDD\u5E94\u7528\u3002",motionStorageUnavailable:"\u5171\u4EAB\u5B58\u50A8\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4ECE\u63D2\u4EF6\u63A7\u5236\u9762\u677F\u6253\u5F00\u5DE5\u5177\u9875\u9762\u3002",motionSelectFirst:"\u8BF7\u5148\u4FDD\u5B58\u6216\u9009\u62E9\u4E00\u4E2A\u52A8\u4F5C\u3002",motionSaveFirst:"\u52A8\u4F5C\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u4FDD\u5B58\u4E3A\u8349\u7A3F\u3001\u9884\u89C8\u540E\u542F\u7528\u3002",motionPreviewFirst:"\u8BF7\u5148\u9884\u89C8\u5F53\u524D\u52A8\u4F5C\uFF0C\u518D\u786E\u8BA4\u542F\u7528\u3002",motionAliasConflict:"\u5339\u914D\u6587\u5B57\u4E3A\u7A7A\u6216\u4E0E\u5DF2\u542F\u7528/\u5185\u7F6E\u8BCD\u6761\u91CD\u590D\uFF1A{detail}\u3002\u8BF7\u6362\u4E00\u4E2A\u660E\u786E\u7684\u65B0\u8BCD\u7EC4\u3002",motionFileTooLarge:"\u6587\u4EF6\u8FC7\u5927\u6216\u6761\u76EE\u8FC7\u591A\uFF08\u5355\u6587\u4EF6\u4E0A\u9650 2 MiB\uFF09\u3002",motionEditorSingleFrame:"\u7F16\u8F91\u5668\u53EA\u7F16\u8F91\u5355\u5E27\u59FF\u52BF\uFF1B\u8BF7\u7528\u5F55\u5236\u5668\u6253\u5F00\u591A\u5E27\u52A8\u753B\uFF0C\u907F\u514D\u4E22\u5E27\u3002",motionFrameLimit:"\u5DF2\u8FBE\u5230 240 \u5E27\u4E0A\u9650\uFF0C\u5F55\u5236\u5DF2\u505C\u6B62\u3002",motionFrameDuration:"\u5173\u952E\u5E27\u65F6\u957F\uFF08\u79D2\uFF0C0.05\u201310\uFF09",motionUpdateFrame:"\u66F4\u65B0\u9009\u4E2D\u5E27",motionHelpRig:"Godette \u4F7F\u7528\u6807\u51C6 Humanoid \u9AA8\u540D\u6620\u5C04\u53CA\u5B8C\u6574\u53EF\u7528\u6307\u9AA8\u94FE\u3002\u7F16\u8F91\u5668\u3001\u5F55\u5236\u5668\u4E0E\u6D6E\u7A97\u5171\u7528\u540C\u4E00\u4E2A profile \u548C REST \u521D\u59CB\u59FF\u52BF\uFF0C\u4E0D\u518D\u5404\u81EA\u89E3\u91CA\u9AA8\u9ABC\u3002",motionHelpAxes:"X/Y/Z \u662F\u9AA8\u9ABC\u672C\u5730\u8F74\uFF0C\u4E0D\u662F\u56FA\u5B9A\u7684\u4E16\u754C\u65B9\u5411\uFF1B\u4E0D\u540C\u9AA8\u9ABC\u7684\u8F74\u5411\u4E0D\u80FD\u4E00\u6982\u800C\u8BBA\u3002\u7EDF\u4E00\u5BFC\u51FA\u4E3A REST \u589E\u91CF\u5F27\u5EA6\uFF0C\u5F55\u5236\u5668\u9AA8\u9ABC\u6ED1\u5757\u663E\u793A\u7EDD\u5BF9\u672C\u5730\u5F27\u5EA6\u3002",motionHelpCreate:"\u59FF\u52BF\u7F16\u8F91\u5668\u5236\u4F5C\u5355\u5E27\uFF0C\u5F55\u5236\u5668\u5236\u4F5C\u591A\u5E27\u3002\u586B\u5199\u52A8\u4F5C\u540D\u79F0\u3001\u5339\u914D\u6587\u5B57\u3001\u6807\u7B7E\u540E\u4FDD\u5B58\u8349\u7A3F\uFF1B\u5339\u914D\u6587\u5B57\u7559\u7A7A\u53EF\u53EA\u4F5C\u59FF\u52BF\u7D20\u6750\u3002\u81EA\u5B9A\u4E49\u6587\u5B57\u4E0D\u80FD\u8986\u76D6\u5185\u7F6E\u8BCD\u6216\u5176\u5B83\u5DF2\u542F\u7528\u8BCD\u6761\u3002",motionHelpReview:"\u4FDD\u5B58\u8349\u7A3F \u2192 \u9884\u89C8\u5F53\u524D\u52A8\u4F5C \u2192 \u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u542B\u4E49 \u2192 \u786E\u8BA4\u540E\u7528\u4E8E\u7FFB\u8BD1\u3002\u4E4B\u540E\u5728\u63A7\u5236\u9762\u677F\u8F93\u5165\u5339\u914D\u6587\u5B57\u9A8C\u8BC1\u6D6E\u7A97\u3002\u4EBA\u5DE5\u786E\u8BA4\u4E0D\u662F\u4E13\u4E1A\u624B\u8BED\u8BA4\u8BC1\u3002",motionHelpFrames:"\u5F55\u5236\u5668\u70B9\u51FB\u65F6\u95F4\u7EBF\u9009\u5E27\uFF0C\u8C03\u597D\u9AA8\u9ABC\u548C\u65F6\u957F\u540E\u70B9\u51FB\u201C\u66F4\u65B0\u9009\u4E2D\u5E27\u201D\uFF1B\u65B0\u589E\u59FF\u52BF\u7528\u6DFB\u52A0\u5173\u952E\u5E27\u3002\u5355\u5E27 0.05\u201310 \u79D2\uFF0C\u6700\u591A 240 \u5E27\u4E14\u603B\u8BA1\u4E0D\u8D85\u8FC7 120 \u79D2\u3002\u81EA\u52A8\u5F55\u5236\u6BCF 0.3 \u79D2\u91C7\u6837\u3002",motionHelpUpdates:"\u4E24\u4E2A\u5DE5\u5177\u9875\u4E0E\u6D6E\u7A97\u5171\u4EAB\u540C\u4E00\u6269\u5C55 ID\u3001\u540C\u4E00\u6D4F\u89C8\u5668\u7528\u6237\u914D\u7F6E\u7684\u672C\u5730\u52A8\u4F5C\u5E93\u3002\u542F\u7528/\u505C\u7528\u4F1A\u81EA\u52A8\u66F4\u65B0\u6D6E\u7A97\u5E76\u53D6\u6D88\u65E7\u64AD\u653E\u961F\u5217\uFF1B\u518D\u6B21\u4FDD\u5B58\u64A4\u9500\u65E7\u786E\u8BA4\u3002\u65B0\u5EFA\u526F\u672C\u4FDD\u7559\u59FF\u52BF\u4F46\u4E0D\u8986\u76D6\u539F\u52A8\u4F5C\u3002",motionHelpBackup:"\u4E0B\u8F7D\u7EDF\u4E00 JSON \u7528\u4E8E\u5907\u4EFD\uFF0C\u5BFC\u51FA\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\u3002\u5BFC\u5165\u662F\u65B0\u8349\u7A3F\u526F\u672C\uFF0C\u5FC5\u987B\u91CD\u65B0\u4FDD\u5B58\u3001\u9884\u89C8\u3001\u786E\u8BA4\u3002\u7F16\u8F91\u5668\u4E0D\u622A\u65AD\u591A\u5E27\u6587\u4EF6\uFF0C\u8BF7\u7528\u5F55\u5236\u5668\u8F7D\u5165\u3002\u5378\u8F7D\u6269\u5C55\u6216\u66F4\u6362\u6269\u5C55 ID \u524D\u52A1\u5FC5\u4E0B\u8F7D\u5907\u4EFD\u3002",motionHelpLegacy:"\u8FC1\u79FB\u672C\u9875\u65E7\u52A8\u4F5C\u5E93\u4F1A\u4FDD\u7559 sb_gestures \u539F\u6570\u636E\uFF0C\u91CD\u590D\u8FC1\u79FB\u4F1A\u751F\u6210\u526F\u672C\u3002\u5BFC\u5165\u65E7 JSON \u65F6\u987B\u660E\u786E\u9009\u62E9\u5EA6\u6570/\u7EDD\u5BF9\u5F27\u5EA6\u7B49\u683C\u5F0F\uFF0C\u4E0D\u731C\u5355\u4F4D\u3001\u4E0D\u6267\u884C\u4EE3\u7801\u3002\u65E7\u6587\u4EF6\u6CA1\u6709\u6A21\u578B\u7ED1\u5B9A\uFF0C\u5FC5\u987B\u6765\u81EA\u5F53\u524D\u6A21\u578B\u5E76\u4EBA\u5DE5\u590D\u6838\u3002",motionHelpBinding:"\u6587\u4EF6\u6700\u591A 2 MiB\uFF0C\u9AA8\u9ABC/REST \u4E0D\u4E00\u81F4\u3001\u672A\u77E5\u9AA8\u540D\u6216\u4E0D\u5408\u6CD5\u53C2\u6570\u4F1A\u88AB\u62D2\u7EDD\u3002\u7ED1\u5B9A\u4E0D\u662F\u6574\u4E2A GLB \u6216\u8499\u76AE\u7684\u6307\u7EB9\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u6253\u5F00\u5DE5\u5177\uFF1B\u72EC\u7ACB localhost \u9875\u9762\u4E0D\u80FD\u5171\u4EAB\u8FD9\u4EFD\u5B58\u50A8\u3002\u5347\u7EA7\u6784\u5EFA\u540E\u987B\u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u5E76\u5173\u95ED\u3001\u91CD\u5F00\u65E7\u5DE5\u5177\u9875\u3002",motionHelpCollision:"\u5148\u5B9A\u4F4D\u5177\u4F53\u8BCD\u6761\u548C\u5173\u952E\u5E27\uFF0C\u5728\u7F16\u8F91\u5668/\u5F55\u5236\u5668\u4ECE\u6B63\u9762\u4E0E\u4FA7\u9762\u68C0\u67E5\u8098\u90E8\u548C\u624B\u8155\uFF1B\u4EC5\u4FEE\u6539\u8BE5\u52A8\u4F5C\u3001\u91CD\u65B0\u9884\u89C8\u786E\u8BA4\uFF0C\u4E0D\u5168\u5C40\u53CD\u8F6C\u6216\u6279\u91CF\u589E\u52A0\u89D2\u5EA6\u3002",motionHelpCoverage:"\u67E5\u770B\u547D\u4E2D\u7684 motionIds \u548C\u672A\u547D\u4E2D\u6587\u672C\uFF1B\u65E0\u5339\u914D\u65F6\u4E0D\u6253\u65AD\u6B63\u5728\u64AD\u653E\u7684\u52A8\u4F5C\u3002",motionHelpCatalog:"\u67E5\u770B\u5DF2\u542F\u7528\u81EA\u5B9A\u4E49\u52A8\u4F5C\u6570\u91CF\u548C\u65E0\u6548\u8BB0\u5F55\u6570\u91CF\uFF1B\u672A\u542F\u7528\u8349\u7A3F\u4E0D\u4F1A\u53C2\u4E0E\u7FFB\u8BD1\u3002",motionDurationInvalid:"\u5173\u952E\u5E27\u65F6\u957F\u987B\u4E3A 0.05\u201310 \u79D2\u3002",motionLoadingFailed:"\u6A21\u578B\u52A0\u8F7D\u5931\u8D25\uFF1A{detail}",name:"\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09",title:"SignBridge \u2014 \u624B\u8BED\u7FFB\u8BD1",description:"\u5B9E\u65F6\u5C06\u89C6\u9891\u8BED\u97F3\u7FFB\u8BD1\u6210\u624B\u8BED\uFF0C\u901A\u8FC73D\u865A\u62DF\u4EBA\u5C55\u793A",settings:"\u8BBE\u7F6E",avatar:"\u865A\u62DF\u4EBA",language:"\u8BED\u8A00",sourceLanguage:"\u89C6\u9891\u8BED\u8A00",targetSignLanguage:"\u624B\u8BED\u7C7B\u578B",avatarStyle:"\u865A\u62DF\u4EBA\u5916\u89C2",avatarSize:"\u865A\u62DF\u4EBA\u5927\u5C0F",avatarPosition:"\u865A\u62DF\u4EBA\u4F4D\u7F6E",positionBottomRight:"\u53F3\u4E0B\u89D2",positionBottomLeft:"\u5DE6\u4E0B\u89D2",positionTopRight:"\u53F3\u4E0A\u89D2",positionTopLeft:"\u5DE6\u4E0A\u89D2",enableAutoDetect:"\u81EA\u52A8\u68C0\u6D4B\u89C6\u9891",enableSubtitles:"\u663E\u793A\u5B57\u5E55",voiceVolume:"\u8BED\u97F3\u97F3\u91CF",speed:"\u624B\u8BED\u901F\u5EA6",about:"\u5173\u4E8E",start:"\u5F00\u59CB\u7FFB\u8BD1",stop:"\u505C\u6B62\u7FFB\u8BD1",loading:"\u52A0\u8F7D\u4E2D...",noVideo:"\u672A\u68C0\u6D4B\u5230\u89C6\u9891",error:"\u51FA\u9519\u4E86",errorNoVideo:"\u9875\u9762\u4E0A\u6CA1\u6709\u627E\u5230\u89C6\u9891",ready:"\u5DF2\u5C31\u7EEA",translating:"\u6B63\u5728\u7FFB\u8BD1...",unavailable:"\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u7528",inputPlaceholder:"\u8F93\u5165\u6587\u5B57\uFF0C\u865A\u62DF\u4EBA\u6253\u624B\u8BED...",send:"\u53D1\u9001",sent:"\u5DF2\u53D1\u9001",audioOff:"\u89C6\u9891\u58F0\u97F3\uFF1A\u5173\u95ED",audioOn:"\u89C6\u9891\u58F0\u97F3\uFF1A\u5F00\u542F",audioStopped:"\u5DF2\u5173\u95ED",audioListening:"\u8BC6\u522B\u4E2D...",audioStarting:"\u6B63\u5728\u6355\u83B7\u58F0\u97F3...",audioUnavailable:"\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u6355\u83B7",audioCaptureFailed:"\u58F0\u97F3\u6355\u83B7\u5931\u8D25",audioCloudKeyRequired:"\u8BF7\u5148\u914D\u7F6E\u4E91\u7AEF API Key",audioPermissionRequired:"\u8BF7\u5148\u4FDD\u5B58\u8BC6\u522B\u8BBE\u7F6E\u5E76\u6388\u6743\u670D\u52A1\u5730\u5740",audioLocalUnavailable:"\u8BF7\u5148\u4E00\u952E\u90E8\u7F72\u672C\u5730 Whisper",asrSettings:"\u58F0\u97F3\u8BC6\u522B\u8BBE\u7F6E",asrTitle:"\u89C6\u9891\u58F0\u97F3\u8BC6\u522B",asrPurpose:"\u9009\u62E9\u672C\u5730 Whisper \u6216\u4E91\u7AEF ASR\uFF0C\u5C06\u5F53\u524D\u89C6\u9891\u58F0\u97F3\u8F6C\u6362\u4E3A\u624B\u8BED\u52A8\u4F5C\u3002",asrProvider:"\u8BC6\u522B\u65B9\u5F0F",asrLocal:"\u672C\u5730 Whisper",asrCloud:"\u4E91\u7AEF ASR",asrLocalSettings:"\u672C\u5730 Whisper \u8BBE\u7F6E",asrLocalPrivacy:"\u6A21\u578B\u548C\u97F3\u9891\u90FD\u5728\u6D4F\u89C8\u5668\u6269\u5C55\u5185\u5904\u7406\uFF0C\u89C6\u9891\u58F0\u97F3\u4E0D\u4F1A\u4E0A\u4F20\u5230\u8BC6\u522B\u670D\u52A1\u3002",asrDeployLocal:"\u4E00\u952E\u90E8\u7F72\u672C\u5730 Whisper",asrEndpoint:"\u670D\u52A1\u5730\u5740",asrModel:"\u6A21\u578B",asrModelTiny:"tiny\uFF08\u6700\u5FEB\uFF0C\u7EA6 75 MB\uFF09",asrModelBase:"base\uFF08\u5747\u8861\uFF0C\u7EA6 150 MB\uFF09",asrModelSmall:"small\uFF08\u66F4\u51C6\u786E\uFF0C\u7EA6 500 MB\uFF09",asrDeployHint:"\u70B9\u51FB\u540E\u81EA\u52A8\u4E0B\u8F7D\u5E76\u7F13\u5B58\u6A21\u578B\uFF0C\u65E0\u9700\u5B89\u88C5 Python \u6216\u8FD0\u884C\u672C\u5730\u670D\u52A1\u3002",asrDeployRequired:"\u5F53\u524D\u6A21\u578B\u5C1A\u672A\u90E8\u7F72\u3002",asrRequestingModelPermission:"\u6B63\u5728\u7533\u8BF7\u6A21\u578B\u4E0B\u8F7D\u6743\u9650...",asrDeploying:"\u6B63\u5728\u4E0B\u8F7D\u5E76\u521D\u59CB\u5316\u6A21\u578B\uFF1A{progress}%",asrDeployReady:"\u672C\u5730\u6A21\u578B {model} \u5DF2\u5C31\u7EEA\u3002",asrDeployFailed:"\u672C\u5730\u6A21\u578B\u90E8\u7F72\u5931\u8D25",asrCloudSettings:"\u4E91\u7AEF ASR \u8BBE\u7F6E",asrCloudPrivacy:"\u89C6\u9891\u97F3\u9891\u5206\u7247\u4F1A\u53D1\u9001\u5230\u4F60\u914D\u7F6E\u7684\u670D\u52A1\uFF0C\u8BF7\u786E\u8BA4\u670D\u52A1\u7684\u9690\u79C1\u4E0E\u8BA1\u8D39\u89C4\u5219\u3002",asrApiKey:"API Key",asrCommonSettings:"\u901A\u7528\u8BBE\u7F6E",asrLanguage:"\u8BC6\u522B\u8BED\u8A00",asrChunkSeconds:"\u97F3\u9891\u5206\u7247",asrTest:"\u6D4B\u8BD5\u8FDE\u63A5",asrSave:"\u4FDD\u5B58\u8BBE\u7F6E",asrPermissionDenied:"\u672A\u6388\u4E88\u8BE5\u670D\u52A1\u5730\u5740\u7684\u7F51\u7EDC\u6743\u9650\u3002",asrSaved:"\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002",asrInvalidConfig:"\u8BBE\u7F6E\u65E0\u6548\uFF1A\u8FDC\u7A0B\u670D\u52A1\u9700HTTPS\uFF1BHTTP\u4EC5\u5141\u8BB8127.0.0.1\u3001localhost\u6216[::1]\u672C\u673A\u5730\u5740\uFF0CURL\u4E0D\u53EF\u542B\u8D26\u53F7\u5BC6\u7801\u3002",asrTesting:"\u6B63\u5728\u6D4B\u8BD5\u8BC6\u522B\u670D\u52A1...",asrTestPassed:"\u8FDE\u63A5\u6D4B\u8BD5\u901A\u8FC7\u3002",asrTestFailed:"\u8FDE\u63A5\u6D4B\u8BD5\u5931\u8D25",poseEditor:"\u59FF\u52BF\u7F16\u8F91\u5668",recorder:"\u5F55\u5236\u5DE5\u5177",help:"\u5E2E\u52A9\u6587\u6863",tagline:"\u8BA9\u4FE1\u606F\u65E0\u969C\u788D",auto:"\u81EA\u52A8\u68C0\u6D4B",simplifiedChinese:"\u4E2D\u6587\uFF08\u666E\u901A\u8BDD\uFF09",footer:"SignBridge \u2014 \u8BA9\u4FE1\u606F\u65E0\u969C\u788D",signLanguageTypes:{csl:"\u4E2D\u56FD\u624B\u8BED (CSL)",asl:"\u7F8E\u56FD\u624B\u8BED (ASL)",bsl:"\u82F1\u56FD\u624B\u8BED (BSL)",jsl:"\u65E5\u672C\u624B\u8BED (JSL)",ksl:"\u97E9\u56FD\u624B\u8BED (KSL)",tsl:"\u53F0\u6E7E\u624B\u8BED (TSL)"},avatarStyles:{default:"\u9ED8\u8BA4",friendly:"\u53CB\u597D",professional:"\u4E13\u4E1A",anime:"\u52A8\u6F2B\u98CE\u683C"},voiceVolumeLevels:{low:"\u4F4E\uFF08\u4EC5\u89C6\u9891\uFF09",medium:"\u4E2D\uFF08\u89C6\u9891+\u624B\u8BED\uFF09",high:"\u9AD8\uFF08\u4EC5\u624B\u8BED\uFF09"}},en:{...$h,...eu,...Ea,...Ra,...Aa,...Wh,modelDemo:Ca,batchTitle:"Vocabulary batch \xB7 up to 8 items",batchManual:"Add a complete phrase manually (optional, avoids token-splitting mistakes)",batchInvalidWord:"Enter a word or phrase of 1\u2013100 characters, not only whitespace or punctuation.",batchIntro:"Add frequent gaps from the analysis. Save a draft, inspect it in Motion review, then explicitly enable it in the editor or recorder. A full match means data is available, not that the sign is linguistically correct. This list never generates, edits or enables motions.",batchAdd:"Add to batch",batchRefresh:"Refresh batch status",batchExport:"Download progress JSON",batchClear:"Clear batch list",batchClearConfirm:"Clear only this list? Motions and visual baselines will not be deleted.",batchRemove:"Remove from batch",batchState:"Actual match status / motion IDs",batchLoading:"Checking the current motion library\u2026",batchEmpty:"No selected words. Analyze a sample, then add vocabulary gaps to this batch.",batchMissing:"Needs authoring \xB7 not fully matched",batchDraft:"Candidate saved \xB7 not enabled or fully matched",batchMatched:"Fully matched \xB7 human sign-language review still required",batchUnverified:"Status not verified; please retry",batchSummary:"Batch {count}/{max} \xB7 fully matched {matched} \xB7 invalid library entries {invalid}. Motion changes trigger a fresh check.",batchPrivacy:"Only words you explicitly add persist in this extension's local storage. No source text or examples are saved or uploaded. The list is not part of a motion pack. Progress exports contain selected words and motion IDs; check privacy before sharing.",batchFailure:"Vocabulary batch failed: {detail}",batchFull:"This batch already has 8 words. Complete or remove some first.",batchInvalid:"Invalid batch data. Existing data was not overwritten; explicitly clear the list to start again.",batchLockUnavailable:"Cross-page write lock unavailable. No changes made. Open this page from the extension panel.",reviewTitle:"Motion review",reviewIntro:"Replay saved motions and compare fixed front, right and left snapshots with manually approved visual references. No rig changes or automatic translation approval.",reviewLimits:"Up to 8 motions per batch and 12 sampled keyframes per motion, including first and last. Snapshots cover target poses, not every transition, collision, subtitle sequence or linguistic meaning. Human review is required. The built-in list covers SIGNS, not CHARS fallbacks.",reviewHelp:"Control panel \u2192 Motion review. Select motions to replay or capture three views. Check hands, directions and intersections before saving a visual baseline. Later captures appear alongside it. Changed motion data requires new review; different model/browser/rendering environments disable numeric comparison. Baselines do not change draft or enabled status, and do not certify correct signing.",reviewStorageHelp:"References stay in this extension's IndexedDB, separate from the motion library, capped at 100 / 64 MiB. Motion packs do not include them. Download PNG and JSON before uninstalling (baseline reimport is not supported yet). Nothing is sent over the network.",reviewReload:"Reload model / retry",reviewSelect:"1 \xB7 Select motions",reviewSearch:"Filter by name, ID or status (checked motions remain selected)",reviewCatalogCount:"{total} available \xB7 {count}/{max} selected \xB7 {invalid} invalid library records",reviewPlay:"Replay all frames in order",reviewCapture:"Capture three-view keyframes",reviewStop:"Stop current task",reviewPreview:"Fixed-view preview",reviewView:"Playback view",reviewFront:"Front",reviewRight:"Character's right",reviewLeft:"Character's left",reviewPreviewHelp:"Views never change the floating avatar. Each replay starts from REST; capture resets to the front view.",reviewResults:"2 \xB7 Human review and baseline comparison",reviewExport:"Download batch JSON report",reviewBuiltin:"Built-in \xB7 needs human review",reviewEnabled:"Custom \xB7 enabled",reviewDraft:"Custom \xB7 draft",reviewLoading:"Loading the actual model, rig and motion library\u2026",reviewReady:"Ready: {total} motions. Select motions to replay or capture.",reviewFailure:"Review failed: {detail}",reviewCatalogChanged:"The library changed; these results are stale. Select and capture again. Existing baselines are never overwritten automatically.",reviewPlaying:"Playing {index}/{total}: {name}",reviewCapturing:"Capturing {index}/{total}: {name}",reviewFinished:"Finished {count} motions; {failures} structural errors. Human review is still required.",reviewCancelled:"Stopped. Incomplete batch captures discarded; baselines unchanged.",reviewDiagnostics:"{frames} frames / {duration}s, {bones} bones. Sheet rows: frames {indices}; {omitted} frames not captured.",reviewSheetOrder:"Columns: front \u2192 character's right \u2192 character's left. Rows follow frame indices. Download PNG to inspect at full size.",reviewCurrent:"Current capture",reviewBaseline:"Confirmed visual reference",reviewNoBaseline:"No visual reference yet. Inspect the motion before saving one.",reviewCompared:"Baseline {date}. Pixels with RGB channel difference >16: {ratio}%; mean channel difference {mean}/255. Review hint only, not signing or collision certification.",reviewMotionChanged:"Motion data changed (including duration or name). Previous reference retained; numeric comparison disabled. Review again.",reviewIncompatible:"Model, rig, browser or rendering environment differs. Numeric comparison is unreliable and disabled. Old image is for reference only.",reviewUnavailable:"Baseline read / comparison failed: {detail}. Current PNG remains downloadable; saving will retry.",reviewSaveBaseline:"Save / replace visual reference",reviewDeleteBaseline:"Delete this reference",reviewDownloadImage:"Download current PNG",reviewSaveConfirm:"Have you checked all three views of \u201C{name}\u201D? Saving replaces its existing visual reference for regression comparison only. It neither enables translation nor certifies correct signing.",reviewDeleteConfirm:"Delete the visual reference for \u201C{name}\u201D? The motion itself is not deleted.",reviewSaved:"Visual reference saved; motion library and translation status unchanged.",reviewDeleted:"Visual reference deleted; motion data unchanged.",reviewStorageError:"Cannot access local baseline storage. Check disk space and reopen from the extension control panel.",reviewStorageFull:"Reference limit reached (100 or 64 MiB). Download a copy, then remove unneeded references.",reviewBaselineChanged:"Another page updated this reference. Nothing overwritten. Capture again before confirming.",reviewModelError:"Model load failed or dimensions invalid. Rebuild the extension and retry.",reviewMissingBones:"Required signing bones are missing; review blocked.",reviewRenderError:"Rendering failed or WebGL context was lost. Stop and reload the model.",reviewInvalidSamples:"Invalid keyframe sampling parameters.",reviewImageMismatch:"Reference image is damaged or dimensions differ; comparison blocked.",motionPackTitle:"Library backup / batch import",motionPackHelp:"Export all saved custom motions for this model, not unsaved edits or built-in signs. Choosing a file only runs preflight. Confirmation adds drafts: identical IDs/content are skipped; differing content blocks the entire import. Load, preview and confirm each new motion separately.",motionPackPrivacy:"Files contain names, matching text, tags, rig binding, frames and an informational enabled-at-export flag, not keys or subtitles. Names and tags may be sensitive; check before sharing. Imports never inherit approval and are not uploaded.",motionPackExport:"Back up all saved motions",motionPackFile:"Select motion pack JSON (not a single-motion file)",motionPackLimits:"Up to 500 motions / 8 MiB per pack; 2 MiB per motion. Rig and REST must match.",motionPackInspect:"Run preflight again",motionPackImport:"Confirm import as new drafts",motionPackClear:"Cancel pending file",motionPackSummary:"Preflight: {new} new, {existing} existing, {conflict} ID conflicts. Nothing has been saved.",motionPackName:"Motion / ID",motionPackState:"Action",motionPackWarnings:"Review notes",motionPackNew:"New draft",motionPackExisting:"Identical; skip",motionPackIdConflict:"ID conflict; no overwrite",motionPackWasEnabled:"Pack says previously enabled; this is source information, not trusted approval.",motionPackAliases:"Potential duplicate matching text: {aliases}. Draft saving is allowed; review before enabling (includes disabled entries).",motionPackMaterial:"No matching text; pose material only, not eligible for translation.",motionPackReady:"Preflight complete. Only new drafts are added; current pose and existing approval remain unchanged.",motionPackChecking:"Checking the rig and local library\u2026",motionPackCleared:"Cancelled. The library is unchanged.",motionPackConfirm:"Add {count} drafts without overwriting or enabling motions? Ensure you have permission to use the source. Review handshape, direction and meaning individually after import.",motionPackImported:"Added {imported} drafts; skipped {skipped} existing motions. Load, preview and confirm each from the list.",motionPackExported:"Started download of {count} saved motions. Check the downloaded file; unsaved edits are not included.",motionPackInvalid:"Not a valid v1 motion pack JSON. For one motion, use the single-motion import above.",motionPackEmpty:"The pack is empty, or there are no saved motions to back up.",motionPackTooLarge:"Limit exceeded: 8 MiB / 500 motions per pack, 2 MiB per motion. Nothing was saved.",motionPackDuplicateId:"Duplicate IDs within the pack are ambiguous; import was rejected.",motionPackInvalidStored:"Local entries are damaged or incompatible with the current model. No incomplete backup was produced; originals are preserved. Inspect those entries first.",motionPackConflict:"A local ID has different or damaged content. The entire import is blocked; nothing is overwritten. Use single-motion import to create a separate copy if needed.",motionPackStale:"The library changed and preflight expired. Run preflight again and review the list before importing.",motionPackLockUnavailable:"Cross-page write locking is unavailable. Batch import stopped; reopen the tool from the extension panel.",motionPackEncoding:"Not valid UTF-8 JSON. Convert the encoding and retry.",coverageTitle:"Vocabulary coverage",coverageHelpWorkflow:"Open Vocabulary coverage from the control panel. Paste text or import UTF-8 TXT / SRT / VTT to inspect unknown words, frequency and context. Editor and recorder buttons only prefill a name and matching text. Create and review a motion, enable it, then analyze again to verify it is active.",coverageIntro:"Find missing vocabulary in real text, then create and review motions. This does not generate signs or change existing poses.",coverageInput:"1 \xB7 Choose material",coverageTextLabel:"Paste text (one segment per line), or import UTF-8 subtitles",coverageLimits:"Limits: 256 KiB file, 50,000 characters, 1,000 segments, 2,000 characters per segment. SRT / WebVTT use subtitle cues.",coverageFormat:"Format",coveragePlainText:"Plain text \xB7 one segment per line",coverageImport:"Import file",coverageAnalyze:"Analyze current vocabulary",coverageClear:"Clear",coverageResults:"2 \xB7 Prioritize missing vocabulary",coverageMetricHelp:"Coverage = matched word tokens / (matched + unknown word tokens). Skipped function words and punctuation are excluded. This measures full-segment dictionary coverage, not sign accuracy, sentence meaning or completed playback.",coverageUnknownTitle:"Unknown words \xB7 most frequent first",coverageDraftHelp:"These are tokenizer suggestions. Check context before deciding whether a full phrase is needed. Tools only prefill the name and matching text: no automatic save, approval or claim that the current pose represents the word.",coverageWord:"Unknown word",coverageFrequency:"Occurrences / segments",coverageExamples:"Example segment numbers",coverageMake:"Create and review",coverageDetailsTitle:"3 \xB7 Inspect actual matches by segment",coverageDisplayLimit:"Shows up to 100 unknown words and 200 segments. Totals cover all input; export for complete results.",coverageIncludeText:"Include source text and segment details in export (may contain private data)",coverageExport:"Export JSON report",coveragePrivacy:"Analysis stays in this page's memory: no uploads or automatic saving. Closing the page discards it. Default exports omit source text but still contain unknown words; check before sharing.",coverageSummary:"Coverage {ratio} \xB7 {segments} segments \xB7 {matched} matched / {unknown} unknown / {skipped} skipped",coverageNoTokens:"N/A (no translatable tokens)",coverageTruncation:"{count} segments reach the runtime limit of 12 motions per segment. Some text may not play; inspect the remaining text below.",coverageOccurrences:"{count} occurrences / {segments} segments",coverageUniqueUnknown:"{count} distinct unknown words. Split or reconsider tokenization for very long words.",coverageNoUnknown:"No unknown words found. Sign meaning and motion still need human review.",coverageMatches:"Matched: {value}",coverageUnmatched:"Unknown: {value}",coverageSkipped:"Skipped: {value}",coverageRemaining:"Text remaining after playback limit: {value}",coverageCatalog:"Vocabulary: {signs} built-in signs / {aliases} lookup aliases / {chars} characters; {enabled} active custom; {drafts} inactive; {invalid} invalid or incompatible entries (originals kept).",coverageReady:"Paste or import, then analyze. The first analysis loads the model to validate custom motion bindings.",coverageLoading:"Validating model and library, then analyzing\u2026",coverageDone:"Analysis complete. Create missing motions, review and enable them, then analyze again here.",coverageChanged:"Input changed. Analyze again; the old report cannot be exported.",coverageCatalogChanged:"Shared library changed. Analyze again for current coverage; the old report cannot be exported.",coverageImported:"Imported. Click Analyze; nothing is played or saved automatically.",coverageFailure:"Analysis did not complete: {detail}",coverageTooLarge:"Material exceeds size, segment count or segment length limits. Split it and try again.",coverageEmpty:"Provide at least one non-empty text segment.",coverageInvalidFormat:"Only TXT, SRT and WebVTT are supported. Select the matching format.",coverageInvalidSubtitles:"Invalid subtitles. Check blank lines, timestamps, start/end order and WebVTT header. Timing lines will not be counted as text.",coverageEncoding:"Not valid UTF-8. Convert the file encoding and retry.",coverageModelError:"Cannot validate the current model or shared library. Open from the extension, check model loading and retry. No incomplete fallback report was produced.",coverageOpenFailed:"Could not open the tool. Retry from the extension panel.",coveragePrefilled:"Name and matching text prefilled from coverage. The current pose is not a verified sign for this word. Create, save, preview and review it before enabling.",motionLibraryTitle:"Shared motion library \xB7 Phase 2",motionLibraryHelp:"Editor, recorder and avatar share radians and REST deltas. Saved drafts affect translation only after preview and explicit confirmation.",motionName:"Motion name (required)",motionTexts:"Matching text (comma separated; empty for pose-only assets)",motionTags:"Tags (comma separated)",motionNew:"New copy",motionNewHelp:"Current pose retained. Enter a new motion name.",motionSave:"Save draft",motionSaved:"Draft saved. Preview and confirm again before enabling.",motionLoad:"Load selected",motionLoaded:"Loaded. Imported files are not automatically saved or enabled. Review and save a draft.",motionChoose:"Choose a saved motion\u2026",motionDraft:"Draft / disabled",motionEnabled:"Confirmed and enabled",motionPreview:"Preview current motion",motionPreviewHelp:"Using the same player as the avatar. Check handshape, direction, collisions and meaning. Save again after edits.",motionEnable:"Confirm for translation",motionDisable:"Disable selected",motionConfirm:"I have previewed the entire motion and checked its handshape, direction, collisions and meaning. This is my confirmation, not professional sign-language certification. Enable it?",motionEnabledHelp:"Enabled. Open avatars reload automatically; newly matched text will use this motion.",motionDisabledHelp:"Disabled; draft retained. Queued custom motions are cancelled in open avatars.",motionRefresh:"Refresh list",motionExport:"Download unified JSON",motionExportCode:"Export code (no save)",motionImport:"Import motion JSON",motionImportFormat:"Import format and units",motionFormat:"Unified \xB7 radians / REST delta",motionLegacyEditor:"Legacy editor delta \xB7 degrees (pose object only)",motionLegacyRecorder:"Legacy recorder frames.pose \xB7 degrees",motionLegacyAbsolute:"Legacy editor absolute rotation \xB7 radians",motionMigrate:"Migrate this page's old library",motionLegacyConfirm:"Legacy data has no rig binding. Continue only if it came from the current model with the selected format and units. Review each converted draft. Original local data will be retained. Continue?",motionMigrated:"Migrated {count} drafts; originals retained, none enabled. Repeating creates copies.",motionIgnored:"Skipped {count} damaged or rig-incompatible entries; original data retained.",motionFailure:"Not completed: {detail}",motionInvalidData:"Invalid motion format or parameters: {detail}",motionModelNotReady:"The model is not ready.",motionRigMismatch:"Skeleton or REST pose mismatch. Motion rejected.",motionStorageUnavailable:"Shared storage unavailable. Open this tool from the extension panel.",motionSelectFirst:"Save or select a motion first.",motionSaveFirst:"Motion changed. Save a draft and preview again before enabling.",motionPreviewFirst:"Preview this motion before confirming.",motionAliasConflict:"Empty text or alias conflicts with an enabled/built-in sign: {detail}. Choose a distinct phrase.",motionFileTooLarge:"File or entry count too large (2 MiB per file).",motionEditorSingleFrame:"The editor handles single poses. Open multi-frame clips in the recorder to avoid losing frames.",motionFrameLimit:"240-frame limit reached. Recording stopped.",motionFrameDuration:"Keyframe duration (seconds, 0.05\u201310)",motionUpdateFrame:"Update selected frame",motionHelpRig:"Godette uses standard Humanoid bone mappings and the available finger chains. The editor, recorder and floating avatar share one profile and REST pose.",motionHelpAxes:"X/Y/Z are bone-local axes, not fixed world directions. Exports use REST-relative radians; recorder bone sliders show absolute local radians. Do not assume the same axis direction for every bone.",motionHelpCreate:"Use the editor for single poses and the recorder for clips. Enter a name, matching text and tags, then save a draft. Leave matching text empty for pose material. Custom aliases cannot override built-in or enabled aliases.",motionHelpReview:"Save draft \u2192 Preview current motion \u2192 Check handshape, direction, collisions and meaning \u2192 Confirm for translation. Test the matching text from the control panel. Confirmation is not professional sign-language certification.",motionHelpFrames:"Select a timeline frame, edit bones and duration, then click Update selected frame. Add keyframes for new poses. Each frame is 0.05\u201310 seconds; up to 240 frames and 120 seconds total. Automatic recording samples every 0.3 seconds.",motionHelpUpdates:"Both tools and the avatar share local storage within one extension ID and browser profile. Enabling or disabling refreshes the avatar and cancels old playback queues. Saving again revokes approval. New copy keeps poses without overwriting the original motion.",motionHelpBackup:"Download unified JSON for backups; exporting does not save or enable. Imports are new draft copies requiring saving, preview and confirmation. Open multi-frame files in the recorder, not the single-pose editor. Back up before uninstalling or changing extension IDs.",motionHelpLegacy:"Migrating the old page library retains sb_gestures; repeating migration creates copies. Explicitly select degrees or absolute radians for old JSON files. Units are never guessed and code is never executed. Legacy data must use the current model and requires manual review.",motionHelpBinding:"Files are limited to 2 MiB. Incompatible bone/REST bindings, unknown bones and invalid values are rejected. This binding is not a full GLB or skin-weight fingerprint. Open tools from the extension popup; standalone localhost pages cannot share this storage. Reload the extension and reopen old tool tabs after updating.",motionHelpCollision:"Identify the exact motion and frame. Inspect elbows and wrists from front and side views in the tools. Edit and review only that motion; do not globally reverse axes or increase angles.",motionHelpCoverage:"Inspect matched motionIds and unmatched text. Unknown input does not interrupt current playback.",motionHelpCatalog:"Inspect enabled custom motion and invalid entry counts. Drafts do not participate in translation.",motionDurationInvalid:"Keyframe duration must be 0.05\u201310 seconds.",motionLoadingFailed:"Model loading failed: {detail}",name:"English",title:"SignBridge \u2014 Sign Language Translation",description:"Real-time video speech to sign language translation via 3D avatar",settings:"Settings",avatar:"Avatar",language:"Language",sourceLanguage:"Video Language",targetSignLanguage:"Sign Language",avatarStyle:"Avatar Style",avatarSize:"Avatar Size",avatarPosition:"Avatar Position",positionBottomRight:"Bottom Right",positionBottomLeft:"Bottom Left",positionTopRight:"Top Right",positionTopLeft:"Top Left",enableAutoDetect:"Auto-detect Video",enableSubtitles:"Show Subtitles",voiceVolume:"Voice Volume",speed:"Sign Speed",about:"About",start:"Start Translation",stop:"Stop Translation",loading:"Loading...",noVideo:"No video detected",error:"Error",errorNoVideo:"No video found on this page",ready:"Ready",translating:"Translating...",unavailable:"Unavailable on this page",inputPlaceholder:"Enter text for the avatar to sign...",send:"Send",sent:"Sent",audioOff:"Video audio: Off",audioOn:"Video audio: On",audioStopped:"Stopped",audioListening:"Recognizing...",audioStarting:"Capturing audio...",audioUnavailable:"Audio capture is unavailable on this page",audioCaptureFailed:"Audio capture failed",audioCloudKeyRequired:"Configure the cloud API key first",audioPermissionRequired:"Save ASR settings and allow the service origin",audioLocalUnavailable:"Deploy local Whisper first",asrSettings:"Audio recognition settings",asrTitle:"Video audio recognition",asrPurpose:"Choose local Whisper or cloud ASR to convert video audio into sign language motion.",asrProvider:"Recognition provider",asrLocal:"Local Whisper",asrCloud:"Cloud ASR",asrLocalSettings:"Local Whisper settings",asrLocalPrivacy:"The model and audio stay inside the extension. Video audio is not uploaded to an ASR service.",asrDeployLocal:"Deploy local Whisper",asrEndpoint:"Service endpoint",asrModel:"Model",asrModelTiny:"tiny (fastest, about 75 MB)",asrModelBase:"base (balanced, about 150 MB)",asrModelSmall:"small (more accurate, about 500 MB)",asrDeployHint:"Downloads and caches the model automatically. Python and a local service are not required.",asrDeployRequired:"The selected model is not deployed.",asrRequestingModelPermission:"Requesting model download access...",asrDeploying:"Downloading and initializing model: {progress}%",asrDeployReady:"Local model {model} is ready.",asrDeployFailed:"Local model deployment failed",asrCloudSettings:"Cloud ASR settings",asrCloudPrivacy:"Video audio chunks are sent to the configured service. Review its privacy and billing terms.",asrApiKey:"API Key",asrCommonSettings:"Common settings",asrLanguage:"Recognition language",asrChunkSeconds:"Audio chunk",asrTest:"Test connection",asrSave:"Save settings",asrPermissionDenied:"Network access to this service was not granted.",asrSaved:"Settings saved.",asrInvalidConfig:"Invalid settings: use HTTPS remotely or HTTP on loopback only. URL credentials are not allowed.",asrTesting:"Testing the recognition service...",asrTestPassed:"Connection test passed.",asrTestFailed:"Connection test failed",poseEditor:"Pose editor",recorder:"Recorder",help:"Help",tagline:"Accessible information",auto:"Auto detect",simplifiedChinese:"Chinese (Mandarin)",footer:"SignBridge \u2014 Making Information Accessible",signLanguageTypes:{csl:"Chinese Sign Language (CSL)",asl:"American Sign Language (ASL)",bsl:"British Sign Language (BSL)",jsl:"Japanese Sign Language (JSL)",ksl:"Korean Sign Language (KSL)",tsl:"Taiwan Sign Language (TSL)"},avatarStyles:{default:"Default",friendly:"Friendly",professional:"Professional",anime:"Anime Style"},voiceVolumeLevels:{low:"Low (video only)",medium:"Medium (video + sign)",high:"High (sign only)"}},ja:{...jh,...tu,...Ea,...Jh,...Aa,...Xh,modelDemo:Ca,workbenchServiceHandoff:"\u610F\u5473\u5206\u6790\u306F\u30ED\u30FC\u30AB\u30EB\u30B5\u30FC\u30D3\u30B9\u3067\u5B9F\u884C\u3057\u307E\u3059\u3002\u30DC\u30BF\u30F3\u3067\u8D77\u52D5\u72B6\u614B\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u30DA\u30FC\u30B8\u3092\u958B\u304D\u307E\u3059\u3002\u79FB\u52D5\u6642\u306B\u53E3\u4EE4\u3084\u5165\u529B\u6587\u306F\u9001\u308A\u307E\u305B\u3093\u3002",privateServiceUnavailableStatus:"\u30ED\u30FC\u30AB\u30EB\u610F\u5473\u5206\u6790\u30B5\u30FC\u30D3\u30B9\u304C\u8D77\u52D5\u3057\u3066\u3044\u307E\u305B\u3093\u3002\u3053\u306E\u30DA\u30FC\u30B8\u304B\u3089\u79FB\u52D5\u3057\u3066\u3044\u307E\u305B\u3093\u3002",privateServiceUnavailable:"\u30ED\u30FC\u30AB\u30EB\u610F\u5473\u5206\u6790\u30B5\u30FC\u30D3\u30B9\u3092\u78BA\u8A8D\u3067\u304D\u307E\u305B\u3093\u3002SignBridge \u30EA\u30DD\u30B8\u30C8\u30EA\u306E\u30EB\u30FC\u30C8\u3067\u30BF\u30FC\u30DF\u30CA\u30EB\u3092\u958B\u304D\u3001\u6B21\u306E\u30B3\u30DE\u30F3\u30C9\u3092\u5B9F\u884C\u3057\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",privateServiceStartFromRoot:"\u8D77\u52D5\u30B3\u30DE\u30F3\u30C9\uFF08\u30EA\u30DD\u30B8\u30C8\u30EA\u306E\u30EB\u30FC\u30C8\u3067\u5B9F\u884C\uFF09\uFF1A",privateServiceCommand:".venv-sign-data/bin/python signbridge/src/tools/sign-private-serve.py --model local-data/csl-understanding-20261017-rLaeiN/learned-roles-v3 --client local-data/existing-resources-optimization-20261019-v1/thin-client-v1.0.5 --port 8770 --scope-experiment --unit-candidates local-data/existing-resources-optimization-20261019-v1/unit-candidates-final/candidates.json",batchTitle:"\u4ECA\u56DE\u306E\u8A9E\u5F59\u8FFD\u52A0\u30EA\u30B9\u30C8 \xB7 \u6700\u5927 8 \u4EF6",batchManual:"\u8A9E\u53E5\u3092\u624B\u52D5\u3067\u8FFD\u52A0\uFF08\u4EFB\u610F\u30FB\u5206\u5272\u306E\u8AA4\u308A\u3092\u56DE\u907F\uFF09",batchInvalidWord:"\u7A7A\u767D\u3084\u8A18\u53F7\u3060\u3051\u3067\u306F\u306A\u3044\u30011\uFF5E100 \u6587\u5B57\u306E\u8A9E\u53E5\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchIntro:"\u5206\u6790\u7D50\u679C\u304B\u3089\u983B\u51FA\u306E\u672A\u5BFE\u5FDC\u8A9E\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u300C\u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C\u300D\u3067\u78BA\u8A8D\u3057\u3066\u304B\u3089\u3001\u7DE8\u96C6\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u3067\u660E\u793A\u7684\u306B\u6709\u52B9\u5316\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5B8C\u5168\u4E00\u81F4\u306F\u30C7\u30FC\u30BF\u306E\u5B58\u5728\u3092\u793A\u3059\u3060\u3051\u3067\u3001\u624B\u8A71\u306E\u6B63\u78BA\u3055\u3092\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002\u3053\u306E\u30EA\u30B9\u30C8\u306F\u52D5\u4F5C\u306E\u751F\u6210\u30FB\u5909\u66F4\u30FB\u6709\u52B9\u5316\u3092\u884C\u3044\u307E\u305B\u3093\u3002",batchAdd:"\u4ECA\u56DE\u306E\u30EA\u30B9\u30C8\u306B\u8FFD\u52A0",batchRefresh:"\u5BFE\u5FDC\u72B6\u6CC1\u3092\u66F4\u65B0",batchExport:"\u9032\u6357 JSON \u3092\u4FDD\u5B58",batchClear:"\u4ECA\u56DE\u306E\u30EA\u30B9\u30C8\u3092\u6D88\u53BB",batchClearConfirm:"\u30EA\u30B9\u30C8\u3060\u3051\u3092\u6D88\u53BB\u3057\u307E\u3059\u304B\uFF1F\u52D5\u4F5C\u3068\u6BD4\u8F03\u57FA\u6E96\u306F\u524A\u9664\u3055\u308C\u307E\u305B\u3093\u3002",batchRemove:"\u30EA\u30B9\u30C8\u304B\u3089\u5916\u3059",batchState:"\u5B9F\u969B\u306E\u5BFE\u5FDC\u72B6\u6CC1 / \u52D5\u4F5C ID",batchLoading:"\u73FE\u5728\u306E\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u4E2D\u2026",batchEmpty:"\u30EA\u30B9\u30C8\u306F\u7A7A\u3067\u3059\u3002\u7D20\u6750\u3092\u5206\u6790\u3057\u3001\u672A\u5BFE\u5FDC\u8A9E\u3092\u8FFD\u52A0\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchMissing:"\u5236\u4F5C\u5F85\u3061 \xB7 \u5B8C\u5168\u4E00\u81F4\u306A\u3057",batchDraft:"\u5019\u88DC\u3092\u4FDD\u5B58\u6E08\u307F \xB7 \u672A\u6709\u52B9\u5316\u307E\u305F\u306F\u5B8C\u5168\u4E00\u81F4\u306A\u3057",batchMatched:"\u5B8C\u5168\u4E00\u81F4\u3042\u308A \xB7 \u624B\u8A71\u306E\u4EBA\u306B\u3088\u308B\u78BA\u8A8D\u304C\u5FC5\u8981",batchUnverified:"\u672A\u691C\u8A3C\u3067\u3059\u3002\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044",batchSummary:"\u4ECA\u56DE {count}/{max} \u4EF6 \xB7 \u5B8C\u5168\u4E00\u81F4 {matched} \u4EF6 \xB7 \u7121\u52B9\u306A\u8A18\u9332 {invalid} \u4EF6\u3002\u52D5\u4F5C\u306E\u5909\u66F4\u6642\u306B\u518D\u78BA\u8A8D\u3057\u307E\u3059\u3002",batchPrivacy:"\u660E\u793A\u7684\u306B\u8FFD\u52A0\u3057\u305F\u8A9E\u3060\u3051\u3092\u62E1\u5F35\u6A5F\u80FD\u5185\u306B\u4FDD\u5B58\u3057\u3001\u518D\u8AAD\u307F\u8FBC\u307F\u5F8C\u3082\u4FDD\u6301\u3057\u307E\u3059\u3002\u539F\u6587\u30FB\u4F8B\u6587\u306F\u4FDD\u5B58\u3082\u9001\u4FE1\u3082\u3057\u307E\u305B\u3093\u3002\u30EA\u30B9\u30C8\u306F\u52D5\u4F5C\u30D1\u30C3\u30AF\u306B\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u9032\u6357\u30D5\u30A1\u30A4\u30EB\u306B\u306F\u9078\u629E\u8A9E\u3068\u52D5\u4F5C ID \u304C\u5165\u308B\u305F\u3081\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchFailure:"\u8A9E\u5F59\u30EA\u30B9\u30C8\u306E\u64CD\u4F5C\u306B\u5931\u6557\uFF1A{detail}",batchFull:"\u6700\u5927 8 \u4EF6\u306B\u9054\u3057\u307E\u3057\u305F\u3002\u4E00\u90E8\u3092\u5B8C\u4E86\u307E\u305F\u306F\u524A\u9664\u3057\u3066\u304F\u3060\u3055\u3044\u3002",batchInvalid:"\u30EA\u30B9\u30C8\u306E\u30C7\u30FC\u30BF\u304C\u7121\u52B9\u3067\u3059\u3002\u5143\u306E\u8A18\u9332\u306F\u7DAD\u6301\u3055\u308C\u307E\u3059\u3002\u660E\u793A\u7684\u306B\u6D88\u53BB\u3057\u3066\u518D\u4F5C\u6210\u3067\u304D\u307E\u3059\u3002",batchLockUnavailable:"\u30DA\u30FC\u30B8\u9593\u66F8\u304D\u8FBC\u307F\u30ED\u30C3\u30AF\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u5909\u66F4\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u62E1\u5F35\u6A5F\u80FD\u30D1\u30CD\u30EB\u304B\u3089\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",reviewTitle:"\u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C",reviewIntro:"\u4FDD\u5B58\u6E08\u307F\u52D5\u4F5C\u3092\u518D\u751F\u3057\u3001\u6B63\u9762\u30FB\u53F3\u5074\u30FB\u5DE6\u5074\u306E\u56FA\u5B9A\u753B\u50CF\u3092\u624B\u52D5\u78BA\u8A8D\u6E08\u307F\u306E\u57FA\u6E96\u3068\u6BD4\u8F03\u3057\u307E\u3059\u3002\u9AA8\u683C\u3084\u7FFB\u8A33\u306E\u6709\u52B9\u5316\u72B6\u614B\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",reviewLimits:"\u4E00\u5EA6\u306B8\u52D5\u4F5C\u307E\u3067\u3001\u5404\u52D5\u4F5C\u306F\u5148\u982D\u3068\u672B\u5C3E\u3092\u542B\u3080\u6700\u592712\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u3092\u62BD\u51FA\u3057\u307E\u3059\u3002\u753B\u50CF\u306F\u76EE\u6A19\u59FF\u52E2\u306E\u307F\u3067\u3001\u5168\u9077\u79FB\u30FB\u885D\u7A81\u30FB\u5B57\u5E55\u6587\u306E\u518D\u751F\u30FB\u624B\u8A71\u306E\u610F\u5473\u306F\u691C\u8A3C\u3067\u304D\u307E\u305B\u3093\u3002\u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002\u5185\u8535\u4E00\u89A7\u306FSIGNS\u306E\u307F\u3067\u3001CHARS\u306F\u542B\u307F\u307E\u305B\u3093\u3002",reviewHelp:"\u30D1\u30CD\u30EB \u2192 \u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C\u3002\u52D5\u4F5C\u3092\u9078\u3073\u518D\u751F\u307E\u305F\u306F3\u65B9\u5411\u64AE\u5F71\u3092\u884C\u3044\u3001\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u3081\u308A\u8FBC\u307F\u3092\u78BA\u8A8D\u3057\u3066\u57FA\u6E96\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002\u6B21\u56DE\u306E\u753B\u50CF\u3092\u4E26\u3079\u3066\u6BD4\u8F03\u3067\u304D\u307E\u3059\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u306E\u5909\u66F4\u306F\u518D\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3001\u30E2\u30C7\u30EB\u30FB\u30D6\u30E9\u30A6\u30B6\u30FB\u63CF\u753B\u74B0\u5883\u304C\u7570\u306A\u308B\u5834\u5408\u306F\u6570\u5024\u6BD4\u8F03\u3057\u307E\u305B\u3093\u3002\u57FA\u6E96\u4FDD\u5B58\u306F\u624B\u8A71\u306E\u6B63\u3057\u3055\u3092\u4FDD\u8A3C\u305B\u305A\u3001\u4E0B\u66F8\u304D\u3084\u6709\u52B9\u5316\u72B6\u614B\u3082\u5909\u3048\u307E\u305B\u3093\u3002",reviewStorageHelp:"\u57FA\u6E96\u753B\u50CF\u306F\u62E1\u5F35\u6A5F\u80FD\u306EIndexedDB\u306B\u4FDD\u5B58\u3055\u308C\u3001\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3068\u306F\u5225\u3067\u6700\u5927100\u4EF6 / 64 MiB\u3067\u3059\u3002\u52D5\u4F5C\u30D1\u30C3\u30AF\u306B\u306F\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u524A\u9664\u524D\u306BPNG\u3068JSON\u3092\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u57FA\u6E96\u306E\u518D\u53D6\u8FBC\u306F\u672A\u5BFE\u5FDC\uFF09\u3002\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u9001\u4FE1\u306F\u3042\u308A\u307E\u305B\u3093\u3002",reviewReload:"\u30E2\u30C7\u30EB\u518D\u8AAD\u8FBC / \u518D\u8A66\u884C",reviewSelect:"1 \xB7 \u52D5\u4F5C\u3092\u9078\u629E",reviewSearch:"\u540D\u524D\u30FBID\u30FB\u72B6\u614B\u3067\u691C\u7D22\uFF08\u9078\u629E\u306F\u7DAD\u6301\u3055\u308C\u307E\u3059\uFF09",reviewCatalogCount:"{total}\u4EF6 \xB7 \u9078\u629E{count}/{max} \xB7 \u7121\u52B9\u30EC\u30B3\u30FC\u30C9{invalid}\u4EF6",reviewPlay:"\u5168\u30D5\u30EC\u30FC\u30E0\u3092\u9806\u756A\u306B\u518D\u751F",reviewCapture:"\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u30923\u65B9\u5411\u304B\u3089\u64AE\u5F71",reviewStop:"\u505C\u6B62",reviewPreview:"\u56FA\u5B9A\u8996\u70B9\u30D7\u30EC\u30D3\u30E5\u30FC",reviewView:"\u518D\u751F\u8996\u70B9",reviewFront:"\u6B63\u9762",reviewRight:"\u4EBA\u7269\u306E\u53F3\u5074",reviewLeft:"\u4EBA\u7269\u306E\u5DE6\u5074",reviewPreviewHelp:"\u30D5\u30ED\u30FC\u30C6\u30A3\u30F3\u30B0\u8868\u793A\u306B\u306F\u5F71\u97FF\u3057\u307E\u305B\u3093\u3002\u5404\u518D\u751F\u306FREST\u304B\u3089\u958B\u59CB\u3057\u3001\u64AE\u5F71\u5F8C\u306F\u6B63\u9762\u306B\u623B\u308A\u307E\u3059\u3002",reviewResults:"2 \xB7 \u76EE\u8996\u78BA\u8A8D\u3068\u57FA\u6E96\u6BD4\u8F03",reviewExport:"JSON\u30EC\u30DD\u30FC\u30C8\u3092\u4FDD\u5B58",reviewBuiltin:"\u5185\u8535 \xB7 \u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981",reviewEnabled:"\u30AB\u30B9\u30BF\u30E0 \xB7 \u6709\u52B9",reviewDraft:"\u30AB\u30B9\u30BF\u30E0 \xB7 \u4E0B\u66F8\u304D",reviewLoading:"\u5B9F\u969B\u306E\u30E2\u30C7\u30EB\u30FB\u9AA8\u683C\u30FB\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u8AAD\u8FBC\u4E2D\u2026",reviewReady:"{total}\u52D5\u4F5C\u3092\u8AAD\u8FBC\u5B8C\u4E86\u3002\u9078\u629E\u3057\u3066\u518D\u751F\u307E\u305F\u306F\u64AE\u5F71\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewFailure:"\u691C\u8A3C\u5931\u6557\uFF1A{detail}",reviewCatalogChanged:"\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u308F\u3063\u305F\u305F\u3081\u7D50\u679C\u306F\u7121\u52B9\u3067\u3059\u3002\u9078\u629E\u3057\u76F4\u3057\u3066\u64AE\u5F71\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u65E2\u5B58\u306E\u57FA\u6E96\u306F\u81EA\u52D5\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002",reviewPlaying:"\u518D\u751F {index}/{total}\uFF1A{name}",reviewCapturing:"\u64AE\u5F71 {index}/{total}\uFF1A{name}",reviewFinished:"{count}\u52D5\u4F5C\u5B8C\u4E86\u3001\u69CB\u9020\u30A8\u30E9\u30FC{failures}\u4EF6\u3002\u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002",reviewCancelled:"\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u672A\u5B8C\u4E86\u306E\u64AE\u5F71\u7D50\u679C\u306F\u7834\u68C4\u3057\u3001\u57FA\u6E96\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",reviewDiagnostics:"{frames}\u30D5\u30EC\u30FC\u30E0 / {duration}\u79D2\u3001{bones}\u9AA8\u683C\u3002\u753B\u50CF\u306E\u884C\uFF1A{indices}\u3002\u672A\u64AE\u5F71{omitted}\u30D5\u30EC\u30FC\u30E0\u3002",reviewSheetOrder:"\u5404\u884C\u306F\u5DE6\u304B\u3089\u6B63\u9762 \u2192 \u4EBA\u7269\u306E\u53F3\u5074 \u2192 \u5DE6\u5074\u3002\u884C\u306F\u30D5\u30EC\u30FC\u30E0\u9806\u3067\u3059\u3002PNG\u3092\u4FDD\u5B58\u3057\u3066\u62E1\u5927\u78BA\u8A8D\u3067\u304D\u307E\u3059\u3002",reviewCurrent:"\u73FE\u5728\u306E\u753B\u50CF",reviewBaseline:"\u78BA\u8A8D\u6E08\u307F\u306E\u57FA\u6E96\u753B\u50CF",reviewNoBaseline:"\u57FA\u6E96\u672A\u4FDD\u5B58\u3002\u52D5\u4F5C\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewCompared:"\u57FA\u6E96\u65E5\u6642{date}\u3002RGB\u5DEE\u5206>16\u306E\u753B\u7D20\uFF1A{ratio}%\u3001\u5E73\u5747\u5DEE\u5206{mean}/255\u3002\u53C2\u8003\u5024\u3067\u3042\u308A\u624B\u8A71\u306E\u6B63\u3057\u3055\u3084\u885D\u7A81\u3092\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002",reviewMotionChanged:"\u52D5\u4F5C\u30C7\u30FC\u30BF\uFF08\u6642\u9593\u3084\u540D\u79F0\u3092\u542B\u3080\uFF09\u304C\u5909\u308F\u308A\u307E\u3057\u305F\u3002\u65E7\u57FA\u6E96\u306F\u4FDD\u6301\u3057\u3001\u6570\u5024\u6BD4\u8F03\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u518D\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewIncompatible:"\u30E2\u30C7\u30EB\u30FB\u9AA8\u683C\u30FB\u30D6\u30E9\u30A6\u30B6\u30FB\u63CF\u753B\u74B0\u5883\u304C\u7570\u306A\u308A\u307E\u3059\u3002\u6570\u5024\u6BD4\u8F03\u306F\u884C\u308F\u305A\u3001\u65E7\u753B\u50CF\u306F\u53C2\u8003\u7528\u3067\u3059\u3002",reviewUnavailable:"\u57FA\u6E96\u8AAD\u8FBC / \u6BD4\u8F03\u5931\u6557\uFF1A{detail}\u3002\u73FE\u5728\u306E\u753B\u50CF\u306F\u4FDD\u5B58\u53EF\u80FD\u3067\u3059\u3002\u57FA\u6E96\u4FDD\u5B58\u3067\u518D\u8A66\u884C\u3057\u307E\u3059\u3002",reviewSaveBaseline:"\u76EE\u8996\u57FA\u6E96\u3092\u4FDD\u5B58 / \u7F6E\u63DB",reviewDeleteBaseline:"\u3053\u306E\u57FA\u6E96\u3092\u524A\u9664",reviewDownloadImage:"\u73FE\u5728\u306EPNG\u3092\u4FDD\u5B58",reviewSaveConfirm:"\u300C{name}\u300D\u30923\u65B9\u5411\u304B\u3089\u78BA\u8A8D\u3057\u307E\u3057\u305F\u304B\uFF1F\u65E2\u5B58\u306E\u76EE\u8996\u57FA\u6E96\u3092\u7F6E\u63DB\u3057\u307E\u3059\u3002\u7FFB\u8A33\u306E\u6709\u52B9\u5316\u3084\u624B\u8A71\u306E\u6B63\u3057\u3055\u306E\u8A8D\u8A3C\u306F\u884C\u3044\u307E\u305B\u3093\u3002",reviewDeleteConfirm:"\u300C{name}\u300D\u306E\u76EE\u8996\u57FA\u6E96\u3092\u524A\u9664\u3057\u307E\u3059\u304B\uFF1F\u52D5\u4F5C\u81EA\u4F53\u306F\u524A\u9664\u3057\u307E\u305B\u3093\u3002",reviewSaved:"\u76EE\u8996\u57FA\u6E96\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u3068\u7FFB\u8A33\u72B6\u614B\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",reviewDeleted:"\u76EE\u8996\u57FA\u6E96\u3092\u524A\u9664\u3057\u307E\u3057\u305F\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",reviewStorageError:"\u57FA\u6E96\u30B9\u30C8\u30EC\u30FC\u30B8\u306B\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u307E\u305B\u3093\u3002\u7A7A\u304D\u5BB9\u91CF\u3092\u78BA\u8A8D\u3057\u3001\u62E1\u5F35\u6A5F\u80FD\u30D1\u30CD\u30EB\u304B\u3089\u958B\u304D\u76F4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewStorageFull:"\u57FA\u6E96\u306E\u4E0A\u9650\uFF08100\u4EF6 / 64 MiB\uFF09\u3067\u3059\u3002\u753B\u50CF\u3092\u4FDD\u5B58\u3057\u3066\u4E0D\u8981\u306A\u57FA\u6E96\u3092\u524A\u9664\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewBaselineChanged:"\u5225\u30DA\u30FC\u30B8\u3067\u57FA\u6E96\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F\u3002\u4E0A\u66F8\u304D\u305B\u305A\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u518D\u64AE\u5F71\u3057\u3066\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewModelError:"\u30E2\u30C7\u30EB\u8AAD\u8FBC\u5931\u6557\u307E\u305F\u306F\u5BF8\u6CD5\u304C\u7121\u52B9\u3067\u3059\u3002\u518D\u30D3\u30EB\u30C9\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewMissingBones:"\u624B\u8A71\u306B\u5FC5\u8981\u306A\u9AA8\u683C\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u308B\u305F\u3081\u505C\u6B62\u3057\u307E\u3057\u305F\u3002",reviewRenderError:"\u63CF\u753B\u5931\u6557\u307E\u305F\u306FWebGL\u63A5\u7D9A\u304C\u5931\u308F\u308C\u307E\u3057\u305F\u3002\u505C\u6B62\u3057\u3066\u518D\u8AAD\u8FBC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",reviewInvalidSamples:"\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u62BD\u51FA\u8A2D\u5B9A\u304C\u7121\u52B9\u3067\u3059\u3002",reviewImageMismatch:"\u57FA\u6E96\u753B\u50CF\u304C\u7834\u640D\u3057\u3066\u3044\u308B\u304B\u5BF8\u6CD5\u304C\u7570\u306A\u308B\u305F\u3081\u6BD4\u8F03\u3067\u304D\u307E\u305B\u3093\u3002",motionPackTitle:"\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u306E\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7 / \u4E00\u62EC\u53D6\u8FBC",motionPackHelp:"\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u306B\u5BFE\u5FDC\u3059\u308B\u4FDD\u5B58\u6E08\u307F\u30AB\u30B9\u30BF\u30E0\u52D5\u4F5C\u3092\u3059\u3079\u3066\u66F8\u304D\u51FA\u3057\u307E\u3059\u3002\u672A\u4FDD\u5B58\u306E\u7DE8\u96C6\u3084\u5185\u8535\u8F9E\u66F8\u306F\u542B\u307F\u307E\u305B\u3093\u3002\u30D5\u30A1\u30A4\u30EB\u9078\u629E\u306F\u4E8B\u524D\u78BA\u8A8D\u306E\u307F\u3067\u3059\u3002\u540C\u3058 ID\u30FB\u5185\u5BB9\u306F\u30B9\u30AD\u30C3\u30D7\u3057\u3001\u5185\u5BB9\u304C\u7570\u306A\u308B\u5834\u5408\u306F\u4E00\u62EC\u53D6\u8FBC\u5168\u4F53\u3092\u505C\u6B62\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u52D5\u4F5C\u306F\u4E0B\u66F8\u304D\u3068\u3057\u3066\u8FFD\u52A0\u3057\u3001\u500B\u5225\u306B\u8AAD\u8FBC\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackPrivacy:"\u30D5\u30A1\u30A4\u30EB\u306B\u306F\u540D\u524D\u3001\u7167\u5408\u6587\u5B57\u5217\u3001\u30BF\u30B0\u3001\u9AA8\u683C\u60C5\u5831\u3001\u30D5\u30EC\u30FC\u30E0\u3001\u66F8\u51FA\u6642\u306E\u6709\u52B9\u30D5\u30E9\u30B0\u306E\u307F\u542B\u307E\u308C\u3001\u30AD\u30FC\u3084\u5B57\u5E55\u306F\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u540D\u524D\u3084\u30BF\u30B0\u306E\u500B\u4EBA\u60C5\u5831\u3092\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u627F\u8A8D\u8A18\u9332\u306F\u5F15\u304D\u7D99\u304C\u305A\u3001\u30D5\u30A1\u30A4\u30EB\u3082\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u305B\u3093\u3002",motionPackExport:"\u4FDD\u5B58\u6E08\u307F\u306E\u5168\u52D5\u4F5C\u3092\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7",motionPackFile:"\u52D5\u4F5C\u30D1\u30C3\u30AF JSON \u3092\u9078\u629E\uFF08\u5358\u4E00\u52D5\u4F5C\u30D5\u30A1\u30A4\u30EB\u3067\u306F\u3042\u308A\u307E\u305B\u3093\uFF09",motionPackLimits:"1 \u30D1\u30C3\u30AF\u6700\u5927 500 \u52D5\u4F5C\u30FB8 MiB\u30011 \u52D5\u4F5C 2 MiB\u3002\u9AA8\u683C\u3068 REST \u306E\u4E00\u81F4\u304C\u5FC5\u8981\u3067\u3059\u3002",motionPackInspect:"\u518D\u5EA6\u4E8B\u524D\u78BA\u8A8D",motionPackImport:"\u65B0\u898F\u4E0B\u66F8\u304D\u3068\u3057\u3066\u53D6\u8FBC\u3092\u78BA\u8A8D",motionPackClear:"\u53D6\u8FBC\u5F85\u3061\u30D5\u30A1\u30A4\u30EB\u3092\u30AD\u30E3\u30F3\u30BB\u30EB",motionPackSummary:"\u4E8B\u524D\u78BA\u8A8D\uFF1A\u65B0\u898F {new}\u3001\u65E2\u5B58 {existing}\u3001ID \u7AF6\u5408 {conflict}\u3002\u307E\u3060\u4FDD\u5B58\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionPackName:"\u52D5\u4F5C / ID",motionPackState:"\u51E6\u7406",motionPackWarnings:"\u78BA\u8A8D\u4E8B\u9805",motionPackNew:"\u65B0\u898F\u4E0B\u66F8\u304D",motionPackExisting:"\u540C\u4E00\u5185\u5BB9\u30FB\u30B9\u30AD\u30C3\u30D7",motionPackIdConflict:"ID \u7AF6\u5408\u30FB\u4E0A\u66F8\u304D\u7981\u6B62",motionPackWasEnabled:"\u30D1\u30C3\u30AF\u4E0A\u3067\u306F\u4EE5\u524D\u6709\u52B9\u3002\u305F\u3060\u3057\u51FA\u6240\u306E\u60C5\u5831\u3067\u3042\u308A\u3001\u4FE1\u983C\u3055\u308C\u305F\u627F\u8A8D\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",motionPackAliases:"\u7167\u5408\u6587\u5B57\u5217\u304C\u91CD\u8907\u3059\u308B\u53EF\u80FD\u6027\uFF1A{aliases}\u3002\u4E0B\u66F8\u304D\u4FDD\u5B58\u306F\u53EF\u80FD\u3067\u3059\u304C\u3001\u6709\u52B9\u5316\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u7121\u52B9\u306A\u52D5\u4F5C\u3082\u542B\u3080\uFF09\u3002",motionPackMaterial:"\u7167\u5408\u6587\u5B57\u5217\u306A\u3057\u3002\u30DD\u30FC\u30BA\u7D20\u6750\u5C02\u7528\u3067\u3001\u7FFB\u8A33\u306B\u306F\u6709\u52B9\u5316\u3067\u304D\u307E\u305B\u3093\u3002",motionPackReady:"\u4E8B\u524D\u78BA\u8A8D\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002\u65B0\u898F\u4E0B\u66F8\u304D\u306E\u307F\u8FFD\u52A0\u3057\u3001\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u3068\u65E2\u5B58\u52D5\u4F5C\u306E\u627F\u8A8D\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",motionPackChecking:"\u9AA8\u683C\u3068\u30ED\u30FC\u30AB\u30EB\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u4E2D\u2026",motionPackCleared:"\u30AD\u30E3\u30F3\u30BB\u30EB\u3057\u307E\u3057\u305F\u3002\u30E9\u30A4\u30D6\u30E9\u30EA\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionPackConfirm:"{count} \u4EF6\u306E\u4E0B\u66F8\u304D\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002\u4E0A\u66F8\u304D\u3084\u81EA\u52D5\u6709\u52B9\u5316\u306F\u3057\u307E\u305B\u3093\u3002\u5229\u7528\u6A29\u9650\u3092\u78BA\u8A8D\u3057\u3001\u53D6\u8FBC\u5F8C\u306B\u624B\u5F62\u30FB\u5411\u304D\u30FB\u610F\u5473\u3092\u500B\u5225\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F",motionPackImported:"\u4E0B\u66F8\u304D {imported} \u4EF6\u3092\u8FFD\u52A0\u3001\u65E2\u5B58 {skipped} \u4EF6\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3057\u305F\u3002\u4E00\u89A7\u304B\u3089\u500B\u5225\u306B\u8AAD\u8FBC\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackExported:"\u4FDD\u5B58\u6E08\u307F {count} \u4EF6\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3092\u958B\u59CB\u3057\u307E\u3057\u305F\u3002\u7D50\u679C\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u672A\u4FDD\u5B58\u306E\u7DE8\u96C6\u306F\u542B\u307F\u307E\u305B\u3093\u3002",motionPackInvalid:"\u6709\u52B9\u306A v1 \u52D5\u4F5C\u30D1\u30C3\u30AF JSON \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u5358\u4E00\u52D5\u4F5C\u306B\u306F\u4E0A\u306E\u52D5\u4F5C JSON \u53D6\u8FBC\u3092\u4F7F\u3063\u3066\u304F\u3060\u3055\u3044\u3002",motionPackEmpty:"\u30D1\u30C3\u30AF\u304C\u7A7A\u304B\u3001\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3067\u304D\u308B\u4FDD\u5B58\u6E08\u307F\u52D5\u4F5C\u304C\u3042\u308A\u307E\u305B\u3093\u3002",motionPackTooLarge:"\u4E0A\u9650\u8D85\u904E\uFF1A1 \u30D1\u30C3\u30AF 8 MiB / 500 \u52D5\u4F5C\u30011 \u52D5\u4F5C 2 MiB\u3002\u4FDD\u5B58\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionPackDuplicateId:"\u30D1\u30C3\u30AF\u5185\u306B\u91CD\u8907 ID \u304C\u3042\u308A\u3001\u52D5\u4F5C\u3092\u7279\u5B9A\u3067\u304D\u306A\u3044\u305F\u3081\u53D6\u8FBC\u3092\u62D2\u5426\u3057\u307E\u3057\u305F\u3002",motionPackInvalidStored:"\u30ED\u30FC\u30AB\u30EB\u8A18\u9332\u304C\u7834\u640D\u3057\u3066\u3044\u308B\u304B\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u306B\u975E\u5BFE\u5FDC\u3067\u3059\u3002\u4E0D\u5B8C\u5168\u306A\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u306F\u4F5C\u6210\u305B\u305A\u3001\u5143\u30C7\u30FC\u30BF\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002\u5148\u306B\u8A72\u5F53\u8A18\u9332\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackConflict:"\u540C\u3058 ID \u306E\u30ED\u30FC\u30AB\u30EB\u5185\u5BB9\u304C\u7570\u306A\u308B\u304B\u7834\u640D\u3057\u3066\u3044\u307E\u3059\u3002\u5168\u4F53\u306E\u53D6\u8FBC\u3092\u505C\u6B62\u3057\u3001\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002\u5FC5\u8981\u306A\u3089\u5358\u4E00\u52D5\u4F5C\u306E\u53D6\u8FBC\u3067\u30B3\u30D4\u30FC\u3092\u4F5C\u6210\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackStale:"\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u66F4\u3055\u308C\u3001\u4E8B\u524D\u78BA\u8A8D\u304C\u5931\u52B9\u3057\u307E\u3057\u305F\u3002\u518D\u5EA6\u4E8B\u524D\u78BA\u8A8D\u3057\u3001\u4E00\u89A7\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u53D6\u308A\u8FBC\u3093\u3067\u304F\u3060\u3055\u3044\u3002",motionPackLockUnavailable:"\u30DA\u30FC\u30B8\u9593\u306E\u66F8\u8FBC\u30ED\u30C3\u30AF\u304C\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u4E00\u62EC\u53D6\u8FBC\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u30C4\u30FC\u30EB\u3092\u958B\u304D\u76F4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionPackEncoding:"\u6709\u52B9\u306A UTF-8 JSON \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6587\u5B57\u30B3\u30FC\u30C9\u3092\u5909\u63DB\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageTitle:"\u8A9E\u5F59\u30AB\u30D0\u30FC\u7387\u5206\u6790",coverageHelpWorkflow:"\u30D1\u30CD\u30EB\u304B\u3089\u8A9E\u5F59\u30AB\u30D0\u30FC\u7387\u5206\u6790\u3092\u958B\u304D\u3001\u6587\u7AE0\u307E\u305F\u306F UTF-8 TXT / SRT / VTT \u3092\u5165\u529B\u3057\u3066\u672A\u5BFE\u5FDC\u8A9E\u306E\u983B\u5EA6\u3068\u6587\u8108\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u7DE8\u96C6\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u306B\u306F\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u3060\u3051\u304C\u5165\u529B\u3055\u308C\u307E\u3059\u3002\u52D5\u4F5C\u306E\u4F5C\u6210\u30FB\u78BA\u8A8D\u30FB\u6709\u52B9\u5316\u5F8C\u306B\u518D\u5206\u6790\u3057\u3001\u53CD\u6620\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageIntro:"\u5B9F\u969B\u306E\u6587\u7AE0\u304B\u3089\u4E0D\u8DB3\u3059\u308B\u8A9E\u5F59\u3092\u63A2\u3057\u3001\u52D5\u4F5C\u3092\u4F5C\u6210\u30FB\u78BA\u8A8D\u3057\u307E\u3059\u3002\u624B\u8A71\u306E\u81EA\u52D5\u751F\u6210\u3084\u65E2\u5B58\u30DD\u30FC\u30BA\u306E\u5909\u66F4\u306F\u884C\u3044\u307E\u305B\u3093\u3002",coverageInput:"1 \xB7 \u5206\u6790\u3059\u308B\u7D20\u6750",coverageTextLabel:"\u6587\u7AE0\u3092\u8CBC\u308A\u4ED8\u3051\uFF081\u884C1\u533A\u9593\uFF09\u3001\u307E\u305F\u306F UTF-8 \u5B57\u5E55\u3092\u8AAD\u307F\u8FBC\u307F",coverageLimits:"\u4E0A\u9650\uFF1A\u30D5\u30A1\u30A4\u30EB256 KiB\u300150,000\u6587\u5B57\u30011,000\u533A\u9593\u30011\u533A\u95932,000\u6587\u5B57\u3002SRT / WebVTT \u306F\u5B57\u5E55\u5358\u4F4D\u3067\u5206\u6790\u3057\u307E\u3059\u3002",coverageFormat:"\u5F62\u5F0F",coveragePlainText:"\u30C6\u30AD\u30B9\u30C8 \xB7 1\u884C1\u533A\u9593",coverageImport:"\u30D5\u30A1\u30A4\u30EB\u3092\u8AAD\u307F\u8FBC\u3080",coverageAnalyze:"\u73FE\u5728\u306E\u8A9E\u5F59\u3092\u5206\u6790",coverageClear:"\u30AF\u30EA\u30A2",coverageResults:"2 \xB7 \u8FFD\u52A0\u3059\u308B\u8A9E\u5F59\u306E\u512A\u5148\u9806\u4F4D",coverageMetricHelp:"\u30AB\u30D0\u30FC\u7387 = \u4E00\u81F4\u3057\u305F\u5206\u5272\u8A9E\u6570 \xF7\uFF08\u4E00\u81F4 + \u672A\u5BFE\u5FDC\u306E\u5206\u5272\u8A9E\u6570\uFF09\u3002\u7701\u7565\u3057\u305F\u6A5F\u80FD\u8A9E\u30FB\u53E5\u8AAD\u70B9\u306F\u9664\u5916\u3057\u307E\u3059\u3002\u8F9E\u66F8\u306E\u30AB\u30D0\u30FC\u7387\u3067\u3042\u308A\u3001\u624B\u8A71\u306E\u6B63\u78BA\u3055\u30FB\u6587\u610F\u30FB\u518D\u751F\u5B8C\u4E86\u3092\u4FDD\u8A3C\u3059\u308B\u5024\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",coverageUnknownTitle:"\u672A\u5BFE\u5FDC\u306E\u8A9E \xB7 \u983B\u5EA6\u9806",coverageDraftHelp:"\u5206\u5272\u7D50\u679C\u3092\u6587\u8108\u3068\u7167\u5408\u3057\u3001\u53E5\u5168\u4F53\u304C\u5FC5\u8981\u304B\u5224\u65AD\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u30C4\u30FC\u30EB\u306B\u306F\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u306E\u307F\u5165\u529B\u3057\u307E\u3059\u3002\u81EA\u52D5\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u306F\u305B\u305A\u3001\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u304C\u305D\u306E\u8A9E\u306E\u6B63\u3057\u3044\u624B\u8A71\u3068\u306F\u9650\u308A\u307E\u305B\u3093\u3002",coverageWord:"\u672A\u5BFE\u5FDC\u306E\u8A9E",coverageFrequency:"\u56DE\u6570 / \u533A\u9593\u6570",coverageExamples:"\u4F8B\u6587\u306E\u533A\u9593\u756A\u53F7",coverageMake:"\u4F5C\u6210\u3068\u78BA\u8A8D",coverageDetailsTitle:"3 \xB7 \u533A\u9593\u3054\u3068\u306E\u4E00\u81F4\u7D50\u679C",coverageDisplayLimit:"\u672A\u5BFE\u5FDC\u8A9E\u306F100\u4EF6\u3001\u533A\u9593\u306F200\u4EF6\u307E\u3067\u8868\u793A\u3057\u307E\u3059\u3002\u96C6\u8A08\u306F\u5168\u5165\u529B\u304C\u5BFE\u8C61\u3067\u3059\u3002\u5168\u7D50\u679C\u306F\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3067\u304D\u307E\u3059\u3002",coverageIncludeText:"\u539F\u6587\u3068\u533A\u9593\u660E\u7D30\u3092\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306B\u542B\u3081\u308B\uFF08\u500B\u4EBA\u60C5\u5831\u306B\u6CE8\u610F\uFF09",coverageExport:"JSON \u30EC\u30DD\u30FC\u30C8\u3092\u51FA\u529B",coveragePrivacy:"\u5206\u6790\u306F\u30DA\u30FC\u30B8\u306E\u30E1\u30E2\u30EA\u5185\u306E\u307F\u3067\u884C\u3044\u3001\u9001\u4FE1\u30FB\u81EA\u52D5\u4FDD\u5B58\u3057\u307E\u305B\u3093\u3002\u9589\u3058\u308B\u3068\u7834\u68C4\u3055\u308C\u307E\u3059\u3002\u65E2\u5B9A\u306E\u51FA\u529B\u306F\u539F\u6587\u3092\u9664\u5916\u3057\u307E\u3059\u304C\u672A\u5BFE\u5FDC\u8A9E\u3092\u542B\u3080\u305F\u3081\u3001\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageSummary:"\u30AB\u30D0\u30FC\u7387 {ratio} \xB7 {segments} \u533A\u9593 \xB7 \u4E00\u81F4 {matched} / \u672A\u5BFE\u5FDC {unknown} / \u7701\u7565 {skipped}",coverageNoTokens:"\u5BFE\u8C61\u5916\uFF08\u7FFB\u8A33\u5BFE\u8C61\u8A9E\u306A\u3057\uFF09",coverageTruncation:"{count} \u533A\u9593\u304C1\u533A\u959312\u52D5\u4F5C\u306E\u518D\u751F\u4E0A\u9650\u306B\u9054\u3057\u3066\u3044\u307E\u3059\u3002\u4E00\u90E8\u306F\u518D\u751F\u3055\u308C\u306A\u3044\u53EF\u80FD\u6027\u304C\u3042\u308B\u305F\u3081\u3001\u6B8B\u308A\u306E\u6587\u7AE0\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageOccurrences:"{count} \u56DE / {segments} \u533A\u9593",coverageUniqueUnknown:"\u672A\u5BFE\u5FDC\u8A9E\u306F {count} \u7A2E\u985E\u3067\u3059\u3002\u9577\u3059\u304E\u308B\u8A9E\u306F\u5206\u5272\u3084\u6587\u8108\u3092\u518D\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageNoUnknown:"\u672A\u5BFE\u5FDC\u8A9E\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u624B\u8A71\u306E\u610F\u5473\u3068\u52D5\u4F5C\u306F\u4EBA\u306B\u3088\u308B\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002",coverageMatches:"\u4E00\u81F4\uFF1A{value}",coverageUnmatched:"\u672A\u5BFE\u5FDC\uFF1A{value}",coverageSkipped:"\u7701\u7565\uFF1A{value}",coverageRemaining:"\u518D\u751F\u4E0A\u9650\u4EE5\u964D\u306E\u6587\u7AE0\uFF1A{value}",coverageCatalog:"\u8A9E\u5F59\uFF1A\u5185\u8535 {signs} \u4EF6 / \u5225\u540D {aliases} \u4EF6 / \u6587\u5B57 {chars} \u4EF6\u3002\u6709\u52B9\u306A\u72EC\u81EA\u52D5\u4F5C {enabled}\u3001\u7121\u52B9 {drafts}\u3001\u4E0D\u6B63\u30FB\u975E\u4E92\u63DB {invalid}\uFF08\u5143\u30C7\u30FC\u30BF\u306F\u4FDD\u6301\uFF09\u3002",coverageReady:"\u8CBC\u308A\u4ED8\u3051\u30FB\u8AAD\u307F\u8FBC\u307F\u5F8C\u306B\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u521D\u56DE\u306F\u30E2\u30C7\u30EB\u3092\u8AAD\u307F\u8FBC\u307F\u3001\u72EC\u81EA\u52D5\u4F5C\u306E\u4E92\u63DB\u6027\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002",coverageLoading:"\u30E2\u30C7\u30EB\u3068\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u3057\u3001\u5206\u6790\u3057\u3066\u3044\u307E\u3059\u2026",coverageDone:"\u5206\u6790\u5B8C\u4E86\u3002\u4E0D\u8DB3\u3059\u308B\u52D5\u4F5C\u3092\u4F5C\u6210\u3057\u3001\u78BA\u8A8D\u30FB\u6709\u52B9\u5316\u3057\u3066\u304B\u3089\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageChanged:"\u7D20\u6750\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53E4\u3044\u30EC\u30DD\u30FC\u30C8\u306F\u51FA\u529B\u3067\u304D\u307E\u305B\u3093\u3002",coverageCatalogChanged:"\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53E4\u3044\u30EC\u30DD\u30FC\u30C8\u306F\u51FA\u529B\u3067\u304D\u307E\u305B\u3093\u3002",coverageImported:"\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86\u3002\u5206\u6790\u3092\u30AF\u30EA\u30C3\u30AF\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u81EA\u52D5\u518D\u751F\u30FB\u4FDD\u5B58\u306F\u3057\u307E\u305B\u3093\u3002",coverageFailure:"\u5206\u6790\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\uFF1A{detail}",coverageTooLarge:"\u5BB9\u91CF\u30FB\u533A\u9593\u6570\u30FB\u533A\u9593\u9577\u306E\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002\u5206\u5272\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageEmpty:"\u7A7A\u3067\u306A\u3044\u6587\u7AE0\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageInvalidFormat:"TXT\u3001SRT\u3001WebVTT \u306E\u307F\u5BFE\u5FDC\u3057\u3066\u3044\u307E\u3059\u3002\u6B63\u3057\u3044\u5F62\u5F0F\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageInvalidSubtitles:"\u5B57\u5E55\u5F62\u5F0F\u304C\u4E0D\u6B63\u3067\u3059\u3002\u7A7A\u884C\u3001\u6642\u523B\u3001\u958B\u59CB\u30FB\u7D42\u4E86\u9806\u5E8F\u3001WebVTT \u30D8\u30C3\u30C0\u30FC\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u6642\u523B\u884C\u3092\u672C\u6587\u3068\u3057\u3066\u96C6\u8A08\u3057\u307E\u305B\u3093\u3002",coverageEncoding:"UTF-8 \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6587\u5B57\u30B3\u30FC\u30C9\u3092\u5909\u63DB\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coverageModelError:"\u30E2\u30C7\u30EB\u307E\u305F\u306F\u5171\u6709\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u3067\u304D\u307E\u305B\u3093\u3002\u62E1\u5F35\u304B\u3089\u958B\u304D\u3001\u30E2\u30C7\u30EB\u8AAD\u307F\u8FBC\u307F\u3092\u78BA\u8A8D\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u4E0D\u5B8C\u5168\u306A\u96C6\u8A08\u306B\u306F\u5207\u308A\u66FF\u3048\u307E\u305B\u3093\u3002",coverageOpenFailed:"\u30C4\u30FC\u30EB\u3092\u958B\u3051\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",coveragePrefilled:"\u5206\u6790\u7D50\u679C\u304B\u3089\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u3092\u5165\u529B\u3057\u307E\u3057\u305F\u3002\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u306F\u3053\u306E\u8A9E\u306E\u691C\u8A3C\u6E08\u307F\u624B\u8A71\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u4F5C\u6210\u30FB\u4FDD\u5B58\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304B\u3089\u6709\u52B9\u5316\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionLibraryTitle:"\u5171\u6709\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA \xB7 \u7B2C2\u6BB5\u968E",motionLibraryHelp:"\u30A8\u30C7\u30A3\u30BF\u30FC\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u30FB\u30A2\u30D0\u30BF\u30FC\u306F\u30E9\u30B8\u30A2\u30F3\u3068 REST \u5DEE\u5206\u3092\u5171\u6709\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u306F\u30D7\u30EC\u30D3\u30E5\u30FC\u3068\u78BA\u8A8D\u5F8C\u306B\u7FFB\u8A33\u3078\u4F7F\u7528\u3057\u307E\u3059\u3002",motionName:"\u52D5\u4F5C\u540D\uFF08\u5FC5\u9808\uFF09",motionTexts:"\u5BFE\u5FDC\u3059\u308B\u6587\u5B57\uFF08\u30AB\u30F3\u30DE\u533A\u5207\u308A\u30FB\u59FF\u52E2\u7D20\u6750\u306E\u307F\u306A\u3089\u7A7A\u6B04\uFF09",motionTags:"\u30BF\u30B0\uFF08\u30AB\u30F3\u30DE\u533A\u5207\u308A\uFF09",motionNew:"\u65B0\u3057\u3044\u30B3\u30D4\u30FC",motionNewHelp:"\u73FE\u5728\u306E\u59FF\u52E2\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u52D5\u4F5C\u540D\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionSave:"\u4E0B\u66F8\u304D\u4FDD\u5B58",motionSaved:"\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002\u30D7\u30EC\u30D3\u30E5\u30FC\u3068\u78BA\u8A8D\u5F8C\u306B\u6709\u52B9\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionLoad:"\u9078\u629E\u3092\u8AAD\u307F\u8FBC\u3080",motionLoaded:"\u8AAD\u307F\u8FBC\u307F\u307E\u3057\u305F\u3002\u30A4\u30F3\u30DD\u30FC\u30C8\u306F\u81EA\u52D5\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u3055\u308C\u307E\u305B\u3093\u3002\u78BA\u8A8D\u5F8C\u306B\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionChoose:"\u4FDD\u5B58\u6E08\u307F\u306E\u52D5\u4F5C\u3092\u9078\u629E\u2026",motionDraft:"\u4E0B\u66F8\u304D / \u7121\u52B9",motionEnabled:"\u78BA\u8A8D\u6E08\u307F / \u6709\u52B9",motionPreview:"\u73FE\u5728\u306E\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC",motionPreviewHelp:"\u30A2\u30D0\u30BF\u30FC\u3068\u540C\u3058\u518D\u751F\u51E6\u7406\u3067\u3059\u3002\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D\u3057\u3001\u5909\u66F4\u5F8C\u306F\u518D\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionEnable:"\u78BA\u8A8D\u3057\u3066\u7FFB\u8A33\u306B\u4F7F\u7528",motionDisable:"\u9078\u629E\u3057\u305F\u52D5\u4F5C\u3092\u7121\u52B9\u5316",motionConfirm:"\u5168\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3001\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D\u3057\u307E\u3057\u305F\u3002\u5C02\u9580\u5BB6\u306B\u3088\u308B\u624B\u8A71\u8A8D\u8A3C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6709\u52B9\u306B\u3057\u307E\u3059\u304B\uFF1F",motionEnabledHelp:"\u6709\u52B9\u5316\u3057\u307E\u3057\u305F\u3002\u958B\u3044\u3066\u3044\u308B\u30A2\u30D0\u30BF\u30FC\u306B\u81EA\u52D5\u53CD\u6620\u3057\u3001\u65B0\u3057\u304F\u4E00\u81F4\u3057\u305F\u6587\u5B57\u306B\u4F7F\u7528\u3057\u307E\u3059\u3002",motionDisabledHelp:"\u7121\u52B9\u5316\u3057\u307E\u3057\u305F\u3002\u4E0B\u66F8\u304D\u3092\u4FDD\u6301\u3057\u3001\u30A2\u30D0\u30BF\u30FC\u306E\u5F85\u6A5F\u4E2D\u306E\u72EC\u81EA\u52D5\u4F5C\u3092\u505C\u6B62\u3057\u307E\u3059\u3002",motionRefresh:"\u4E00\u89A7\u66F4\u65B0",motionExport:"\u7D71\u4E00 JSON \u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9",motionExportCode:"\u30B3\u30FC\u30C9\u51FA\u529B\uFF08\u4FDD\u5B58\u306A\u3057\uFF09",motionImport:"\u52D5\u4F5C JSON \u3092\u30A4\u30F3\u30DD\u30FC\u30C8",motionImportFormat:"\u30A4\u30F3\u30DD\u30FC\u30C8\u5F62\u5F0F\u3068\u5358\u4F4D",motionFormat:"\u7D71\u4E00\u5F62\u5F0F \xB7 \u30E9\u30B8\u30A2\u30F3 / REST \u5DEE\u5206",motionLegacyEditor:"\u65E7\u30A8\u30C7\u30A3\u30BF\u30FC\u5DEE\u5206 \xB7 \u5EA6\uFF08\u59FF\u52E2\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u306E\u307F\uFF09",motionLegacyRecorder:"\u65E7\u9332\u753B frames.pose \xB7 \u5EA6",motionLegacyAbsolute:"\u65E7\u30A8\u30C7\u30A3\u30BF\u30FC\u7D76\u5BFE\u89D2 \xB7 \u30E9\u30B8\u30A2\u30F3",motionMigrate:"\u3053\u306E\u30DA\u30FC\u30B8\u306E\u65E7\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u79FB\u884C",motionLegacyConfirm:"\u65E7\u30C7\u30FC\u30BF\u306B\u306F\u30E2\u30C7\u30EB\u60C5\u5831\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u3067\u6B63\u3057\u3044\u5F62\u5F0F\u30FB\u5358\u4F4D\u3067\u3042\u308B\u5834\u5408\u306E\u307F\u7D9A\u884C\u3057\u3001\u5909\u63DB\u5F8C\u306F\u5404\u52D5\u4F5C\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5143\u30C7\u30FC\u30BF\u306F\u524A\u9664\u3057\u307E\u305B\u3093\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F",motionMigrated:"{count} \u4EF6\u306E\u4E0B\u66F8\u304D\u3092\u79FB\u884C\u3057\u307E\u3057\u305F\u3002\u5143\u30C7\u30FC\u30BF\u3092\u4FDD\u6301\u3057\u3001\u672A\u6709\u52B9\u3067\u3059\u3002\u518D\u5B9F\u884C\u3059\u308B\u3068\u30B3\u30D4\u30FC\u3092\u4F5C\u6210\u3057\u307E\u3059\u3002",motionIgnored:"\u7834\u640D\u307E\u305F\u306F\u30E2\u30C7\u30EB\u4E0D\u4E00\u81F4\u306E {count} \u4EF6\u3092\u9664\u5916\u3057\u307E\u3057\u305F\u3002\u5143\u30C7\u30FC\u30BF\u306F\u4FDD\u6301\u3057\u307E\u3059\u3002",motionFailure:"\u672A\u5B8C\u4E86\uFF1A{detail}",motionInvalidData:"\u52D5\u4F5C\u5F62\u5F0F\u307E\u305F\u306F\u30D1\u30E9\u30E1\u30FC\u30BF\u30FC\u304C\u7121\u52B9\uFF1A{detail}",motionModelNotReady:"\u30E2\u30C7\u30EB\u306E\u8AAD\u307F\u8FBC\u307F\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093\u3002",motionRigMismatch:"\u9AA8\u683C\u307E\u305F\u306F REST \u59FF\u52E2\u304C\u4E00\u81F4\u3057\u306A\u3044\u305F\u3081\u3001\u9069\u7528\u3057\u307E\u305B\u3093\u3002",motionStorageUnavailable:"\u5171\u6709\u30B9\u30C8\u30EC\u30FC\u30B8\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u62E1\u5F35\u6A5F\u80FD\u306E\u30D1\u30CD\u30EB\u304B\u3089\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",motionSelectFirst:"\u52D5\u4F5C\u3092\u4FDD\u5B58\u307E\u305F\u306F\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionSaveFirst:"\u52D5\u4F5C\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u4FDD\u5B58\u3068\u30D7\u30EC\u30D3\u30E5\u30FC\u304C\u5FC5\u8981\u3067\u3059\u3002",motionPreviewFirst:"\u6709\u52B9\u5316\u306E\u524D\u306B\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionAliasConflict:"\u5BFE\u5FDC\u6587\u5B57\u304C\u7A7A\u6B04\u3001\u307E\u305F\u306F\u65E2\u5B58\u306E\u52D5\u4F5C\u3068\u91CD\u8907\uFF1A{detail}\u3002\u5225\u306E\u8A9E\u53E5\u3092\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionFileTooLarge:"\u30D5\u30A1\u30A4\u30EB\u307E\u305F\u306F\u9805\u76EE\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\uFF082 MiB\uFF09\u3002",motionEditorSingleFrame:"\u30A8\u30C7\u30A3\u30BF\u30FC\u306F\u5358\u4E00\u59FF\u52E2\u5C02\u7528\u3067\u3059\u3002\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",motionFrameLimit:"240 \u30D5\u30EC\u30FC\u30E0\u306B\u9054\u3057\u305F\u305F\u3081\u9332\u753B\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002",motionFrameDuration:"\u30D5\u30EC\u30FC\u30E0\u6642\u9593\uFF08\u79D2\u30010.05\u201310\uFF09",motionUpdateFrame:"\u9078\u629E\u30D5\u30EC\u30FC\u30E0\u3092\u66F4\u65B0",motionHelpRig:"Godette \u306F\u6A19\u6E96 Humanoid \u30DC\u30FC\u30F3\u3068\u5229\u7528\u53EF\u80FD\u306A\u6307\u306E\u30DC\u30FC\u30F3\u30C1\u30A7\u30FC\u30F3\u3092\u4F7F\u3044\u307E\u3059\u3002\u30A8\u30C7\u30A3\u30BF\u30FC\u3001\u9332\u753B\u30C4\u30FC\u30EB\u3001\u30A2\u30D0\u30BF\u30FC\u306F\u540C\u3058 profile \u3068 REST \u30DD\u30FC\u30BA\u3092\u5171\u6709\u3057\u307E\u3059\u3002",motionHelpAxes:"X/Y/Z \u306F\u30DC\u30FC\u30F3\u306E\u30ED\u30FC\u30AB\u30EB\u8EF8\u3067\u3001\u56FA\u5B9A\u306E\u4E16\u754C\u65B9\u5411\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u51FA\u529B\u306F REST \u5DEE\u5206\u30E9\u30B8\u30A2\u30F3\u3001\u9332\u753B\u30C4\u30FC\u30EB\u306E\u30B9\u30E9\u30A4\u30C0\u30FC\u306F\u7D76\u5BFE\u30ED\u30FC\u30AB\u30EB\u30E9\u30B8\u30A2\u30F3\u3067\u3059\u3002\u5168\u30DC\u30FC\u30F3\u3092\u540C\u3058\u8EF8\u65B9\u5411\u3068\u307F\u306A\u3055\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3002",motionHelpCreate:"\u5358\u4E00\u30DD\u30FC\u30BA\u306F\u30A8\u30C7\u30A3\u30BF\u30FC\u3001\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u4F5C\u308A\u307E\u3059\u3002\u540D\u524D\u3001\u7167\u5408\u30C6\u30AD\u30B9\u30C8\u3001\u30BF\u30B0\u3092\u5165\u529B\u3057\u3066\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002\u7167\u5408\u30C6\u30AD\u30B9\u30C8\u304C\u7A7A\u306A\u3089\u7D20\u6750\u3068\u3057\u3066\u4FDD\u5B58\u3067\u304D\u307E\u3059\u3002\u65E2\u5B58\u306E\u7167\u5408\u8A9E\u306F\u4E0A\u66F8\u304D\u3067\u304D\u307E\u305B\u3093\u3002",motionHelpReview:"\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58 \u2192 \u73FE\u5728\u306E\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC \u2192 \u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D \u2192 \u7FFB\u8A33\u306B\u6709\u52B9\u5316\u3002\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB\u30D1\u30CD\u30EB\u304B\u3089\u7167\u5408\u8A9E\u3092\u5165\u529B\u3057\u3066\u691C\u8A3C\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u3053\u306E\u78BA\u8A8D\u306F\u624B\u8A71\u306E\u5C02\u9580\u8A8D\u8A3C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",motionHelpFrames:"\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306E\u30D5\u30EC\u30FC\u30E0\u3092\u9078\u629E\u3057\u3001\u30DC\u30FC\u30F3\u3068\u6642\u9593\u3092\u7DE8\u96C6\u3057\u3066\u300C\u9078\u629E\u30D5\u30EC\u30FC\u30E0\u3092\u66F4\u65B0\u300D\u3092\u62BC\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u59FF\u52E2\u306B\u306F\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u3092\u8FFD\u52A0\u3057\u307E\u3059\u30021 \u30D5\u30EC\u30FC\u30E0 0.05\u201310 \u79D2\u3001\u6700\u5927 240 \u30D5\u30EC\u30FC\u30E0\u3001\u5408\u8A08 120 \u79D2\u3002\u81EA\u52D5\u9332\u753B\u306F 0.3 \u79D2\u9593\u9694\u3067\u3059\u3002",motionHelpUpdates:"\u4E21\u30C4\u30FC\u30EB\u3068\u30A2\u30D0\u30BF\u30FC\u306F\u540C\u3058\u62E1\u5F35 ID\u30FB\u30D6\u30E9\u30A6\u30B6\u30FC\u30D7\u30ED\u30D5\u30A1\u30A4\u30EB\u306E\u4FDD\u5B58\u9818\u57DF\u3092\u5171\u6709\u3057\u307E\u3059\u3002\u6709\u52B9\u5316\u30FB\u7121\u52B9\u5316\u3067\u30A2\u30D0\u30BF\u30FC\u3068\u5F85\u3061\u884C\u5217\u3092\u66F4\u65B0\u3057\u307E\u3059\u3002\u518D\u4FDD\u5B58\u3059\u308B\u3068\u627F\u8A8D\u3092\u89E3\u9664\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u30B3\u30D4\u30FC\u306F\u5143\u306E\u52D5\u4F5C\u3092\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002",motionHelpBackup:"\u7D71\u4E00 JSON \u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3057\u307E\u3059\u3002\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3060\u3051\u3067\u306F\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u3055\u308C\u307E\u305B\u3093\u3002\u30A4\u30F3\u30DD\u30FC\u30C8\u306F\u65B0\u3057\u3044\u4E0B\u66F8\u304D\u3068\u3057\u3066\u518D\u4FDD\u5B58\u30FB\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u958B\u304D\u307E\u3059\u3002\u62E1\u5F35\u306E\u524A\u9664\u3084 ID \u5909\u66F4\u524D\u306B\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionHelpLegacy:"\u65E7\u30E9\u30A4\u30D6\u30E9\u30EA\u306E\u79FB\u884C\u306F sb_gestures \u3092\u6B8B\u3057\u3001\u518D\u5B9F\u884C\u3059\u308B\u3068\u30B3\u30D4\u30FC\u3092\u4F5C\u308A\u307E\u3059\u3002\u65E7 JSON \u306E\u5EA6\u6570\u30FB\u7D76\u5BFE\u30E9\u30B8\u30A2\u30F3\u5F62\u5F0F\u3092\u660E\u793A\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5358\u4F4D\u3092\u63A8\u6E2C\u305B\u305A\u3001\u30B3\u30FC\u30C9\u3082\u5B9F\u884C\u3057\u307E\u305B\u3093\u3002\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u7528\u30C7\u30FC\u30BF\u3067\u3042\u308B\u3053\u3068\u3092\u78BA\u8A8D\u3057\u3001\u5FC5\u305A\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionHelpBinding:"\u30D5\u30A1\u30A4\u30EB\u4E0A\u9650\u306F 2 MiB\u3002\u4E0D\u4E00\u81F4\u306E\u30DC\u30FC\u30F3/REST\u3001\u672A\u77E5\u306E\u30DC\u30FC\u30F3\u3001\u4E0D\u6B63\u306A\u5024\u306F\u62D2\u5426\u3057\u307E\u3059\u3002\u3053\u308C\u306F GLB \u5168\u4F53\u3084\u30B9\u30AD\u30F3\u306E\u6307\u7D0B\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u30C4\u30FC\u30EB\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002localhost \u306E\u30DA\u30FC\u30B8\u3068\u306F\u5171\u6709\u3067\u304D\u307E\u305B\u3093\u3002\u66F4\u65B0\u5F8C\u306F\u62E1\u5F35\u3092\u518D\u8AAD\u8FBC\u3057\u3001\u53E4\u3044\u30C4\u30FC\u30EB\u30BF\u30D6\u3092\u958B\u304D\u76F4\u3057\u307E\u3059\u3002",motionHelpCollision:"\u8A72\u5F53\u3059\u308B\u52D5\u4F5C\u3068\u30D5\u30EC\u30FC\u30E0\u3092\u7279\u5B9A\u3057\u3001\u6B63\u9762\u3068\u5074\u9762\u304B\u3089\u8098\u30FB\u624B\u9996\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u305D\u306E\u52D5\u4F5C\u306E\u307F\u4FEE\u6B63\u3057\u3066\u518D\u78BA\u8A8D\u3057\u3001\u5168\u4F53\u306E\u8EF8\u53CD\u8EE2\u3084\u4E00\u62EC\u89D2\u5EA6\u5909\u66F4\u3092\u907F\u3051\u3066\u304F\u3060\u3055\u3044\u3002",motionHelpCoverage:"\u4E00\u81F4\u3057\u305F motionIds \u3068\u672A\u4E00\u81F4\u30C6\u30AD\u30B9\u30C8\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u672A\u53CE\u9332\u306E\u5165\u529B\u306F\u73FE\u5728\u306E\u518D\u751F\u3092\u4E2D\u65AD\u3057\u307E\u305B\u3093\u3002",motionHelpCatalog:"\u6709\u52B9\u306A\u30AB\u30B9\u30BF\u30E0\u52D5\u4F5C\u6570\u3068\u4E0D\u6B63\u306A\u8A18\u9332\u6570\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u306F\u7FFB\u8A33\u3055\u308C\u307E\u305B\u3093\u3002",motionDurationInvalid:"\u6642\u9593\u306F 0.05\u201310 \u79D2\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",motionLoadingFailed:"\u30E2\u30C7\u30EB\u8AAD\u307F\u8FBC\u307F\u5931\u6557\uFF1A{detail}",name:"\u65E5\u672C\u8A9E",title:"SignBridge \u2014 \u624B\u8A71\u7FFB\u8A33",description:"\u52D5\u753B\u306E\u97F3\u58F0\u3092\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0\u3067\u624B\u8A71\u306B\u7FFB\u8A33\u30013D\u30A2\u30D0\u30BF\u30FC\u3067\u8868\u793A",settings:"\u8A2D\u5B9A",avatar:"\u30A2\u30D0\u30BF\u30FC",language:"\u8A00\u8A9E",sourceLanguage:"\u52D5\u753B\u306E\u8A00\u8A9E",targetSignLanguage:"\u624B\u8A71\u306E\u7A2E\u985E",avatarStyle:"\u30A2\u30D0\u30BF\u30FC\u30B9\u30BF\u30A4\u30EB",avatarSize:"\u30A2\u30D0\u30BF\u30FC\u30B5\u30A4\u30BA",avatarPosition:"\u30A2\u30D0\u30BF\u30FC\u4F4D\u7F6E",positionBottomRight:"\u53F3\u4E0B",positionBottomLeft:"\u5DE6\u4E0B",positionTopRight:"\u53F3\u4E0A",positionTopLeft:"\u5DE6\u4E0A",enableAutoDetect:"\u52D5\u753B\u3092\u81EA\u52D5\u691C\u51FA",enableSubtitles:"\u5B57\u5E55\u3092\u8868\u793A",voiceVolume:"\u97F3\u58F0\u97F3\u91CF",speed:"\u624B\u8A71\u306E\u901F\u5EA6",about:"\u306B\u3064\u3044\u3066",start:"\u7FFB\u8A33\u958B\u59CB",stop:"\u7FFB\u8A33\u505C\u6B62",loading:"\u8AAD\u307F\u8FBC\u307F\u4E2D...",noVideo:"\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",error:"\u30A8\u30E9\u30FC",errorNoVideo:"\u30DA\u30FC\u30B8\u306B\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",ready:"\u6E96\u5099\u5B8C\u4E86",translating:"\u7FFB\u8A33\u4E2D...",unavailable:"\u3053\u306E\u30DA\u30FC\u30B8\u3067\u306F\u5229\u7528\u3067\u304D\u307E\u305B\u3093",inputPlaceholder:"\u624B\u8A71\u306B\u3059\u308B\u30C6\u30AD\u30B9\u30C8\u3092\u5165\u529B...",send:"\u9001\u4FE1",sent:"\u9001\u4FE1\u6E08\u307F",audioOff:"\u52D5\u753B\u97F3\u58F0\uFF1A\u30AA\u30D5",audioOn:"\u52D5\u753B\u97F3\u58F0\uFF1A\u30AA\u30F3",audioStopped:"\u505C\u6B62\u4E2D",audioListening:"\u8A8D\u8B58\u4E2D...",audioStarting:"\u97F3\u58F0\u3092\u53D6\u5F97\u4E2D...",audioUnavailable:"\u3053\u306E\u30DA\u30FC\u30B8\u3067\u306F\u97F3\u58F0\u3092\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093",audioCaptureFailed:"\u97F3\u58F0\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F",audioCloudKeyRequired:"\u30AF\u30E9\u30A6\u30C9 API Key \u3092\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044",audioPermissionRequired:"ASR \u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u3066\u63A5\u7D9A\u5148\u3092\u8A31\u53EF\u3057\u3066\u304F\u3060\u3055\u3044",audioLocalUnavailable:"\u5148\u306B\u30ED\u30FC\u30AB\u30EB Whisper \u3092\u5C0E\u5165\u3057\u3066\u304F\u3060\u3055\u3044",asrSettings:"\u97F3\u58F0\u8A8D\u8B58\u8A2D\u5B9A",asrTitle:"\u52D5\u753B\u97F3\u58F0\u8A8D\u8B58",asrPurpose:"\u30ED\u30FC\u30AB\u30EB Whisper \u307E\u305F\u306F\u30AF\u30E9\u30A6\u30C9 ASR \u3067\u52D5\u753B\u97F3\u58F0\u3092\u624B\u8A71\u52D5\u4F5C\u306B\u5909\u63DB\u3057\u307E\u3059\u3002",asrProvider:"\u8A8D\u8B58\u65B9\u5F0F",asrLocal:"\u30ED\u30FC\u30AB\u30EB Whisper",asrCloud:"\u30AF\u30E9\u30A6\u30C9 ASR",asrLocalSettings:"\u30ED\u30FC\u30AB\u30EB Whisper \u8A2D\u5B9A",asrLocalPrivacy:"\u30E2\u30C7\u30EB\u3068\u97F3\u58F0\u306F\u62E1\u5F35\u6A5F\u80FD\u5185\u3067\u51E6\u7406\u3055\u308C\u3001\u52D5\u753B\u97F3\u58F0\u306F\u8A8D\u8B58\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u305B\u3093\u3002",asrDeployLocal:"\u30ED\u30FC\u30AB\u30EB Whisper \u3092\u5C0E\u5165",asrEndpoint:"\u30B5\u30FC\u30D3\u30B9 URL",asrModel:"\u30E2\u30C7\u30EB",asrModelTiny:"tiny\uFF08\u6700\u901F\u3001\u7D04 75 MB\uFF09",asrModelBase:"base\uFF08\u30D0\u30E9\u30F3\u30B9\u3001\u7D04 150 MB\uFF09",asrModelSmall:"small\uFF08\u9AD8\u7CBE\u5EA6\u3001\u7D04 500 MB\uFF09",asrDeployHint:"\u30AF\u30EA\u30C3\u30AF\u3059\u308B\u3068\u30E2\u30C7\u30EB\u3092\u81EA\u52D5\u3067\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u4FDD\u5B58\u3057\u307E\u3059\u3002Python \u3084\u30ED\u30FC\u30AB\u30EB\u30B5\u30FC\u30D3\u30B9\u306F\u4E0D\u8981\u3067\u3059\u3002",asrDeployRequired:"\u9078\u629E\u3057\u305F\u30E2\u30C7\u30EB\u306F\u307E\u3060\u5C0E\u5165\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002",asrRequestingModelPermission:"\u30E2\u30C7\u30EB\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u6A29\u9650\u3092\u78BA\u8A8D\u4E2D...",asrDeploying:"\u30E2\u30C7\u30EB\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u521D\u671F\u5316\u4E2D\uFF1A{progress}%",asrDeployReady:"\u30ED\u30FC\u30AB\u30EB\u30E2\u30C7\u30EB {model} \u306E\u6E96\u5099\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002",asrDeployFailed:"\u30ED\u30FC\u30AB\u30EB\u30E2\u30C7\u30EB\u306E\u5C0E\u5165\u306B\u5931\u6557\u3057\u307E\u3057\u305F",asrCloudSettings:"\u30AF\u30E9\u30A6\u30C9 ASR \u8A2D\u5B9A",asrCloudPrivacy:"\u52D5\u753B\u97F3\u58F0\u306F\u8A2D\u5B9A\u3057\u305F\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u3059\u3002\u30D7\u30E9\u30A4\u30D0\u30B7\u30FC\u3068\u6599\u91D1\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",asrApiKey:"API Key",asrCommonSettings:"\u5171\u901A\u8A2D\u5B9A",asrLanguage:"\u8A8D\u8B58\u8A00\u8A9E",asrChunkSeconds:"\u97F3\u58F0\u30C1\u30E3\u30F3\u30AF",asrTest:"\u63A5\u7D9A\u30C6\u30B9\u30C8",asrSave:"\u8A2D\u5B9A\u3092\u4FDD\u5B58",asrPermissionDenied:"\u3053\u306E\u30B5\u30FC\u30D3\u30B9\u3078\u306E\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093\u3002",asrSaved:"\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002",asrInvalidConfig:"\u30EA\u30E2\u30FC\u30C8URL\u306B\u306FHTTPS\u304C\u5FC5\u8981\u3067\u3059\u3002HTTP\u306F\u30EB\u30FC\u30D7\u30D0\u30C3\u30AF\u306E\u307F\u8A31\u53EF\u3057\u3001URL\u306E\u8A8D\u8A3C\u60C5\u5831\u306F\u7981\u6B62\u3057\u307E\u3059\u3002",asrTesting:"\u8A8D\u8B58\u30B5\u30FC\u30D3\u30B9\u3092\u30C6\u30B9\u30C8\u3057\u3066\u3044\u307E\u3059...",asrTestPassed:"\u63A5\u7D9A\u30C6\u30B9\u30C8\u306B\u6210\u529F\u3057\u307E\u3057\u305F\u3002",asrTestFailed:"\u63A5\u7D9A\u30C6\u30B9\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F",poseEditor:"\u30DD\u30FC\u30BA\u7DE8\u96C6",recorder:"\u9332\u753B\u30C4\u30FC\u30EB",help:"\u30D8\u30EB\u30D7",tagline:"\u60C5\u5831\u3092\u30A2\u30AF\u30BB\u30B7\u30D6\u30EB\u306B",auto:"\u81EA\u52D5\u691C\u51FA",simplifiedChinese:"\u4E2D\u56FD\u8A9E\uFF08\u6A19\u6E96\u8A9E\uFF09",footer:"SignBridge \u2014 \u60C5\u5831\u3092\u30A2\u30AF\u30BB\u30B7\u30D6\u30EB\u306B",signLanguageTypes:{csl:"\u4E2D\u56FD\u624B\u8A71 (CSL)",asl:"\u30A2\u30E1\u30EA\u30AB\u624B\u8A71 (ASL)",bsl:"\u30A4\u30AE\u30EA\u30B9\u624B\u8A71 (BSL)",jsl:"\u65E5\u672C\u624B\u8A71 (JSL)",ksl:"\u97D3\u56FD\u624B\u8A71 (KSL)"},avatarStyles:{default:"\u30C7\u30D5\u30A9\u30EB\u30C8",friendly:"\u30D5\u30EC\u30F3\u30C9\u30EA\u30FC",professional:"\u30D7\u30ED\u30D5\u30A7\u30C3\u30B7\u30E7\u30CA\u30EB",anime:"\u30A2\u30CB\u30E1\u98A8"}}},wr="en",Pa=null;function Tr(){return Pa||navigator.language||wr}function La(c){Pa=c}function U(c,e={}){let t=Tr(),n=Fi[t]||Fi[t.split("-")[0]]||Fi[wr],i=c.split("."),s=n;for(let r of i)if(s&&typeof s=="object")s=s[r];else{s=void 0;break}if(s===void 0){n=Fi[wr],s=n;for(let r of i)if(s&&typeof s=="object")s=s[r];else break}return typeof s!="string"?c:s.replace(/\{(\w+)\}/g,(r,o)=>e[o]??`{${o}}`)}var En="signbridge.vocabulary-batch.v1",ki=8;function Oi(c){if(!Array.isArray(c)||c.length>ki)throw new Error("batchInvalid");let e=new Set;return c.map(t=>{if(typeof t!="string"||!t.trim()||t.length>100)throw new Error("batchInvalid");let n=ce(t);if(!n||e.has(n))throw new Error("batchInvalid");return e.add(n),t.trim()})}function Da(c,e){let t=Ni(e),n=bn(t);return Oi(c).map(i=>{let s=wn(i,12,n),r=s?.matches.length>0&&!s.unmatched.length&&!s.skipped.length&&!s.truncated,o=e.filter(a=>a.asset.texts.some(l=>ce(l)===ce(i))).map(a=>a.asset.id);return{word:i,state:r?"matched":o.length?"draft":"missing",matches:s?.matches.map(({id:a,text:l})=>({id:a,text:l}))||[],draftIds:r?[]:o}})}function Na(c=globalThis.chrome?.storage,e=globalThis.navigator?.locks){async function t(){let i=(await c.local.get(En))[En];if(i===void 0)return[];if(i?.version!==1)throw new Error("batchInvalid");return Oi(i.words)}function n(i){if(!e?.request)throw new Error("batchLockUnavailable");return e.request(En,async()=>{let s=Oi(await i());return await c.local.set({[En]:{version:1,words:s}}),s})}return{read:t,add(i){let s;try{[s]=Oi([i])}catch{throw new Error("batchInvalidWord")}return n(async()=>{let r=await t();if(r.some(o=>ce(o)===ce(s)))return r;if(r.length>=ki)throw new Error("batchFull");return[...r,s]})},remove(i){return n(async()=>(await t()).filter(s=>s!==i))},clear:()=>n(()=>[]),subscribe(i){let s=(r,o)=>{o==="local"&&Object.hasOwn(r,En)&&i()};return c.onChanged.addListener(s),()=>c.onChanged.removeListener(s)}}}function Ua({getLibrary:c,authorButton:e}){let t=Na(),n=x=>document.getElementById(x),i=n("batch-status"),s=n("batch-rows"),r=n("batch-export"),o=0,a=!1,l=null,d=new Map;function h(x,y,M){let b=document.createElement(y);return b.textContent=M,x.appendChild(b),b}function u(x,y,M){let b=h(x,"button",U(y));return b.type="button",b.addEventListener("click",()=>p(M)),b}function f(x){i.textContent=U("batchFailure",{detail:U(x.message)})}async function p(x){try{return await x(),a||await m(),!0}catch(y){return a||f(y),!1}}async function m(){let x=++o;l=null,r.disabled=!0,s.replaceChildren(),i.textContent=U("batchLoading");try{let y=await t.read();if(a||x!==o)return;for(let E of y){let N=h(s,"tr","");N.dataset.word=E,h(N,"th",E).scope="row",h(N,"td",U("batchLoading")).className="batch-state";let k=h(N,"td","");e(k,E,"pose-editor","poseEditor"),e(k,E,"record-mode","recorder"),u(k,"batchRemove",()=>t.remove(E))}if(!y.length){i.textContent=U("batchEmpty");return}let M=await c();if(a||x!==o)return;let{entries:b,invalidCount:C}=await M.list();if(a||x!==o)return;let A=Da(y,b);A.forEach((E,N)=>{let k=s.children[N].querySelector(".batch-state");k.textContent=U({matched:"batchMatched",draft:"batchDraft",missing:"batchMissing"}[E.state]),h(k,"div",[...new Set(E.matches.map(X=>X.id)),...E.draftIds].join(", ")).className="muted"}),l={format:"signbridge-vocabulary-batch",version:1,generatedAt:new Date().toISOString(),extensionVersion:chrome.runtime.getManifest().version,includesSourceText:!1,linguisticReview:"not-assessed",invalidLibraryEntries:C,items:A},r.disabled=!1,i.textContent=U("batchSummary",{count:y.length,max:ki,matched:A.filter(E=>E.state==="matched").length,invalid:C})}catch(y){!a&&x===o&&(s.querySelectorAll(".batch-state").forEach(M=>{M.textContent=U("batchUnverified")}),f(y))}}n("batch-refresh").addEventListener("click",m),n("batch-add-form").addEventListener("submit",async x=>{x.preventDefault();let y=n("batch-word"),M=y.value;await p(()=>t.add(M))&&!a&&y.value===M&&(y.value="")}),n("batch-clear").addEventListener("click",()=>{window.confirm(U("batchClearConfirm"))&&p(()=>t.clear())}),n("batch-review").addEventListener("click",async()=>{try{await chrome.tabs.create({url:chrome.runtime.getURL("tools/motion-review.html")})}catch{f(new Error("coverageOpenFailed"))}}),r.addEventListener("click",async()=>{if(await m(),a||!l)return;let x=URL.createObjectURL(new Blob([JSON.stringify(l,null,2)],{type:"application/json"})),y=h(document.body,"a","");y.href=x,y.download="signbridge-vocabulary-batch.json",y.click(),y.remove(),d.set(x,setTimeout(()=>{URL.revokeObjectURL(x),d.delete(x)},1e3))});let g=t.subscribe(m),v=(x,y)=>{y==="local"&&Object.keys(x).some(M=>M.startsWith(be))&&m()};return chrome.storage.onChanged.addListener(v),window.addEventListener("pagehide",()=>{a=!0,o+=1,g(),chrome.storage.onChanged.removeListener(v);for(let[x,y]of d)clearTimeout(y),URL.revokeObjectURL(x);d.clear()},{once:!0}),m(),{add:x=>p(()=>t.add(x))}}var W=c=>document.getElementById(c),Bi=W("coverage-text"),Ar=W("coverage-format"),Rn=W("coverage-status"),zi=W("coverage-analyze"),Cr=W("coverage-export"),_t=0,vt=0,Ve=!1,Cn=null,Fa=null,In=null,Oa=null,Hi=new Map;function Kt(c="coverageChanged"){_t+=1,In=null,Cr.disabled=!0,zi.disabled=!1,W("coverage-results").hidden=!0,W("coverage-catalog").textContent="",Rn.textContent=U(c)}function Vi(c){Rn.textContent=U("coverageFailure",{detail:U(c.message,{detail:c.detail||""})})}function ka(){return Cn||(Cn=(async()=>{let c=await new Ri().loadAsync(chrome.runtime.getURL("avatar/model.glb"));try{if(Ve)return null;let e=jo(c.scene);if(!e.isSigningReady)throw new Error("coverageModelError");let t=ma(e);return Fa=t.subscribe(()=>Kt("coverageCatalogChanged")),t}finally{Qo(c.scene)}})().catch(()=>{throw Cn=null,new Error("coverageModelError")})),Cn}function me(c,e,t){let n=document.createElement(e);return n.textContent=t,c.appendChild(n),n}function Er(c,e,t,n){let i=me(c,"button",U(n));i.type="button",i.disabled=e.length>100,i.addEventListener("click",async()=>{try{let s=new URL(chrome.runtime.getURL(`avatar/${t}.html`));s.hash=new globalThis.URLSearchParams({"motion-text":e}).toString(),await chrome.tabs.create({url:s.href})}catch{Vi(new Error("coverageOpenFailed"))}})}function nu(c){let e=c.summary;W("coverage-results").hidden=!1,W("coverage-summary").textContent=U("coverageSummary",{ratio:e.coverage===null?U("coverageNoTokens"):`${(e.coverage*100).toFixed(1)}%`,segments:e.segments,matched:e.matchedTokens,unknown:e.unknownTokens,skipped:e.skippedTokens}),W("coverage-truncation").textContent=U("coverageTruncation",{count:e.runtimeTruncatedSegments});let t=W("coverage-unknown");t.replaceChildren();for(let i of c.unknown.slice(0,100)){let s=document.createElement("tr");t.appendChild(s),me(s,"th",i.word).scope="row",me(s,"td",U("coverageOccurrences",{count:i.count,segments:i.segmentCount})),me(s,"td",i.examples.join(", "));let r=me(s,"td","");Er(r,i.word,"pose-editor","poseEditor"),Er(r,i.word,"record-mode","recorder");let o=me(r,"button",U("batchAdd"));o.type="button",o.disabled=i.word.length>100,o.addEventListener("click",()=>Oa.add(i.word))}W("coverage-unknown-note").textContent=c.unknown.length?U("coverageUniqueUnknown",{count:c.unknown.length}):U("coverageNoUnknown");let n=W("coverage-details");n.replaceChildren();for(let i of c.details.slice(0,200)){let s=document.createElement("details");n.appendChild(s),me(s,"summary",`${i.segment}. ${i.text.slice(0,140)}${i.text.length>140?"\u2026":""}`),me(s,"p",i.text),me(s,"p",U("coverageMatches",{value:i.matches.map(r=>`${r.text} [${r.id}]`).join(", ")||"\u2014"})),me(s,"p",U("coverageUnmatched",{value:i.unmatched.join(", ")||"\u2014"})),me(s,"p",U("coverageSkipped",{value:i.skipped.join(", ")||"\u2014"})),i.truncated&&me(s,"p",U("coverageRemaining",{value:i.remainingText}))}Cr.disabled=!1}async function iu(){Kt("coverageLoading");let c=_t;zi.disabled=!0;try{let e=ya(Bi.value,Ar.value),t=await ka();if(Ve||c!==_t)return;let{entries:n,invalidCount:i}=await t.list();if(Ve||c!==_t)return;let s=Ni(n);In=Ma(e,s),nu(In),W("coverage-catalog").textContent=U("coverageCatalog",{signs:Object.keys(ze).length,aliases:Object.keys(da).length,chars:Object.keys(ha).length,enabled:s.length,drafts:n.length-s.length,invalid:i}),Rn.textContent=U("coverageDone")}catch(e){!Ve&&c===_t&&Vi(e)}finally{!Ve&&c===_t&&(zi.disabled=!1)}}async function su(){let c=await Ta();if(!Ve){La(c.uiLocale==="auto"?null:c.uiLocale),document.documentElement.lang=Tr(),document.title=`${U("coverageTitle")} \xB7 SignBridge`;for(let e of document.querySelectorAll("[data-i18n]"))e.textContent=U(e.dataset.i18n);Rn.textContent=U("coverageReady"),Oa=Ua({getLibrary:ka,authorButton:Er}),zi.addEventListener("click",iu);for(let e of[Bi,Ar])e.addEventListener("input",()=>{vt+=1,Kt()});W("coverage-clear").addEventListener("click",()=>{vt+=1,Bi.value="",W("coverage-file").value="",W("coverage-include-text").checked=!1,Kt("coverageReady")}),W("coverage-file").addEventListener("change",async e=>{let t=e.target.files?.[0];if(!t)return;let n=++vt;Kt();try{if(t.size>va)throw new Error("coverageTooLarge");let i=t.name.split(".").pop().toLowerCase();if(!["txt","srt","vtt"].includes(i))throw new Error("coverageInvalidFormat");let s=await t.arrayBuffer();if(Ve||n!==vt)return;let r;try{r=new globalThis.TextDecoder("utf-8",{fatal:!0}).decode(s)}catch{throw new Error("coverageEncoding")}if(r.length>Ui)throw new Error("coverageTooLarge");Kt(),Bi.value=r,Ar.value=i==="txt"?"text":i,Rn.textContent=U("coverageImported")}catch(i){!Ve&&n===vt&&Vi(i)}finally{n===vt&&(e.target.value="")}}),Cr.addEventListener("click",()=>{if(!In)return;let e=Sa(In,W("coverage-include-text").checked),t=URL.createObjectURL(new Blob([JSON.stringify(e,null,2)],{type:"application/json"})),n=document.createElement("a");n.href=t,n.download="signbridge-coverage.json",document.body.appendChild(n),n.click(),n.remove();let i=setTimeout(()=>{URL.revokeObjectURL(t),Hi.delete(t)},1e3);Hi.set(t,i)})}}window.addEventListener("pagehide",()=>{Ve=!0,_t+=1,vt+=1,Fa?.(),Cn=null;for(let[c,e]of Hi)clearTimeout(e),URL.revokeObjectURL(c);Hi.clear()});su().catch(Vi);
