// src/demo/motion-cache.js
function createMotionCache({ maxEntries = 8, maxValues = 35e4 } = {}) {
  const entries = /* @__PURE__ */ new Map();
  let values = 0;
  return {
    get(key, compile) {
      const start = performance.now();
      const existing = entries.get(key);
      if (existing) {
        entries.delete(key);
        entries.set(key, existing);
        return {
          frames: existing.frames,
          cacheHit: true,
          compileMs: performance.now() - start
        };
      }
      const frames = compile();
      const size = frames.reduce(
        (sum, frame) => sum + Object.keys(frame).length * 4,
        0
      );
      if (size <= maxValues && maxEntries > 0) {
        while (entries.size && (entries.size >= maxEntries || values + size > maxValues)) {
          const first = entries.keys().next().value;
          values -= entries.get(first).size;
          entries.delete(first);
        }
        entries.set(key, { frames, size });
        values += size;
      }
      return { frames, cacheHit: false, compileMs: performance.now() - start };
    },
    stats() {
      return {
        entries: entries.size,
        numericBytes: values * 8,
        budgetNumericBytes: maxValues * 8
      };
    },
    clear() {
      entries.clear();
      values = 0;
    }
  };
}

// src/avatar/iframe-bundle.js
import * as THREE2 from "./three.module.js";
import { GLTFLoader } from "./jsm/loaders/GLTFLoader.js";

// src/avatar/humanoid-rig.js
var HUMANOID_BONES = Object.freeze([
  "root",
  "body",
  "hips",
  "spine",
  "chest",
  "upperChest",
  "neck",
  "neck2",
  "neck3",
  "head",
  "rightShoulder",
  "rightUpperArm",
  "rightLowerArm",
  "rightHand",
  "leftShoulder",
  "leftUpperArm",
  "leftLowerArm",
  "leftHand",
  "rightThumbMetacarpal",
  "rightThumbProximal",
  "rightThumbDistal",
  "rightIndexProximal",
  "rightIndexIntermediate",
  "rightIndexDistal",
  "rightMiddleProximal",
  "rightMiddleIntermediate",
  "rightMiddleDistal",
  "rightRingProximal",
  "rightRingIntermediate",
  "rightRingDistal",
  "rightLittleProximal",
  "rightLittleIntermediate",
  "rightLittleDistal",
  "leftThumbMetacarpal",
  "leftThumbProximal",
  "leftThumbDistal",
  "leftIndexProximal",
  "leftIndexIntermediate",
  "leftIndexDistal",
  "leftMiddleProximal",
  "leftMiddleIntermediate",
  "leftMiddleDistal",
  "leftRingProximal",
  "leftRingIntermediate",
  "leftRingDistal",
  "leftLittleProximal",
  "leftLittleIntermediate",
  "leftLittleDistal",
  "jaw",
  "leftUpperEyelid",
  "rightUpperEyelid",
  "leftLowerEyelid",
  "rightLowerEyelid"
]);
var REQUIRED_SIGNING_BONES = Object.freeze([
  "rightUpperArm",
  "rightLowerArm",
  "rightHand",
  "leftUpperArm",
  "leftLowerArm",
  "leftHand",
  "rightThumbMetacarpal",
  "rightThumbProximal",
  "rightThumbDistal",
  "rightIndexProximal",
  "rightIndexIntermediate",
  "rightIndexDistal",
  "rightMiddleProximal",
  "rightMiddleIntermediate",
  "rightMiddleDistal",
  "rightRingProximal",
  "rightRingIntermediate",
  "rightRingDistal",
  "rightLittleProximal",
  "rightLittleIntermediate",
  "rightLittleDistal",
  "leftThumbMetacarpal",
  "leftThumbProximal",
  "leftThumbDistal",
  "leftIndexProximal",
  "leftIndexIntermediate",
  "leftIndexDistal",
  "leftMiddleProximal",
  "leftMiddleIntermediate",
  "leftMiddleDistal",
  "leftRingProximal",
  "leftRingIntermediate",
  "leftRingDistal",
  "leftLittleProximal",
  "leftLittleIntermediate",
  "leftLittleDistal"
]);
var GODETTE_PROFILE = Object.freeze({
  id: "godette-v1",
  motionSpace: "humanoid-local-v1",
  bones: Object.freeze({
    root: ["Root_225"],
    body: ["Body_220"],
    hips: ["Hip_218"],
    spine: ["Spine_1_199"],
    chest: ["Spine_2_198"],
    upperChest: ["Ribcage_197"],
    neck: ["Neck_1_132"],
    neck2: ["Neck_2_131"],
    neck3: ["Neck_3_130"],
    head: ["Head_129"],
    rightShoulder: ["ClavicR_192", "Clavic.R_192"],
    rightUpperArm: ["Arm_Upper_1R_187", "Arm_Upper_1.R_187"],
    rightLowerArm: ["Arm_Lower_1R_185", "Arm_Lower_1.R_185"],
    rightHand: ["HandR_184", "Hand.R_184"],
    leftShoulder: ["ClavicL_162", "Clavic.L_162"],
    leftUpperArm: ["Arm_Upper_1L_157", "Arm_Upper_1.L_157"],
    leftLowerArm: ["Arm_Lower_1L_155", "Arm_Lower_1.L_155"],
    leftHand: ["HandL_154", "Hand.L_154"],
    rightThumbMetacarpal: ["ThumbR_178", "Thumb.R_178"],
    rightThumbProximal: ["ThumbR002_177", "Thumb.R.002_177"],
    rightThumbDistal: ["ThumbR001_176", "Thumb.R.001_176"],
    rightIndexProximal: ["Finger_1R_166", "Finger_1.R_166"],
    rightIndexIntermediate: ["Finger_1R002_165", "Finger_1.R.002_165"],
    rightIndexDistal: ["Finger_1R001_164", "Finger_1.R.001_164"],
    rightMiddleProximal: ["Finger_2R_169", "Finger_2.R_169"],
    rightMiddleIntermediate: ["Finger_2R002_168", "Finger_2.R.002_168"],
    rightMiddleDistal: ["Finger_2R001_167", "Finger_2.R.001_167"],
    rightRingProximal: ["Finger_3R_172", "Finger_3.R_172"],
    rightRingIntermediate: ["Finger_3R002_171", "Finger_3.R.002_171"],
    rightRingDistal: ["Finger_3R001_170", "Finger_3.R.001_170"],
    rightLittleProximal: ["Finger_4R_175", "Finger_4.R_175"],
    rightLittleIntermediate: ["Finger_4R002_174", "Finger_4.R.002_174"],
    rightLittleDistal: ["Finger_4R001_173", "Finger_4.R.001_173"],
    leftThumbMetacarpal: ["ThumbL_148", "Thumb.L_148"],
    leftThumbProximal: ["ThumbL002_147", "Thumb.L.002_147"],
    leftThumbDistal: ["ThumbL001_146", "Thumb.L.001_146"],
    leftIndexProximal: ["Finger_1L_136", "Finger_1.L_136"],
    leftIndexIntermediate: ["Finger_1L002_135", "Finger_1.L.002_135"],
    leftIndexDistal: ["Finger_1L001_134", "Finger_1.L.001_134"],
    leftMiddleProximal: ["Finger_2L_139", "Finger_2.L_139"],
    leftMiddleIntermediate: ["Finger_2L002_138", "Finger_2.L.002_138"],
    leftMiddleDistal: ["Finger_2L001_137", "Finger_2.L.001_137"],
    leftRingProximal: ["Finger_3L_142", "Finger_3.L_142"],
    leftRingIntermediate: ["Finger_3L002_141", "Finger_3.L.002_141"],
    leftRingDistal: ["Finger_3L001_140", "Finger_3.L.001_140"],
    leftLittleProximal: ["Finger_4L_145", "Finger_4.L_145"],
    leftLittleIntermediate: ["Finger_4L002_144", "Finger_4.L.002_144"],
    leftLittleDistal: ["Finger_4L001_143", "Finger_4.L.001_143"],
    jaw: ["Jaw_4"],
    leftUpperEyelid: ["Eyelid_Control_UpperL_14"],
    rightUpperEyelid: ["Eyelid_Control_UpperR_15"],
    leftLowerEyelid: ["Eyelid_Control_LowerL_16"],
    rightLowerEyelid: ["Eyelid_Control_LowerR_17"]
  })
});
var LEGACY_BONE_ALIASES = Object.freeze({
  hip: "hips",
  ribcage: "upperChest",
  rShoulder: "rightShoulder",
  rUpperArm: "rightUpperArm",
  rForearm: "rightLowerArm",
  rHand: "rightHand",
  lShoulder: "leftShoulder",
  lUpperArm: "leftUpperArm",
  lForearm: "leftLowerArm",
  lHand: "leftHand",
  rthumb: "rightThumbMetacarpal",
  rindex: "rightIndexIntermediate",
  rmiddle: "rightMiddleIntermediate",
  rring: "rightRingIntermediate",
  rpinky: "rightLittleIntermediate",
  lthumb: "leftThumbMetacarpal",
  lindex: "leftIndexIntermediate",
  lmiddle: "leftMiddleIntermediate",
  lring: "leftRingIntermediate",
  lpinky: "leftLittleIntermediate",
  lUpperEyelid: "leftUpperEyelid",
  rUpperEyelid: "rightUpperEyelid",
  lLowerEyelid: "leftLowerEyelid",
  rLowerEyelid: "rightLowerEyelid"
});
function normalizeBoneName(name) {
  return String(name || "").replace(/[._\s-]/g, "").toLowerCase();
}
function canonicalizePose(pose = {}) {
  const canonical = {};
  for (const [name, rotation] of Object.entries(pose)) {
    canonical[LEGACY_BONE_ALIASES[name] || name] = rotation;
  }
  return canonical;
}
function indexSceneBones(root) {
  const exact = /* @__PURE__ */ new Map();
  const normalized = /* @__PURE__ */ new Map();
  const skeletons = /* @__PURE__ */ new Set();
  root?.traverse?.((object) => {
    if (object.isBone) {
      exact.set(object.name, object);
      normalized.set(normalizeBoneName(object.name), object);
    }
    if (object.isSkinnedMesh && object.skeleton) skeletons.add(object.skeleton);
  });
  return { exact, normalized, skeletons: [...skeletons] };
}
function resolveProfileBones(root, profile = GODETTE_PROFILE) {
  const index = indexSceneBones(root);
  const bones = {};
  for (const [canonicalName, candidates] of Object.entries(profile.bones)) {
    for (const candidate of candidates) {
      const bone = index.exact.get(candidate) || index.normalized.get(normalizeBoneName(candidate));
      if (bone) {
        bones[canonicalName] = bone;
        break;
      }
    }
  }
  return { bones, skeletons: index.skeletons };
}
function createHumanoidRig(root, profile = GODETTE_PROFILE) {
  const { bones, skeletons } = resolveProfileBones(root, profile);
  const rest = {};
  for (const [name, bone] of Object.entries(bones)) {
    rest[name] = {
      quaternion: bone.quaternion.clone(),
      rotation: {
        x: bone.rotation.x,
        y: bone.rotation.y,
        z: bone.rotation.z,
        order: bone.rotation.order
      }
    };
  }
  function update() {
    for (const skeleton of skeletons) skeleton.update();
  }
  function createTargets(pose = {}) {
    const canonicalPose = canonicalizePose(pose);
    const targets = {};
    for (const [name, bone] of Object.entries(bones)) {
      const base = rest[name];
      const delta = canonicalPose[name];
      if (!delta) {
        targets[name] = base.quaternion.clone();
        continue;
      }
      const rotation = bone.rotation.clone();
      rotation.set(
        base.rotation.x + (delta.x || 0),
        base.rotation.y + (delta.y || 0),
        base.rotation.z + (delta.z || 0),
        base.rotation.order
      );
      targets[name] = bone.quaternion.clone().setFromEuler(rotation);
    }
    return targets;
  }
  function capture() {
    const snapshot = {};
    for (const [name, bone] of Object.entries(bones)) {
      snapshot[name] = bone.quaternion.clone();
    }
    return snapshot;
  }
  function capturePose() {
    const pose = {};
    for (const [name, bone] of Object.entries(bones)) {
      const base = rest[name].rotation;
      pose[name] = {
        x: bone.rotation.x - base.x,
        y: bone.rotation.y - base.y,
        z: bone.rotation.z - base.z
      };
    }
    return pose;
  }
  function interpolate(from, targets, amount) {
    for (const [name, bone] of Object.entries(bones)) {
      const start = from[name] || rest[name].quaternion;
      const target = targets[name] || rest[name].quaternion;
      bone.quaternion.copy(start).slerp(target, amount);
    }
    update();
  }
  function applyPose(pose) {
    const targets = createTargets(pose);
    for (const [name, bone] of Object.entries(bones)) {
      bone.quaternion.copy(targets[name]);
    }
    update();
  }
  function reset() {
    for (const [name, bone] of Object.entries(bones)) {
      bone.quaternion.copy(rest[name].quaternion);
    }
    update();
  }
  const missing = REQUIRED_SIGNING_BONES.filter((name) => !bones[name]);
  return {
    profile,
    bones,
    rest,
    missing,
    isSigningReady: missing.length === 0,
    createTargets,
    capture,
    capturePose,
    interpolate,
    applyPose,
    reset,
    update
  };
}

// src/avatar/motion-player.js
function easeInOut(amount) {
  return amount < 0.5 ? 2 * amount * amount : -1 + (4 - 2 * amount) * amount;
}
function normalizeMotionFrames(input) {
  if (input?.type === "motion-sequence") {
    if (!Array.isArray(input.motions) || !input.motions.length || input.motions.length > 40)
      return [];
    const parts = input.motions.map(
      (motion) => motion?.type === "motion-sequence" ? [] : normalizeMotionFrames(motion)
    );
    return parts.some((part) => !part.length) ? [] : parts.flat();
  }
  let normalized;
  if (input?.type === "quaternion-track") {
    if (!Array.isArray(input.samples) || input.samples.length < 2 || !Number.isFinite(input.fps) || input.fps <= 0 || !Number.isFinite(input.duration) || input.duration <= 0)
      return [];
    normalized = [
      {
        track: input.samples,
        fps: input.fps,
        duration: input.duration
      }
    ];
  } else {
    const frames = Array.isArray(input) ? input : input?.frames;
    if (!Array.isArray(frames) || frames.length === 0) return [];
    normalized = frames.map((frame) => ({
      value: frame?.value && typeof frame.value === "object" ? frame.value : {},
      duration: Number.isFinite(frame?.duration) && frame.duration > 0 ? frame.duration : 0.8
    }));
  }
  if (input.sourceInfo) normalized[0].sourceInfo = input.sourceInfo;
  return normalized;
}
function createMotionPlayer(rig2, {
  requestFrame = requestAnimationFrame,
  cancelFrame = cancelAnimationFrame,
  setTimer = setTimeout,
  clearTimer = clearTimeout,
  now = () => performance.now(),
  maxPendingMotions = 2,
  maxPendingAgeMs = 6e3,
  onComplete = () => {
  },
  onMotionStart = () => {
  }
} = {}) {
  let queue = [];
  let timerId = null;
  let frameId = null;
  let playing = false;
  let pendingMotions = [];
  let currentKey = null;
  function stop({ reset = false } = {}) {
    playing = false;
    queue = [];
    pendingMotions = [];
    currentKey = null;
    if (timerId !== null) clearTimer(timerId);
    if (frameId !== null) cancelFrame(frameId);
    timerId = null;
    frameId = null;
    if (reset) rig2.reset();
  }
  function playNext() {
    if (frameId !== null) cancelFrame(frameId);
    frameId = null;
    timerId = null;
    if (playing && queue.length === 0) {
      pendingMotions = pendingMotions.filter(
        (motion) => now() - motion.receivedAt <= maxPendingAgeMs
      );
      const next = pendingMotions.shift();
      queue = next?.frames || [];
      currentKey = next?.key ?? null;
    }
    if (!playing || queue.length === 0) {
      playing = false;
      onComplete();
      return;
    }
    const frame = queue.shift();
    if (frame.sourceInfo) onMotionStart(frame.sourceInfo);
    if (frame.track) {
      let animateTrack = function() {
        if (!playing) return;
        const elapsed = Math.max(0, now() - startedAt2) / 1e3;
        const framePosition = Math.min(
          elapsed * frame.fps,
          frame.track.length - 1
        );
        const fromIndex = Math.floor(framePosition);
        const toIndex = Math.min(fromIndex + 1, frame.track.length - 1);
        rig2.interpolate(
          frame.track[fromIndex],
          frame.track[toIndex],
          framePosition - fromIndex
        );
        if (elapsed >= frame.duration) {
          frameId = null;
          playNext();
        } else {
          frameId = requestFrame(animateTrack);
        }
      };
      const startedAt2 = now();
      animateTrack();
      return;
    }
    const durationMs = frame.duration * 1e3;
    const blendMs = Math.max(1, Math.min(durationMs * 0.35, 150));
    const from = rig2.capture();
    const targets = rig2.createTargets(frame.value);
    const startedAt = now();
    function blend() {
      const elapsed = now() - startedAt;
      const amount = Math.min(elapsed / blendMs, 1);
      rig2.interpolate(from, targets, easeInOut(amount));
      if (amount < 1 && playing) frameId = requestFrame(blend);
      else frameId = null;
    }
    blend();
    timerId = setTimer(playNext, durationMs);
  }
  function play(motion) {
    const frames = normalizeMotionFrames(motion);
    if (frames.length === 0) return false;
    stop();
    queue = frames;
    playing = true;
    playNext();
    return true;
  }
  function enqueue(motion, { key = null } = {}) {
    const frames = normalizeMotionFrames(motion);
    if (frames.length === 0) return false;
    if (key !== null && (key === currentKey || pendingMotions.some((item) => item.key === key))) {
      return false;
    }
    if (!playing) {
      queue = frames;
      currentKey = key;
      playing = true;
      playNext();
    } else {
      pendingMotions = pendingMotions.filter(
        (item) => now() - item.receivedAt <= maxPendingAgeMs
      );
      pendingMotions.push({ frames, key, receivedAt: now() });
      while (pendingMotions.length > maxPendingMotions) pendingMotions.shift();
    }
    return true;
  }
  return {
    play,
    enqueue,
    stop,
    get isPlaying() {
      return playing;
    }
  };
}

// src/avatar/pose-engine.js
function deg(x, y, z) {
  const d = Math.PI / 180;
  return { x: (x || 0) * d, y: (y || 0) * d, z: (z || 0) * d };
}
function frm(pose, dur) {
  return { value: pose, duration: dur || 0.8 };
}
function motionClip(id, frames, metadata = {}) {
  if (!id || !Array.isArray(frames) || frames.length === 0) {
    throw new TypeError("A motion clip requires an id and at least one frame.");
  }
  return {
    id,
    version: 1,
    space: "humanoid-local-v1",
    frames,
    metadata
  };
}

// src/avatar/sign-language-data.js
var FINGERS = ["Index", "Middle", "Ring", "Little"];
function setFinger(pose, side, finger, [proximal, intermediate, distal]) {
  pose[`${side}${finger}Proximal`] = deg(proximal, 0, 0);
  pose[`${side}${finger}Intermediate`] = deg(intermediate, 0, 0);
  pose[`${side}${finger}Distal`] = deg(distal, 0, 0);
}
function setThumb(pose, side, rotations) {
  const [metacarpal, proximal, distal] = rotations;
  pose[`${side}ThumbMetacarpal`] = metacarpal;
  pose[`${side}ThumbProximal`] = proximal;
  pose[`${side}ThumbDistal`] = distal;
}
function handShape(name, side = "right") {
  if (name === "relax") return {};
  const pose = {};
  const mirror = side === "left" ? -1 : 1;
  const fistFinger = [-25, -55, -30];
  const flatFinger = [8, 14, 8];
  const fistThumb = [deg(-10, 0, 0), deg(-20, 0, 0), deg(-10, 0, 0)];
  const flatThumb = [deg(8, 0, 0), deg(14, 0, 0), deg(8, 0, 0)];
  if (name === "fist") {
    for (const finger of FINGERS) setFinger(pose, side, finger, fistFinger);
    setThumb(pose, side, fistThumb);
  } else if (name === "flat") {
    for (const finger of FINGERS) setFinger(pose, side, finger, flatFinger);
    setThumb(pose, side, flatThumb);
  } else if (name === "point") {
    for (const finger of FINGERS) {
      setFinger(
        pose,
        side,
        finger,
        finger === "Index" ? flatFinger : fistFinger
      );
    }
    setThumb(pose, side, fistThumb);
  } else if (name === "thumbUp") {
    for (const finger of FINGERS) setFinger(pose, side, finger, fistFinger);
    setThumb(pose, side, [
      deg(0, 63 * mirror, 63 * mirror),
      deg(0, 0, 0),
      deg(0, 0, 0)
    ]);
  } else if (name === "peace") {
    for (const finger of FINGERS) {
      setFinger(
        pose,
        side,
        finger,
        finger === "Index" || finger === "Middle" ? flatFinger : fistFinger
      );
    }
    setThumb(pose, side, fistThumb);
  } else if (name === "ok") {
    setFinger(pose, side, "Index", [-20, -45, -25]);
    for (const finger of ["Middle", "Ring", "Little"]) {
      setFinger(pose, side, finger, [-15, -35, -20]);
    }
    setThumb(pose, side, [
      deg(-10, 30 * mirror, 0),
      deg(-10, 0, 0),
      deg(0, 0, 0)
    ]);
  }
  return pose;
}
function gesture(arm, shape, lArm, lShape) {
  const p = {};
  p.rightShoulder = deg(arm[0] || 0, arm[1] || 0, arm[2] || 0);
  p.rightUpperArm = deg(arm[3] || 0, arm[4] || 0, arm[5] || 0);
  p.rightLowerArm = deg(arm[6] || 0, arm[7] || 0, arm[8] || 0);
  p.rightHand = deg(arm[9] || 0, arm[10] || 0, arm[11] || 0);
  if (lArm) {
    p.leftShoulder = deg(lArm[0] || 0, lArm[1] || 0, lArm[2] || 0);
    p.leftUpperArm = deg(lArm[3] || 0, lArm[4] || 0, lArm[5] || 0);
    p.leftLowerArm = deg(lArm[6] || 0, lArm[7] || 0, lArm[8] || 0);
    p.leftHand = deg(lArm[9] || 0, lArm[10] || 0, lArm[11] || 0);
  }
  if (shape) {
    const s = handShape(shape, "right");
    for (const k in s) p[k] = s[k];
  }
  if (lShape) {
    const s = handShape(lShape, "left");
    for (const k in s) p[k] = s[k];
  }
  return p;
}
var A = [0, 0, 0, 35, 50, -15, 15, 0, 0, 0, 0, 0];
var AL = [0, 0, 0, 30, 50, -10, 10, 0, 0, 0, 0, 0];
var AT = [0, 0, 0, 55, 5, -10, 20, 0, 0, 0, 10, 10];
var AW = [10, 20, 0, 35, 20, 0, 15, 5, 0, 10, 0, 0];
var AWL = [10, -20, 0, 35, -5, 0, 15, -5, 0, 10, 0, 0];
var AD = [0, 0, 0, 35, 40, -10, 20, 0, 0, 0, -5, 0];
var APL = [0, 0, 0, 40, 50, -15, 20, 0, 0, 5, 0, 0];
var AW2 = [15, 20, 0, 50, 40, -15, 25, 5, 0, 5, 0, 0];
var SIGNS = {
  csl_hello: {
    id: "csl_hello",
    gloss: "\u4F60\u597D",
    texts: ["\u4F60\u597D", "\u60A8\u597D", "\u55E8", "hello", "hi"],
    tags: ["greeting"],
    frames: [frm(gesture(A, "point"), 0.6), frm(gesture(A, "thumbUp"), 0.7)],
    meta: { handshape: "point+thumbUp", location: "chest", movement: "none" }
  },
  csl_thanks: {
    id: "csl_thanks",
    gloss: "\u8C22\u8C22",
    texts: ["\u8C22\u8C22", "\u591A\u8C22", "\u611F\u8C22", "thanks"],
    tags: ["polite"],
    frames: [frm(gesture(AT, "fist"), 0.8)],
    meta: { handshape: "fist", location: "chest", movement: "nod" }
  },
  csl_yes: {
    id: "csl_yes",
    gloss: "\u662F",
    texts: ["\u662F", "\u5BF9", "\u6B63\u786E", "yes", "ok"],
    tags: ["confirm"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "nod" }
  },
  csl_no: {
    id: "csl_no",
    gloss: "\u4E0D",
    texts: ["\u4E0D", "\u6CA1", "\u6CA1\u6709", "\u522B", "no", "not"],
    tags: ["negation"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "chest", movement: "sway" }
  },
  csl_good: {
    id: "csl_good",
    gloss: "\u597D",
    texts: ["\u597D", "\u68D2", "\u4F18\u79C0", "good", "great"],
    tags: ["positive"],
    frames: [frm(gesture(A, "thumbUp"), 0.7)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_me: {
    id: "csl_me",
    gloss: "\u6211",
    texts: ["\u6211", "\u81EA\u5DF1", "me", "I"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 35, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "chest", movement: "self" }
  },
  csl_you: {
    id: "csl_you",
    gloss: "\u4F60",
    texts: ["\u4F60", "\u60A8", "you"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "forward", movement: "none" }
  },
  csl_help: {
    id: "csl_help",
    gloss: "\u5E2E\u52A9",
    texts: ["\u5E2E\u52A9", "\u5E2E\u5FD9", "\u5E2E", "help"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 40, 40, -10, 25, 0, 0, -5, 5, 0], "flat"), 0.7)
    ],
    meta: { handshape: "flat", location: "chest", movement: "support" }
  },
  csl_welcome: {
    id: "csl_welcome",
    gloss: "\u6B22\u8FCE",
    texts: ["\u6B22\u8FCE", "welcome"],
    tags: ["greeting"],
    frames: [frm(gesture(AW, "flat", AWL, "flat"), 0.8)],
    meta: { handshape: "flat", location: "side", movement: "open" }
  },
  csl_love: {
    id: "csl_love",
    gloss: "\u7231",
    texts: ["\u7231", "\u559C\u6B22", "love", "like"],
    tags: ["emotion"],
    frames: [frm(gesture(AL, "fist", AL, "fist"), 0.8)],
    meta: { handshape: "fist", location: "heart", movement: "none" }
  },
  csl_goodbye: {
    id: "csl_goodbye",
    gloss: "\u518D\u89C1",
    texts: ["\u518D\u89C1", "\u62DC\u62DC", "bye", "goodbye"],
    tags: ["greeting"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.6),
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.4),
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.4)
    ],
    meta: { handshape: "flat", location: "side", movement: "wave" }
  },
  csl_happy: {
    id: "csl_happy",
    gloss: "\u5F00\u5FC3",
    texts: ["\u5F00\u5FC3", "\u9AD8\u5174", "\u5FEB\u4E50", "happy"],
    tags: ["emotion"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 0, 0, 0], "flat"), 0.6)
    ],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_true: {
    id: "csl_true",
    gloss: "\u771F",
    texts: ["\u771F", "\u771F\u7684", "\u786E\u5B9E", "true", "really"],
    tags: ["confirm"],
    frames: [frm(gesture(A, "point"), 0.5)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_too: {
    id: "csl_too",
    gloss: "\u592A",
    texts: ["\u592A", "\u5F88", "\u975E\u5E38", "very", "too"],
    tags: ["degree"],
    frames: [frm(gesture(A, "thumbUp"), 0.5)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_what: {
    id: "csl_what",
    gloss: "\u4EC0\u4E48",
    texts: ["\u4EC0\u4E48", "\u5565", "what"],
    tags: ["question"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_he: {
    id: "csl_he",
    gloss: "\u4ED6",
    texts: ["\u4ED6", "\u5979", "\u5B83", "he", "she"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 40, 60, -15, 20, 0, 0, 5, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "side", movement: "none" }
  },
  csl_we: {
    id: "csl_we",
    gloss: "\u6211\u4EEC",
    texts: ["\u6211\u4EEC", "\u54B1\u4EEC", "we", "us"],
    tags: ["pronoun"],
    frames: [
      frm(gesture([0, 0, 0, 30, 40, -10, 20, 0, 0, 5, 0, 0], "point"), 0.7)
    ],
    meta: { handshape: "point", location: "chest", movement: "arc" }
  },
  csl_this: {
    id: "csl_this",
    gloss: "\u8FD9",
    texts: ["\u8FD9", "\u8FD9\u4E2A", "this"],
    tags: ["demonstrative"],
    frames: [frm(gesture(AD, "point"), 0.5)],
    meta: { handshape: "point", location: "down", movement: "none" }
  },
  csl_that: {
    id: "csl_that",
    gloss: "\u90A3",
    texts: ["\u90A3", "\u90A3\u4E2A", "that"],
    tags: ["demonstrative"],
    frames: [
      frm(gesture([0, 0, 0, 40, 60, -15, 20, 0, 0, 5, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "forward", movement: "none" }
  },
  csl_who: {
    id: "csl_who",
    gloss: "\u8C01",
    texts: ["\u8C01", "who"],
    tags: ["question"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_how: {
    id: "csl_how",
    gloss: "\u600E\u4E48",
    texts: ["\u600E\u4E48", "\u600E\u6837", "how"],
    tags: ["question"],
    frames: [frm(gesture(A, "flat"), 0.6)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_where: {
    id: "csl_where",
    gloss: "\u54EA",
    texts: ["\u54EA", "\u54EA\u91CC", "where"],
    tags: ["question"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_have: {
    id: "csl_have",
    gloss: "\u6709",
    texts: ["\u6709", "have", "has"],
    tags: ["state"],
    frames: [frm(gesture(A, "thumbUp"), 0.6)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_can: {
    id: "csl_can",
    gloss: "\u53EF\u4EE5",
    texts: ["\u53EF\u4EE5", "\u80FD", "can", "may"],
    tags: ["modal"],
    frames: [frm(gesture(A, "ok"), 0.6)],
    meta: { handshape: "ok", location: "chest", movement: "nod" }
  },
  csl_want: {
    id: "csl_want",
    gloss: "\u8981",
    texts: ["\u8981", "\u60F3", "want", "need"],
    tags: ["modal"],
    frames: [frm(gesture(A, "flat"), 0.6)],
    meta: { handshape: "flat", location: "chest", movement: "pull" }
  },
  csl_come: {
    id: "csl_come",
    gloss: "\u6765",
    texts: ["\u6765", "\u8FC7\u6765", "come"],
    tags: ["action"],
    frames: [frm(gesture(APL, "flat"), 0.6)],
    meta: { handshape: "flat", location: "side", movement: "beckon" }
  },
  csl_go: {
    id: "csl_go",
    gloss: "\u53BB",
    texts: ["\u53BB", "\u8D70", "go"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 0, 0, 0], "flat"), 0.5)
    ],
    meta: { handshape: "flat", location: "forward", movement: "push" }
  },
  csl_say: {
    id: "csl_say",
    gloss: "\u8BF4",
    texts: ["\u8BF4", "\u8BB2", "say", "speak"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 35, 40, -15, 20, 0, 0, -5, 0, 0], "flat"), 0.6)
    ],
    meta: { handshape: "flat", location: "mouth", movement: "none" }
  },
  csl_see: {
    id: "csl_see",
    gloss: "\u770B",
    texts: ["\u770B", "\u89C1", "see", "look"],
    tags: ["action"],
    frames: [
      frm(gesture([0, 0, 0, 35, 35, -10, 20, 0, 0, 0, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "eyes", movement: "none" }
  },
  csl_know: {
    id: "csl_know",
    gloss: "\u77E5\u9053",
    texts: ["\u77E5\u9053", "\u61C2", "know", "understand"],
    tags: ["cognition"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "temple", movement: "none" }
  },
  csl_big: {
    id: "csl_big",
    gloss: "\u5927",
    texts: ["\u5927", "big", "large"],
    tags: ["size"],
    frames: [frm(gesture(AW2, "flat"), 0.6)],
    meta: { handshape: "flat", location: "side", movement: "spread" }
  },
  csl_small: {
    id: "csl_small",
    gloss: "\u5C0F",
    texts: ["\u5C0F", "small", "little"],
    tags: ["size"],
    frames: [
      frm(gesture([0, 0, 0, 35, 30, -10, 20, 0, 0, 0, 0, 0], "flat"), 0.5)
    ],
    meta: { handshape: "flat", location: "chest", movement: "close" }
  },
  csl_many: {
    id: "csl_many",
    gloss: "\u591A",
    texts: ["\u591A", "\u5F88\u591A", "many", "much"],
    tags: ["quantity"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_up: {
    id: "csl_up",
    gloss: "\u4E0A",
    texts: ["\u4E0A", "up", "above"],
    tags: ["direction"],
    frames: [
      frm(gesture([0, 0, 0, 40, 40, -15, 15, 0, 0, 10, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "up", movement: "none" }
  },
  csl_down: {
    id: "csl_down",
    gloss: "\u4E0B",
    texts: ["\u4E0B", "down", "below"],
    tags: ["direction"],
    frames: [
      frm(gesture([0, 0, 0, 35, 40, -15, 25, 0, 0, -5, 0, 0], "point"), 0.5)
    ],
    meta: { handshape: "point", location: "down", movement: "none" }
  },
  csl_now: {
    id: "csl_now",
    gloss: "\u73B0\u5728",
    texts: ["\u73B0\u5728", "now"],
    tags: ["time"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_today: {
    id: "csl_today",
    gloss: "\u4ECA\u5929",
    texts: ["\u4ECA\u5929", "today"],
    tags: ["time"],
    frames: [frm(gesture(A, "point"), 0.5)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_also: {
    id: "csl_also",
    gloss: "\u4E5F",
    texts: ["\u4E5F", "also", "too"],
    tags: ["conjunction"],
    frames: [frm(gesture(A, "point"), 0.5)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_all: {
    id: "csl_all",
    gloss: "\u90FD",
    texts: ["\u90FD", "\u5168\u90E8", "all"],
    tags: ["quantity"],
    frames: [frm(gesture(AW2, "flat", AWL, "flat"), 0.6)],
    meta: { handshape: "flat", location: "side", movement: "arc" }
  },
  csl_but: {
    id: "csl_but",
    gloss: "\u4F46\u662F",
    texts: ["\u4F46\u662F", "\u4F46", "but"],
    tags: ["conjunction"],
    frames: [frm(gesture(A, "point"), 0.6)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_if: {
    id: "csl_if",
    gloss: "\u5982\u679C",
    texts: ["\u5982\u679C", "\u8981\u662F", "if"],
    tags: ["conjunction"],
    frames: [frm(gesture(A, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_very: {
    id: "csl_very",
    gloss: "\u5F88",
    texts: ["\u5F88", "\u975E\u5E38", "very", "quite"],
    tags: ["degree"],
    frames: [frm(gesture(A, "thumbUp"), 0.5)],
    meta: { handshape: "thumbUp", location: "chest", movement: "none" }
  },
  csl_and: {
    id: "csl_and",
    gloss: "\u548C",
    texts: ["\u548C", "\u8DDF", "\u4E0E", "and"],
    tags: ["conjunction"],
    frames: [
      frm(gesture([0, 0, 0, 35, 40, -15, 20, 0, 0, 5, 0, 0], "flat"), 0.5)
    ],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_new: {
    id: "csl_new",
    gloss: "\u65B0",
    texts: ["\u65B0", "new"],
    tags: ["quality"],
    frames: [frm(gesture(APL, "flat"), 0.5)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_old: {
    id: "csl_old",
    gloss: "\u8001",
    texts: ["\u8001", "\u65E7", "old"],
    tags: ["quality"],
    frames: [frm(gesture(AD, "fist"), 0.5)],
    meta: { handshape: "fist", location: "chest", movement: "none" }
  },
  csl_one: {
    id: "csl_one",
    gloss: "\u4E00",
    texts: ["\u4E00", "one"],
    tags: ["number"],
    frames: [frm(gesture(A, "point"), 0.4)],
    meta: { handshape: "point", location: "chest", movement: "none" }
  },
  csl_two: {
    id: "csl_two",
    gloss: "\u4E8C",
    texts: ["\u4E8C", "\u4E24", "two"],
    tags: ["number"],
    frames: [frm(gesture(A, "peace"), 0.4)],
    meta: { handshape: "peace", location: "chest", movement: "none" }
  },
  csl_three: {
    id: "csl_three",
    gloss: "\u4E09",
    texts: ["\u4E09", "three"],
    tags: ["number"],
    frames: [frm(gesture(A, "ok"), 0.4)],
    meta: { handshape: "ok", location: "chest", movement: "none" }
  },
  csl_please: {
    id: "csl_please",
    gloss: "\u8BF7",
    texts: ["\u8BF7", "please"],
    tags: ["polite"],
    frames: [frm(gesture(APL, "flat"), 0.7)],
    meta: { handshape: "flat", location: "chest", movement: "none" }
  },
  csl_do: {
    id: "csl_do",
    gloss: "\u505A",
    texts: ["\u505A", "\u5E72", "do"],
    tags: ["action"],
    frames: [frm(gesture(A, "fist"), 0.5)],
    meta: { handshape: "fist", location: "chest", movement: "none" }
  },
  csl_people: {
    id: "csl_people",
    gloss: "\u4EBA",
    texts: ["\u4EBA", "person", "people"],
    tags: ["noun"],
    frames: [
      frm(gesture([0, 0, 0, 35, 50, -15, 25, 0, 0, 0, 0, 0], "point"), 0.6)
    ],
    meta: { handshape: "point", location: "side", movement: "none" }
  },
  csl_self: {
    id: "csl_self",
    gloss: "\u81EA\u5DF1",
    texts: ["\u81EA\u5DF1", "self"],
    tags: ["pronoun"],
    frames: [frm(gesture(AL, "fist", AL, "fist"), 0.6)],
    meta: { handshape: "fist", location: "chest", movement: "self" }
  }
};
for (const sign of Object.values(SIGNS)) {
  sign.motion = motionClip(sign.id, sign.frames, {
    gloss: sign.gloss,
    tags: sign.tags,
    ...sign.meta
  });
}
var SINGLE_CHARS = {};
function addChar(c, frames) {
  SINGLE_CHARS[c] = frames;
}
addChar("\u4F60", [frm(gesture(A, "point"), 0.6)]);
addChar("\u597D", [frm(gesture(A, "thumbUp"), 0.7)]);
addChar("\u8C22", [frm(gesture(AT, "fist"), 0.8)]);
addChar("\u6211", [
  frm(gesture([0, 0, 0, 35, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.6)
]);
addChar("\u7231", [frm(gesture(AL, "fist", AL, "fist"), 0.8)]);
addChar("\u662F", [frm(gesture(A, "point"), 0.6)]);
addChar("\u5BF9", [frm(gesture(A, "point"), 0.6)]);
addChar("\u4E0D", [
  frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "point"), 0.5)
]);
addChar("\u5E2E", [
  frm(gesture([0, 0, 0, 40, 40, -10, 25, 0, 0, -5, 5, 0], "flat"), 0.6)
]);
addChar("\u52A9", [
  frm(gesture([0, 0, 0, 40, 40, -10, 25, 0, 0, -5, 5, 0], "flat"), 0.6)
]);
addChar("\u518D", [
  frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.6)
]);
addChar("\u89C1", [
  frm(gesture([0, 0, 0, 40, 50, -15, 25, 0, 0, 5, 0, 0], "flat"), 0.6)
]);
addChar("\u6B22", [frm(gesture(AW, "flat", AWL, "flat"), 0.6)]);
addChar("\u8FCE", [frm(gesture(AW, "flat", AWL, "flat"), 0.6)]);
addChar("\u559C", [frm(gesture(AL, "fist", AL, "fist"), 0.7)]);
addChar(" ", [frm({}, 0.3)]);
function buildLookup() {
  const lookup = {};
  for (const sign of Object.values(SIGNS)) {
    for (const text of sign.texts) {
      if (!lookup[text]) lookup[text] = sign.frames;
    }
  }
  return lookup;
}
function normalizeText(text) {
  if (!text) return "";
  return text.replace(/[，。！？、；："“”（）【】《》\s]+/g, " ").replace(/[^\u4e00-\u9fff\u3400-\u4dbf a-zA-Z0-9'’-]/g, " ").replace(/\s+/g, " ").trim();
}
var FUNCTION_WORDS = /* @__PURE__ */ new Set([
  "\u7684",
  "\u4E86",
  "\u7740",
  "\u8FC7",
  "\u5427",
  "\u5417",
  "\u5462",
  "\u554A",
  "\u561B",
  "\u5457",
  "\u54E6",
  "\u55EF",
  "\u5440",
  "\u5566",
  "\u54C8",
  "\u54C7",
  "\u54CE",
  "\u5582",
  "\u4E2A"
]);
var wordSegmenter = new Intl.Segmenter("zh", { granularity: "word" });
function wordTokens(text) {
  return [...wordSegmenter.segment(text)].filter((token) => token.isWordLike);
}
function translationAliasKey(text) {
  const tokens = wordTokens(normalizeText(text).toLowerCase()).map(
    (token) => token.segment
  );
  return tokens.length ? JSON.stringify(tokens) : "";
}
function compileTranslationMatchers(customMotions = []) {
  return [...Object.values(SIGNS), ...customMotions].flatMap(
    (sign) => sign.texts.map((text) => ({
      id: sign.id,
      sign,
      text: normalizeText(text).toLowerCase(),
      tokens: wordTokens(normalizeText(text).toLowerCase()).map(
        (token) => token.segment
      )
    }))
  ).filter((entry) => entry.text && entry.tokens.length).sort((a, b) => b.text.length - a.text.length);
}
var SIGN_MATCHERS = compileTranslationMatchers();
function neutralGesture() {
  return { frames: [frm({}, 0.5)], matches: [] };
}
function scanDictionaryText(input, maxSigns = 12, matchers = SIGN_MATCHERS) {
  const text = String(input).normalize("NFKC");
  const tokens = [...wordSegmenter.segment(text)];
  const matches = [], unmatched = [], skipped = [];
  let cursor = 0;
  const offset = (index) => [...text.slice(0, index)].length;
  while (cursor < tokens.length && matches.length < maxSigns) {
    const current = tokens[cursor];
    if (!current.isWordLike) {
      if (!/^[\s\p{P}]*$/u.test(current.segment))
        unmatched.push(current.segment);
      cursor++;
      continue;
    }
    let end = cursor;
    const entry = matchers.find((candidate) => {
      let position = cursor;
      for (const expected of candidate.tokens) {
        while (position < tokens.length && !tokens[position].isWordLike && /^[\s\p{P}]*$/u.test(tokens[position].segment))
          position++;
        if (tokens[position]?.segment.toLowerCase() !== expected) return false;
        position++;
      }
      end = position;
      return true;
    });
    const word = current.segment.toLowerCase();
    const sign = entry?.sign;
    const fallback = !entry && SINGLE_CHARS[word];
    if (entry || fallback) {
      if (!entry) end = cursor + 1;
      const last = tokens[end - 1];
      matches.push({
        id: entry?.id || `char_${word}`,
        text: entry?.text || word,
        gloss: sign?.gloss || word,
        frames: sign?.frames || fallback,
        start: offset(current.index),
        end: offset(last.index + last.segment.length)
      });
      cursor = end;
      continue;
    }
    if (FUNCTION_WORDS.has(word)) skipped.push(word);
    else unmatched.push(current.segment);
    cursor++;
  }
  return {
    matches,
    unmatched,
    skipped,
    truncated: cursor < tokens.length,
    remainingText: cursor < tokens.length ? text.slice(tokens[cursor].index) : ""
  };
}
function translateText(subtitleText, maxSigns = 12, matchers = SIGN_MATCHERS) {
  const text = normalizeText(subtitleText).toLowerCase();
  if (!text) return null;
  const result = scanDictionaryText(text, maxSigns, matchers);
  return {
    ...result,
    frames: result.matches.length ? [...result.matches.flatMap((match) => match.frames), frm({}, 0.25)] : neutralGesture().frames,
    matches: result.matches.map(({ id, text: text2, gloss }) => ({ id, text: text2, gloss }))
  };
}
var GESTURES = buildLookup();

// src/avatar/motion-asset.js
var MAX_MOTION_BYTES = 2 * 1024 * 1024;
var MAX_MOTION_FRAMES = 240;
var knownBones = new Set(HUMANOID_BONES);
function invalid(detail, message = "motionInvalidData") {
  const error = new Error(message);
  error.detail = detail;
  throw error;
}
function plainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function boundedText(value, field, limit = 100) {
  if (typeof value !== "string" || !value.trim() || value.length > limit)
    invalid(field);
  return value.trim();
}
function textList(value, field, max = 20) {
  if (!Array.isArray(value) || value.length > max) invalid(field);
  return [...new Set(value.map((text) => boundedText(text, field)))];
}
function createRigBinding(rig2) {
  if (!rig2?.rest || !rig2?.profile) invalid("rig", "motionModelNotReady");
  const rest = Object.keys(rig2.rest).sort().map((name) => {
    const bone = rig2.bones[name];
    const rotation = rig2.rest[name].rotation;
    return [
      name,
      bone.name,
      bone.parent?.name || "",
      rotation.order,
      ...[
        rotation.x,
        rotation.y,
        rotation.z,
        ...bone.position.toArray(),
        ...bone.scale.toArray()
      ].map((value) => Number(value.toFixed(9)))
    ];
  });
  return { profile: rig2.profile.id, rest: JSON.stringify(rest) };
}
function validateMotionAsset(input, rig2) {
  if (!plainObject(input) || input.type !== "signbridge-motion" || input.version !== 1 || input.space !== "humanoid-local-v1" || input.unit !== "radians")
    invalid("type/version/space/unit");
  const id = boundedText(input.id, "id", 90);
  if (!/^custom_[a-zA-Z0-9_-]+$/.test(id)) invalid("id");
  const binding = createRigBinding(rig2);
  if (input.rig?.profile !== binding.profile || input.rig?.rest !== binding.rest)
    invalid("rig", "motionRigMismatch");
  if (!Array.isArray(input.frames) || !input.frames.length || input.frames.length > MAX_MOTION_FRAMES)
    invalid("frames");
  let total = 0;
  const frames = input.frames.map((frame, index) => {
    if (!plainObject(frame?.value) || !Number.isFinite(frame.duration) || frame.duration < 0.05 || frame.duration > 10)
      invalid(`frames[${index}]`);
    total += frame.duration;
    const value = {};
    for (const [name, rotation] of Object.entries(frame.value)) {
      if (!knownBones.has(name) || !rig2.bones[name] || !plainObject(rotation))
        invalid(`frames[${index}].${name}`);
      for (const axis of ["x", "y", "z"]) {
        if (!Number.isFinite(rotation[axis]) || Math.abs(rotation[axis]) > Math.PI * 2)
          invalid(`${name}.${axis}`);
      }
      value[name] = { x: rotation.x, y: rotation.y, z: rotation.z };
    }
    return { value, duration: frame.duration };
  });
  if (total > 120) invalid("duration > 120s");
  return {
    type: "signbridge-motion",
    version: 1,
    id,
    gloss: boundedText(input.gloss, "gloss"),
    texts: textList(input.texts, "texts"),
    tags: textList(input.tags, "tags"),
    space: "humanoid-local-v1",
    unit: "radians",
    rig: binding,
    frames
  };
}
function serializeMotionAsset(asset, round = false) {
  return JSON.stringify(asset, (_key, value) => {
    if (round && typeof value === "number") return Number(value.toFixed(8));
    if (plainObject(value))
      return Object.fromEntries(
        Object.keys(value).sort().map((key) => [key, value[key]])
      );
    return value;
  });
}
function motionIdentity(asset) {
  return serializeMotionAsset(asset, true);
}

// src/avatar/motion-pack.js
var MAX_MOTION_PACK_BYTES = 8 * 1024 * 1024;
var MAX_MOTION_PACK_ASSETS = 500;
function reject(message = "motionPackInvalid") {
  throw new Error(message);
}
function validateMotionPack(input, rig2) {
  if (input?.type !== "signbridge-motion-pack" || input.version !== 1 || typeof input.createdAt !== "string" || !Number.isFinite(Date.parse(input.createdAt)) || !Array.isArray(input.motions))
    reject();
  if (!input.motions.length) reject("motionPackEmpty");
  if (input.motions.length > MAX_MOTION_PACK_ASSETS)
    reject("motionPackTooLarge");
  const ids = /* @__PURE__ */ new Set();
  const motions = input.motions.map((entry) => {
    const asset = validateMotionAsset(entry?.asset, rig2);
    if (ids.has(asset.id)) reject("motionPackDuplicateId");
    ids.add(asset.id);
    if (new Blob([serializeMotionAsset(asset)]).size > MAX_MOTION_BYTES)
      reject("motionPackTooLarge");
    return { asset, wasEnabled: entry.wasEnabled === true };
  });
  const pack = {
    type: "signbridge-motion-pack",
    version: 1,
    createdAt: input.createdAt,
    motions
  };
  if (new Blob([JSON.stringify(pack, null, 2)]).size > MAX_MOTION_PACK_BYTES)
    reject("motionPackTooLarge");
  return pack;
}
function createMotionPack(entries, rig2) {
  return validateMotionPack(
    {
      type: "signbridge-motion-pack",
      version: 1,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      motions: entries.map((entry) => ({
        asset: entry.asset,
        wasEnabled: entry.enabled === true
      }))
    },
    rig2
  );
}
function inspectMotionPack(input, stored, rig2) {
  const pack = validateMotionPack(input, rig2);
  const aliases = /* @__PURE__ */ new Map();
  function addAliases(asset) {
    for (const text of asset.texts) {
      const key = translationAliasKey(text);
      if (!aliases.has(key)) aliases.set(key, /* @__PURE__ */ new Set());
      aliases.get(key).add(asset.id);
    }
  }
  Object.values(SIGNS).forEach(addAliases);
  const valid = /* @__PURE__ */ new Map();
  for (const [id, entry] of Object.entries(stored)) {
    try {
      const asset = validateMotionAsset(entry?.asset, rig2);
      if (asset.id !== id) continue;
      valid.set(id, asset);
      addAliases(asset);
    } catch {
      continue;
    }
  }
  pack.motions.forEach((entry) => addAliases(entry.asset));
  const counts = { new: 0, existing: 0, conflict: 0 };
  const items = pack.motions.map(({ asset, wasEnabled }) => {
    let state = "new";
    if (Object.hasOwn(stored, asset.id)) {
      state = valid.has(asset.id) && serializeMotionAsset(valid.get(asset.id)) === serializeMotionAsset(asset) ? "existing" : "conflict";
    }
    counts[state] += 1;
    return {
      id: asset.id,
      gloss: asset.gloss,
      state,
      wasEnabled,
      aliasConflicts: asset.texts.filter((text) => {
        const key = translationAliasKey(text);
        return !key || [...aliases.get(key)].some((id) => id !== asset.id);
      }),
      emptyTexts: asset.texts.length === 0
    };
  });
  return { pack, items, counts, revision: serializeMotionAsset(stored) };
}

// src/avatar/motion-library.js
var MOTION_STORAGE_PREFIX = "signbridge.motion.v1.";
var normalizedAlias = translationAliasKey;
var builtinAliases = new Set(
  Object.values(SIGNS).flatMap((sign) => sign.texts.map(normalizedAlias))
);
function motionError(message, detail = "") {
  const error = new Error(message);
  error.detail = detail;
  return error;
}
function isConfirmed(entry) {
  return entry.enabled === true && typeof entry.review?.confirmedAt === "string" && entry.review.assetJson === serializeMotionAsset(entry.asset);
}
function aliasConflict(asset, aliases) {
  if (!asset.texts.length) return "texts";
  return asset.texts.find(
    (text) => !normalizedAlias(text) || aliases.has(normalizedAlias(text))
  ) ?? null;
}
function selectEnabledMotions(entries) {
  const used = new Set(builtinAliases);
  const motions = [];
  for (const entry of [...entries].sort(
    (first, second) => first.asset.id.localeCompare(second.asset.id)
  )) {
    if (!isConfirmed(entry) || aliasConflict(entry.asset, used) !== null)
      continue;
    motions.push(entry.asset);
    entry.asset.texts.forEach((text) => used.add(normalizedAlias(text)));
  }
  return motions;
}
function createMotionLibrary(rig2, storage = globalThis.chrome?.storage, locks = globalThis.navigator?.locks) {
  if (!storage?.local) throw motionError("motionStorageUnavailable");
  const area = storage.local;
  const write = (operation) => locks ? locks.request(MOTION_STORAGE_PREFIX, operation) : operation();
  async function list() {
    const values = await area.get(null);
    const entries = [];
    let invalidCount = 0;
    for (const [key, stored] of Object.entries(values)) {
      if (!key.startsWith(MOTION_STORAGE_PREFIX)) continue;
      try {
        const asset = validateMotionAsset(stored.asset, rig2);
        if (key !== MOTION_STORAGE_PREFIX + asset.id)
          throw motionError("motionInvalidData");
        entries.push({
          asset,
          enabled: isConfirmed({ ...stored, asset }),
          review: stored.review
        });
      } catch {
        invalidCount += 1;
      }
    }
    return { entries, invalidCount };
  }
  async function saveDraft(input) {
    const asset = validateMotionAsset(input, rig2);
    const entry = { asset, enabled: false, review: null };
    await write(() => area.set({ [MOTION_STORAGE_PREFIX + asset.id]: entry }));
    return entry;
  }
  async function setEnabled(id, enabled, expectedAsset) {
    return write(async () => {
      const { entries } = await list();
      const entry = entries.find((candidate) => candidate.asset.id === id);
      if (!entry) throw motionError("motionSelectFirst");
      if (enabled) {
        if (motionIdentity(entry.asset) !== motionIdentity(expectedAsset))
          throw motionError("motionSaveFirst");
        const aliases = new Set(builtinAliases);
        for (const other of entries) {
          if (other.asset.id !== id && isConfirmed(other))
            other.asset.texts.forEach(
              (text) => aliases.add(normalizedAlias(text))
            );
        }
        const conflict = aliasConflict(entry.asset, aliases);
        if (conflict !== null)
          throw motionError("motionAliasConflict", conflict);
      }
      await area.set({
        [MOTION_STORAGE_PREFIX + id]: {
          asset: entry.asset,
          enabled,
          review: enabled ? {
            confirmedAt: (/* @__PURE__ */ new Date()).toISOString(),
            assetJson: serializeMotionAsset(entry.asset)
          } : null
        }
      });
    });
  }
  async function storedMotions() {
    const values = await area.get(null);
    return Object.fromEntries(
      Object.entries(values).filter(([key]) => key.startsWith(MOTION_STORAGE_PREFIX)).map(([key, value]) => [
        key.slice(MOTION_STORAGE_PREFIX.length),
        value
      ])
    );
  }
  async function exportPack() {
    const { entries, invalidCount } = await list();
    if (invalidCount) throw motionError("motionPackInvalidStored");
    return createMotionPack(entries, rig2);
  }
  async function previewPack(input) {
    const pack = validateMotionPack(input, rig2);
    return inspectMotionPack(pack, await storedMotions(), rig2);
  }
  async function importPack(input, expectedRevision) {
    if (!locks?.request) throw motionError("motionPackLockUnavailable");
    const pack = validateMotionPack(input, rig2);
    return write(async () => {
      const plan = inspectMotionPack(pack, await storedMotions(), rig2);
      if (plan.revision !== expectedRevision)
        throw motionError("motionPackStale");
      if (plan.counts.conflict) throw motionError("motionPackConflict");
      const newIds = new Set(
        plan.items.filter((item) => item.state === "new").map((item) => item.id)
      );
      const updates = Object.fromEntries(
        pack.motions.filter(({ asset }) => newIds.has(asset.id)).map(({ asset }) => [
          MOTION_STORAGE_PREFIX + asset.id,
          { asset, enabled: false, review: null }
        ])
      );
      if (newIds.size) await area.set(updates);
      return { imported: newIds.size, skipped: plan.counts.existing };
    });
  }
  function subscribe(listener) {
    const handler = (changes, areaName) => {
      if (areaName === "local" && Object.keys(changes).some(
        (key) => key.startsWith(MOTION_STORAGE_PREFIX)
      ))
        listener();
    };
    storage.onChanged.addListener(handler);
    return () => storage.onChanged.removeListener(handler);
  }
  return {
    list,
    saveDraft,
    setEnabled,
    subscribe,
    exportPack,
    previewPack,
    importPack
  };
}

// src/i18n/locales.js
var WORKBENCH_ZH = {
  optimizationAdaptiveWarning: "\u81EA\u9002\u5E94\u8FC7\u6EE4\u4EC5\u4E3A\u7814\u7A76\u5BF9\u7167\uFF1A\u516D\u627995\u6761\u52A8\u4F5C\u672A\u6709\u7247\u6BB5\u540C\u65F6\u901A\u8FC7\u6296\u52A8\u3001\u624B\u8155\u4E0E\u52A8\u4F5C\u8303\u56F4\u6570\u503C\u95E8\u69DB\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u5E94\u7528\u3002\u9010\u6761\u590D\u6838\u524D\u8BF7\u4FDD\u7559\u539F\u65B9\u6848\u6216\u539F\u59CB\u663E\u793A\u3002",
  optimizationDisplayProfile: "\u663E\u793A\u8FC7\u6EE4\u5BF9\u7167",
  optimizationAssetProfile: "\u539F\u6709\u914D\u7F6E\uFF08\u9ED8\u8BA4\uFF09",
  optimizationAdaptiveProfile: "\u5B9E\u9A8C\u5BF9\u7167\uFF1A\u5B64\u7ACB\u5C16\u5CF0\uFF0C\u975E\u63A8\u8350\u914D\u7F6E",
  workbenchCatalogCount: "\u5F53\u524D\u53EF\u9009 {count} \u6761\u3002\u5339\u914D\u8868\u793A\u6709\u52A8\u4F5C\u6570\u636E\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u542B\u4E49\u5DF2\u6838\u51C6\u3002",
  workbenchScope: "\u7814\u7A76\u6F14\u793A\uFF1A\u5F53\u524D\u64AD\u653E\u5DF2\u6709\u52A8\u4F5C\u3002\u672A\u8986\u76D6\u5185\u5BB9\u4F1A\u63D0\u793A\uFF1B\u52A8\u4F5C\u64AD\u653E\u4E0D\u4EE3\u8868\u6587\u5B57\u5DF2\u88AB\u7406\u89E3\u3002",
  workbenchServiceHandoff: "\u610F\u601D\u5206\u6790\u7531\u672C\u673A\u670D\u52A1\u63D0\u4F9B\u3002\u6309\u94AE\u4F1A\u5148\u68C0\u67E5\u670D\u52A1\u662F\u5426\u5DF2\u542F\u52A8\uFF1B\u8DF3\u8F6C\u4E0D\u643A\u5E26\u53E3\u4EE4\u6216\u8F93\u5165\u6587\u5B57\u3002",
  workbenchOpenService: "\u6253\u5F00\u672C\u673A\u670D\u52A1\u5206\u6790\u9875",
  workbenchCsl: "\u5F53\u524D\u652F\u6301\uFF1A\u4E2D\u56FD\u624B\u8BED",
  workbenchTextPreview: "\u6587\u5B57\u9884\u89C8",
  workbenchOpen: "\u6253\u5F00\u5DE5\u4F5C\u53F0",
  workbenchSettings: "SignBridge \u8BBE\u7F6E",
  workbenchSettingsLead: "\u663E\u793A\u4E0E\u58F0\u97F3\u7EDF\u4E00\u8BBE\u7F6E\u3002\u7F51\u9875\u5B57\u5E55\u6309\u4E2D\u6587\u8BFB\u53D6\uFF0C\u58F0\u97F3\u8BC6\u522B\u53EF\u5355\u72EC\u914D\u7F6E\u8BED\u8A00\u3002",
  workbenchDisplay: "\u663E\u793A",
  workbenchSystemLanguage: "\u8DDF\u968F\u7CFB\u7EDF",
  workbenchChinese: "\u4E2D\u6587",
  workbenchLocaleChinese: "\u7B80\u4F53\u4E2D\u6587",
  workbenchLocaleEnglish: "English",
  workbenchLocaleJapanese: "\u65E5\u672C\u8A9E",
  workbenchAsrLead: "\u65E0\u5B57\u5E55\u65F6\u53EF\u5728\u63D2\u4EF6\u4E2D\u4E3B\u52A8\u5F00\u542F\u58F0\u97F3\u8BC6\u522B\u3002\u9ED8\u8BA4\u4F7F\u7528\u672C\u5730 Whisper\uFF1B\u4E0B\u8F7D\u6A21\u578B\u4E0D\u4F1A\u81EA\u52A8\u5F00\u59CB\u5F55\u97F3\u3002",
  workbenchAdvancedAsr: "\u9AD8\u7EA7\u58F0\u97F3\u8BBE\u7F6E\uFF1A\u8BC6\u522B\u65B9\u5F0F\u3001\u6A21\u578B\u4E0E\u97F3\u9891\u53C2\u6570",
  workbenchSettingsSaved: "\u663E\u793A\u548C\u58F0\u97F3\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002\u5DF2\u6253\u5F00\u7684\u865A\u62DF\u4EBA\u5927\u5C0F\u540C\u6B65\u66F4\u65B0\uFF1B\u754C\u9762\u8BED\u8A00\u91CD\u65B0\u6253\u5F00\u76F8\u5173\u9875\u9762\u540E\u751F\u6548\u3002",
  workbenchTasks: "\u5DE5\u4F5C\u53F0\u4EFB\u52A1",
  workbenchMotion: "\u52A8\u4F5C\u6F14\u793A",
  workbenchMeaning: "\u610F\u601D\u5206\u6790\uFF08\u8BAD\u7EC3\u6A21\u578B\uFF09",
  workbenchResearch: "\u7814\u7A76\u5DE5\u5177\u4E0E\u6280\u672F\u8BE6\u60C5",
  workbenchResearchLead: "\u5236\u4F5C\u548C\u6838\u9A8C\u5DF2\u6709\u52A8\u4F5C\uFF0C\u67E5\u770B\u6765\u6E90\u6216\u6BD4\u8F83\u89C4\u5219\u5206\u6790\u3002\u8FD9\u91CC\u7684\u5DE5\u5177\u4E0D\u4F1A\u81EA\u52A8\u4EA7\u751F\u4E2D\u56FD\u624B\u8BED\u6279\u51C6\u3002",
  workbenchTools: "\u52A8\u4F5C\u5236\u4F5C\u4E0E\u68C0\u67E5",
  workbenchExtensionTools: "\u52A8\u4F5C\u5236\u4F5C\u3001\u8986\u76D6\uFF0F\u8865\u8BCD\u4E0E\u9A8C\u6536\u5DE5\u5177\u9700\u8981 Chrome \u6269\u5C55\u73AF\u5883\u3002\u8BF7\u52A0\u8F7D\u672C\u6B21\u6784\u5EFA\u7684\u6269\u5C55\u76EE\u5F55\uFF0C\u518D\u4ECE\u63D2\u4EF6\u6253\u5F00\u5DE5\u4F5C\u53F0\u3002",
  workbenchAuthoring: "\u52A8\u4F5C\u5236\u4F5C",
  workbenchPose: "\u7F16\u8F91\u5355\u5E27\u59FF\u52BF",
  workbenchSequence: "\u7F16\u6392\u591A\u5E27\u52A8\u4F5C",
  workbenchRouting: "\u6765\u6E90\u9009\u62E9\u4E0E\u89C4\u5219\u5BF9\u7167",
  workbenchModeAutoDescription: "\u81EA\u52A8\u5339\u914D\uFF1A\u4F18\u5148\u4F7F\u7528\u5B8C\u6574\u53C2\u8003\u53E5\uFF0C\u518D\u6309\u53EF\u7528\u52A8\u4F5C\u8865\u9F50\u8BCD\u5E93\u7247\u6BB5\uFF1B\u7F3A\u5931\u5185\u5BB9\u4F1A\u6807\u51FA\uFF0C\u4E0D\u4F1A\u9759\u9ED8\u66FF\u6362\u3002",
  workbenchModeT08Description: "\u53C2\u8003\u4E0E\u5B9E\u9A8C\u52A8\u4F5C\uFF1A\u53EA\u7B5B\u9009\u5DF2\u6709 T08 \u53C2\u8003\u548C\u62DF\u5408\u5019\u9009\uFF0C\u4E0D\u56DE\u9000\u5230\u5185\u7F6E\u8BCD\u5E93\uFF1B\u5019\u9009\u4E0D\u4EE3\u8868\u8BED\u4E49\u6216\u52A8\u4F5C\u8D28\u91CF\u5DF2\u6279\u51C6\u3002",
  workbenchModeDictionaryDescription: "\u5185\u7F6E\u8BCD\u5E93\uFF1A\u4EC5\u4F7F\u7528\u5DF2\u6536\u5F55\u7684\u8BCD\u6761\u52A8\u4F5C\u3002\u5F53\u524D\u5DF2\u5207\u5230\u8BCD\u6761\u76EE\u5F55\uFF0C\u4E0D\u8C03\u7528 T08 \u53C2\u8003\u53E5\u3002",
  workbenchModeSemanticDescription: "\u89C4\u5219\u7814\u7A76\u4EC5\u663E\u793A\u4E2D\u6587\u89E3\u6790\u8349\u6848\uFF0C\u4E0D\u64AD\u653E\u52A8\u4F5C\uFF0C\u4E5F\u4E0D\u8C03\u7528\u8BAD\u7EC3\u89D2\u8272\u6A21\u578B\u3002",
  workbenchPresentation: "\u89C6\u89D2\u4E0E\u663E\u793A\u5904\u7406",
  workbenchRuleOnly: "\u5F53\u524D\u4E3A\u89C4\u5219\u5206\u6790\u5BF9\u7167\uFF0C\u53EA\u8F93\u51FA\u8349\u6848\uFF1B\u4E0D\u8FDE\u63A5\u8BAD\u7EC3\u6A21\u578B\uFF0C\u4E5F\u4E0D\u64AD\u653E\u52A8\u4F5C\u3002",
  workbenchForcedSource: "\u5F53\u524D\u9650\u5B9A\u4E86\u52A8\u4F5C\u6765\u6E90\u3002\u5173\u95ED\u7814\u7A76\u533A\u57DF\u5373\u53EF\u6062\u590D\u81EA\u52A8\u5339\u914D\u3002",
  workbenchStart: "\u5F00\u59CB\u5B57\u5E55\u8F85\u52A9",
  workbenchStop: "\u505C\u6B62\u8F85\u52A9",
  workbenchRunning: "\u5B57\u5E55\u8F85\u52A9\u4E2D"
};
var WORKBENCH_EN = {
  optimizationAdaptiveWarning: "Adaptive filtering is comparison-only: 0 of 95 motions met the combined jitter, wrist and range gate. It is never applied automatically.",
  optimizationDisplayProfile: "Display filter comparison",
  optimizationAssetProfile: "Asset profile (default)",
  optimizationAdaptiveProfile: "Experimental isolated-spike filter",
  workbenchCatalogCount: "{count} entries available. Matching indicates motion data, not linguistic approval.",
  workbenchScope: "Research demo: plays existing motions and reports gaps. Meaning analysis and motion playback are separate tasks.",
  workbenchServiceHandoff: "Meaning analysis runs in the local service. Open its analysis page and enter the token there. Navigation carries no token or input text.",
  workbenchOpenService: "Open local analysis service",
  workbenchCsl: "Supported: Chinese Sign Language",
  workbenchTextPreview: "Text preview",
  workbenchOpen: "Open workspace",
  workbenchSettings: "SignBridge settings",
  workbenchSettingsLead: "Display and audio in one place. Subtitles are read as Chinese; ASR language is configured separately.",
  workbenchDisplay: "Display",
  workbenchSystemLanguage: "Use system language",
  workbenchChinese: "Chinese",
  workbenchLocaleChinese: "\u7B80\u4F53\u4E2D\u6587",
  workbenchLocaleEnglish: "English",
  workbenchLocaleJapanese: "\u65E5\u672C\u8A9E",
  workbenchAsrLead: "Enable audio recognition from the extension when subtitles are unavailable. Local Whisper is the default; downloading a model does not start recording.",
  workbenchAdvancedAsr: "Advanced audio: provider, model and capture settings",
  workbenchSettingsSaved: "Display and audio settings saved. Open avatars resize now; reopen other pages to apply the interface language.",
  workbenchTasks: "Workspace tasks",
  workbenchMotion: "Motion preview",
  workbenchMeaning: "Meaning analysis (trained model)",
  workbenchResearch: "Research tools and technical details",
  workbenchResearchLead: "Create and review existing motions, inspect sources or compare rule analysis. These tools never grant CSL approval automatically.",
  workbenchTools: "Motion creation and checks",
  workbenchExtensionTools: "Motion creation, coverage and review require the Chrome extension. Load this build as an extension and open the workspace from its popup.",
  workbenchAuthoring: "Create motions",
  workbenchPose: "Edit a single pose",
  workbenchSequence: "Arrange motion frames",
  workbenchRouting: "Source selection and rule comparison",
  workbenchModeAutoDescription: "Automatic matching: prefer complete reference phrases, then fill gaps with available dictionary entries. Unsupported text remains visible.",
  workbenchModeT08Description: "Reference and experimental motions: use existing T08 references and fit candidates only; do not fall back to dictionary motions.",
  workbenchModeDictionaryDescription: "Built-in dictionary: use recorded word motions only. The catalog switches to word entries and excludes T08 phrase references.",
  workbenchModeSemanticDescription: "Rule research shows a Chinese analysis draft only; it does not play motion or call the trained role model.",
  workbenchPresentation: "View and display processing",
  workbenchRuleOnly: "Rule comparison produces a draft only. It does not connect to the trained model or play motion.",
  workbenchForcedSource: "Motion sources are restricted. Close research details to restore automatic matching.",
  workbenchStart: "Start subtitle assistance",
  workbenchStop: "Stop assistance",
  workbenchRunning: "Subtitle assistance active"
};
var WORKBENCH_JA = {
  optimizationAdaptiveWarning: "\u9069\u5FDC\u578B\u30D5\u30A3\u30EB\u30BF\u30FC\u306F\u6BD4\u8F03\u5C02\u7528\u3067\u3059\u300295\u4EF6\u4E2D\u3001\u63FA\u308C\u30FB\u624B\u9996\u30FB\u52D5\u4F5C\u7BC4\u56F2\u306E\u57FA\u6E96\u3092\u3059\u3079\u3066\u6E80\u305F\u3057\u305F\u3082\u306E\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u81EA\u52D5\u9069\u7528\u3055\u308C\u307E\u305B\u3093\u3002",
  optimizationDisplayProfile: "\u8868\u793A\u30D5\u30A3\u30EB\u30BF\u30FC\u6BD4\u8F03",
  optimizationAssetProfile: "\u65E2\u5B58\u8A2D\u5B9A\uFF08\u65E2\u5B9A\uFF09",
  optimizationAdaptiveProfile: "\u5B9F\u9A13\uFF1A\u5B64\u7ACB\u30B9\u30D1\u30A4\u30AF\u9664\u53BB",
  workbenchCatalogCount: "\u9078\u629E\u53EF\u80FD\uFF1A{count} \u4EF6\u3002\u4E00\u81F4\u306F\u52D5\u4F5C\u30C7\u30FC\u30BF\u306E\u5B58\u5728\u3092\u793A\u3057\u3001\u624B\u8A71\u306E\u610F\u5473\u306E\u627F\u8A8D\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
  workbenchScope: "\u7814\u7A76\u30C7\u30E2\uFF1A\u65E2\u5B58\u306E\u52D5\u4F5C\u3092\u518D\u751F\u3057\u3001\u672A\u5BFE\u5FDC\u306E\u5185\u5BB9\u3092\u8868\u793A\u3057\u307E\u3059\u3002\u610F\u5473\u5206\u6790\u3068\u52D5\u4F5C\u518D\u751F\u306F\u5225\u3005\u306E\u64CD\u4F5C\u3067\u3059\u3002",
  workbenchServiceHandoff: "\u30D6\u30E9\u30A6\u30B6\u30FC\u306E\u30C7\u30E2\u3068\u63A8\u8AD6\u30B5\u30FC\u30D3\u30B9\u306E\u30DD\u30FC\u30C8\u304C\u7570\u306A\u308B\u5834\u5408\u3001\u30B5\u30FC\u30D3\u30B9\u306E\u5206\u6790\u30DA\u30FC\u30B8\u3092\u958B\u3044\u3066\u53E3\u4EE4\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u79FB\u52D5\u6642\u306B\u53E3\u4EE4\u3084\u5165\u529B\u6587\u306F\u9001\u308A\u307E\u305B\u3093\u3002",
  workbenchOpenService: "\u30ED\u30FC\u30AB\u30EB\u5206\u6790\u30B5\u30FC\u30D3\u30B9\u3092\u958B\u304F",
  workbenchCsl: "\u5BFE\u5FDC\uFF1A \u4E2D\u56FD\u624B\u8A71",
  workbenchTextPreview: "\u30C6\u30AD\u30B9\u30C8\u306E\u30D7\u30EC\u30D3\u30E5\u30FC",
  workbenchOpen: "\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9\u3092\u958B\u304F",
  workbenchSettings: "SignBridge \u8A2D\u5B9A",
  workbenchSettingsLead: "Display and audio in one place. Subtitles are read as Chinese; ASR language is configured separately.",
  workbenchDisplay: "\u8868\u793A",
  workbenchSystemLanguage: "\u30B7\u30B9\u30C6\u30E0\u8A00\u8A9E\u306B\u5408\u308F\u305B\u308B",
  workbenchChinese: "\u4E2D\u56FD\u8A9E",
  workbenchLocaleChinese: "\u7B80\u4F53\u4E2D\u6587",
  workbenchLocaleEnglish: "English",
  workbenchLocaleJapanese: "\u65E5\u672C\u8A9E",
  workbenchAsrLead: "Enable audio recognition from the extension when subtitles are unavailable. Local Whisper is the default; downloading a model does not start recording.",
  workbenchAdvancedAsr: "Advanced audio: provider, model and capture settings",
  workbenchSettingsSaved: "Display and audio settings saved. Open avatars resize now; reopen other pages to apply the interface language.",
  workbenchTasks: "\u30EF\u30FC\u30AF\u30B9\u30DA\u30FC\u30B9\u306E\u64CD\u4F5C",
  workbenchMotion: "\u52D5\u4F5C\u30D7\u30EC\u30D3\u30E5\u30FC",
  workbenchMeaning: "\u610F\u5473\u5206\u6790\uFF08\u5B66\u7FD2\u6E08\u307F\u30E2\u30C7\u30EB\uFF09",
  workbenchResearch: "\u7814\u7A76\u30C4\u30FC\u30EB\u3068\u6280\u8853\u60C5\u5831",
  workbenchResearchLead: "Create and review existing motions, inspect sources or compare rule analysis. These tools never grant CSL approval automatically.",
  workbenchTools: "\u52D5\u4F5C\u306E\u4F5C\u6210\u3068\u78BA\u8A8D",
  workbenchExtensionTools: "Motion creation, coverage and review require the Chrome extension. Load this build as an extension and open the workspace from its popup.",
  workbenchAuthoring: "\u52D5\u4F5C\u3092\u4F5C\u6210",
  workbenchPose: "\u5358\u4E00\u59FF\u52E2\u306E\u7DE8\u96C6",
  workbenchSequence: "\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306E\u7DE8\u6210",
  workbenchRouting: "\u52D5\u4F5C\u30BD\u30FC\u30B9\u3068\u898F\u5247\u306E\u6BD4\u8F03",
  workbenchModeAutoDescription: "\u81EA\u52D5\u7167\u5408\uFF1A\u6587\u5168\u4F53\u306E\u53C2\u8003\u52D5\u4F5C\u3092\u512A\u5148\u3057\u3001\u4E0D\u8DB3\u5206\u3092\u5229\u7528\u53EF\u80FD\u306A\u8F9E\u66F8\u52D5\u4F5C\u3067\u88DC\u3044\u307E\u3059\u3002\u5BFE\u5FDC\u3067\u304D\u306A\u3044\u6587\u5B57\u306F\u8868\u793A\u3057\u307E\u3059\u3002",
  workbenchModeT08Description: "\u53C2\u8003\u30FB\u5B9F\u9A13\u52D5\u4F5C\uFF1A\u65E2\u5B58\u306ET08\u53C2\u8003\u52D5\u4F5C\u3068\u30D5\u30A3\u30C3\u30C8\u5019\u88DC\u306E\u307F\u3092\u4F7F\u3044\u3001\u8F9E\u66F8\u52D5\u4F5C\u306B\u306F\u30D5\u30A9\u30FC\u30EB\u30D0\u30C3\u30AF\u3057\u307E\u305B\u3093\u3002",
  workbenchModeDictionaryDescription: "\u5185\u8535\u8F9E\u66F8\uFF1A\u767B\u9332\u6E08\u307F\u5358\u8A9E\u52D5\u4F5C\u306E\u307F\u3092\u4F7F\u3044\u307E\u3059\u3002\u30AB\u30BF\u30ED\u30B0\u3092\u5358\u8A9E\u4E00\u89A7\u306B\u5207\u308A\u66FF\u3048\u3001T08\u6587\u5168\u4F53\u306E\u53C2\u8003\u52D5\u4F5C\u306F\u9664\u5916\u3057\u307E\u3059\u3002",
  workbenchModeSemanticDescription: "\u898F\u5247\u7814\u7A76\u306F\u4E2D\u56FD\u8A9E\u306E\u89E3\u6790\u6848\u3092\u8868\u793A\u3059\u308B\u3060\u3051\u3067\u3059\u3002\u52D5\u4F5C\u3092\u518D\u751F\u305B\u305A\u3001\u5B66\u7FD2\u6E08\u307F\u5F79\u5272\u30E2\u30C7\u30EB\u3082\u547C\u3073\u51FA\u3057\u307E\u305B\u3093\u3002",
  workbenchPresentation: "\u8996\u70B9\u3068\u8868\u793A\u51E6\u7406",
  workbenchRuleOnly: "Rule comparison produces a draft only. It does not connect to the trained model or play motion.",
  workbenchForcedSource: "Motion sources are restricted. Close research details to restore automatic matching.",
  workbenchStart: "\u5B57\u5E55\u652F\u63F4\u3092\u958B\u59CB",
  workbenchStop: "\u652F\u63F4\u3092\u505C\u6B62",
  workbenchRunning: "\u5B57\u5E55\u652F\u63F4\u4E2D"
};
var PRIVATE_ZH = {
  privateScopeExperiment: "\u4F5C\u7528\u57DF\u5BF9\u7167\u5B9E\u9A8C\uFF1A\u590D\u7528\u51BB\u7ED3\u89D2\u8272\u6743\u91CD\uFF0C\u4EC5\u52A0\u53D7\u9650\u4E8B\u4EF6\u7ED3\u6784\u7EA6\u675F\uFF1B\u8FD9\u662F\u5408\u6210\u4E2D\u6587\u5DE5\u7A0B\u8BC4\u4F30\uFF0C\u4E0D\u662F\u4E2D\u56FD\u624B\u8BED\u7406\u89E3\u6216\u51C6\u786E\u7387\u3002",
  privateScopeAnalyzed: "\u4F5C\u7528\u57DF\u7ED3\u6784\u5DF2\u89E3\u6790\uFF1B\u52A8\u4F5C\u4ECD\u9700\u4E2D\u56FD\u624B\u8BED\u8BCD\u7EA7\u3001\u7A7A\u95F4\u548C\u975E\u624B\u90E8\u5BF9\u9F50\u5BA1\u6838\u3002",
  privateEventStructure: "\u4E8B\u4EF6\u4E0E\u4F5C\u7528\u57DF\uFF08\u51BB\u7ED3\u6A21\u578B\uFF0B\u7ED3\u6784\u7EA6\u675F\u5B9E\u9A8C\uFF09",
  privatePlanEvidence: "\u8BED\u4E49\u7EC4\u6210\uFF1A{components}\u3002\u7F3A\u5C11\u5019\u9009\u8BC1\u636E\uFF1A{gaps}\u3002\u5019\u9009\u5747\u5F85\u624B\u8BED\u5BF9\u9F50\u590D\u6838\uFF0C\u4E0D\u751F\u6210\u6216\u64AD\u653E\u52A8\u4F5C\u3002",
  privatePlanReview: "\u5168\u90E8\u4ECD\u9700\u6838\u51C6",
  privateTitle: "SignBridge \xB7 \u4E2D\u56FD\u624B\u8BED\u7406\u89E3\u7814\u7A76\u7248",
  privateScope: "\u5F53\u524D\u5DF2\u8BAD\u7EC3\uFF1A\u53D7\u9650\u4E2D\u6587\u8BED\u4E49\u89D2\u8272\u89E3\u6790\u3002\u8BAD\u7EC3\u6807\u7B7E\u4E3A\u52A9\u624B\u5408\u6210\u4E2D\u6587\u793A\u4F8B\uFF0C\u5C1A\u672A\u8BAD\u7EC3\u51FA\u4E2D\u56FD\u624B\u8BED\u7FFB\u8BD1\u6216\u89C6\u9891\u8BC6\u522B\u80FD\u529B\u3002",
  privateEndpoint: "\u672C\u673A\u63A8\u7406\u670D\u52A1\u5730\u5740",
  privateToken: "\u672C\u6B21\u670D\u52A1\u7684\u4F1A\u8BDD\u53E3\u4EE4",
  privateTokenHelp: "\u53E3\u4EE4\u7531\u672C\u673A\u670D\u52A1\u7EC8\u7AEF\u751F\u6210\uFF0C\u4EC5\u5728\u672C\u9875\u9762\u5185\u5B58\u4E2D\u4F7F\u7528\uFF1B\u91CD\u542F\u670D\u52A1\u540E\u5931\u6548\u3002",
  privateSentence: "\u8F93\u5165\u4E00\u53E5\u4E2D\u6587\uFF08\u6700\u591A500\u5B57\uFF09",
  privateAnalyze: "\u89E3\u6790\u610F\u601D",
  privateDisconnect: "\u6E05\u7A7A\u4F1A\u8BDD",
  privateResult: "\u8BED\u4E49\u89E3\u6790\u7ED3\u679C",
  privateWaiting: "\u542F\u52A8\u672C\u673A\u670D\u52A1\u5E76\u586B\u5199\u4F1A\u8BDD\u53E3\u4EE4\u540E\u53EF\u89E3\u6790\u3002",
  privateAnalyzing: "\u6B63\u5728\u8C03\u7528\u672C\u673A\u8BAD\u7EC3\u6A21\u578B\u2026",
  privateParsed: "\u5DF2\u89E3\u6790\u89D2\u8272\uFF1B\u5C1A\u9700\u4E2D\u56FD\u624B\u8BED\u52A8\u4F5C\u5BF9\u9F50\u4E0E\u8868\u8FBE\u6838\u9A8C\u3002",
  privateAbstained: "\u8BE5\u53E5\u8D85\u51FA\u5DF2\u8BAD\u7EC3\u8303\u56F4\u6216\u5B58\u5728\u6B67\u4E49\uFF1B\u5DF2\u505C\u6B62\u89E3\u6790\uFF0C\u8BF7\u4FDD\u7559\u539F\u6587\u3002",
  privateMotionGap: "\u624B\u8BED\u8F93\u51FA\u6682\u672A\u542F\u7528\uFF1A\u8BCD\u7EA7\u52A8\u4F5C\u8FB9\u754C\u3001\u7A7A\u95F4\u6307\u4EE3\u548C\u975E\u624B\u90E8\u8868\u8FBE\u4ECD\u9700\u6838\u5BF9\u3002\u8FD9\u91CC\u4E0D\u4F1A\u7528\u6574\u53E5\u68C0\u7D22\u6216\u624B\u5DE5\u8BCD\u5E93\u64AD\u653E\u4EE3\u66FF\u7406\u89E3\u3002",
  privateProtectionScope: "\u6B64\u5BA2\u6237\u7AEF\u4E0D\u5305\u542B\u5B8C\u6574\u8BCD\u5E93\u3001\u52A8\u4F5C\u6570\u636E\u6216\u6A21\u578B\u6743\u91CD\u3002\u9875\u9762\u5C55\u793A\u7684\u7ED3\u679C\u4ECD\u53EF\u88AB\u590D\u5236\uFF1B\u5DF2\u53D1\u51FA\u7684\u65E7\u7248\u5B89\u88C5\u5305\u65E0\u6CD5\u64A4\u56DE\u3002",
  privateModel: "\u672C\u6B21\u6A21\u578B\uFF1A{model}",
  privateDisconnected: "\u4F1A\u8BDD\u5DF2\u6E05\u7A7A\u3002",
  privateEndpointInvalid: "\u8BF7\u4F7F\u7528\u660E\u786E\u7AEF\u53E3\u7684 http://127.0.0.1 \u672C\u673A\u670D\u52A1\u5730\u5740\u3002",
  privateTokenInvalid: "\u8BF7\u586B\u5199\u672C\u6B21\u7EC8\u7AEF\u751F\u6210\u7684\u5B8C\u6574\u4F1A\u8BDD\u53E3\u4EE4\u3002",
  privateTextInvalid: "\u8BF7\u8F93\u51651\u81F3500\u5B57\u7684\u4E2D\u6587\u3002",
  privateUnauthorized: "\u53E3\u4EE4\u65E0\u6548\u6216\u5DF2\u5931\u6548\uFF0C\u8BF7\u4F7F\u7528\u5F53\u524D\u670D\u52A1\u7EC8\u7AEF\u7684\u53E3\u4EE4\u3002",
  privateForbidden: "\u670D\u52A1\u62D2\u7EDD\u4E86\u6765\u6E90\uFF1B\u63D2\u4EF6\u9700\u5728\u542F\u52A8\u670D\u52A1\u65F6\u52A0\u5165\u5176\u51C6\u786E\u7684\u6269\u5C55\u6765\u6E90\u3002",
  privateRateLimited: "\u8BF7\u6C42\u8FC7\u4E8E\u9891\u7E41\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
  privateBusy: "\u670D\u52A1\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u3002",
  privateRequestFailed: "\u63A8\u7406\u8BF7\u6C42\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u672C\u673A\u670D\u52A1\u3002",
  privateResponseInvalid: "\u670D\u52A1\u8FD4\u56DE\u5185\u5BB9\u4E0D\u7B26\u5408\u5F53\u524D\u6A21\u578B\u63A5\u53E3\u3002",
  privateConnectionFailed: "\u65E0\u6CD5\u8FDE\u63A5\u672C\u673A\u670D\u52A1\u6216\u8BF7\u6C42\u5DF2\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5\u670D\u52A1\u5730\u5740\u548C\u8FD0\u884C\u72B6\u6001\u3002",
  privateServiceUnavailableStatus: "\u672C\u673A\u8BED\u4E49\u670D\u52A1\u672A\u8FD0\u884C\uFF0C\u5C1A\u672A\u79BB\u5F00\u5F53\u524D\u9875\u9762\u3002",
  privateServiceUnavailable: "\u6CA1\u6709\u68C0\u6D4B\u5230\u672C\u673A\u8BED\u4E49\u670D\u52A1\u3002\u8BF7\u5728\u9879\u76EE\u4ED3\u5E93\u6839\u76EE\u5F55\u6253\u5F00\u7EC8\u7AEF\u5E76\u8FD0\u884C\u4E0B\u9762\u7684\u547D\u4EE4\uFF1B\u670D\u52A1\u542F\u52A8\u540E\u56DE\u5230\u8FD9\u91CC\u91CD\u8BD5\u3002",
  privateServiceStartFromRoot: "\u542F\u52A8\u547D\u4EE4\uFF08\u5728 SignBridge \u9879\u76EE\u4ED3\u5E93\u6839\u76EE\u5F55\u8FD0\u884C\uFF09\uFF1A",
  privateServiceCommand: ".venv-sign-data/bin/python signbridge/src/tools/sign-private-serve.py --model local-data/csl-understanding-20261017-rLaeiN/learned-roles-v3 --client local-data/existing-resources-optimization-20261019-v1/thin-client-v1.0.5 --port 8770 --scope-experiment --unit-candidates local-data/existing-resources-optimization-20261019-v1/unit-candidates-final/candidates.json",
  privateRoles: {
    actor: "\u8C01\uFF0F\u65BD\u4E8B",
    predicate: "\u52A8\u4F5C\uFF0F\u72B6\u6001",
    patient: "\u5BF9\u8C01\uFF0F\u53D7\u4E8B",
    goal: "\u76EE\u6807\u5730\u70B9",
    time: "\u65F6\u95F4",
    negation: "\u5426\u5B9A",
    modal: "\u610F\u613F\uFF0F\u80FD\u529B\uFF0F\u5FC5\u8981\u6027",
    question: "\u7591\u95EE",
    aspect: "\u4F53\u8C8C",
    politeness: "\u8BF7\u6C42",
    degree: "\u7A0B\u5EA6"
  }
};
var PRIVATE_EN = {
  privateScopeExperiment: "Scope comparison: frozen role weights with bounded event-structure constraints. Synthetic Chinese engineering evaluation only; not CSL understanding or accuracy.",
  privateScopeAnalyzed: "Event scope parsed; CSL lexical, spatial and nonmanual alignment still requires review.",
  privateEventStructure: "Event scope (frozen model + explicit constraints)",
  privatePlanEvidence: "Meaning components: {components}. Candidate evidence gaps: {gaps}. All candidates await CSL alignment; no motion generation or playback.",
  privatePlanReview: "all still require review",
  privateTitle: "SignBridge \xB7 CSL understanding research",
  privateScope: "Trained capability: bounded Chinese semantic roles, using assistant synthetic Chinese labels. CSL translation and video recognition are not trained.",
  privateEndpoint: "Local inference service",
  privateToken: "Session token",
  privateTokenHelp: "The local service prints a new token in its terminal. This page holds it in memory only; restart invalidates it.",
  privateSentence: "Chinese sentence (up to 500 characters)",
  privateAnalyze: "Analyze meaning",
  privateDisconnect: "Clear session",
  privateResult: "Semantic result",
  privateWaiting: "Start the local service and enter its session token.",
  privateAnalyzing: "Running the local trained model\u2026",
  privateParsed: "Roles parsed; CSL motion alignment and realization still require review.",
  privateAbstained: "Unsupported or ambiguous sentence. Parsing stopped; retain the original text.",
  privateMotionGap: "Signing output awaits word-level motion alignment, spatial reference and nonmanual review. No retrieval or dictionary playback substitutes for understanding here.",
  privateProtectionScope: "This client includes no complete lexicon, motion data or model weights. Displayed results can still be copied; previously distributed packages cannot be recalled.",
  privateModel: "Model: {model}",
  privateDisconnected: "Session cleared.",
  privateEndpointInvalid: "Use an http://127.0.0.1 address with an explicit local service port.",
  privateTokenInvalid: "Enter the complete token from the current service terminal.",
  privateTextInvalid: "Enter 1\u2013500 characters.",
  privateUnauthorized: "Invalid or expired token. Use the current service terminal token.",
  privateForbidden: "Origin rejected. Start the service with this exact extension origin allowed.",
  privateRateLimited: "Too many requests. Try again later.",
  privateBusy: "Service busy. Try again shortly.",
  privateRequestFailed: "Inference request failed. Check the local service.",
  privateResponseInvalid: "Unexpected model response.",
  privateConnectionFailed: "Local service unavailable or request timed out. Check the address and service.",
  privateServiceUnavailableStatus: "The local meaning service is not running. You have not left this page.",
  privateServiceUnavailable: "The local meaning service was not detected. Open a terminal at the SignBridge repository root, run the command below, then return here and retry.",
  privateServiceStartFromRoot: "Start command (run at the repository root):",
  privateServiceCommand: ".venv-sign-data/bin/python signbridge/src/tools/sign-private-serve.py --model local-data/csl-understanding-20261017-rLaeiN/learned-roles-v3 --client local-data/existing-resources-optimization-20261019-v1/thin-client-v1.0.5 --port 8770 --scope-experiment --unit-candidates local-data/existing-resources-optimization-20261019-v1/unit-candidates-final/candidates.json",
  privateRoles: {
    actor: "Actor",
    predicate: "Action / state",
    patient: "Patient / recipient",
    goal: "Goal",
    time: "Time",
    negation: "Negation",
    modal: "Modality",
    question: "Question",
    aspect: "Aspect",
    politeness: "Request",
    degree: "Degree"
  }
};
var SEMANTIC_ZH = {
  cslMode: "\u4E2D\u6587\u610F\u601D\u5206\u6790\uFF08\u89C4\u5219\u7814\u7A76\uFF09",
  cslAnalysisOnly: "\u4EC5\u5206\u6790\u4E2D\u6587\u610F\u601D\uFF1A\u672A\u5B8C\u6210\u4E2D\u56FD\u624B\u8BED\u8BCD\u7EA7\u5BF9\u9F50\u4E0E\u8BED\u8A00\u590D\u6838\uFF0C\u4E0D\u64AD\u653E\u52A8\u4F5C\u3002",
  cslTitle: "\u610F\u601D\u5206\u6790\u4E0E\u8868\u8FBE\u8349\u6848",
  cslScope: "\u6709\u9650\u89C4\u5219\u539F\u578B\uFF1A\u5148\u5206\u6790\u610F\u601D\uFF0C\u518D\u68C0\u67E5\u52A8\u4F5C\u3002\u4E0D\u662F\u5DF2\u8BAD\u7EC3\u7684\u4E2D\u56FD\u624B\u8BED\u7406\u89E3\u6A21\u578B\uFF1B\u8BCD\u5E8F\u3001\u624B\u578B\u3001\u7A7A\u95F4\u5173\u7CFB\u548C\u8868\u60C5\u4ECD\u9700\u6838\u5BF9\u3002",
  cslActor: "\u65BD\u4E8B / \u8C01",
  cslPredicate: "\u52A8\u4F5C / \u72B6\u6001",
  cslPatient: "\u53D7\u4E8B / \u5BF9\u8C01",
  cslGoal: "\u5730\u70B9 / \u76EE\u6807",
  cslTime: "\u65F6\u95F4",
  cslNegation: "\u5426\u5B9A\u53CA\u8303\u56F4",
  cslModality: "\u610F\u613F / \u80FD\u529B / \u5FC5\u8981\u6027",
  cslQuestion: "\u7591\u95EE",
  cslDegree: "\u7A0B\u5EA6",
  cslPoliteness: "\u8BF7\u6C42",
  cslUnset: "\u672A\u660E\u786E",
  cslDraft: "\u5019\u9009\u8868\u8FBE\u5355\u5143\uFF08\u975E\u56FA\u5B9A\u4E2D\u56FD\u624B\u8BED\u8BED\u5E8F\uFF09",
  cslNoDraft: "\u53E5\u6CD5\u8D85\u51FA\u539F\u578B\u8303\u56F4\uFF0C\u8BF7\u6838\u5BF9\u539F\u6587\u3002",
  cslGaps: "\u7F3A\u5C11\u52A8\u4F5C\u8BC1\u636E\uFF1A{words}",
  cslUnknown: "\u4FDD\u7559\u7684\u672A\u89E3\u6790\u5185\u5BB9\uFF1A{words}",
  cslMeaningKey: "\u673A\u5668\u8BED\u4E49\u8868\u793A\uFF08\u8349\u6848\uFF09",
  cslNoMatch: "\u8BE5\u8BED\u4E49\u8BA1\u5212\u4ECD\u6709\u8BC1\u636E\u7F3A\u53E3\uFF0C\u4E0D\u80FD\u64AD\u653E\u4E3A\u5B8C\u6574\u8868\u8FBE\u3002",
  cslSources: "\u8BCD\u7EA7ID\u4EC5\u4F5C\u4E3A\u8349\u6848\u5F15\u7528\uFF1B\u5206\u6790\u7ED3\u679C\u4E0D\u4F1A\u89E6\u53D1\u8BCD\u5E93\u6216\u89C6\u9891\u52A8\u4F5C\u64AD\u653E\u3002",
  cslIssues: {
    csl_alignment_unreviewed: "\u4E2D\u56FD\u624B\u8BED\u8BCD\u7EA7\u5BF9\u9F50\u3001\u7A7A\u95F4\u6307\u4EE3\u548C\u975E\u624B\u90E8\u8BED\u6CD5\u5C1A\u672A\u590D\u6838\u3002",
    empty_input: "\u8BF7\u8F93\u5165\u4E00\u53E5\u4E2D\u6587\u3002",
    unknown_input: "\u4ECD\u6709\u672A\u89E3\u6790\u7684\u8BCD\u6216\u7B26\u53F7\u3002",
    unsupported_predicate_structure: "\u591A\u4E2A\u52A8\u4F5C\u6216\u7F3A\u5C11\u8C13\u8BCD\uFF0C\u9700\u8FDB\u4E00\u6B65\u6807\u6CE8\u3002",
    ambiguous_scope: "\u5426\u5B9A\u3001\u60C5\u6001\u6216\u65F6\u95F4\u7684\u8303\u56F4\u6709\u6B67\u4E49\u3002",
    actor_unresolved: "\u53E5\u4E2D\u6267\u884C\u52A8\u4F5C\u7684\u4EBA\u5C1A\u672A\u660E\u786E\u3002",
    ambiguous_participants: "\u4EBA\u7269\u5173\u7CFB\u8D85\u51FA\u5F53\u524D\u7B80\u5355\u53E5\u8303\u56F4\u3002",
    unsupported_operator_order: "\u5426\u5B9A\u6216\u60C5\u6001\u4F4D\u7F6E\u8D85\u51FA\u5DF2\u652F\u6301\u7ED3\u6784\u3002",
    unsupported_predicate_arguments: "\u52A8\u4F5C\u7684\u53C2\u4E0E\u5173\u7CFB\u9700\u8FDB\u4E00\u6B65\u6838\u5BF9\u3002",
    goal_unresolved: "\u76EE\u6807\u5730\u70B9\u6216\u52A8\u4F5C\u53D7\u4E8B\u5C1A\u672A\u89E3\u6790\u6E05\u695A\u3002",
    question_role_unresolved: "\u7591\u95EE\u8BCD\u7684\u8BED\u4E49\u89D2\u8272\u5C1A\u672A\u786E\u8BA4\u3002",
    multiple_clauses: "\u5305\u542B\u591A\u5206\u53E5\uFF0C\u539F\u578B\u4E0D\u4F1A\u64C5\u81EA\u5408\u5E76\u3002",
    unassigned_meaning: "\u4ECD\u6709\u672A\u5F52\u5C5E\u7684\u8BED\u4E49\u5355\u5143\u3002",
    unsupported_degree_scope: "\u7A0B\u5EA6\u4FEE\u9970\u7684\u8303\u56F4\u5C1A\u672A\u786E\u8BA4\u3002",
    motion_evidence_missing: "\u90E8\u5206\u6982\u5FF5\u6CA1\u6709\u53EF\u9760\u7684\u72EC\u7ACB\u52A8\u4F5C\u8D44\u4EA7\u3002",
    nonmanual_question_unavailable: "\u7591\u95EE\u9700\u8981\u7684\u9762\u90E8\u6216\u5934\u90E8\u8868\u8FBE\u5C1A\u672A\u5B9E\u73B0\u3002",
    spatial_agreement_unavailable: "\u5E2E\u52A9\u7684\u65B9\u5411\u3001\u4EBA\u7269\u7A7A\u95F4\u6307\u4EE3\u5C1A\u672A\u6838\u9A8C\u3002",
    modal_interpretation_unreviewed: "\u60C5\u6001\u542B\u4E49\u4E0D\u80FD\u76F4\u63A5\u7528\u4E00\u4E2A\u8BCD\u5E93\u52A8\u4F5C\u66FF\u4EE3\u3002",
    input_limit: "\u8D85\u8FC7500\u5B57\uFF0C\u5C3E\u90E8\u4FDD\u7559\u5E76\u505C\u6B62\u7EC4\u5408\u3002"
  }
};
var SEMANTIC_EN = {
  cslMode: "Chinese meaning analysis (rules)",
  cslAnalysisOnly: "Chinese analysis only: CSL alignment and language review are incomplete. Motion playback is disabled.",
  cslTitle: "Meaning and expression draft",
  cslScope: "Bounded rule prototype: analyze meaning, then check motion evidence. This is not a trained CSL understanding model. Order, handshape, spatial agreement and nonmanuals remain unverified.",
  cslActor: "Actor",
  cslPredicate: "Action / state",
  cslPatient: "Patient / recipient",
  cslGoal: "Location / goal",
  cslTime: "Time",
  cslNegation: "Negation and scope",
  cslModality: "Desire / ability / obligation",
  cslQuestion: "Question",
  cslDegree: "Degree",
  cslPoliteness: "Request",
  cslUnset: "Unspecified",
  cslDraft: "Candidate units (not a fixed CSL word order)",
  cslNoDraft: "Outside the supported syntax. Review the original input.",
  cslGaps: "Missing motion evidence: {words}",
  cslUnknown: "Unparsed content preserved: {words}",
  cslMeaningKey: "Machine meaning representation (draft)",
  cslNoMatch: "Evidence is missing; this plan cannot play as a complete expression.",
  cslSources: "Word IDs are draft references only. Analysis never triggers dictionary or video motion playback.",
  cslIssues: {
    csl_alignment_unreviewed: "CSL word alignment, spatial reference and nonmanual grammar remain unreviewed.",
    empty_input: "Enter one Chinese sentence.",
    unknown_input: "Some words or symbols remain unparsed.",
    unsupported_predicate_structure: "Multiple actions or a missing predicate require annotation.",
    ambiguous_scope: "Negation, modality or time scope is ambiguous.",
    actor_unresolved: "The actor is unresolved.",
    ambiguous_participants: "Participant relations exceed this simple-clause prototype.",
    unsupported_operator_order: "Negation or modality order is unsupported.",
    unsupported_predicate_arguments: "Predicate arguments require review.",
    goal_unresolved: "The goal or patient is unresolved.",
    question_role_unresolved: "The question role is unresolved.",
    multiple_clauses: "Multiple clauses cannot be silently merged.",
    unassigned_meaning: "Some meaning units have no assigned role.",
    unsupported_degree_scope: "Degree scope is unresolved.",
    motion_evidence_missing: "Some concepts have no reliable independent motion.",
    nonmanual_question_unavailable: "Question-related facial and head expressions are unavailable.",
    spatial_agreement_unavailable: "Direction and spatial reference for help remain unverified.",
    modal_interpretation_unreviewed: "Modal meaning cannot be replaced by one dictionary motion.",
    input_limit: "Input exceeds 500 characters; the tail is retained and composition stopped."
  }
};
var SEMANTIC_JA = {
  ...SEMANTIC_EN,
  cslMode: "\u4E2D\u56FD\u8A9E\u306E\u610F\u5473\u5206\u6790\uFF08\u898F\u5247\u7814\u7A76\uFF09",
  cslAnalysisOnly: "\u4E2D\u56FD\u8A9E\u306E\u610F\u5473\u5206\u6790\u306E\u307F\u3067\u3059\u3002\u4E2D\u56FD\u624B\u8A71\u306E\u8A9E\u5358\u4F4D\u5BFE\u5FDC\u3068\u78BA\u8A8D\u306F\u672A\u5B8C\u4E86\u306E\u305F\u3081\u3001\u52D5\u4F5C\u306F\u518D\u751F\u3057\u307E\u305B\u3093\u3002",
  cslTitle: "\u610F\u5473\u5206\u6790\u3068\u8868\u73FE\u6848",
  cslScope: "\u9650\u5B9A\u3057\u305F\u898F\u5247\u306B\u3088\u308B\u8A66\u4F5C\u3067\u3059\u3002\u610F\u5473\u3092\u5206\u6790\u3057\u3066\u52D5\u4F5C\u8CC7\u6599\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u5B66\u7FD2\u6E08\u307F\u306E\u4E2D\u56FD\u624B\u8A71\u7406\u89E3\u30E2\u30C7\u30EB\u3067\u306F\u306A\u304F\u3001\u8A9E\u9806\u30FB\u624B\u5F62\u30FB\u7A7A\u9593\u8868\u73FE\u30FB\u8868\u60C5\u306F\u672A\u78BA\u8A8D\u3067\u3059\u3002",
  cslActor: "\u52D5\u4F5C\u4E3B",
  cslPredicate: "\u52D5\u4F5C\u30FB\u72B6\u614B",
  cslPatient: "\u5BFE\u8C61\u30FB\u53D7\u3051\u624B",
  cslGoal: "\u5834\u6240\u30FB\u76EE\u6A19",
  cslTime: "\u6642",
  cslNegation: "\u5426\u5B9A\u3068\u7BC4\u56F2",
  cslModality: "\u5E0C\u671B\u30FB\u80FD\u529B\u30FB\u5FC5\u8981\u6027",
  cslQuestion: "\u7591\u554F",
  cslDegree: "\u7A0B\u5EA6",
  cslPoliteness: "\u4F9D\u983C",
  cslUnset: "\u672A\u6307\u5B9A",
  cslDraft: "\u8868\u73FE\u5358\u4F4D\u6848\uFF08\u56FA\u5B9A\u3057\u305F\u4E2D\u56FD\u624B\u8A71\u306E\u8A9E\u9806\u3067\u306F\u3042\u308A\u307E\u305B\u3093\uFF09",
  cslNoDraft: "\u69CB\u6587\u304C\u8A66\u4F5C\u306E\u7BC4\u56F2\u5916\u3067\u3059\u3002\u539F\u6587\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
  cslGaps: "\u52D5\u4F5C\u8CC7\u6599\u306E\u4E0D\u8DB3\uFF1A{words}",
  cslUnknown: "\u672A\u89E3\u6790\u306E\u5185\u5BB9\u3092\u4FDD\u6301\uFF1A{words}",
  cslMeaningKey: "\u610F\u5473\u306E\u6A5F\u68B0\u8868\u73FE\uFF08\u6848\uFF09",
  cslNoMatch: "\u8CC7\u6599\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u308B\u305F\u3081\u3001\u5B8C\u5168\u306A\u8868\u73FE\u3068\u3057\u3066\u518D\u751F\u3067\u304D\u307E\u305B\u3093\u3002",
  cslSources: "\u65E2\u5B58\u306E\u624B\u4F5C\u6210\u8F9E\u66F8\u3092\u4F7F\u3044\u307E\u3059\u3002\u52D5\u753B\u306E\u5019\u88DC\u306F\u81EA\u52D5\u7684\u306B\u6709\u52B9\u5316\u3057\u307E\u305B\u3093\u3002"
};
var DEMO_ZH = {
  intakeRefinementTitle: "\u6765\u6E90 {name} \xB7 \u52A8\u4F5C\u8FB9\u754C\u590D\u6838",
  intakeRefinementPending: "\u6587\u5B57\u4E0E\u8FB9\u754C\u5EFA\u8BAE \xB7 \u672A\u4EBA\u5DE5\u786E\u8BA4",
  intakePrevious: "\u539F\u5019\u9009\u7A97\u53E3 {start}\u2013{end}s\uFF1A{text}",
  intakeBefore: "\u539F\u5019\u9009\u7A97\u53E3\uFF08\u4F9B\u5BF9\u6BD4\uFF09",
  intakeAfter: "\u8C03\u6574\u540E\u7684\u5019\u9009\u7A97\u53E3",
  intakeRefinedWindow: "\u8C03\u6574\u540E\u540D\u4E49\u533A\u95F4 {start}\u2013{end}s\uFF1B\u5B9E\u9645\u89E3\u7801 {frames} \u5E27 / {duration}s\u3002\u4E34\u8FD1\u89C6\u9891\u7ED3\u5C3E\u7684\u52A8\u4F5C\u4ECD\u9700\u6838\u5BF9\u662F\u5426\u5B8C\u6574\u3002",
  intakeCoverageComparison: "\u89C2\u6D4B\u5230\u81F3\u5C11\u4E00\u53EA\u624B\u7684\u5E27\u5360\u6BD4\uFF1A\u539F\u7A97\u53E3 {before}% \u2192 \u8C03\u6574\u540E {after}%\u3002\u8FD9\u662F\u4E0D\u540C\u7A97\u53E3\u7684\u53D6\u6750\u5BF9\u6BD4\uFF0C\u4E0D\u4EE3\u8868\u68C0\u6D4B\u5668\u51C6\u786E\u7387\u63D0\u5347\u3002",
  intakeTitle: "\u6765\u6E90 {name} \xB7 \u65B0\u89C6\u9891\u590D\u6838",
  intakeSummary: "{files} \u4E2A\u6587\u4EF6 / {unique} \u4EFD\u4E0D\u540C\u5185\u5BB9\uFF1B{screened} \u4E2A\u6765\u6E90\u5B8C\u6210 OCR\uFF0C{candidates} \u6761\u6587\u5B57\u5019\u9009\uFF1B{references} \u6BB5\u3001{frames} \u5E27\u5B8C\u6210 2D \u53C2\u8003\u3002",
  intakeLimits: "\u5B57\u5E55\u8BED\u4E49\u3001\u52A8\u4F5C\u8FB9\u754C\u3001\u955C\u50CF\u3001\u624B\u522B\u548C\u4EBA\u7269\u5206\u7EC4\u5F85\u786E\u8BA4\u3002\u8FD9\u91CC\u53EA\u5C55\u793A OCR \u5019\u9009\u53CA\u4E8C\u7EF4\u89C2\u6D4B\uFF0C\u6CA1\u6709\u751F\u6210\u65B0\u7684 SMPL-X \u52A8\u4F5C\u6216\u8BAD\u7EC3\u6A21\u578B\uFF1Btraining_ready=false\u3002",
  intakePending: "OCR\u5019\u9009 \xB7 \u672A\u590D\u6838",
  intakeWindow: "\u540D\u4E49\u533A\u95F4 {start}\u2013{end}s \xB7 OCR\u5747\u503C {confidence}",
  intakeOriginal: "\u67E5\u770B\u6388\u6743\u539F\u89C6\u9891\u533A\u95F4",
  intakeDuplicate: "\u4E0E\u65E7\u6279\u6B21\u5185\u5BB9\u91CD\u590D",
  catchupTitle: "\u624B\u8BED\u89C6\u9891\u7EED\u5904\u7406 \xB7 \u539F\u7247\u4E0E\u624B\u90E8\u53C2\u8003",
  catchupSummary: "{files} \u4E2A\u89C6\u9891\u6587\u4EF6 / {sources} \u4EFD\u4E0D\u540C\u5185\u5BB9 \xB7 \u65B0\u589E {windows} \u6BB5\u8FDE\u7EED\u53C2\u8003 / {frames} \u5E27 \xB7 \u53E6\u6709 {sampled} \u5E27\u72EC\u7ACB\u624B\u90E8\u89C2\u6D4B",
  catchupLimits: "\u672C\u9875\u662F\u6807\u6CE8\u5019\u9009\u548C\u6280\u672F\u89C2\u6D4B\u3002\u5B57\u5E55\u53EF\u80FD\u6709\u9519\u5B57\u6216\u591A\u53E5\u5BF9\u8BDD\uFF0C\u8FB9\u754C\u3001\u955C\u50CF\u548C\u4EBA\u7269\u5206\u7EC4\u5F85\u786E\u8BA4\uFF1B\u672A\u5F00\u59CB\u8BAD\u7EC3\uFF0C\u672A\u751F\u6210\u65B0\u7684 SMPL-X \u53C2\u6570\u30025\u5E27\u62BD\u6837\u4E0D\u4EE3\u8868\u6574\u6BB5\u5DF2\u6807\u6CE8\u3002",
  catchupReferences: "\u65B0\u589E\u8FDE\u7EED\u7247\u6BB5",
  catchupSources: "\u5168\u90E8\u89C6\u9891\u8FDB\u5EA6",
  catchupCaptions: "\u539F\u59CB\u5B57\u5E55\u5019\u9009",
  catchupIndex: "\u7A0B\u5E8F\u8C03\u7528\u7D22\u5F15",
  catchupRegistry: "\u5B8C\u6574\u6765\u6E90\u767B\u8BB0",
  catchupReport: "\u9636\u6BB5\u62A5\u544A",
  catchupSearch: "\u641C\u7D22\u53E5\u5B50\u3001\u89C6\u9891\u540D\u6216\u6765\u6E90 ID",
  catchupPage: "{count} \u9879 \xB7 \u7B2C {page}/{pages} \u9875",
  catchupPrevious: "\u4E0A\u4E00\u9875",
  catchupNext: "\u4E0B\u4E00\u9875",
  catchupOriginal: "\u539F\u7247\u5019\u9009\u7A97\u53E3",
  catchupOverlay: "\u5173\u952E\u70B9\u53E0\u52A0\u9884\u89C8",
  catchupSync: "\u540C\u6B65\u64AD\u653E / \u6682\u505C",
  catchupKeyframes: "\u5C55\u5F005\u5E27\u539F\u56FE\u4E0E\u624B\u90E8\u88C1\u526A",
  catchupKeyframeAlt: "{text} \u7684\u539F\u56FE\u4E0E\u4F30\u8BA1\u624B\u90E8\u69FD\u88C1\u526A",
  catchupIndependentAlt: "\u8BE5\u6765\u6E905\u4E2A\u72EC\u7ACB\u62BD\u6837\u5E27\u7684\u624B\u90E8\u89C2\u6D4B",
  catchupCoverage: "\u6280\u672F\u89C2\u6D4B\u53EF\u7528\u5E27\uFF1Aleft {left}/{frames}\uFF0Cright {right}/{frames}\uFF1B\u8FD9\u4E0D\u662F\u51C6\u786E\u7387\u6216\u89E3\u5256\u4FA7\u522B\u6838\u9A8C\u3002",
  catchupSourceStages: "\u65E7\u53C2\u8003 {prior} \u6BB5 \xB7 \u65E7\u8FDE\u7EED\u52A8\u4F5C {motions} \u6BB5 \xB7 \u65B0\u8FDE\u7EED\u53C2\u8003 {fresh} \u6BB5 \xB7 \u65B0\u72EC\u7ACB\u62BD\u6837 {sampled} \u5E27\uFF1B\u5B8C\u6574\u89C6\u9891\u5904\u7406\u4ECD\u89C1\u62A5\u544A\u3002",
  catchupHksl: "\u6807\u9898\u63D0\u793A\u9999\u6E2F\u624B\u8BED\uFF0C\u8BED\u8A00\u5C1A\u5F85\u6838\u9A8C\uFF1B\u72EC\u7ACB\u4FDD\u5B58\uFF0C\u672A\u7EB3\u5165\u4E2D\u56FD\u624B\u8BED\u53E5\u5B50\u8BAD\u7EC3\u3002",
  catchupEmptyCaption: "\u65E0\u53EF\u8BFB\u53D6\u5B57\u5E55",
  catchupMediaError: "\u5A92\u4F53\u64AD\u653E\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u672C\u5730\u6587\u4EF6\u5E76\u91CD\u8BD5\u3002",
  demoSample: "\u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",
  demoRetry: "\u91CD\u65B0\u52A0\u8F7D\u6F14\u793A",
  demoLimit: "\u6BCF\u6B21\u6700\u591A\u64AD\u653E40\u4E2A\u52A8\u4F5C\uFF0C\u5176\u4F59\u6587\u5B57\u5217\u5728\u6682\u4E0D\u652F\u6301\u5185\u5BB9\u4E2D\u3002",
  demoCheckpoint: "Checkpoint\uFF1A{hash} \xB7 {steps}\u6B65",
  demoWebGL: "3D\u6E32\u67D3\u73AF\u5883\u4E0D\u53EF\u7528",
  demoOpen: "\u6253\u5F00\u6F14\u793A\u5DE5\u4F5C\u53F0",
  demoLocal: "\u672C\u5730\u79BB\u7EBF\u6F14\u793A",
  demoExport: "\u5BFC\u51FA\u672C\u6B21\u7ED3\u679C",
  demoEyebrow: "\u8BA9\u624B\u8BED\u52A8\u8D77\u6765 \xB7 \u5B9E\u9A8C\u6F14\u793A",
  demoHeading: "\u4ECE\u6587\u5B57\uFF0C\u5230\u770B\u5F97\u89C1\u7684\u8868\u8FBE",
  demoLead: "\u9009\u62E9\u7247\u6BB5\u6216\u8F93\u5165\u6587\u5B57\uFF0C\u5728\u865A\u62DF\u4EBA\u4E0A\u64AD\u653E\u53C2\u8003\u52A8\u4F5C\u3001\u5B9E\u9A8C\u91CD\u5EFA\u4E0E\u8BCD\u5E93\u52A8\u4F5C\u3002",
  demoInput: "\u8F93\u5165\u6587\u5B57",
  demoMode: "\u52A8\u4F5C\u6765\u6E90\u6A21\u5F0F",
  demoAuto: "\u81EA\u52A8\u5339\u914D",
  demoT08: "\u53C2\u8003\u4E0E\u5B9E\u9A8C\u52A8\u4F5C",
  demoDictionary: "\u5185\u7F6E\u8BCD\u5E93",
  demoPlaceholder: "\u8BD5\u8BD5\uFF1A\u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",
  demoShortcut: "Ctrl / \u2318 + Enter \u64AD\u653E",
  demoPlay: "\u64AD\u653E\u52A8\u4F5C",
  demoPause: "\u6682\u505C",
  demoResume: "\u7EE7\u7EED",
  demoStop: "\u505C\u6B62",
  demoLoading: "\u6B63\u5728\u52A0\u8F7D\u89D2\u8272\u4E0E\u52A8\u4F5C\u2026",
  demoMatches: "\u5DF2\u8BC6\u522B\u5185\u5BB9",
  demoCatalog: "\u77ED\u53E5\u4E0E\u8BCD\u5E93",
  demoCatalogViews: "\u77ED\u53E5\u6216\u8BCD\u5E93\u52A8\u4F5C",
  demoPhraseTab: "\u77ED\u53E5\u4E0E\u7247\u6BB5",
  demoWordTab: "\u5355\u8BCD\u52A8\u4F5C",
  demoPhraseSourceNote: "\u5171 {total} \u6761\uFF1A{reference} \u6761 T08 \u53C2\u8003\u3001{candidate} \u6761\u5019\u9009\u3001{experimental} \u6761\u5B9E\u9A8C\u91CD\u5EFA\u3001{composed} \u6761\u8BCD\u5E93\u7EC4\u5408\u3002",
  demoWordSourceNote: "\u5171 {count} \u4E2A\u5185\u7F6E\u8BCD\u6761\uFF1B\u8BCD\u6761\u52A8\u753B\u4E0D\u662F\u672C\u8F6E\u65B0\u589E\u7684\u53E5\u5B50\u8BAD\u7EC3\u7ED3\u679C\u3002",
  demoSearch: "\u641C\u7D22\u77ED\u53E5\u6216\u8BCD\u6761",
  demoAvatarLabel: "\u5F53\u524D\u9879\u76EE\u89D2\u8272 \xB7 Godette",
  demoStage: "\u865A\u62DF\u4EBA\u7269",
  demoReadyBadge: "\u51C6\u5907\u5C31\u7EEA",
  demoAtRest: "\u5F85\u673A",
  demoView: "\u89C6\u89D2",
  demoFront: "\u6B63\u9762",
  demoLeft: "\u5DE6\u4FA7",
  demoRight: "\u53F3\u4FA7",
  demoSpeed: "\u901F\u5EA6",
  demoSmoothing: "\u52A8\u4F5C\u5E73\u6ED1",
  demoExperimentalSmoothedBadge: "SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u5E73\u6ED1",
  demoAdaptiveFilteredBadge: "SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u9694\u79BB\u5C16\u5CF0\u5BF9\u7167",
  demoAdaptiveFilteredWarningBadge: "SMPL-X \xB7 \u5C16\u5CF0\u5BF9\u7167 \xB7 \u539F\u59CB\u98CE\u9669\u4ECD\u5728",
  demoExperimentalSmoothedWarningBadge: "SMPL-X \xB7 \u5B9E\u9A8C\u5E73\u6ED1 \xB7 \u539F\u59CB\u8DF3\u53D8\u8F83\u5927",
  demoExperimentalRawBadge: "SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u539F\u59CB",
  demoModel: "\u7814\u7A76\u6A21\u578B",
  demoLearned: "T08\u539F\u53C2\u8003\u53E5",
  demoWords: "\u5185\u7F6E\u8BCD\u5E93\u52A8\u4F5C",
  demoCandidates: "\u5019\u9009\u53C2\u8003\u52A8\u4F5C",
  demoExperimental: "\u5B9E\u9A8C\u91CD\u5EFA\u52A8\u4F5C",
  demoExperimentalBadge: "SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA",
  demoExperimentalWarningBadge: "SMPL-X \xB7 \u5B9E\u9A8C\u91CD\u5EFA \xB7 \u8DF3\u53D8\u8F83\u5927",
  demoExperimentalToken: "\u5F53\u524D\u4E3A\u89C6\u9891\u62DF\u5408\u7684 SMPL-X \u5B9E\u9A8C\u52A8\u4F5C\uFF0C\u672A\u7ECF\u8FC7 T08 token \u89E3\u7801\uFF0C\u672A\u66F4\u65B0\u6A21\u578B\u6743\u91CD\u3002",
  demoExperimentalWarning: "\u5B9E\u9A8C\u52A8\u4F5C\u4FDD\u7559\u672A\u7ECF\u52A8\u4F5C\u8D28\u91CF\u3001\u955C\u50CF\u548C\u4EBA\u7269\u6838\u9A8C\u7684\u72B6\u6001\uFF1B\u4EC5\u7528\u4E8E Demo\uFF0C\u53EF\u80FD\u51FA\u73B0\u624B\u578B\u8BEF\u5DEE\u3001\u8DF3\u53D8\u6216\u7A7F\u6A21\u3002",
  demoExperimentalApprovedWarning: "\u5F53\u524D\u62DF\u5408\u52A8\u4F5C\u5DF2\u901A\u8FC7\u52A8\u4F5C\u8D28\u91CF\u4EBA\u5DE5\u5BA1\u6838\uFF0C\u4EC5\u7528\u4E8E\u672C\u5730\u7814\u7A76\u6F14\u793A\u3002\u955C\u50CF\u65B9\u5411\u3001\u60EF\u7528\u624B\u3001\u4EBA\u7269\u8EAB\u4EFD\u3001\u4E2D\u6587\u542B\u4E49\u548C\u8BCD\u754C\u4ECD\u672A\u786E\u8BA4\uFF1B\u5B83\u4EEC\u4E0D\u662F\u8BAD\u7EC3\u6570\u636E\u3001\u672A\u66F4\u65B0\u6A21\u578B\u6743\u91CD\uFF0C\u6F14\u793A\u4ECD\u53EF\u80FD\u6709\u624B\u578B\u8BEF\u5DEE\u3001\u8DF3\u53D8\u6216\u7A7F\u6A21\u3002",
  demoExperimentalMixedWarning: "\u90E8\u5206\u62DF\u5408\u52A8\u4F5C\u5DF2\u901A\u8FC7\u52A8\u4F5C\u8D28\u91CF\u4EBA\u5DE5\u5BA1\u6838\uFF1B\u5176\u4F59\u52A8\u4F5C\u4ECD\u5F85\u5BA1\u6838\u3002\u5168\u90E8\u52A8\u4F5C\u4EC5\u7528\u4E8E\u7814\u7A76\u6F14\u793A\u3002\u955C\u50CF\u65B9\u5411\u3001\u60EF\u7528\u624B\u3001\u4EBA\u7269\u8EAB\u4EFD\u3001\u4E2D\u6587\u542B\u4E49\u548C\u8BCD\u754C\u4ECD\u672A\u786E\u8BA4\uFF0C\u4E5F\u672A\u7528\u4E8E\u8BAD\u7EC3\u6216\u66F4\u65B0\u6A21\u578B\u6743\u91CD\u3002",
  demoExperimentalPreviewWarning: "\u7B2C 6 \u6279\u4EBA\u7269\u9884\u89C8\uFF1A\u6587\u5B57\u548C\u52A8\u4F5C\u9996\u5C3E\u662F\u672A\u6838\u9A8C\u5019\u9009\uFF0C\u53EF\u80FD\u5939\u5E26\u76F8\u90BB\u6559\u5B66\u52A8\u4F5C\u3002\u8BF7\u5BF9\u7167\u539F\u7247\u68C0\u67E5\u624B\u578B\u3001\u65B9\u5411\u548C\u6296\u52A8\uFF1B\u955C\u50CF\u3001\u4EBA\u7269\u53CA\u52A8\u4F5C\u8D28\u91CF\u4ECD\u5F85\u786E\u8BA4\u3002\u663E\u793A\u5E73\u6ED1\u53EA\u6539\u53D8\u64AD\u653E\u6548\u679C\uFF0C\u672A\u8BAD\u7EC3\u6A21\u578B\u3002",
  demoInvalidExperimentalAsset: "\u5B9E\u9A8C\u52A8\u4F5C\u6587\u4EF6\u4E0D\u5B8C\u6574\u6216\u6765\u6E90\u6821\u9A8C\u5931\u8D25",
  demoCandidateBadge: "T08 tokenizer \xB7 \u5019\u9009\u91CD\u5EFA",
  demoCandidateDetail: "T08\u5019\u9009 \xB7 \u5F52\u4E00\u5316\u8BEF\u5DEE {mse}",
  demoInvalidCandidateAsset: "\u5019\u9009\u52A8\u4F5C\u6765\u6E90\u6216\u5BA1\u6838\u72B6\u6001\u4E0D\u7B26",
  demoCandidateWarning: "\u65B0\u589E3\u6761\u5019\u9009\u53E5\uFF1A\u7531\u73B0\u6709T08\u6743\u91CD\u7F16\u7801/\u89E3\u7801\uFF0C\u672A\u66F4\u65B0\u6743\u91CD\uFF1B\u91CD\u5EFA\u8BEF\u5DEE\u9AD8\u4E8E\u539F14\u6761\uFF0C\u955C\u50CF\u65B9\u5411\u548C\u4EBA\u7269\u5206\u7EC4\u672A\u786E\u8BA4\u3002\u4EC5\u4F9BDemo\u6BD4\u8F83\uFF0C\u4E0D\u4F5C\u4E3A\u51C6\u786E\u7FFB\u8BD1\u6216\u6B63\u5F0F\u8BAD\u7EC3\u6570\u636E\u3002",
  demoTokens: "\u67E5\u770B\u6700\u8FD1\u64AD\u653E\u7684\u52A8\u4F5C\u7F16\u7801",
  demoTokenNote: "\u4E0B\u65B9\u4E3A\u5B9E\u9645 T08 \u7F16\u7801\u7684 token\u3002\u64AD\u653E\u6765\u81EA\u8FD9\u4E9B token \u7684\u79BB\u7EBF\u89E3\u7801\u7ED3\u679C\uFF1B\u6D4F\u89C8\u5668\u4E0D\u6267\u884C PyTorch\u3002",
  demoEvidence: "\u91CD\u5EFA\u8BC1\u636E",
  demoComparison: "\u7814\u7A76\u5173\u952E\u5E27\u5BF9\u7167",
  demoReadonly: "\u53EA\u8BFB\u5019\u9009 \xB7 \u70B9\u51FB\u653E\u5927",
  demoClose: "\u6536\u8D77\u5BF9\u7167",
  demoScope: "\u5B9E\u9A8C\u6027\u5C55\u793A\uFF1AT08 \u8D1F\u8D23\u5DF2\u6709\u53C2\u8003\u52A8\u4F5C\u7684\u7F16\u7801/\u91CD\u5EFA\uFF1B\u6587\u5B57\u7528\u4E8E\u68C0\u7D22\uFF0C\u5185\u7F6E\u8BCD\u5E93\u7528\u4E8E\u8865\u5145\u3002\u672A\u8986\u76D6\u6587\u5B57\u4E0D\u4F1A\u81EA\u52A8\u751F\u6210\u624B\u8BED\uFF0C\u62FC\u63A5\u4E5F\u4E0D\u4EE3\u8868\u6B63\u786E\u7684\u624B\u8BED\u8BED\u6CD5\u3002",
  demoHow: "\u8FD9\u4EFD Demo \u600E\u6837\u5DE5\u4F5C\uFF1F",
  demoHowBody: "\u76EE\u5F55\u5408\u5E76\u4E86 T08 \u53C2\u8003\u4E0E\u5019\u9009\u3001\u89C6\u9891\u62DF\u5408\u7684\u5B9E\u9A8C\u52A8\u4F5C\u548C\u8BCD\u5E93\u7EC4\u5408\uFF1B\u91CD\u590D\u6587\u5B57\u53EA\u4FDD\u7559\u4E00\u4E2A\u5165\u53E3\u3002\u5B9E\u9A8C\u52A8\u4F5C\u672A\u66F4\u65B0\u6A21\u578B\u6743\u91CD\uFF1B\u8BCD\u5E93\u7EC4\u5408\u5E76\u975E\u53E5\u7EA7\u8BAD\u7EC3\u6216\u7ECF\u624B\u8BED\u8005\u6838\u9A8C\u7684\u7FFB\u8BD1\u3002",
  demoRetargetNote: "SMPL-X \u59FF\u6001\u901A\u8FC7\u6E90\u9AA8\u67B6\u4E0E\u89D2\u8272 REST \u6821\u51C6\u540E\u8F6C\u6362\u4E3A\u56DB\u5143\u6570\u3002\u6839\u90E8\u3001\u4E0B\u8EAB\u4FDD\u6301\u89D2\u8272\u5F85\u673A\uFF0C\u8868\u60C5\u7CFB\u6570\u5C1A\u672A\u5B8C\u6574\u6620\u5C04\u3002\u624B\u578B\u548C\u7A7F\u6A21\u4ECD\u4E3A\u5B9E\u9A8C\u6548\u679C\u3002",
  demoReady: "\u5DF2\u5C31\u7EEA\uFF0C\u8F93\u5165\u6587\u5B57\u6216\u9009\u62E9\u7247\u6BB5\u3002",
  demoNoMatch: "\u6682\u672A\u5339\u914D\u5230\u53EF\u7528\u52A8\u4F5C\uFF0C\u8BF7\u4ECE\u4E0B\u65B9\u9009\u62E9\u4E00\u4E2A\u4F8B\u5B50\u3002",
  demoUnknown: "\u6682\u4E0D\u652F\u6301\uFF1A{text}",
  demoAllMatched: "\u5DF2\u8986\u76D6\u5168\u90E8\u8F93\u5165\u5185\u5BB9\u3002",
  demoCount: "{count} \u4E2A\u52A8\u4F5C",
  demoPlaying: "\u6B63\u5728\u64AD\u653E {index}/{count}\uFF1A{text}",
  demoPaused: "\u5DF2\u6682\u505C\uFF0C\u53EF\u7EE7\u7EED\u6216\u505C\u6B62\u3002",
  demoStopped: "\u5DF2\u505C\u6B62\u5E76\u56DE\u5230\u5F85\u673A\u3002",
  demoFinished: "\u672C\u6B21\u64AD\u653E\u5B8C\u6210\u3002",
  demoFailed: "\u52A0\u8F7D\u5931\u8D25\uFF1A{detail}\u3002\u8BF7\u91CD\u65B0\u52A0\u8F7D\u9875\u9762\u3002",
  demoTokenEmpty: "\u64AD\u653E\u4E00\u6BB5 T08 \u53C2\u8003\u77ED\u53E5\u540E\uFF0C\u53EF\u67E5\u770B\u4E09\u8DEF\u7F16\u7801\u3002",
  demoDictionaryToken: "\u5F53\u524D\u64AD\u653E\u5185\u7F6E\u8BCD\u5E93\u52A8\u4F5C\uFF0C\u4E0D\u4F7F\u7528 T08 token\u3002",
  demoSourceT08: "T08 \xB7 \u53C2\u8003\u52A8\u4F5C\u91CD\u5EFA",
  demoSourceDictionary: "\u8BCD\u5E93 \xB7 \u5185\u7F6E\u52A8\u4F5C",
  demoSourceFallback: "\u8BCD\u5E93\u56DE\u9000 \xB7 \u53C2\u8003\u52A8\u4F5C\u52A0\u8F7D\u5931\u8D25",
  demoSourceComposition: "\u8BCD\u5E93\u7EC4\u5408 \xB7 \u9010\u8BCD\u64AD\u653E\uFF0C\u975E\u53E5\u7EA7\u8BAD\u7EC3",
  demoResearchLabel: "{text} \xB7 {series} \xB7 \u539F\u56FE / baseline / candidate",
  demoResearchMissing: "\u6B64\u5DE5\u4F5C\u533A\u5C1A\u672A\u6253\u5305\u7814\u7A76\u5BF9\u7167\u56FE\u3002",
  demoPartialAsset: "T08 \u8D44\u4EA7\u4E0D\u53EF\u7528\uFF0C\u73B0\u6709\u8BCD\u5E93\u4ECD\u53EF\u64AD\u653E\u3002",
  demoExported: "\u672C\u6B21\u5339\u914D\u4E0E\u6765\u6E90\u62A5\u544A\u5DF2\u4E0B\u8F7D\u3002",
  demoInvalidMode: "\u672A\u77E5\u52A8\u4F5C\u6A21\u5F0F",
  demoInvalidAsset: "T08\u8D44\u4EA7\u683C\u5F0F\u6216checkpoint\u6765\u6E90\u4E0D\u7B26",
  demoInvalidRotation: "\u65E0\u6548\u59FF\u6001\u65CB\u8F6C",
  demoMissingBone: "\u89D2\u8272\u7F3A\u5C11\u5FC5\u8981\u624B\u90E8\u9AA8\u9ABC",
  demoNotReady: "\u89D2\u8272\u5C1A\u672A\u52A0\u8F7D\u5B8C\u6210",
  demoTooLong: "\u8F93\u5165\u8FC7\u957F\uFF0C\u4EC5\u5339\u914D\u524D500\u4E2A\u5B57\u7B26\u3002"
};
var DEMO_EN = {
  intakeRefinementTitle: "Source {name} \xB7 Motion boundary review",
  intakeRefinementPending: "Text/boundary proposal \xB7 Not human-confirmed",
  intakePrevious: "Previous candidate window {start}\u2013{end}s: {text}",
  intakeBefore: "Previous candidate window",
  intakeAfter: "Revised candidate window",
  intakeRefinedWindow: "Revised nominal window {start}\u2013{end}s; {frames} decoded frames / {duration}s. Check completion near the original video end.",
  intakeCoverageComparison: "Frames with at least one observed hand: {before}% \u2192 {after}%. Different windows are compared; this is not improved detector accuracy.",
  intakeTitle: "Source {name} \xB7 New video review",
  intakeSummary: "{files} files / {unique} unique contents; {screened} sources screened, {candidates} caption candidates; {references} 2D references / {frames} frames.",
  intakeLimits: "Text meaning, boundaries, mirroring, handedness and signer groups are unverified. OCR candidates and 2D observations only; no new SMPL-X motions or model training. training_ready=false.",
  intakePending: "OCR candidate \xB7 Unreviewed",
  intakeWindow: "Nominal window {start}\u2013{end}s \xB7 Mean OCR confidence {confidence}",
  intakeOriginal: "Open authorized source interval",
  intakeDuplicate: "Same bytes as an earlier source",
  catchupTitle: "Video catch-up \xB7 Source clips and hand references",
  catchupSummary: "{files} video files / {sources} unique contents \xB7 {windows} new reference windows / {frames} frames \xB7 {sampled} independent hand observations",
  catchupLimits: "Caption candidates and estimated observations only. Text, boundaries, mirroring and signer groups are unverified; no new training or SMPL-X parameters. Five samples do not annotate an entire video.",
  catchupReferences: "New continuous windows",
  catchupSources: "All source progress",
  catchupCaptions: "Raw caption candidates",
  catchupIndex: "Fitting index",
  catchupRegistry: "Source registry",
  catchupReport: "Stage report",
  catchupSearch: "Search text, video name or source ID",
  catchupPage: "{count} items \xB7 Page {page}/{pages}",
  catchupPrevious: "Previous",
  catchupNext: "Next",
  catchupOriginal: "Source candidate window",
  catchupOverlay: "Landmark preview",
  catchupSync: "Play / pause together",
  catchupKeyframes: "Five source frames and hand crops",
  catchupKeyframeAlt: "Source images and estimated hand crops for {text}",
  catchupIndependentAlt: "Five independent hand observation samples",
  catchupCoverage: "Eligible estimated frames: left {left}/{frames}, right {right}/{frames}; this is not accuracy or anatomical verification.",
  catchupSourceStages: "{prior} prior references \xB7 {motions} prior motions \xB7 {fresh} new reference windows \xB7 {sampled} independent samples. Whole-video completion remains described in the report.",
  catchupHksl: "Title suggests Hong Kong Sign Language; unverified, stored separately and excluded from CSL sentence training.",
  catchupEmptyCaption: "No readable caption",
  catchupMediaError: "Media playback failed. Check the local files and retry.",
  demoOpen: "Open demo workspace",
  demoLocal: "Local offline demo",
  demoExport: "Export session",
  demoEyebrow: "Sign language in motion \xB7 Experimental demo",
  demoHeading: "Words you can see",
  demoLead: "Choose a clip or enter text to play reference motions, experimental fits and dictionary motions.",
  demoInput: "Text input",
  demoMode: "Motion source",
  demoAuto: "Automatic",
  demoT08: "Reference / experimental",
  demoDictionary: "Dictionary",
  demoPlaceholder: "Try: \u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",
  demoSample: "\u5DE5\u4F5C\u5FD9\u5417\uFF1F\u8C22\u8C22",
  demoShortcut: "Ctrl / \u2318 + Enter to play",
  demoPlay: "Play",
  demoPause: "Pause",
  demoResume: "Resume",
  demoStop: "Stop",
  demoRetry: "Reload demo",
  demoLoading: "Loading avatar and motions\u2026",
  demoMatches: "Matched text",
  demoCatalog: "Phrases and dictionary",
  demoCatalogViews: "Phrase or dictionary view",
  demoPhraseTab: "Phrases / clips",
  demoWordTab: "Dictionary motions",
  demoPhraseSourceNote: "{total} entries: {reference} T08 references, {candidate} candidates, {experimental} experimental fits, {composed} dictionary compositions.",
  demoWordSourceNote: "{count} built-in entries. These word motions are not new sentence-training results.",
  demoSearch: "Search phrases or dictionary entries",
  demoAvatarLabel: "Project avatar \xB7 Godette",
  demoStage: "Avatar",
  demoReadyBadge: "Ready",
  demoAtRest: "Idle",
  demoView: "View",
  demoFront: "Front",
  demoLeft: "Left",
  demoRight: "Right",
  demoSpeed: "Speed",
  demoSmoothing: "Motion smoothing",
  demoExperimentalSmoothedBadge: "SMPL-X \xB7 Experimental fit \xB7 Smoothed",
  demoAdaptiveFilteredBadge: "SMPL-X \xB7 Experimental fit \xB7 isolated-spike comparison",
  demoAdaptiveFilteredWarningBadge: "SMPL-X \xB7 Spike comparison \xB7 raw risk remains",
  demoExperimentalSmoothedWarningBadge: "SMPL-X \xB7 Experimental \xB7 Smoothed \xB7 Raw jitter flagged",
  demoExperimentalRawBadge: "SMPL-X \xB7 Experimental fit \xB7 Raw",
  demoModel: "Research model",
  demoLearned: "Original T08 phrases",
  demoWords: "Dictionary motions",
  demoCandidates: "Motion candidates",
  demoExperimental: "Experimental fits",
  demoExperimentalBadge: "SMPL-X \xB7 Experimental fit",
  demoExperimentalWarningBadge: "SMPL-X \xB7 Experimental fit \xB7 High jitter",
  demoExperimentalToken: "Video-fitted SMPL-X motion, not T08 token decoding. No model weights were updated.",
  demoExperimentalWarning: "Experimental motions have unreviewed motion quality, mirroring and signer identity. Demo only; hand errors, jitter and mesh intersections may occur.",
  demoExperimentalApprovedWarning: "Fitted motions passed human motion-quality review for local research demos only. Mirroring, handedness, signer identity, Chinese meaning and boundaries remain unverified. These are not training data; no model weights were updated, and hand errors, jitter or mesh intersections may still occur.",
  demoExperimentalMixedWarning: "Some fitted motions passed human motion-quality review; others remain unreviewed. All are research-demo only. Mirroring, handedness, signer identity, Chinese meaning and boundaries remain unverified; no training or weight updates occurred.",
  demoExperimentalPreviewWarning: "Source-6 avatar preview: text and motion boundaries are unverified proposals and may include adjacent teaching demonstrations. Compare with the source for hand shapes, direction and jitter. Mirror, signer and motion quality remain unreviewed. Display smoothing changes playback only; no model was trained.",
  demoInvalidExperimentalAsset: "Incomplete experimental motion or provenance mismatch",
  demoCandidateBadge: "T08 tokenizer \xB7 Candidate reconstruction",
  demoCandidateDetail: "T08 candidate \xB7 normalized error {mse}",
  demoInvalidCandidateAsset: "Candidate motion provenance or review contract differs",
  demoCandidateWarning: "Three added phrase candidates are encoded/decoded with the existing T08 weights; weights were not updated. Reconstruction error is higher than for the original 14, and mirroring/signer grouping remain unconfirmed. Demo comparison only; not approved translation or training data.",
  demoTokens: "Last played motion tokens",
  demoTokenNote: "Actual T08 tokens are shown below. Playback uses their offline decoded motions; the browser does not run PyTorch.",
  demoEvidence: "Reconstruction evidence",
  demoComparison: "Research keyframe comparisons",
  demoReadonly: "Read-only candidates \xB7 Click to enlarge",
  demoClose: "Close comparison",
  demoScope: "Experimental showcase: T08 encodes and reconstructs existing reference motions. Text retrieves clips; dictionary entries supplement coverage. Unsupported text is reported. Concatenation does not establish correct sign language grammar.",
  demoHow: "How does this demo work?",
  demoHowBody: "The catalog merges T08 references and candidates, video-fitted experimental motions and dictionary compositions. Duplicate text has one entry. Experimental fits do not update model weights; dictionary compositions are not sentence-trained or sign-expert reviewed.",
  demoRetargetNote: "SMPL-X poses are calibrated to the avatar skeleton and played as quaternions. The root and lower body remain at rest; facial coefficients are not mapped. Hand shapes and mesh contact remain experimental.",
  demoReady: "Ready. Enter text or choose an example.",
  demoNoMatch: "No motion matched. Choose an example below.",
  demoUnknown: "Not supported: {text}",
  demoAllMatched: "All input text is covered.",
  demoCount: "{count} motions",
  demoPlaying: "Playing {index}/{count}: {text}",
  demoPaused: "Paused. Resume or stop.",
  demoStopped: "Stopped and reset to idle.",
  demoFinished: "Playback complete.",
  demoFailed: "Playback unavailable: {detail}. Reload to retry.",
  demoTokenEmpty: "Play a T08 reference phrase to inspect its three token streams.",
  demoDictionaryToken: "The last played dictionary motion does not use T08 tokens.",
  demoSourceT08: "T08 \xB7 Reference reconstruction",
  demoSourceDictionary: "Dictionary \xB7 Built-in motion",
  demoSourceFallback: "Dictionary fallback \xB7 Reference unavailable",
  demoSourceComposition: "Dictionary composition \xB7 Word-by-word, not sentence-trained",
  demoResearchLabel: "{text} \xB7 {series} \xB7 Original / baseline / candidate",
  demoResearchMissing: "No research comparisons were packaged in this workspace.",
  demoPartialAsset: "T08 assets unavailable. Dictionary motions can still play.",
  demoExported: "Session matching and provenance report downloaded.",
  demoInvalidMode: "Unknown motion mode",
  demoInvalidAsset: "Invalid T08 asset or checkpoint provenance",
  demoInvalidRotation: "Invalid pose rotation",
  demoMissingBone: "Required avatar hand bones are missing",
  demoNotReady: "Avatar is still loading",
  demoTooLong: "Only the first 500 characters are matched.",
  demoLimit: "Up to 40 motions per playback; the remaining text is listed as unsupported.",
  demoCheckpoint: "Checkpoint: {hash} \xB7 {steps} steps",
  demoWebGL: "3D rendering context unavailable"
};
var LOCALES = {
  "zh-CN": {
    ...DEMO_ZH,
    ...SEMANTIC_ZH,
    ...PRIVATE_ZH,
    ...WORKBENCH_ZH,
    batchTitle: "\u672C\u6279\u8865\u8BCD\u6E05\u5355 \xB7 \u6700\u591A 8 \u4E2A",
    batchManual: "\u624B\u52A8\u52A0\u5165\u5B8C\u6574\u8BCD\u7EC4\uFF08\u53EF\u9009\uFF0C\u907F\u514D\u5206\u8BCD\u8BEF\u62C6\uFF09",
    batchInvalidWord: "\u8BF7\u8F93\u5165 1\u2013100 \u4E2A\u5B57\u7B26\u7684\u6709\u6548\u8BCD\u8BED\u6216\u8BCD\u7EC4\uFF0C\u4E0D\u80FD\u53EA\u6709\u7A7A\u767D\u6216\u6807\u70B9\u3002",
    batchIntro: "\u5728\u5206\u6790\u7ED3\u679C\u4E2D\u6311\u9009\u9AD8\u9891\u7F3A\u8BCD\u52A0\u5165\u6E05\u5355\u3002\u5148\u5236\u4F5C\u5E76\u4FDD\u5B58\u8349\u7A3F\uFF0C\u518D\u53BB\u201C\u52A8\u4F5C\u9A8C\u6536\u201D\u68C0\u67E5\uFF0C\u6700\u540E\u5728\u7F16\u8F91\u5668\u6216\u5F55\u5236\u5DE5\u5177\u4E2D\u4EBA\u5DE5\u786E\u8BA4\u542F\u7528\u3002\u53EF\u5339\u914D\u53EA\u8868\u793A\u8BCD\u5E93\u6709\u5BF9\u5E94\u6570\u636E\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u542B\u4E49\u6B63\u786E\uFF1B\u6B64\u6E05\u5355\u4E0D\u4F1A\u751F\u6210\u3001\u4FEE\u6539\u6216\u81EA\u52A8\u542F\u7528\u52A8\u4F5C\u3002",
    batchAdd: "\u52A0\u5165\u672C\u6279",
    batchRefresh: "\u5237\u65B0\u8865\u8BCD\u72B6\u6001",
    batchExport: "\u4E0B\u8F7D\u8865\u8BCD\u8FDB\u5EA6 JSON",
    batchClear: "\u6E05\u7A7A\u672C\u6279\u6E05\u5355",
    batchClearConfirm: "\u53EA\u6E05\u7A7A\u8865\u8BCD\u6E05\u5355\uFF1F\u4E0D\u4F1A\u5220\u9664\u4EFB\u4F55\u52A8\u4F5C\u6216\u89C6\u89C9\u57FA\u51C6\u3002",
    batchRemove: "\u79FB\u51FA\u672C\u6279",
    batchState: "\u5B9E\u9645\u5339\u914D\u72B6\u6001 / \u52A8\u4F5C ID",
    batchLoading: "\u6B63\u5728\u6838\u5BF9\u5F53\u524D\u52A8\u4F5C\u5E93\u2026",
    batchEmpty: "\u6E05\u5355\u4E3A\u7A7A\u3002\u5206\u6790\u6750\u6599\u540E\uFF0C\u5728\u672A\u8986\u76D6\u8BCD\u65C1\u70B9\u51FB\u201C\u52A0\u5165\u672C\u6279\u201D\u3002",
    batchMissing: "\u5F85\u5236\u4F5C \xB7 \u5C1A\u672A\u5B8C\u5168\u5339\u914D",
    batchDraft: "\u5DF2\u4FDD\u5B58\u5019\u9009 \xB7 \u5C1A\u672A\u542F\u7528\u6216\u5B8C\u5168\u5339\u914D",
    batchMatched: "\u53EF\u5B8C\u5168\u5339\u914D \xB7 \u624B\u8BED\u4ECD\u9700\u4EBA\u5DE5\u6838\u9A8C",
    batchUnverified: "\u72B6\u6001\u672A\u6838\u9A8C\uFF0C\u8BF7\u91CD\u8BD5",
    batchSummary: "\u672C\u6279 {count}/{max} \u4E2A \xB7 \u53EF\u5B8C\u5168\u5339\u914D {matched} \u4E2A \xB7 \u65E0\u6548\u5E93\u8BB0\u5F55 {invalid} \u4E2A\u3002\u4FEE\u6539\u52A8\u4F5C\u540E\u4F1A\u81EA\u52A8\u91CD\u65B0\u6838\u5BF9\u3002",
    batchPrivacy: "\u53EA\u6709\u4E3B\u52A8\u52A0\u5165\u7684\u8BCD\u4F1A\u4FDD\u5B58\u5230\u672C\u6269\u5C55\u672C\u5730\u5B58\u50A8\uFF08\u5237\u65B0\u540E\u4FDD\u7559\uFF09\uFF0C\u4E0D\u4FDD\u5B58\u539F\u6587\u6216\u4F8B\u53E5\u3001\u4E0D\u4E0A\u4F20\u3002\u6E05\u5355\u4E0D\u5C5E\u4E8E\u52A8\u4F5C\u5305\uFF0C\u4E0B\u8F7D\u7684\u8FDB\u5EA6\u5305\u542B\u6240\u9009\u8BCD\u53CA\u5339\u914D ID\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u9690\u79C1\u3002",
    batchFailure: "\u8865\u8BCD\u6E05\u5355\u64CD\u4F5C\u5931\u8D25\uFF1A{detail}",
    batchFull: "\u672C\u6279\u5DF2\u6EE1 8 \u4E2A\uFF0C\u8BF7\u5148\u5B8C\u6210\u6216\u79FB\u9664\u90E8\u5206\u8BCD\u3002",
    batchInvalid: "\u8865\u8BCD\u6E05\u5355\u6570\u636E\u65E0\u6548\uFF0C\u539F\u8BB0\u5F55\u672A\u88AB\u8986\u76D6\u3002\u53EF\u660E\u786E\u6E05\u7A7A\u540E\u91CD\u65B0\u52A0\u5165\u3002",
    batchLockUnavailable: "\u8DE8\u9875\u9762\u5199\u5165\u9501\u4E0D\u53EF\u7528\uFF0C\u5DF2\u505C\u6B62\u4FEE\u6539\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u6253\u5F00\u6B64\u9875\u3002",
    reviewTitle: "\u52A8\u4F5C\u9A8C\u6536",
    reviewIntro: "\u6279\u91CF\u56DE\u653E\u5DF2\u4FDD\u5B58\u7684\u52A8\u4F5C\uFF0C\u4EE5\u56FA\u5B9A\u6B63\u9762\u3001\u53F3\u4FA7\u3001\u5DE6\u4FA7\u622A\u56FE\u5BF9\u7167\u81EA\u5DF1\u786E\u8BA4\u7684\u57FA\u51C6\u3002\u4E0D\u6539\u9AA8\u9ABC\u53C2\u6570\uFF0C\u4E5F\u4E0D\u81EA\u52A8\u542F\u7528\u7FFB\u8BD1\u3002",
    reviewLimits: "\u6BCF\u6279\u6700\u591A 8 \u4E2A\u52A8\u4F5C\uFF0C\u6BCF\u4E2A\u6700\u591A\u62BD\u53D6 12 \u4E2A\u5173\u952E\u5E27\uFF0C\u5305\u542B\u9996\u5C3E\u5E27\u3002\u622A\u56FE\u4EC5\u68C0\u67E5\u76EE\u6807\u59FF\u6001\uFF0C\u4E0D\u8986\u76D6\u6240\u6709\u8FC7\u6E21\u3001\u78B0\u649E\u3001\u5B57\u5E55\u53E5\u7EA7\u64AD\u653E\u6216\u624B\u8BED\u542B\u4E49\uFF1B\u89C6\u89C9\u53D8\u5316\u9700\u4EBA\u5DE5\u590D\u6838\u3002\u5185\u7F6E\u5217\u8868\u4F7F\u7528 SIGNS\uFF0C\u4E0D\u5305\u542B CHARS \u5355\u5B57\u56DE\u9000\u3002",
    reviewHelp: "\u63A7\u5236\u9762\u677F \u2192 \u52A8\u4F5C\u9A8C\u6536\u3002\u52FE\u9009\u52A8\u4F5C\u540E\u53EF\u81EA\u52A8\u4F9D\u6B21\u56DE\u653E\u6216\u751F\u6210\u4E09\u89C6\u56FE\uFF1B\u67E5\u770B\u624B\u5F62\u3001\u65B9\u5411\u548C\u7A7F\u6A21\uFF0C\u786E\u8BA4\u540E\u70B9\u51FB\u201C\u4FDD\u5B58 / \u66FF\u6362\u89C6\u89C9\u57FA\u51C6\u201D\u3002\u4EE5\u540E\u91CD\u65B0\u622A\u56FE\u53EF\u5E76\u6392\u5BF9\u6BD4\u3002\u52A8\u4F5C\u6570\u636E\u6539\u53D8\u4F1A\u63D0\u793A\u91CD\u65B0\u6838\u9A8C\uFF0C\u6A21\u578B/\u6D4F\u89C8\u5668/\u6E32\u67D3\u73AF\u5883\u6539\u53D8\u65F6\u4E0D\u8FDB\u884C\u6570\u503C\u5BF9\u6BD4\u3002\u4FDD\u5B58\u57FA\u51C6\u4E0D\u7B49\u4E8E\u786E\u8BA4\u624B\u8BED\u6B63\u786E\uFF0C\u4E0D\u4F1A\u4FEE\u6539\u52A8\u4F5C\u5E93\u7684\u8349\u7A3F\u6216\u542F\u7528\u72B6\u6001\u3002",
    reviewStorageHelp: "\u89C6\u89C9\u57FA\u51C6\u53EA\u5B58\u4E8E\u5F53\u524D\u6269\u5C55\u7684 IndexedDB\uFF0C\u4E0E\u52A8\u4F5C\u5E93\u5206\u5F00\uFF0C\u6700\u591A 100 \u4E2A / 64 MiB\u3002\u4E0D\u5305\u542B\u5728\u52A8\u4F5C\u5305\u5907\u4EFD\u4E2D\uFF1B\u5378\u8F7D\u524D\u8BF7\u4E0B\u8F7D PNG \u548C JSON \u62A5\u544A\u7559\u5B58\uFF08\u672C\u8F6E\u4E0D\u652F\u6301\u91CD\u65B0\u5BFC\u5165\u57FA\u51C6\uFF09\u3002\u622A\u56FE\u548C\u62A5\u544A\u4EC5\u5728\u4F60\u70B9\u51FB\u4E0B\u8F7D\u65F6\u5BFC\u51FA\uFF0C\u4E0D\u53D1\u9001\u5230\u7F51\u7EDC\u3002",
    reviewReload: "\u91CD\u65B0\u52A0\u8F7D\u6A21\u578B / \u91CD\u8BD5",
    reviewSelect: "1 \xB7 \u9009\u62E9\u52A8\u4F5C",
    reviewSearch: "\u6309\u540D\u79F0\u3001ID \u6216\u72B6\u6001\u7B5B\u9009\uFF08\u4E0D\u4F1A\u53D6\u6D88\u5DF2\u52FE\u9009\u52A8\u4F5C\uFF09",
    reviewCatalogCount: "\u53EF\u7528 {total} \u4E2A \xB7 \u5DF2\u9009 {count}/{max} \xB7 \u65E0\u6548\u5E93\u8BB0\u5F55 {invalid} \u4E2A",
    reviewPlay: "\u4F9D\u6B21\u56DE\u653E\u5168\u90E8\u5E27",
    reviewCapture: "\u751F\u6210\u5173\u952E\u5E27\u4E09\u89C6\u56FE",
    reviewStop: "\u505C\u6B62\u5F53\u524D\u4EFB\u52A1",
    reviewPreview: "\u56FA\u5B9A\u89C6\u89D2\u9884\u89C8",
    reviewView: "\u56DE\u653E\u89C6\u89D2",
    reviewFront: "\u6B63\u9762",
    reviewRight: "\u4EBA\u7269\u53F3\u4FA7",
    reviewLeft: "\u4EBA\u7269\u5DE6\u4FA7",
    reviewPreviewHelp: "\u89C6\u89D2\u53EA\u7528\u4E8E\u68C0\u67E5\uFF0C\u4E0D\u6539\u53D8\u6D6E\u7A97\u4F4D\u7F6E\u6216\u5927\u5C0F\u3002\u56DE\u653E\u6BCF\u4E2A\u52A8\u4F5C\u524D\u6062\u590D REST\uFF1B\u622A\u56FE\u5B8C\u6210\u540E\u6062\u590D\u6B63\u9762\u3002",
    reviewResults: "2 \xB7 \u4EBA\u5DE5\u6838\u9A8C\u4E0E\u57FA\u51C6\u5BF9\u6BD4",
    reviewExport: "\u4E0B\u8F7D\u672C\u6279 JSON \u62A5\u544A",
    reviewBuiltin: "\u5185\u7F6E \xB7 \u5F85\u4EBA\u5DE5\u6838\u9A8C",
    reviewEnabled: "\u81EA\u5B9A\u4E49 \xB7 \u5DF2\u542F\u7528",
    reviewDraft: "\u81EA\u5B9A\u4E49 \xB7 \u8349\u7A3F",
    reviewLoading: "\u6B63\u5728\u52A0\u8F7D\u5B9E\u9645\u6A21\u578B\u3001\u9AA8\u9ABC\u548C\u52A8\u4F5C\u5E93\u2026",
    reviewReady: "\u5DF2\u5C31\u7EEA\uFF0C\u5171 {total} \u4E2A\u52A8\u4F5C\u3002\u9009\u62E9\u52A8\u4F5C\u540E\u56DE\u653E\u6216\u622A\u56FE\u3002",
    reviewFailure: "\u9A8C\u6536\u5931\u8D25\uFF1A{detail}",
    reviewCatalogChanged: "\u52A8\u4F5C\u5E93\u5DF2\u53D8\u5316\uFF0C\u672C\u6279\u7ED3\u679C\u5931\u6548\u3002\u8BF7\u91CD\u65B0\u9009\u62E9\u5E76\u622A\u56FE\uFF0C\u65E7\u57FA\u51C6\u4E0D\u4F1A\u81EA\u52A8\u8986\u76D6\u3002",
    reviewPlaying: "\u6B63\u5728\u56DE\u653E {index}/{total}\uFF1A{name}",
    reviewCapturing: "\u6B63\u5728\u622A\u56FE {index}/{total}\uFF1A{name}",
    reviewFinished: "\u672C\u6279\u5B8C\u6210 {count} \u4E2A\uFF0C\u7ED3\u6784\u9519\u8BEF {failures} \u4E2A\uFF1B\u7ED3\u679C\u4ECD\u9700\u4EBA\u5DE5\u68C0\u67E5\u3002",
    reviewCancelled: "\u5DF2\u505C\u6B62\uFF1B\u672A\u5B8C\u6210\u6279\u6B21\u4E0D\u4FDD\u7559\u622A\u56FE\u7ED3\u679C\uFF0C\u4E0D\u4FEE\u6539\u57FA\u51C6\u3002",
    reviewDiagnostics: "\u5171 {frames} \u5E27 / {duration} \u79D2\uFF0C\u4F7F\u7528 {bones} \u4E2A\u9AA8\u9ABC\u3002\u622A\u56FE\u884C\u5BF9\u5E94\u5E27\uFF1A{indices}\uFF1B\u672A\u622A\u56FE {omitted} \u5E27\u3002",
    reviewSheetOrder: "\u6BCF\u884C\u4ECE\u5DE6\u5230\u53F3\uFF1A\u6B63\u9762 \u2192 \u4EBA\u7269\u53F3\u4FA7 \u2192 \u4EBA\u7269\u5DE6\u4FA7\uFF1B\u884C\u987A\u5E8F\u6309\u5E27\u53F7\u3002\u4E0B\u8F7D PNG \u53EF\u653E\u5927\u68C0\u67E5\u3002",
    reviewCurrent: "\u5F53\u524D\u622A\u56FE",
    reviewBaseline: "\u5DF2\u786E\u8BA4\u7684\u89C6\u89C9\u57FA\u51C6",
    reviewNoBaseline: "\u5C1A\u65E0\u89C6\u89C9\u57FA\u51C6\u3002\u5148\u68C0\u67E5\u52A8\u4F5C\uFF0C\u518D\u624B\u52A8\u4FDD\u5B58\u3002",
    reviewCompared: "\u57FA\u51C6\u65F6\u95F4 {date}\u3002RGB \u5355\u901A\u9053\u5DEE\u5F02 >16 \u7684\u50CF\u7D20\u5360 {ratio}%\uFF0C\u5E73\u5747\u901A\u9053\u5DEE\u5F02 {mean}/255\u3002\u4EC5\u4F9B\u4EBA\u5DE5\u590D\u6838\uFF0C\u4E0D\u4EE3\u8868\u624B\u8BED\u6B63\u786E\u6216\u4E0D\u5B58\u5728\u7A7F\u6A21\u3002",
    reviewMotionChanged: "\u52A8\u4F5C\u6570\u636E\u5DF2\u6539\u53D8\uFF08\u5305\u62EC\u65F6\u957F\u6216\u540D\u79F0\uFF09\uFF0C\u65E7\u57FA\u51C6\u4ECD\u4FDD\u7559\u3002\u6570\u503C\u5BF9\u6BD4\u5DF2\u505C\u6B62\uFF0C\u8BF7\u91CD\u65B0\u6838\u9A8C\u3002",
    reviewIncompatible: "\u6A21\u578B\u3001\u9AA8\u9ABC\u3001\u6D4F\u89C8\u5668\u6216\u6E32\u67D3\u73AF\u5883\u4E0E\u65E7\u57FA\u51C6\u4E0D\u540C\uFF0C\u4E0D\u80FD\u53EF\u9760\u8FDB\u884C\u6570\u503C\u5BF9\u6BD4\u3002\u65E7\u56FE\u53EA\u4F9B\u53C2\u8003\u3002",
    reviewUnavailable: "\u57FA\u51C6\u8BFB\u53D6 / \u5BF9\u6BD4\u5931\u8D25\uFF1A{detail}\u3002\u5F53\u524D\u622A\u56FE\u4ECD\u53EF\u4E0B\u8F7D\uFF0C\u4FDD\u5B58\u5C06\u518D\u6B21\u5C1D\u8BD5\u3002",
    reviewSaveBaseline: "\u4FDD\u5B58 / \u66FF\u6362\u89C6\u89C9\u57FA\u51C6",
    reviewDeleteBaseline: "\u5220\u9664\u6B64\u52A8\u4F5C\u57FA\u51C6",
    reviewDownloadImage: "\u4E0B\u8F7D\u5F53\u524D PNG",
    reviewSaveConfirm: "\u786E\u8BA4\u5DF2\u68C0\u67E5\u201C{name}\u201D\u7684\u4E09\u89C6\u56FE\uFF1F\u5C06\u4FDD\u5B58\u5F53\u524D\u622A\u56FE\u5E76\u66FF\u6362\u5DF2\u6709\u89C6\u89C9\u57FA\u51C6\uFF0C\u4EC5\u7528\u4E8E\u56DE\u5F52\u6BD4\u8F83\uFF1B\u4E0D\u4F1A\u542F\u7528\u7FFB\u8BD1\u6216\u8BA4\u8BC1\u624B\u8BED\u6B63\u786E\u6027\u3002",
    reviewDeleteConfirm: "\u5220\u9664\u201C{name}\u201D\u7684\u89C6\u89C9\u57FA\u51C6\uFF1F\u6B64\u64CD\u4F5C\u4E0D\u5220\u9664\u52A8\u4F5C\u5E93\u4E2D\u7684\u52A8\u4F5C\u3002",
    reviewSaved: "\u89C6\u89C9\u57FA\u51C6\u5DF2\u4FDD\u5B58\uFF1B\u52A8\u4F5C\u5E93\u4E0E\u7FFB\u8BD1\u542F\u7528\u72B6\u6001\u672A\u6539\u53D8\u3002",
    reviewDeleted: "\u6B64\u52A8\u4F5C\u7684\u89C6\u89C9\u57FA\u51C6\u5DF2\u5220\u9664\uFF0C\u52A8\u4F5C\u6570\u636E\u672A\u6539\u53D8\u3002",
    reviewStorageError: "\u65E0\u6CD5\u8BBF\u95EE\u672C\u5730\u57FA\u51C6\u5B58\u50A8\u3002\u8BF7\u68C0\u67E5\u6D4F\u89C8\u5668\u53EF\u7528\u7A7A\u95F4\u5E76\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u91CD\u5F00\u3002",
    reviewStorageFull: "\u89C6\u89C9\u57FA\u51C6\u8FBE\u5230 100 \u4E2A\u6216 64 MiB \u4E0A\u9650\u3002\u8BF7\u5148\u4E0B\u8F7D\u7559\u5B58\uFF0C\u518D\u5220\u9664\u4E0D\u9700\u8981\u7684\u57FA\u51C6\u3002",
    reviewBaselineChanged: "\u53E6\u4E00\u9875\u9762\u5DF2\u66F4\u65B0\u57FA\u51C6\uFF0C\u672A\u8986\u76D6\u3002\u8BF7\u91CD\u65B0\u622A\u56FE\u8BFB\u53D6\u6700\u65B0\u57FA\u51C6\u540E\u518D\u786E\u8BA4\u3002",
    reviewModelError: "\u6A21\u578B\u52A0\u8F7D\u5931\u8D25\u6216\u5C3A\u5BF8\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u6784\u5EFA\u6269\u5C55\u5E76\u91CD\u8BD5\u3002",
    reviewMissingBones: "\u6A21\u578B\u7F3A\u5C11\u624B\u8BED\u5FC5\u9700\u9AA8\u9ABC\uFF0C\u5DF2\u963B\u6B62\u9A8C\u6536\u3002",
    reviewRenderError: "\u6E32\u67D3\u5931\u8D25\u6216 WebGL \u4E0A\u4E0B\u6587\u4E22\u5931\uFF0C\u505C\u6B62\u4EFB\u52A1\u540E\u8BF7\u70B9\u51FB\u91CD\u65B0\u52A0\u8F7D\u3002",
    reviewInvalidSamples: "\u5173\u952E\u5E27\u62BD\u6837\u53C2\u6570\u65E0\u6548\u3002",
    reviewImageMismatch: "\u57FA\u51C6\u56FE\u7247\u635F\u574F\u6216\u5C3A\u5BF8\u4E0D\u4E00\u81F4\uFF0C\u4E0D\u80FD\u8FDB\u884C\u5BF9\u6BD4\u3002",
    motionPackTitle: "\u52A8\u4F5C\u5E93\u5907\u4EFD / \u6279\u91CF\u5BFC\u5165",
    motionPackHelp: "\u5BFC\u51FA\u5F53\u524D\u6A21\u578B\u4E0B\u5168\u90E8\u5DF2\u4FDD\u5B58\u7684\u81EA\u5B9A\u4E49\u52A8\u4F5C\uFF08\u4E0D\u542B\u672A\u4FDD\u5B58\u7F16\u8F91\u6216\u5185\u7F6E\u8BCD\u5178\uFF09\u3002\u9009\u6587\u4EF6\u53EA\u505A\u9884\u68C0\uFF0C\u786E\u8BA4\u540E\u65B0\u589E\u8349\u7A3F\uFF1B\u540C ID \u540C\u5185\u5BB9\u8DF3\u8FC7\uFF0C\u4E0D\u540C\u5185\u5BB9\u62D2\u7EDD\u6574\u5305\u5BFC\u5165\u3002\u65B0\u52A8\u4F5C\u4ECD\u987B\u9010\u6761\u8F7D\u5165\u3001\u9884\u89C8\u3001\u786E\u8BA4\u542F\u7528\u3002",
    motionPackPrivacy: "\u6587\u4EF6\u53EA\u5305\u542B\u52A8\u4F5C\u540D\u79F0\u3001\u5339\u914D\u6587\u5B57\u3001\u6807\u7B7E\u3001\u9AA8\u9ABC\u7ED1\u5B9A\u3001\u5E27\u6570\u636E\u53CA\u5BFC\u51FA\u65F6\u542F\u7528\u6807\u8BB0\uFF0C\u4E0D\u542B\u5BC6\u94A5\u6216\u5B57\u5E55\u3002\u540D\u79F0\u548C\u6807\u7B7E\u4E5F\u53EF\u80FD\u542B\u9690\u79C1\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u3002\u5BFC\u5165\u4E0D\u4F1A\u7EE7\u627F\u5BA1\u6838\u8BB0\u5F55\uFF0C\u4E5F\u4E0D\u4E0A\u4F20\u6587\u4EF6\u3002",
    motionPackExport: "\u5907\u4EFD\u5168\u90E8\u5DF2\u4FDD\u5B58\u52A8\u4F5C",
    motionPackFile: "\u9009\u62E9\u52A8\u4F5C\u5305 JSON\uFF08\u4E0D\u662F\u5355\u52A8\u4F5C JSON\uFF09",
    motionPackLimits: "\u6BCF\u5305\u6700\u591A 500 \u4E2A\u52A8\u4F5C\u30018 MiB\uFF1B\u5355\u52A8\u4F5C\u6700\u591A 2 MiB\u3002\u6A21\u578B\u4E0E REST \u5FC5\u987B\u4E00\u81F4\u3002",
    motionPackInspect: "\u91CD\u65B0\u9884\u68C0",
    motionPackImport: "\u786E\u8BA4\u5BFC\u5165\u65B0\u8349\u7A3F",
    motionPackClear: "\u53D6\u6D88\u5F85\u5BFC\u5165\u6587\u4EF6",
    motionPackSummary: "\u9884\u68C0\uFF1A\u65B0\u589E {new}\uFF0C\u5DF2\u5B58\u5728 {existing}\uFF0CID \u51B2\u7A81 {conflict}\u3002\u5C1A\u672A\u5199\u5165\u52A8\u4F5C\u5E93\u3002",
    motionPackName: "\u52A8\u4F5C / ID",
    motionPackState: "\u5904\u7406\u65B9\u5F0F",
    motionPackWarnings: "\u9700\u8981\u6CE8\u610F",
    motionPackNew: "\u65B0\u589E\u8349\u7A3F",
    motionPackExisting: "\u76F8\u540C\u5185\u5BB9\uFF0C\u8DF3\u8FC7",
    motionPackIdConflict: "ID \u51B2\u7A81\uFF0C\u4E0D\u8986\u76D6",
    motionPackWasEnabled: "\u5305\u5185\u6807\u8BB0\u66FE\u542F\u7528\uFF1B\u53EA\u662F\u6765\u6E90\u4FE1\u606F\uFF0C\u4E0D\u4EE3\u8868\u5BA1\u6838\u53EF\u4FE1\u3002",
    motionPackAliases: "\u5339\u914D\u6587\u5B57\u53EF\u80FD\u91CD\u590D\uFF1A{aliases}\u3002\u8349\u7A3F\u53EF\u4FDD\u5B58\uFF0C\u542F\u7528\u524D\u9700\u68C0\u67E5\uFF08\u542B\u672A\u542F\u7528\u6761\u76EE\uFF09\u3002",
    motionPackMaterial: "\u65E0\u5339\u914D\u6587\u5B57\uFF0C\u53EA\u4F5C\u59FF\u52BF\u7D20\u6750\uFF0C\u4E0D\u80FD\u542F\u7528\u7FFB\u8BD1\u3002",
    motionPackReady: "\u9884\u68C0\u5B8C\u6210\u3002\u53EA\u4F1A\u65B0\u589E\u8349\u7A3F\uFF0C\u4E0D\u6539\u53D8\u5F53\u524D\u59FF\u52BF\u6216\u5DF2\u6709\u52A8\u4F5C\u7684\u542F\u7528\u72B6\u6001\u3002",
    motionPackChecking: "\u6B63\u5728\u6838\u5BF9\u6A21\u578B\u548C\u672C\u5730\u52A8\u4F5C\u5E93\u2026",
    motionPackCleared: "\u5DF2\u53D6\u6D88\uFF0C\u52A8\u4F5C\u5E93\u6CA1\u6709\u6539\u53D8\u3002",
    motionPackConfirm: "\u5C06\u65B0\u589E {count} \u4E2A\u8349\u7A3F\uFF0C\u4E0D\u8986\u76D6\u65E7\u52A8\u4F5C\u3001\u4E0D\u81EA\u52A8\u542F\u7528\u3002\u8BF7\u786E\u8BA4\u6765\u6E90\u6388\u6743\uFF0C\u5BFC\u5165\u540E\u9010\u6761\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u548C\u542B\u4E49\u3002\u7EE7\u7EED\uFF1F",
    motionPackImported: "\u5DF2\u65B0\u589E {imported} \u4E2A\u8349\u7A3F\uFF0C\u8DF3\u8FC7 {skipped} \u4E2A\u5DF2\u6709\u52A8\u4F5C\u3002\u8BF7\u4ECE\u5217\u8868\u8F7D\u5165\u3001\u9884\u89C8\u5E76\u9010\u6761\u786E\u8BA4\u3002",
    motionPackExported: "\u5DF2\u53D1\u8D77 {count} \u4E2A\u5DF2\u4FDD\u5B58\u52A8\u4F5C\u7684\u4E0B\u8F7D\uFF0C\u8BF7\u68C0\u67E5\u4E0B\u8F7D\u7ED3\u679C\uFF1B\u4E0D\u542B\u5C1A\u672A\u4FDD\u5B58\u7684\u7F16\u8F91\u3002",
    motionPackInvalid: "\u4E0D\u662F\u6709\u6548\u7684 v1 \u52A8\u4F5C\u5305 JSON\uFF1B\u5355\u52A8\u4F5C\u6587\u4EF6\u8BF7\u4F7F\u7528\u4E0A\u65B9\u201C\u5BFC\u5165\u52A8\u4F5C JSON\u201D\u3002",
    motionPackEmpty: "\u52A8\u4F5C\u5305\u4E3A\u7A7A\uFF0C\u6216\u5F53\u524D\u6CA1\u6709\u53EF\u5907\u4EFD\u7684\u5DF2\u4FDD\u5B58\u52A8\u4F5C\u3002",
    motionPackTooLarge: "\u8D85\u8FC7\u9650\u5236\uFF1A\u52A8\u4F5C\u5305 8 MiB / 500 \u4E2A\u52A8\u4F5C\uFF0C\u5355\u52A8\u4F5C 2 MiB\u3002\u6CA1\u6709\u5199\u5165\u3002",
    motionPackDuplicateId: "\u5305\u5185\u5B58\u5728\u91CD\u590D ID\uFF0C\u65E0\u6CD5\u786E\u5B9A\u5E94\u4FDD\u7559\u54EA\u4E2A\u52A8\u4F5C\uFF0C\u5DF2\u62D2\u7EDD\u5BFC\u5165\u3002",
    motionPackInvalidStored: "\u672C\u5730\u5E93\u6709\u635F\u574F\u6216\u4E0E\u5F53\u524D\u6A21\u578B\u4E0D\u517C\u5BB9\u7684\u8BB0\u5F55\uFF0C\u672A\u751F\u6210\u4E0D\u5B8C\u6574\u5907\u4EFD\uFF1B\u539F\u6570\u636E\u4FDD\u7559\uFF0C\u8BF7\u5148\u68C0\u67E5\u8FD9\u4E9B\u8BB0\u5F55\u3002",
    motionPackConflict: "\u540C ID \u7684\u672C\u5730\u5185\u5BB9\u4E0D\u540C\u6216\u635F\u574F\uFF0C\u6574\u5305\u5BFC\u5165\u5DF2\u963B\u6B62\uFF0C\u4E0D\u4F1A\u8986\u76D6\u3002\u9700\u8981\u53E6\u5B58\u65F6\u8BF7\u4F7F\u7528\u5355\u52A8\u4F5C\u5BFC\u5165\u521B\u5EFA\u526F\u672C\u3002",
    motionPackStale: "\u52A8\u4F5C\u5E93\u5DF2\u6539\u53D8\uFF0C\u65E7\u9884\u68C0\u5931\u6548\u3002\u8BF7\u70B9\u51FB\u201C\u91CD\u65B0\u9884\u68C0\u201D\uFF0C\u786E\u8BA4\u6E05\u5355\u540E\u518D\u5BFC\u5165\u3002",
    motionPackLockUnavailable: "\u8DE8\u9875\u9762\u5199\u5165\u9501\u4E0D\u53EF\u7528\uFF0C\u5DF2\u505C\u6B62\u6279\u91CF\u5BFC\u5165\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u91CD\u65B0\u6253\u5F00\u5DE5\u5177\u9875\u3002",
    motionPackEncoding: "\u6587\u4EF6\u4E0D\u662F\u6709\u6548\u7684 UTF-8 JSON\uFF0C\u8BF7\u8F6C\u6362\u7F16\u7801\u540E\u91CD\u8BD5\u3002",
    coverageTitle: "\u8BCD\u5E93\u8986\u76D6\u5206\u6790",
    coverageHelpWorkflow: "\u5728\u63A7\u5236\u9762\u677F\u6253\u5F00\u201C\u8BCD\u5E93\u8986\u76D6\u5206\u6790\u201D\uFF0C\u7C98\u8D34\u6587\u5B57\u6216\u5BFC\u5165 UTF-8 TXT / SRT / VTT\uFF0C\u5206\u6790\u672A\u8986\u76D6\u8BCD\u7684\u9891\u6B21\u4E0E\u8BED\u5883\u3002\u70B9\u51FB\u8BCD\u6761\u65C1\u7684\u59FF\u52BF\u7F16\u8F91\u5668\u6216\u5F55\u5236\u5DE5\u5177\u53EA\u4F1A\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\uFF1B\u5236\u4F5C\u5E76\u4EBA\u5DE5\u786E\u8BA4\u52A8\u4F5C\u540E\u56DE\u5230\u5206\u6790\u9875\u91CD\u65B0\u5206\u6790\uFF0C\u53EF\u6838\u5BF9\u662F\u5426\u5B9E\u9645\u751F\u6548\u3002",
    coverageIntro: "\u5148\u627E\u51FA\u771F\u5B9E\u8BED\u6599\u91CC\u7F3A\u5C11\u7684\u8BCD\uFF0C\u518D\u5236\u4F5C\u5E76\u9A8C\u8BC1\u52A8\u4F5C\u3002\u4E0D\u4F1A\u81EA\u52A8\u751F\u6210\u624B\u8BED\uFF0C\u4E5F\u4E0D\u4F1A\u6539\u52A8\u73B0\u6709\u59FF\u52BF\u3002",
    coverageInput: "1 \xB7 \u9009\u62E9\u5206\u6790\u6750\u6599",
    coverageTextLabel: "\u7C98\u8D34\u6587\u5B57\uFF08\u6BCF\u884C\u4E00\u6BB5\uFF09\uFF0C\u6216\u5BFC\u5165 UTF-8 \u5B57\u5E55",
    coverageLimits: "\u4E0A\u9650\uFF1A256 KiB \u6587\u4EF6\u300150,000 \u5B57\u7B26\u30011,000 \u6BB5\u3001\u6BCF\u6BB5 2,000 \u5B57\u7B26\u3002SRT / WebVTT \u6309\u5B57\u5E55\u6761\u76EE\u5206\u6790\u3002",
    coverageFormat: "\u683C\u5F0F",
    coveragePlainText: "\u7EAF\u6587\u5B57 \xB7 \u6BCF\u884C\u4E00\u6BB5",
    coverageImport: "\u5BFC\u5165\u6587\u4EF6",
    coverageAnalyze: "\u5206\u6790\u5F53\u524D\u8BCD\u5E93",
    coverageClear: "\u6E05\u7A7A",
    coverageResults: "2 \xB7 \u627E\u5230\u8865\u8BCD\u4F18\u5148\u7EA7",
    coverageMetricHelp: "\u8986\u76D6\u7387 = \u547D\u4E2D\u7684\u5206\u8BCD\u6570 \xF7\uFF08\u547D\u4E2D\u5206\u8BCD\u6570 + \u672A\u8986\u76D6\u5206\u8BCD\u6570\uFF09\uFF0C\u8DF3\u8FC7\u7684\u865A\u8BCD\u4E0E\u6807\u70B9\u4E0D\u8BA1\u5165\u3002\u7EDF\u8BA1\u7684\u662F\u6574\u6BB5\u8BCD\u5E93\u8986\u76D6\uFF0C\u4E0D\u662F\u624B\u8BED\u51C6\u786E\u7387\uFF0C\u4E5F\u4E0D\u4FDD\u8BC1\u53E5\u610F\u5B8C\u6574\u6216\u5168\u90E8\u52A8\u4F5C\u4F1A\u64AD\u5B8C\u3002",
    coverageUnknownTitle: "\u672A\u8986\u76D6\u8BCD \xB7 \u6309\u51FA\u73B0\u6B21\u6570\u6392\u5E8F",
    coverageDraftHelp: "\u4F18\u5148\u7EA7\u53EA\u662F\u5206\u8BCD\u7ED3\u679C\uFF0C\u5148\u7ED3\u5408\u8BED\u5883\u5224\u65AD\u662F\u5426\u5E94\u5236\u4F5C\u5B8C\u6574\u8BCD\u7EC4\u3002\u8FDB\u5165\u5DE5\u5177\u53EA\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\uFF0C\u4E5F\u4E0D\u4F1A\u628A\u5F53\u524D\u59FF\u52BF\u5F53\u6210\u8BE5\u8BCD\u7684\u6B63\u786E\u624B\u8BED\u3002",
    coverageWord: "\u672A\u8986\u76D6\u8BCD",
    coverageFrequency: "\u6B21\u6570 / \u6BB5\u6570",
    coverageExamples: "\u4F8B\u53E5\u6BB5\u53F7",
    coverageMake: "\u5236\u4F5C\u4E0E\u4EBA\u5DE5\u9A8C\u8BC1",
    coverageDetailsTitle: "3 \xB7 \u9010\u6BB5\u6838\u5BF9\u5B9E\u9645\u547D\u4E2D",
    coverageDisplayLimit: "\u9875\u9762\u6700\u591A\u663E\u793A\u524D 100 \u4E2A\u672A\u8986\u76D6\u8BCD\u548C\u524D 200 \u6BB5\uFF1B\u7EDF\u8BA1\u5305\u542B\u5168\u90E8\u8F93\u5165\u3002\u5BFC\u51FA\u62A5\u544A\u53EF\u4FDD\u7559\u5168\u90E8\u7ED3\u679C\u3002",
    coverageIncludeText: "\u5BFC\u51FA\u65F6\u5305\u542B\u539F\u6587\u548C\u9010\u6BB5\u660E\u7EC6\uFF08\u53EF\u80FD\u542B\u9690\u79C1\uFF09",
    coverageExport: "\u5BFC\u51FA\u5206\u6790\u62A5\u544A JSON",
    coveragePrivacy: "\u6750\u6599\u4EC5\u5728\u672C\u9875\u5185\u5B58\u5206\u6790\uFF0C\u4E0D\u4E0A\u4F20\u3001\u4E0D\u81EA\u52A8\u4FDD\u5B58\uFF0C\u5173\u95ED\u9875\u9762\u5373\u4E22\u5F03\u3002\u9ED8\u8BA4\u62A5\u544A\u4E0D\u542B\u539F\u6587\uFF0C\u4F46\u4ECD\u5305\u542B\u672A\u8986\u76D6\u8BCD\uFF0C\u5206\u4EAB\u524D\u8BF7\u68C0\u67E5\u3002",
    coverageSummary: "\u8986\u76D6 {ratio} \xB7 {segments} \u6BB5 \xB7 \u547D\u4E2D {matched} / \u672A\u8986\u76D6 {unknown} / \u8DF3\u8FC7 {skipped}",
    coverageNoTokens: "\u4E0D\u9002\u7528\uFF08\u65E0\u5F85\u7FFB\u8BD1\u8BCD\uFF09",
    coverageTruncation: "{count} \u6BB5\u89E6\u53CA\u5B9E\u65F6\u64AD\u653E\u6BCF\u6BB5 12 \u4E2A\u52A8\u4F5C\u4E0A\u9650\uFF1B\u8FD9\u90E8\u5206\u53EF\u80FD\u672A\u64AD\u653E\uFF0C\u8BF7\u67E5\u770B\u9010\u6BB5\u5269\u4F59\u6587\u672C\u3002",
    coverageOccurrences: "{count} \u6B21 / {segments} \u6BB5",
    coverageUniqueUnknown: "\u5171 {count} \u4E2A\u4E0D\u540C\u7684\u672A\u8986\u76D6\u8BCD\u3002\u8FC7\u957F\u7684\u8BCD\u8BF7\u5148\u62C6\u5206\u6216\u91CD\u65B0\u5224\u65AD\u5206\u8BCD\u3002",
    coverageNoUnknown: "\u672A\u53D1\u73B0\u672A\u8986\u76D6\u8BCD\uFF1B\u4ECD\u9700\u4EBA\u5DE5\u6838\u5BF9\u624B\u8BED\u542B\u4E49\u4E0E\u52A8\u4F5C\u3002",
    coverageMatches: "\u547D\u4E2D\uFF1A{value}",
    coverageUnmatched: "\u672A\u8986\u76D6\uFF1A{value}",
    coverageSkipped: "\u8DF3\u8FC7\uFF1A{value}",
    coverageRemaining: "\u8FBE\u5230\u64AD\u653E\u4E0A\u9650\u540E\u7684\u5269\u4F59\u6587\u672C\uFF1A{value}",
    coverageCatalog: "\u5F53\u524D\u8BCD\u5E93\uFF1A{signs} \u5185\u7F6E\u8BCD\u6761 / {aliases} \u67E5\u627E\u522B\u540D / {chars} \u5355\u5B57\uFF1B\u5DF2\u542F\u7528\u81EA\u5B9A\u4E49 {enabled}\uFF1B\u672A\u751F\u6548 {drafts}\uFF1B\u65E0\u6548\u6216\u6A21\u578B\u4E0D\u5339\u914D {invalid}\uFF08\u539F\u6570\u636E\u4FDD\u7559\uFF09\u3002",
    coverageReady: "\u7C98\u8D34\u6216\u5BFC\u5165\u6750\u6599\u540E\u70B9\u51FB\u5206\u6790\u3002\u9996\u6B21\u5206\u6790\u4F1A\u8BFB\u53D6\u5F53\u524D\u6A21\u578B\uFF0C\u6838\u9A8C\u81EA\u5B9A\u4E49\u52A8\u4F5C\u7ED1\u5B9A\u3002",
    coverageLoading: "\u6B63\u5728\u6838\u9A8C\u6A21\u578B\u4E0E\u52A8\u4F5C\u5E93\u5E76\u5206\u6790\u2026",
    coverageDone: "\u5206\u6790\u5B8C\u6210\u3002\u53EF\u5236\u4F5C\u7F3A\u5931\u52A8\u4F5C\uFF0C\u4EBA\u5DE5\u786E\u8BA4\u542F\u7528\u540E\u56DE\u5230\u6B64\u9875\u518D\u6B21\u5206\u6790\u3002",
    coverageChanged: "\u6750\u6599\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u5206\u6790\uFF1B\u65E7\u62A5\u544A\u4E0D\u53EF\u5BFC\u51FA\u3002",
    coverageCatalogChanged: "\u5171\u4EAB\u52A8\u4F5C\u5E93\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u5206\u6790\u4EE5\u67E5\u770B\u6700\u65B0\u8986\u76D6\uFF1B\u65E7\u62A5\u544A\u4E0D\u53EF\u5BFC\u51FA\u3002",
    coverageImported: "\u6750\u6599\u5DF2\u5BFC\u5165\u3002\u70B9\u51FB\u5206\u6790\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u64AD\u653E\u6216\u4FDD\u5B58\u3002",
    coverageFailure: "\u5206\u6790\u672A\u5B8C\u6210\uFF1A{detail}",
    coverageTooLarge: "\u8D85\u8FC7\u6750\u6599\u5927\u5C0F\u3001\u6BB5\u6570\u6216\u5355\u6BB5\u957F\u5EA6\u4E0A\u9650\uFF0C\u8BF7\u62C6\u5206\u540E\u5206\u6790\u3002",
    coverageEmpty: "\u8BF7\u63D0\u4F9B\u81F3\u5C11\u4E00\u6BB5\u975E\u7A7A\u6587\u5B57\u3002",
    coverageInvalidFormat: "\u4EC5\u652F\u6301 TXT\u3001SRT\u3001WebVTT\uFF0C\u8BF7\u9009\u62E9\u6B63\u786E\u683C\u5F0F\u3002",
    coverageInvalidSubtitles: "\u5B57\u5E55\u683C\u5F0F\u65E0\u6548\u3002\u8BF7\u68C0\u67E5\u7A7A\u884C\u3001\u65F6\u95F4\u8F74\u3001\u8D77\u6B62\u987A\u5E8F\u53CA WebVTT \u6587\u4EF6\u5934\uFF1B\u4E0D\u4F1A\u628A\u65F6\u95F4\u8F74\u5F53\u6B63\u6587\u7EDF\u8BA1\u3002",
    coverageEncoding: "\u6587\u4EF6\u4E0D\u662F\u6709\u6548 UTF-8\uFF0C\u8BF7\u8F6C\u6362\u7F16\u7801\u540E\u91CD\u8BD5\u3002",
    coverageModelError: "\u65E0\u6CD5\u6838\u9A8C\u5F53\u524D\u6A21\u578B\u6216\u5171\u4EAB\u52A8\u4F5C\u5E93\uFF0C\u8BF7\u786E\u8BA4\u4ECE\u63D2\u4EF6\u6253\u5F00\u4E14\u6A21\u578B\u53EF\u52A0\u8F7D\uFF0C\u7136\u540E\u91CD\u8BD5\u3002\u6CA1\u6709\u9000\u56DE\u5230\u4E0D\u5B8C\u6574\u7684\u7EDF\u8BA1\u3002",
    coverageOpenFailed: "\u5DE5\u5177\u9875\u9762\u672A\u80FD\u6253\u5F00\uFF0C\u8BF7\u4ECE\u63D2\u4EF6\u63A7\u5236\u9762\u677F\u91CD\u8BD5\u3002",
    coveragePrefilled: "\u5DF2\u4ECE\u8986\u76D6\u5206\u6790\u9884\u586B\u540D\u79F0\u548C\u5339\u914D\u6587\u5B57\u3002\u5F53\u524D\u59FF\u52BF\u4E0D\u662F\u8BE5\u8BCD\u7684\u5DF2\u9A8C\u8BC1\u52A8\u4F5C\uFF1B\u8BF7\u5236\u4F5C\u3001\u4FDD\u5B58\u3001\u9884\u89C8\u5E76\u4EBA\u5DE5\u786E\u8BA4\u3002",
    motionLibraryTitle: "\u5171\u4EAB\u52A8\u4F5C\u5E93 \xB7 \u7B2C\u4E8C\u9636\u6BB5",
    motionLibraryHelp: "\u7F16\u8F91\u5668\u3001\u5F55\u5236\u5668\u3001\u6D6E\u7A97\u4F7F\u7528\u540C\u4E00\u4EFD\u5F27\u5EA6\u6570\u636E\u3002\u4FDD\u5B58\u7684\u662F\u8349\u7A3F\uFF1B\u9884\u89C8\u5E76\u786E\u8BA4\u542F\u7528\u540E\uFF0C\u5339\u914D\u6587\u5B57\u624D\u53C2\u4E0E\u7FFB\u8BD1\u3002",
    motionName: "\u52A8\u4F5C\u540D\u79F0\uFF08\u5FC5\u586B\uFF09",
    motionTexts: "\u5339\u914D\u6587\u5B57\uFF08\u591A\u4E2A\u7528\u9017\u53F7\u5206\u9694\uFF1B\u7559\u7A7A\u4EC5\u4F5C\u59FF\u52BF\u7D20\u6750\uFF09",
    motionTags: "\u5206\u7C7B\u6807\u7B7E\uFF08\u9017\u53F7\u5206\u9694\uFF09",
    motionNew: "\u65B0\u5EFA\u526F\u672C",
    motionNewHelp: "\u5F53\u524D\u59FF\u52BF\u4FDD\u7559\uFF0C\u8BF7\u586B\u5199\u65B0\u7684\u52A8\u4F5C\u540D\u79F0\u3002",
    motionSave: "\u4FDD\u5B58\u8349\u7A3F",
    motionSaved: "\u5DF2\u4FDD\u5B58\u8349\u7A3F\uFF0C\u9700\u91CD\u65B0\u9884\u89C8\u3001\u786E\u8BA4\u540E\u542F\u7528\u3002",
    motionLoad: "\u8F7D\u5165\u9009\u4E2D",
    motionLoaded: "\u5DF2\u8F7D\u5165\u3002\u5BFC\u5165\u6587\u4EF6\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\uFF0C\u8BF7\u68C0\u67E5\u540E\u4FDD\u5B58\u8349\u7A3F\u3002",
    motionChoose: "\u9009\u62E9\u5DF2\u4FDD\u5B58\u7684\u52A8\u4F5C\u2026",
    motionDraft: "\u8349\u7A3F / \u672A\u542F\u7528",
    motionEnabled: "\u5DF2\u786E\u8BA4\u542F\u7528",
    motionPreview: "\u9884\u89C8\u5F53\u524D\u52A8\u4F5C",
    motionPreviewHelp: "\u6B63\u5728\u4F7F\u7528\u4E0E\u6D6E\u7A97\u76F8\u540C\u7684\u64AD\u653E\u5668\u3002\u8BF7\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u542B\u4E49\uFF1B\u4FEE\u6539\u540E\u9700\u91CD\u65B0\u4FDD\u5B58\u3002",
    motionEnable: "\u786E\u8BA4\u540E\u7528\u4E8E\u7FFB\u8BD1",
    motionDisable: "\u505C\u7528\u9009\u4E2D\u52A8\u4F5C",
    motionConfirm: "\u6211\u5DF2\u5B8C\u6574\u9884\u89C8\u5E76\u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u6587\u5B57\u542B\u4E49\uFF0C\u786E\u8BA4\u5C06\u8FD9\u4E2A\u52A8\u4F5C\u7528\u4E8E\u7FFB\u8BD1\u3002\u6B64\u786E\u8BA4\u4E0D\u662F\u4E13\u4E1A\u624B\u8BED\u8BA4\u8BC1\u3002\u662F\u5426\u542F\u7528\uFF1F",
    motionEnabledHelp: "\u5DF2\u542F\u7528\uFF1B\u5DF2\u6253\u5F00\u7684\u6D6E\u7A97\u4F1A\u81EA\u52A8\u8BFB\u53D6\uFF0C\u65B0\u8F93\u5165\u7684\u5339\u914D\u6587\u5B57\u4F7F\u7528\u6B64\u52A8\u4F5C\u3002",
    motionDisabledHelp: "\u5DF2\u505C\u7528\uFF0C\u8349\u7A3F\u4FDD\u7559\u3002\u6D6E\u7A97\u53D6\u6D88\u6B63\u5728\u6392\u961F\u7684\u81EA\u5B9A\u4E49\u52A8\u4F5C\u3002",
    motionRefresh: "\u5237\u65B0\u52A8\u4F5C\u5217\u8868",
    motionExport: "\u4E0B\u8F7D\u7EDF\u4E00 JSON",
    motionExportCode: "\u5BFC\u51FA\u4EE3\u7801\uFF08\u4E0D\u4FDD\u5B58\uFF09",
    motionImport: "\u5BFC\u5165\u52A8\u4F5C JSON",
    motionImportFormat: "\u5BFC\u5165\u6587\u4EF6\u7684\u5355\u4F4D\u548C\u683C\u5F0F",
    motionFormat: "\u7EDF\u4E00\u683C\u5F0F \xB7 \u5F27\u5EA6 / REST \u589E\u91CF",
    motionLegacyEditor: "\u65E7\u7F16\u8F91\u5668 delta \xB7 \u5EA6\u6570\uFF08\u4EC5\u59FF\u52BF\u5BF9\u8C61\uFF09",
    motionLegacyRecorder: "\u65E7\u5F55\u5236\u5668 frames.pose \xB7 \u5EA6\u6570",
    motionLegacyAbsolute: "\u65E7\u7F16\u8F91\u5668\u7EDD\u5BF9\u65CB\u8F6C \xB7 \u5F27\u5EA6",
    motionMigrate: "\u8FC1\u79FB\u672C\u9875\u65E7\u52A8\u4F5C\u5E93",
    motionLegacyConfirm: "\u65E7\u6587\u4EF6\u6CA1\u6709\u6A21\u578B\u7ED1\u5B9A\u4FE1\u606F\u3002\u4EC5\u5F53\u5B83\u6765\u81EA\u5F53\u524D\u6A21\u578B\u4E14\u6240\u9009\u683C\u5F0F\u4E0E\u5355\u4F4D\u6B63\u786E\u65F6\u624D\u7EE7\u7EED\uFF1B\u8F6C\u6362\u540E\u5FC5\u987B\u9010\u4E2A\u68C0\u67E5\u3002\u539F\u59CB\u672C\u5730\u52A8\u4F5C\u5E93\u4E0D\u4F1A\u5220\u9664\u3002\u662F\u5426\u7EE7\u7EED\uFF1F",
    motionMigrated: "\u5DF2\u8FC1\u79FB {count} \u4E2A\u8349\u7A3F\uFF1B\u65E7\u5E93\u4FDD\u7559\uFF0C\u5C1A\u672A\u542F\u7528\u3002\u91CD\u590D\u8FC1\u79FB\u4F1A\u751F\u6210\u526F\u672C\u3002",
    motionIgnored: "\u6709 {count} \u4E2A\u635F\u574F\u6216\u6A21\u578B\u4E0D\u5339\u914D\u7684\u6761\u76EE\u672A\u8F7D\u5165\uFF1B\u539F\u6570\u636E\u4FDD\u7559\u3002",
    motionFailure: "\u672A\u5B8C\u6210\uFF1A{detail}",
    motionInvalidData: "\u52A8\u4F5C\u683C\u5F0F\u6216\u53C2\u6570\u65E0\u6548\uFF1A{detail}",
    motionModelNotReady: "\u6A21\u578B\u5C1A\u672A\u52A0\u8F7D\u5B8C\u6210\u3002",
    motionRigMismatch: "\u6A21\u578B\u9AA8\u9ABC\u6216 REST \u521D\u59CB\u59FF\u52BF\u4E0D\u4E00\u81F4\uFF0C\u5DF2\u62D2\u7EDD\u5E94\u7528\u3002",
    motionStorageUnavailable: "\u5171\u4EAB\u5B58\u50A8\u4E0D\u53EF\u7528\uFF0C\u8BF7\u4ECE\u63D2\u4EF6\u63A7\u5236\u9762\u677F\u6253\u5F00\u5DE5\u5177\u9875\u9762\u3002",
    motionSelectFirst: "\u8BF7\u5148\u4FDD\u5B58\u6216\u9009\u62E9\u4E00\u4E2A\u52A8\u4F5C\u3002",
    motionSaveFirst: "\u52A8\u4F5C\u5DF2\u6539\u53D8\uFF0C\u8BF7\u91CD\u65B0\u4FDD\u5B58\u4E3A\u8349\u7A3F\u3001\u9884\u89C8\u540E\u542F\u7528\u3002",
    motionPreviewFirst: "\u8BF7\u5148\u9884\u89C8\u5F53\u524D\u52A8\u4F5C\uFF0C\u518D\u786E\u8BA4\u542F\u7528\u3002",
    motionAliasConflict: "\u5339\u914D\u6587\u5B57\u4E3A\u7A7A\u6216\u4E0E\u5DF2\u542F\u7528/\u5185\u7F6E\u8BCD\u6761\u91CD\u590D\uFF1A{detail}\u3002\u8BF7\u6362\u4E00\u4E2A\u660E\u786E\u7684\u65B0\u8BCD\u7EC4\u3002",
    motionFileTooLarge: "\u6587\u4EF6\u8FC7\u5927\u6216\u6761\u76EE\u8FC7\u591A\uFF08\u5355\u6587\u4EF6\u4E0A\u9650 2 MiB\uFF09\u3002",
    motionEditorSingleFrame: "\u7F16\u8F91\u5668\u53EA\u7F16\u8F91\u5355\u5E27\u59FF\u52BF\uFF1B\u8BF7\u7528\u5F55\u5236\u5668\u6253\u5F00\u591A\u5E27\u52A8\u753B\uFF0C\u907F\u514D\u4E22\u5E27\u3002",
    motionFrameLimit: "\u5DF2\u8FBE\u5230 240 \u5E27\u4E0A\u9650\uFF0C\u5F55\u5236\u5DF2\u505C\u6B62\u3002",
    motionFrameDuration: "\u5173\u952E\u5E27\u65F6\u957F\uFF08\u79D2\uFF0C0.05\u201310\uFF09",
    motionUpdateFrame: "\u66F4\u65B0\u9009\u4E2D\u5E27",
    motionHelpRig: "Godette \u4F7F\u7528\u6807\u51C6 Humanoid \u9AA8\u540D\u6620\u5C04\u53CA\u5B8C\u6574\u53EF\u7528\u6307\u9AA8\u94FE\u3002\u7F16\u8F91\u5668\u3001\u5F55\u5236\u5668\u4E0E\u6D6E\u7A97\u5171\u7528\u540C\u4E00\u4E2A profile \u548C REST \u521D\u59CB\u59FF\u52BF\uFF0C\u4E0D\u518D\u5404\u81EA\u89E3\u91CA\u9AA8\u9ABC\u3002",
    motionHelpAxes: "X/Y/Z \u662F\u9AA8\u9ABC\u672C\u5730\u8F74\uFF0C\u4E0D\u662F\u56FA\u5B9A\u7684\u4E16\u754C\u65B9\u5411\uFF1B\u4E0D\u540C\u9AA8\u9ABC\u7684\u8F74\u5411\u4E0D\u80FD\u4E00\u6982\u800C\u8BBA\u3002\u7EDF\u4E00\u5BFC\u51FA\u4E3A REST \u589E\u91CF\u5F27\u5EA6\uFF0C\u5F55\u5236\u5668\u9AA8\u9ABC\u6ED1\u5757\u663E\u793A\u7EDD\u5BF9\u672C\u5730\u5F27\u5EA6\u3002",
    motionHelpCreate: "\u59FF\u52BF\u7F16\u8F91\u5668\u5236\u4F5C\u5355\u5E27\uFF0C\u5F55\u5236\u5668\u5236\u4F5C\u591A\u5E27\u3002\u586B\u5199\u52A8\u4F5C\u540D\u79F0\u3001\u5339\u914D\u6587\u5B57\u3001\u6807\u7B7E\u540E\u4FDD\u5B58\u8349\u7A3F\uFF1B\u5339\u914D\u6587\u5B57\u7559\u7A7A\u53EF\u53EA\u4F5C\u59FF\u52BF\u7D20\u6750\u3002\u81EA\u5B9A\u4E49\u6587\u5B57\u4E0D\u80FD\u8986\u76D6\u5185\u7F6E\u8BCD\u6216\u5176\u5B83\u5DF2\u542F\u7528\u8BCD\u6761\u3002",
    motionHelpReview: "\u4FDD\u5B58\u8349\u7A3F \u2192 \u9884\u89C8\u5F53\u524D\u52A8\u4F5C \u2192 \u68C0\u67E5\u624B\u5F62\u3001\u65B9\u5411\u3001\u7A7F\u6A21\u548C\u542B\u4E49 \u2192 \u786E\u8BA4\u540E\u7528\u4E8E\u7FFB\u8BD1\u3002\u4E4B\u540E\u5728\u63A7\u5236\u9762\u677F\u8F93\u5165\u5339\u914D\u6587\u5B57\u9A8C\u8BC1\u6D6E\u7A97\u3002\u4EBA\u5DE5\u786E\u8BA4\u4E0D\u662F\u4E13\u4E1A\u624B\u8BED\u8BA4\u8BC1\u3002",
    motionHelpFrames: "\u5F55\u5236\u5668\u70B9\u51FB\u65F6\u95F4\u7EBF\u9009\u5E27\uFF0C\u8C03\u597D\u9AA8\u9ABC\u548C\u65F6\u957F\u540E\u70B9\u51FB\u201C\u66F4\u65B0\u9009\u4E2D\u5E27\u201D\uFF1B\u65B0\u589E\u59FF\u52BF\u7528\u6DFB\u52A0\u5173\u952E\u5E27\u3002\u5355\u5E27 0.05\u201310 \u79D2\uFF0C\u6700\u591A 240 \u5E27\u4E14\u603B\u8BA1\u4E0D\u8D85\u8FC7 120 \u79D2\u3002\u81EA\u52A8\u5F55\u5236\u6BCF 0.3 \u79D2\u91C7\u6837\u3002",
    motionHelpUpdates: "\u4E24\u4E2A\u5DE5\u5177\u9875\u4E0E\u6D6E\u7A97\u5171\u4EAB\u540C\u4E00\u6269\u5C55 ID\u3001\u540C\u4E00\u6D4F\u89C8\u5668\u7528\u6237\u914D\u7F6E\u7684\u672C\u5730\u52A8\u4F5C\u5E93\u3002\u542F\u7528/\u505C\u7528\u4F1A\u81EA\u52A8\u66F4\u65B0\u6D6E\u7A97\u5E76\u53D6\u6D88\u65E7\u64AD\u653E\u961F\u5217\uFF1B\u518D\u6B21\u4FDD\u5B58\u64A4\u9500\u65E7\u786E\u8BA4\u3002\u65B0\u5EFA\u526F\u672C\u4FDD\u7559\u59FF\u52BF\u4F46\u4E0D\u8986\u76D6\u539F\u52A8\u4F5C\u3002",
    motionHelpBackup: "\u4E0B\u8F7D\u7EDF\u4E00 JSON \u7528\u4E8E\u5907\u4EFD\uFF0C\u5BFC\u51FA\u4E0D\u4F1A\u81EA\u52A8\u4FDD\u5B58\u6216\u542F\u7528\u3002\u5BFC\u5165\u662F\u65B0\u8349\u7A3F\u526F\u672C\uFF0C\u5FC5\u987B\u91CD\u65B0\u4FDD\u5B58\u3001\u9884\u89C8\u3001\u786E\u8BA4\u3002\u7F16\u8F91\u5668\u4E0D\u622A\u65AD\u591A\u5E27\u6587\u4EF6\uFF0C\u8BF7\u7528\u5F55\u5236\u5668\u8F7D\u5165\u3002\u5378\u8F7D\u6269\u5C55\u6216\u66F4\u6362\u6269\u5C55 ID \u524D\u52A1\u5FC5\u4E0B\u8F7D\u5907\u4EFD\u3002",
    motionHelpLegacy: "\u8FC1\u79FB\u672C\u9875\u65E7\u52A8\u4F5C\u5E93\u4F1A\u4FDD\u7559 sb_gestures \u539F\u6570\u636E\uFF0C\u91CD\u590D\u8FC1\u79FB\u4F1A\u751F\u6210\u526F\u672C\u3002\u5BFC\u5165\u65E7 JSON \u65F6\u987B\u660E\u786E\u9009\u62E9\u5EA6\u6570/\u7EDD\u5BF9\u5F27\u5EA6\u7B49\u683C\u5F0F\uFF0C\u4E0D\u731C\u5355\u4F4D\u3001\u4E0D\u6267\u884C\u4EE3\u7801\u3002\u65E7\u6587\u4EF6\u6CA1\u6709\u6A21\u578B\u7ED1\u5B9A\uFF0C\u5FC5\u987B\u6765\u81EA\u5F53\u524D\u6A21\u578B\u5E76\u4EBA\u5DE5\u590D\u6838\u3002",
    motionHelpBinding: "\u6587\u4EF6\u6700\u591A 2 MiB\uFF0C\u9AA8\u9ABC/REST \u4E0D\u4E00\u81F4\u3001\u672A\u77E5\u9AA8\u540D\u6216\u4E0D\u5408\u6CD5\u53C2\u6570\u4F1A\u88AB\u62D2\u7EDD\u3002\u7ED1\u5B9A\u4E0D\u662F\u6574\u4E2A GLB \u6216\u8499\u76AE\u7684\u6307\u7EB9\u3002\u8BF7\u4ECE\u6269\u5C55\u63A7\u5236\u9762\u677F\u6253\u5F00\u5DE5\u5177\uFF1B\u72EC\u7ACB localhost \u9875\u9762\u4E0D\u80FD\u5171\u4EAB\u8FD9\u4EFD\u5B58\u50A8\u3002\u5347\u7EA7\u6784\u5EFA\u540E\u987B\u91CD\u65B0\u52A0\u8F7D\u6269\u5C55\u5E76\u5173\u95ED\u3001\u91CD\u5F00\u65E7\u5DE5\u5177\u9875\u3002",
    motionHelpCollision: "\u5148\u5B9A\u4F4D\u5177\u4F53\u8BCD\u6761\u548C\u5173\u952E\u5E27\uFF0C\u5728\u7F16\u8F91\u5668/\u5F55\u5236\u5668\u4ECE\u6B63\u9762\u4E0E\u4FA7\u9762\u68C0\u67E5\u8098\u90E8\u548C\u624B\u8155\uFF1B\u4EC5\u4FEE\u6539\u8BE5\u52A8\u4F5C\u3001\u91CD\u65B0\u9884\u89C8\u786E\u8BA4\uFF0C\u4E0D\u5168\u5C40\u53CD\u8F6C\u6216\u6279\u91CF\u589E\u52A0\u89D2\u5EA6\u3002",
    motionHelpCoverage: "\u67E5\u770B\u547D\u4E2D\u7684 motionIds \u548C\u672A\u547D\u4E2D\u6587\u672C\uFF1B\u65E0\u5339\u914D\u65F6\u4E0D\u6253\u65AD\u6B63\u5728\u64AD\u653E\u7684\u52A8\u4F5C\u3002",
    motionHelpCatalog: "\u67E5\u770B\u5DF2\u542F\u7528\u81EA\u5B9A\u4E49\u52A8\u4F5C\u6570\u91CF\u548C\u65E0\u6548\u8BB0\u5F55\u6570\u91CF\uFF1B\u672A\u542F\u7528\u8349\u7A3F\u4E0D\u4F1A\u53C2\u4E0E\u7FFB\u8BD1\u3002",
    motionDurationInvalid: "\u5173\u952E\u5E27\u65F6\u957F\u987B\u4E3A 0.05\u201310 \u79D2\u3002",
    motionLoadingFailed: "\u6A21\u578B\u52A0\u8F7D\u5931\u8D25\uFF1A{detail}",
    name: "\u4E2D\u6587\uFF08\u7B80\u4F53\uFF09",
    title: "SignBridge \u2014 \u624B\u8BED\u7FFB\u8BD1",
    description: "\u5B9E\u65F6\u5C06\u89C6\u9891\u8BED\u97F3\u7FFB\u8BD1\u6210\u624B\u8BED\uFF0C\u901A\u8FC73D\u865A\u62DF\u4EBA\u5C55\u793A",
    settings: "\u8BBE\u7F6E",
    avatar: "\u865A\u62DF\u4EBA",
    language: "\u8BED\u8A00",
    sourceLanguage: "\u89C6\u9891\u8BED\u8A00",
    targetSignLanguage: "\u624B\u8BED\u7C7B\u578B",
    avatarStyle: "\u865A\u62DF\u4EBA\u5916\u89C2",
    avatarSize: "\u865A\u62DF\u4EBA\u5927\u5C0F",
    avatarPosition: "\u865A\u62DF\u4EBA\u4F4D\u7F6E",
    positionBottomRight: "\u53F3\u4E0B\u89D2",
    positionBottomLeft: "\u5DE6\u4E0B\u89D2",
    positionTopRight: "\u53F3\u4E0A\u89D2",
    positionTopLeft: "\u5DE6\u4E0A\u89D2",
    enableAutoDetect: "\u81EA\u52A8\u68C0\u6D4B\u89C6\u9891",
    enableSubtitles: "\u663E\u793A\u5B57\u5E55",
    voiceVolume: "\u8BED\u97F3\u97F3\u91CF",
    speed: "\u624B\u8BED\u901F\u5EA6",
    about: "\u5173\u4E8E",
    start: "\u5F00\u59CB\u7FFB\u8BD1",
    stop: "\u505C\u6B62\u7FFB\u8BD1",
    loading: "\u52A0\u8F7D\u4E2D...",
    noVideo: "\u672A\u68C0\u6D4B\u5230\u89C6\u9891",
    error: "\u51FA\u9519\u4E86",
    errorNoVideo: "\u9875\u9762\u4E0A\u6CA1\u6709\u627E\u5230\u89C6\u9891",
    ready: "\u5DF2\u5C31\u7EEA",
    translating: "\u6B63\u5728\u7FFB\u8BD1...",
    unavailable: "\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u7528",
    inputPlaceholder: "\u8F93\u5165\u6587\u5B57\uFF0C\u865A\u62DF\u4EBA\u6253\u624B\u8BED...",
    send: "\u53D1\u9001",
    sent: "\u5DF2\u53D1\u9001",
    audioOff: "\u89C6\u9891\u58F0\u97F3\uFF1A\u5173\u95ED",
    audioOn: "\u89C6\u9891\u58F0\u97F3\uFF1A\u5F00\u542F",
    audioStopped: "\u5DF2\u5173\u95ED",
    audioListening: "\u8BC6\u522B\u4E2D...",
    audioStarting: "\u6B63\u5728\u6355\u83B7\u58F0\u97F3...",
    audioUnavailable: "\u5F53\u524D\u9875\u9762\u4E0D\u53EF\u6355\u83B7",
    audioCaptureFailed: "\u58F0\u97F3\u6355\u83B7\u5931\u8D25",
    audioCloudKeyRequired: "\u8BF7\u5148\u914D\u7F6E\u4E91\u7AEF API Key",
    audioPermissionRequired: "\u8BF7\u5148\u4FDD\u5B58\u8BC6\u522B\u8BBE\u7F6E\u5E76\u6388\u6743\u670D\u52A1\u5730\u5740",
    audioLocalUnavailable: "\u8BF7\u5148\u4E00\u952E\u90E8\u7F72\u672C\u5730 Whisper",
    asrSettings: "\u58F0\u97F3\u8BC6\u522B\u8BBE\u7F6E",
    asrTitle: "\u89C6\u9891\u58F0\u97F3\u8BC6\u522B",
    asrPurpose: "\u9009\u62E9\u672C\u5730 Whisper \u6216\u4E91\u7AEF ASR\uFF0C\u5C06\u5F53\u524D\u89C6\u9891\u58F0\u97F3\u8F6C\u6362\u4E3A\u624B\u8BED\u52A8\u4F5C\u3002",
    asrProvider: "\u8BC6\u522B\u65B9\u5F0F",
    asrLocal: "\u672C\u5730 Whisper",
    asrCloud: "\u4E91\u7AEF ASR",
    asrLocalSettings: "\u672C\u5730 Whisper \u8BBE\u7F6E",
    asrLocalPrivacy: "\u6A21\u578B\u548C\u97F3\u9891\u90FD\u5728\u6D4F\u89C8\u5668\u6269\u5C55\u5185\u5904\u7406\uFF0C\u89C6\u9891\u58F0\u97F3\u4E0D\u4F1A\u4E0A\u4F20\u5230\u8BC6\u522B\u670D\u52A1\u3002",
    asrDeployLocal: "\u4E00\u952E\u90E8\u7F72\u672C\u5730 Whisper",
    asrEndpoint: "\u670D\u52A1\u5730\u5740",
    asrModel: "\u6A21\u578B",
    asrModelTiny: "tiny\uFF08\u6700\u5FEB\uFF0C\u7EA6 75 MB\uFF09",
    asrModelBase: "base\uFF08\u5747\u8861\uFF0C\u7EA6 150 MB\uFF09",
    asrModelSmall: "small\uFF08\u66F4\u51C6\u786E\uFF0C\u7EA6 500 MB\uFF09",
    asrDeployHint: "\u70B9\u51FB\u540E\u81EA\u52A8\u4E0B\u8F7D\u5E76\u7F13\u5B58\u6A21\u578B\uFF0C\u65E0\u9700\u5B89\u88C5 Python \u6216\u8FD0\u884C\u672C\u5730\u670D\u52A1\u3002",
    asrDeployRequired: "\u5F53\u524D\u6A21\u578B\u5C1A\u672A\u90E8\u7F72\u3002",
    asrRequestingModelPermission: "\u6B63\u5728\u7533\u8BF7\u6A21\u578B\u4E0B\u8F7D\u6743\u9650...",
    asrDeploying: "\u6B63\u5728\u4E0B\u8F7D\u5E76\u521D\u59CB\u5316\u6A21\u578B\uFF1A{progress}%",
    asrDeployReady: "\u672C\u5730\u6A21\u578B {model} \u5DF2\u5C31\u7EEA\u3002",
    asrDeployFailed: "\u672C\u5730\u6A21\u578B\u90E8\u7F72\u5931\u8D25",
    asrCloudSettings: "\u4E91\u7AEF ASR \u8BBE\u7F6E",
    asrCloudPrivacy: "\u89C6\u9891\u97F3\u9891\u5206\u7247\u4F1A\u53D1\u9001\u5230\u4F60\u914D\u7F6E\u7684\u670D\u52A1\uFF0C\u8BF7\u786E\u8BA4\u670D\u52A1\u7684\u9690\u79C1\u4E0E\u8BA1\u8D39\u89C4\u5219\u3002",
    asrApiKey: "API Key",
    asrCommonSettings: "\u901A\u7528\u8BBE\u7F6E",
    asrLanguage: "\u8BC6\u522B\u8BED\u8A00",
    asrChunkSeconds: "\u97F3\u9891\u5206\u7247",
    asrTest: "\u6D4B\u8BD5\u8FDE\u63A5",
    asrSave: "\u4FDD\u5B58\u8BBE\u7F6E",
    asrPermissionDenied: "\u672A\u6388\u4E88\u8BE5\u670D\u52A1\u5730\u5740\u7684\u7F51\u7EDC\u6743\u9650\u3002",
    asrSaved: "\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002",
    asrInvalidConfig: "\u8BBE\u7F6E\u65E0\u6548\uFF1A\u8FDC\u7A0B\u670D\u52A1\u9700HTTPS\uFF1BHTTP\u4EC5\u5141\u8BB8127.0.0.1\u3001localhost\u6216[::1]\u672C\u673A\u5730\u5740\uFF0CURL\u4E0D\u53EF\u542B\u8D26\u53F7\u5BC6\u7801\u3002",
    asrTesting: "\u6B63\u5728\u6D4B\u8BD5\u8BC6\u522B\u670D\u52A1...",
    asrTestPassed: "\u8FDE\u63A5\u6D4B\u8BD5\u901A\u8FC7\u3002",
    asrTestFailed: "\u8FDE\u63A5\u6D4B\u8BD5\u5931\u8D25",
    poseEditor: "\u59FF\u52BF\u7F16\u8F91\u5668",
    recorder: "\u5F55\u5236\u5DE5\u5177",
    help: "\u5E2E\u52A9\u6587\u6863",
    tagline: "\u8BA9\u4FE1\u606F\u65E0\u969C\u788D",
    auto: "\u81EA\u52A8\u68C0\u6D4B",
    simplifiedChinese: "\u4E2D\u6587\uFF08\u666E\u901A\u8BDD\uFF09",
    footer: "SignBridge \u2014 \u8BA9\u4FE1\u606F\u65E0\u969C\u788D",
    signLanguageTypes: {
      csl: "\u4E2D\u56FD\u624B\u8BED (CSL)",
      asl: "\u7F8E\u56FD\u624B\u8BED (ASL)",
      bsl: "\u82F1\u56FD\u624B\u8BED (BSL)",
      jsl: "\u65E5\u672C\u624B\u8BED (JSL)",
      ksl: "\u97E9\u56FD\u624B\u8BED (KSL)",
      tsl: "\u53F0\u6E7E\u624B\u8BED (TSL)"
    },
    avatarStyles: {
      default: "\u9ED8\u8BA4",
      friendly: "\u53CB\u597D",
      professional: "\u4E13\u4E1A",
      anime: "\u52A8\u6F2B\u98CE\u683C"
    },
    voiceVolumeLevels: {
      low: "\u4F4E\uFF08\u4EC5\u89C6\u9891\uFF09",
      medium: "\u4E2D\uFF08\u89C6\u9891+\u624B\u8BED\uFF09",
      high: "\u9AD8\uFF08\u4EC5\u624B\u8BED\uFF09"
    }
  },
  en: {
    ...DEMO_EN,
    ...SEMANTIC_EN,
    ...PRIVATE_EN,
    ...WORKBENCH_EN,
    batchTitle: "Vocabulary batch \xB7 up to 8 items",
    batchManual: "Add a complete phrase manually (optional, avoids token-splitting mistakes)",
    batchInvalidWord: "Enter a word or phrase of 1\u2013100 characters, not only whitespace or punctuation.",
    batchIntro: "Add frequent gaps from the analysis. Save a draft, inspect it in Motion review, then explicitly enable it in the editor or recorder. A full match means data is available, not that the sign is linguistically correct. This list never generates, edits or enables motions.",
    batchAdd: "Add to batch",
    batchRefresh: "Refresh batch status",
    batchExport: "Download progress JSON",
    batchClear: "Clear batch list",
    batchClearConfirm: "Clear only this list? Motions and visual baselines will not be deleted.",
    batchRemove: "Remove from batch",
    batchState: "Actual match status / motion IDs",
    batchLoading: "Checking the current motion library\u2026",
    batchEmpty: "No selected words. Analyze a sample, then add vocabulary gaps to this batch.",
    batchMissing: "Needs authoring \xB7 not fully matched",
    batchDraft: "Candidate saved \xB7 not enabled or fully matched",
    batchMatched: "Fully matched \xB7 human sign-language review still required",
    batchUnverified: "Status not verified; please retry",
    batchSummary: "Batch {count}/{max} \xB7 fully matched {matched} \xB7 invalid library entries {invalid}. Motion changes trigger a fresh check.",
    batchPrivacy: "Only words you explicitly add persist in this extension's local storage. No source text or examples are saved or uploaded. The list is not part of a motion pack. Progress exports contain selected words and motion IDs; check privacy before sharing.",
    batchFailure: "Vocabulary batch failed: {detail}",
    batchFull: "This batch already has 8 words. Complete or remove some first.",
    batchInvalid: "Invalid batch data. Existing data was not overwritten; explicitly clear the list to start again.",
    batchLockUnavailable: "Cross-page write lock unavailable. No changes made. Open this page from the extension panel.",
    reviewTitle: "Motion review",
    reviewIntro: "Replay saved motions and compare fixed front, right and left snapshots with manually approved visual references. No rig changes or automatic translation approval.",
    reviewLimits: "Up to 8 motions per batch and 12 sampled keyframes per motion, including first and last. Snapshots cover target poses, not every transition, collision, subtitle sequence or linguistic meaning. Human review is required. The built-in list covers SIGNS, not CHARS fallbacks.",
    reviewHelp: "Control panel \u2192 Motion review. Select motions to replay or capture three views. Check hands, directions and intersections before saving a visual baseline. Later captures appear alongside it. Changed motion data requires new review; different model/browser/rendering environments disable numeric comparison. Baselines do not change draft or enabled status, and do not certify correct signing.",
    reviewStorageHelp: "References stay in this extension's IndexedDB, separate from the motion library, capped at 100 / 64 MiB. Motion packs do not include them. Download PNG and JSON before uninstalling (baseline reimport is not supported yet). Nothing is sent over the network.",
    reviewReload: "Reload model / retry",
    reviewSelect: "1 \xB7 Select motions",
    reviewSearch: "Filter by name, ID or status (checked motions remain selected)",
    reviewCatalogCount: "{total} available \xB7 {count}/{max} selected \xB7 {invalid} invalid library records",
    reviewPlay: "Replay all frames in order",
    reviewCapture: "Capture three-view keyframes",
    reviewStop: "Stop current task",
    reviewPreview: "Fixed-view preview",
    reviewView: "Playback view",
    reviewFront: "Front",
    reviewRight: "Character's right",
    reviewLeft: "Character's left",
    reviewPreviewHelp: "Views never change the floating avatar. Each replay starts from REST; capture resets to the front view.",
    reviewResults: "2 \xB7 Human review and baseline comparison",
    reviewExport: "Download batch JSON report",
    reviewBuiltin: "Built-in \xB7 needs human review",
    reviewEnabled: "Custom \xB7 enabled",
    reviewDraft: "Custom \xB7 draft",
    reviewLoading: "Loading the actual model, rig and motion library\u2026",
    reviewReady: "Ready: {total} motions. Select motions to replay or capture.",
    reviewFailure: "Review failed: {detail}",
    reviewCatalogChanged: "The library changed; these results are stale. Select and capture again. Existing baselines are never overwritten automatically.",
    reviewPlaying: "Playing {index}/{total}: {name}",
    reviewCapturing: "Capturing {index}/{total}: {name}",
    reviewFinished: "Finished {count} motions; {failures} structural errors. Human review is still required.",
    reviewCancelled: "Stopped. Incomplete batch captures discarded; baselines unchanged.",
    reviewDiagnostics: "{frames} frames / {duration}s, {bones} bones. Sheet rows: frames {indices}; {omitted} frames not captured.",
    reviewSheetOrder: "Columns: front \u2192 character's right \u2192 character's left. Rows follow frame indices. Download PNG to inspect at full size.",
    reviewCurrent: "Current capture",
    reviewBaseline: "Confirmed visual reference",
    reviewNoBaseline: "No visual reference yet. Inspect the motion before saving one.",
    reviewCompared: "Baseline {date}. Pixels with RGB channel difference >16: {ratio}%; mean channel difference {mean}/255. Review hint only, not signing or collision certification.",
    reviewMotionChanged: "Motion data changed (including duration or name). Previous reference retained; numeric comparison disabled. Review again.",
    reviewIncompatible: "Model, rig, browser or rendering environment differs. Numeric comparison is unreliable and disabled. Old image is for reference only.",
    reviewUnavailable: "Baseline read / comparison failed: {detail}. Current PNG remains downloadable; saving will retry.",
    reviewSaveBaseline: "Save / replace visual reference",
    reviewDeleteBaseline: "Delete this reference",
    reviewDownloadImage: "Download current PNG",
    reviewSaveConfirm: "Have you checked all three views of \u201C{name}\u201D? Saving replaces its existing visual reference for regression comparison only. It neither enables translation nor certifies correct signing.",
    reviewDeleteConfirm: "Delete the visual reference for \u201C{name}\u201D? The motion itself is not deleted.",
    reviewSaved: "Visual reference saved; motion library and translation status unchanged.",
    reviewDeleted: "Visual reference deleted; motion data unchanged.",
    reviewStorageError: "Cannot access local baseline storage. Check disk space and reopen from the extension control panel.",
    reviewStorageFull: "Reference limit reached (100 or 64 MiB). Download a copy, then remove unneeded references.",
    reviewBaselineChanged: "Another page updated this reference. Nothing overwritten. Capture again before confirming.",
    reviewModelError: "Model load failed or dimensions invalid. Rebuild the extension and retry.",
    reviewMissingBones: "Required signing bones are missing; review blocked.",
    reviewRenderError: "Rendering failed or WebGL context was lost. Stop and reload the model.",
    reviewInvalidSamples: "Invalid keyframe sampling parameters.",
    reviewImageMismatch: "Reference image is damaged or dimensions differ; comparison blocked.",
    motionPackTitle: "Library backup / batch import",
    motionPackHelp: "Export all saved custom motions for this model, not unsaved edits or built-in signs. Choosing a file only runs preflight. Confirmation adds drafts: identical IDs/content are skipped; differing content blocks the entire import. Load, preview and confirm each new motion separately.",
    motionPackPrivacy: "Files contain names, matching text, tags, rig binding, frames and an informational enabled-at-export flag, not keys or subtitles. Names and tags may be sensitive; check before sharing. Imports never inherit approval and are not uploaded.",
    motionPackExport: "Back up all saved motions",
    motionPackFile: "Select motion pack JSON (not a single-motion file)",
    motionPackLimits: "Up to 500 motions / 8 MiB per pack; 2 MiB per motion. Rig and REST must match.",
    motionPackInspect: "Run preflight again",
    motionPackImport: "Confirm import as new drafts",
    motionPackClear: "Cancel pending file",
    motionPackSummary: "Preflight: {new} new, {existing} existing, {conflict} ID conflicts. Nothing has been saved.",
    motionPackName: "Motion / ID",
    motionPackState: "Action",
    motionPackWarnings: "Review notes",
    motionPackNew: "New draft",
    motionPackExisting: "Identical; skip",
    motionPackIdConflict: "ID conflict; no overwrite",
    motionPackWasEnabled: "Pack says previously enabled; this is source information, not trusted approval.",
    motionPackAliases: "Potential duplicate matching text: {aliases}. Draft saving is allowed; review before enabling (includes disabled entries).",
    motionPackMaterial: "No matching text; pose material only, not eligible for translation.",
    motionPackReady: "Preflight complete. Only new drafts are added; current pose and existing approval remain unchanged.",
    motionPackChecking: "Checking the rig and local library\u2026",
    motionPackCleared: "Cancelled. The library is unchanged.",
    motionPackConfirm: "Add {count} drafts without overwriting or enabling motions? Ensure you have permission to use the source. Review handshape, direction and meaning individually after import.",
    motionPackImported: "Added {imported} drafts; skipped {skipped} existing motions. Load, preview and confirm each from the list.",
    motionPackExported: "Started download of {count} saved motions. Check the downloaded file; unsaved edits are not included.",
    motionPackInvalid: "Not a valid v1 motion pack JSON. For one motion, use the single-motion import above.",
    motionPackEmpty: "The pack is empty, or there are no saved motions to back up.",
    motionPackTooLarge: "Limit exceeded: 8 MiB / 500 motions per pack, 2 MiB per motion. Nothing was saved.",
    motionPackDuplicateId: "Duplicate IDs within the pack are ambiguous; import was rejected.",
    motionPackInvalidStored: "Local entries are damaged or incompatible with the current model. No incomplete backup was produced; originals are preserved. Inspect those entries first.",
    motionPackConflict: "A local ID has different or damaged content. The entire import is blocked; nothing is overwritten. Use single-motion import to create a separate copy if needed.",
    motionPackStale: "The library changed and preflight expired. Run preflight again and review the list before importing.",
    motionPackLockUnavailable: "Cross-page write locking is unavailable. Batch import stopped; reopen the tool from the extension panel.",
    motionPackEncoding: "Not valid UTF-8 JSON. Convert the encoding and retry.",
    coverageTitle: "Vocabulary coverage",
    coverageHelpWorkflow: "Open Vocabulary coverage from the control panel. Paste text or import UTF-8 TXT / SRT / VTT to inspect unknown words, frequency and context. Editor and recorder buttons only prefill a name and matching text. Create and review a motion, enable it, then analyze again to verify it is active.",
    coverageIntro: "Find missing vocabulary in real text, then create and review motions. This does not generate signs or change existing poses.",
    coverageInput: "1 \xB7 Choose material",
    coverageTextLabel: "Paste text (one segment per line), or import UTF-8 subtitles",
    coverageLimits: "Limits: 256 KiB file, 50,000 characters, 1,000 segments, 2,000 characters per segment. SRT / WebVTT use subtitle cues.",
    coverageFormat: "Format",
    coveragePlainText: "Plain text \xB7 one segment per line",
    coverageImport: "Import file",
    coverageAnalyze: "Analyze current vocabulary",
    coverageClear: "Clear",
    coverageResults: "2 \xB7 Prioritize missing vocabulary",
    coverageMetricHelp: "Coverage = matched word tokens / (matched + unknown word tokens). Skipped function words and punctuation are excluded. This measures full-segment dictionary coverage, not sign accuracy, sentence meaning or completed playback.",
    coverageUnknownTitle: "Unknown words \xB7 most frequent first",
    coverageDraftHelp: "These are tokenizer suggestions. Check context before deciding whether a full phrase is needed. Tools only prefill the name and matching text: no automatic save, approval or claim that the current pose represents the word.",
    coverageWord: "Unknown word",
    coverageFrequency: "Occurrences / segments",
    coverageExamples: "Example segment numbers",
    coverageMake: "Create and review",
    coverageDetailsTitle: "3 \xB7 Inspect actual matches by segment",
    coverageDisplayLimit: "Shows up to 100 unknown words and 200 segments. Totals cover all input; export for complete results.",
    coverageIncludeText: "Include source text and segment details in export (may contain private data)",
    coverageExport: "Export JSON report",
    coveragePrivacy: "Analysis stays in this page's memory: no uploads or automatic saving. Closing the page discards it. Default exports omit source text but still contain unknown words; check before sharing.",
    coverageSummary: "Coverage {ratio} \xB7 {segments} segments \xB7 {matched} matched / {unknown} unknown / {skipped} skipped",
    coverageNoTokens: "N/A (no translatable tokens)",
    coverageTruncation: "{count} segments reach the runtime limit of 12 motions per segment. Some text may not play; inspect the remaining text below.",
    coverageOccurrences: "{count} occurrences / {segments} segments",
    coverageUniqueUnknown: "{count} distinct unknown words. Split or reconsider tokenization for very long words.",
    coverageNoUnknown: "No unknown words found. Sign meaning and motion still need human review.",
    coverageMatches: "Matched: {value}",
    coverageUnmatched: "Unknown: {value}",
    coverageSkipped: "Skipped: {value}",
    coverageRemaining: "Text remaining after playback limit: {value}",
    coverageCatalog: "Vocabulary: {signs} built-in signs / {aliases} lookup aliases / {chars} characters; {enabled} active custom; {drafts} inactive; {invalid} invalid or incompatible entries (originals kept).",
    coverageReady: "Paste or import, then analyze. The first analysis loads the model to validate custom motion bindings.",
    coverageLoading: "Validating model and library, then analyzing\u2026",
    coverageDone: "Analysis complete. Create missing motions, review and enable them, then analyze again here.",
    coverageChanged: "Input changed. Analyze again; the old report cannot be exported.",
    coverageCatalogChanged: "Shared library changed. Analyze again for current coverage; the old report cannot be exported.",
    coverageImported: "Imported. Click Analyze; nothing is played or saved automatically.",
    coverageFailure: "Analysis did not complete: {detail}",
    coverageTooLarge: "Material exceeds size, segment count or segment length limits. Split it and try again.",
    coverageEmpty: "Provide at least one non-empty text segment.",
    coverageInvalidFormat: "Only TXT, SRT and WebVTT are supported. Select the matching format.",
    coverageInvalidSubtitles: "Invalid subtitles. Check blank lines, timestamps, start/end order and WebVTT header. Timing lines will not be counted as text.",
    coverageEncoding: "Not valid UTF-8. Convert the file encoding and retry.",
    coverageModelError: "Cannot validate the current model or shared library. Open from the extension, check model loading and retry. No incomplete fallback report was produced.",
    coverageOpenFailed: "Could not open the tool. Retry from the extension panel.",
    coveragePrefilled: "Name and matching text prefilled from coverage. The current pose is not a verified sign for this word. Create, save, preview and review it before enabling.",
    motionLibraryTitle: "Shared motion library \xB7 Phase 2",
    motionLibraryHelp: "Editor, recorder and avatar share radians and REST deltas. Saved drafts affect translation only after preview and explicit confirmation.",
    motionName: "Motion name (required)",
    motionTexts: "Matching text (comma separated; empty for pose-only assets)",
    motionTags: "Tags (comma separated)",
    motionNew: "New copy",
    motionNewHelp: "Current pose retained. Enter a new motion name.",
    motionSave: "Save draft",
    motionSaved: "Draft saved. Preview and confirm again before enabling.",
    motionLoad: "Load selected",
    motionLoaded: "Loaded. Imported files are not automatically saved or enabled. Review and save a draft.",
    motionChoose: "Choose a saved motion\u2026",
    motionDraft: "Draft / disabled",
    motionEnabled: "Confirmed and enabled",
    motionPreview: "Preview current motion",
    motionPreviewHelp: "Using the same player as the avatar. Check handshape, direction, collisions and meaning. Save again after edits.",
    motionEnable: "Confirm for translation",
    motionDisable: "Disable selected",
    motionConfirm: "I have previewed the entire motion and checked its handshape, direction, collisions and meaning. This is my confirmation, not professional sign-language certification. Enable it?",
    motionEnabledHelp: "Enabled. Open avatars reload automatically; newly matched text will use this motion.",
    motionDisabledHelp: "Disabled; draft retained. Queued custom motions are cancelled in open avatars.",
    motionRefresh: "Refresh list",
    motionExport: "Download unified JSON",
    motionExportCode: "Export code (no save)",
    motionImport: "Import motion JSON",
    motionImportFormat: "Import format and units",
    motionFormat: "Unified \xB7 radians / REST delta",
    motionLegacyEditor: "Legacy editor delta \xB7 degrees (pose object only)",
    motionLegacyRecorder: "Legacy recorder frames.pose \xB7 degrees",
    motionLegacyAbsolute: "Legacy editor absolute rotation \xB7 radians",
    motionMigrate: "Migrate this page's old library",
    motionLegacyConfirm: "Legacy data has no rig binding. Continue only if it came from the current model with the selected format and units. Review each converted draft. Original local data will be retained. Continue?",
    motionMigrated: "Migrated {count} drafts; originals retained, none enabled. Repeating creates copies.",
    motionIgnored: "Skipped {count} damaged or rig-incompatible entries; original data retained.",
    motionFailure: "Not completed: {detail}",
    motionInvalidData: "Invalid motion format or parameters: {detail}",
    motionModelNotReady: "The model is not ready.",
    motionRigMismatch: "Skeleton or REST pose mismatch. Motion rejected.",
    motionStorageUnavailable: "Shared storage unavailable. Open this tool from the extension panel.",
    motionSelectFirst: "Save or select a motion first.",
    motionSaveFirst: "Motion changed. Save a draft and preview again before enabling.",
    motionPreviewFirst: "Preview this motion before confirming.",
    motionAliasConflict: "Empty text or alias conflicts with an enabled/built-in sign: {detail}. Choose a distinct phrase.",
    motionFileTooLarge: "File or entry count too large (2 MiB per file).",
    motionEditorSingleFrame: "The editor handles single poses. Open multi-frame clips in the recorder to avoid losing frames.",
    motionFrameLimit: "240-frame limit reached. Recording stopped.",
    motionFrameDuration: "Keyframe duration (seconds, 0.05\u201310)",
    motionUpdateFrame: "Update selected frame",
    motionHelpRig: "Godette uses standard Humanoid bone mappings and the available finger chains. The editor, recorder and floating avatar share one profile and REST pose.",
    motionHelpAxes: "X/Y/Z are bone-local axes, not fixed world directions. Exports use REST-relative radians; recorder bone sliders show absolute local radians. Do not assume the same axis direction for every bone.",
    motionHelpCreate: "Use the editor for single poses and the recorder for clips. Enter a name, matching text and tags, then save a draft. Leave matching text empty for pose material. Custom aliases cannot override built-in or enabled aliases.",
    motionHelpReview: "Save draft \u2192 Preview current motion \u2192 Check handshape, direction, collisions and meaning \u2192 Confirm for translation. Test the matching text from the control panel. Confirmation is not professional sign-language certification.",
    motionHelpFrames: "Select a timeline frame, edit bones and duration, then click Update selected frame. Add keyframes for new poses. Each frame is 0.05\u201310 seconds; up to 240 frames and 120 seconds total. Automatic recording samples every 0.3 seconds.",
    motionHelpUpdates: "Both tools and the avatar share local storage within one extension ID and browser profile. Enabling or disabling refreshes the avatar and cancels old playback queues. Saving again revokes approval. New copy keeps poses without overwriting the original motion.",
    motionHelpBackup: "Download unified JSON for backups; exporting does not save or enable. Imports are new draft copies requiring saving, preview and confirmation. Open multi-frame files in the recorder, not the single-pose editor. Back up before uninstalling or changing extension IDs.",
    motionHelpLegacy: "Migrating the old page library retains sb_gestures; repeating migration creates copies. Explicitly select degrees or absolute radians for old JSON files. Units are never guessed and code is never executed. Legacy data must use the current model and requires manual review.",
    motionHelpBinding: "Files are limited to 2 MiB. Incompatible bone/REST bindings, unknown bones and invalid values are rejected. This binding is not a full GLB or skin-weight fingerprint. Open tools from the extension popup; standalone localhost pages cannot share this storage. Reload the extension and reopen old tool tabs after updating.",
    motionHelpCollision: "Identify the exact motion and frame. Inspect elbows and wrists from front and side views in the tools. Edit and review only that motion; do not globally reverse axes or increase angles.",
    motionHelpCoverage: "Inspect matched motionIds and unmatched text. Unknown input does not interrupt current playback.",
    motionHelpCatalog: "Inspect enabled custom motion and invalid entry counts. Drafts do not participate in translation.",
    motionDurationInvalid: "Keyframe duration must be 0.05\u201310 seconds.",
    motionLoadingFailed: "Model loading failed: {detail}",
    name: "English",
    title: "SignBridge \u2014 Sign Language Translation",
    description: "Real-time video speech to sign language translation via 3D avatar",
    settings: "Settings",
    avatar: "Avatar",
    language: "Language",
    sourceLanguage: "Video Language",
    targetSignLanguage: "Sign Language",
    avatarStyle: "Avatar Style",
    avatarSize: "Avatar Size",
    avatarPosition: "Avatar Position",
    positionBottomRight: "Bottom Right",
    positionBottomLeft: "Bottom Left",
    positionTopRight: "Top Right",
    positionTopLeft: "Top Left",
    enableAutoDetect: "Auto-detect Video",
    enableSubtitles: "Show Subtitles",
    voiceVolume: "Voice Volume",
    speed: "Sign Speed",
    about: "About",
    start: "Start Translation",
    stop: "Stop Translation",
    loading: "Loading...",
    noVideo: "No video detected",
    error: "Error",
    errorNoVideo: "No video found on this page",
    ready: "Ready",
    translating: "Translating...",
    unavailable: "Unavailable on this page",
    inputPlaceholder: "Enter text for the avatar to sign...",
    send: "Send",
    sent: "Sent",
    audioOff: "Video audio: Off",
    audioOn: "Video audio: On",
    audioStopped: "Stopped",
    audioListening: "Recognizing...",
    audioStarting: "Capturing audio...",
    audioUnavailable: "Audio capture is unavailable on this page",
    audioCaptureFailed: "Audio capture failed",
    audioCloudKeyRequired: "Configure the cloud API key first",
    audioPermissionRequired: "Save ASR settings and allow the service origin",
    audioLocalUnavailable: "Deploy local Whisper first",
    asrSettings: "Audio recognition settings",
    asrTitle: "Video audio recognition",
    asrPurpose: "Choose local Whisper or cloud ASR to convert video audio into sign language motion.",
    asrProvider: "Recognition provider",
    asrLocal: "Local Whisper",
    asrCloud: "Cloud ASR",
    asrLocalSettings: "Local Whisper settings",
    asrLocalPrivacy: "The model and audio stay inside the extension. Video audio is not uploaded to an ASR service.",
    asrDeployLocal: "Deploy local Whisper",
    asrEndpoint: "Service endpoint",
    asrModel: "Model",
    asrModelTiny: "tiny (fastest, about 75 MB)",
    asrModelBase: "base (balanced, about 150 MB)",
    asrModelSmall: "small (more accurate, about 500 MB)",
    asrDeployHint: "Downloads and caches the model automatically. Python and a local service are not required.",
    asrDeployRequired: "The selected model is not deployed.",
    asrRequestingModelPermission: "Requesting model download access...",
    asrDeploying: "Downloading and initializing model: {progress}%",
    asrDeployReady: "Local model {model} is ready.",
    asrDeployFailed: "Local model deployment failed",
    asrCloudSettings: "Cloud ASR settings",
    asrCloudPrivacy: "Video audio chunks are sent to the configured service. Review its privacy and billing terms.",
    asrApiKey: "API Key",
    asrCommonSettings: "Common settings",
    asrLanguage: "Recognition language",
    asrChunkSeconds: "Audio chunk",
    asrTest: "Test connection",
    asrSave: "Save settings",
    asrPermissionDenied: "Network access to this service was not granted.",
    asrSaved: "Settings saved.",
    asrInvalidConfig: "Invalid settings: use HTTPS remotely or HTTP on loopback only. URL credentials are not allowed.",
    asrTesting: "Testing the recognition service...",
    asrTestPassed: "Connection test passed.",
    asrTestFailed: "Connection test failed",
    poseEditor: "Pose editor",
    recorder: "Recorder",
    help: "Help",
    tagline: "Accessible information",
    auto: "Auto detect",
    simplifiedChinese: "Chinese (Mandarin)",
    footer: "SignBridge \u2014 Making Information Accessible",
    signLanguageTypes: {
      csl: "Chinese Sign Language (CSL)",
      asl: "American Sign Language (ASL)",
      bsl: "British Sign Language (BSL)",
      jsl: "Japanese Sign Language (JSL)",
      ksl: "Korean Sign Language (KSL)",
      tsl: "Taiwan Sign Language (TSL)"
    },
    avatarStyles: {
      default: "Default",
      friendly: "Friendly",
      professional: "Professional",
      anime: "Anime Style"
    },
    voiceVolumeLevels: {
      low: "Low (video only)",
      medium: "Medium (video + sign)",
      high: "High (sign only)"
    }
  },
  ja: {
    ...DEMO_EN,
    ...SEMANTIC_JA,
    ...PRIVATE_EN,
    ...WORKBENCH_JA,
    workbenchServiceHandoff: "\u610F\u5473\u5206\u6790\u306F\u30ED\u30FC\u30AB\u30EB\u30B5\u30FC\u30D3\u30B9\u3067\u5B9F\u884C\u3057\u307E\u3059\u3002\u30DC\u30BF\u30F3\u3067\u8D77\u52D5\u72B6\u614B\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u30DA\u30FC\u30B8\u3092\u958B\u304D\u307E\u3059\u3002\u79FB\u52D5\u6642\u306B\u53E3\u4EE4\u3084\u5165\u529B\u6587\u306F\u9001\u308A\u307E\u305B\u3093\u3002",
    privateServiceUnavailableStatus: "\u30ED\u30FC\u30AB\u30EB\u610F\u5473\u5206\u6790\u30B5\u30FC\u30D3\u30B9\u304C\u8D77\u52D5\u3057\u3066\u3044\u307E\u305B\u3093\u3002\u3053\u306E\u30DA\u30FC\u30B8\u304B\u3089\u79FB\u52D5\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
    privateServiceUnavailable: "\u30ED\u30FC\u30AB\u30EB\u610F\u5473\u5206\u6790\u30B5\u30FC\u30D3\u30B9\u3092\u78BA\u8A8D\u3067\u304D\u307E\u305B\u3093\u3002SignBridge \u30EA\u30DD\u30B8\u30C8\u30EA\u306E\u30EB\u30FC\u30C8\u3067\u30BF\u30FC\u30DF\u30CA\u30EB\u3092\u958B\u304D\u3001\u6B21\u306E\u30B3\u30DE\u30F3\u30C9\u3092\u5B9F\u884C\u3057\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    privateServiceStartFromRoot: "\u8D77\u52D5\u30B3\u30DE\u30F3\u30C9\uFF08\u30EA\u30DD\u30B8\u30C8\u30EA\u306E\u30EB\u30FC\u30C8\u3067\u5B9F\u884C\uFF09\uFF1A",
    privateServiceCommand: ".venv-sign-data/bin/python signbridge/src/tools/sign-private-serve.py --model local-data/csl-understanding-20261017-rLaeiN/learned-roles-v3 --client local-data/existing-resources-optimization-20261019-v1/thin-client-v1.0.5 --port 8770 --scope-experiment --unit-candidates local-data/existing-resources-optimization-20261019-v1/unit-candidates-final/candidates.json",
    batchTitle: "\u4ECA\u56DE\u306E\u8A9E\u5F59\u8FFD\u52A0\u30EA\u30B9\u30C8 \xB7 \u6700\u5927 8 \u4EF6",
    batchManual: "\u8A9E\u53E5\u3092\u624B\u52D5\u3067\u8FFD\u52A0\uFF08\u4EFB\u610F\u30FB\u5206\u5272\u306E\u8AA4\u308A\u3092\u56DE\u907F\uFF09",
    batchInvalidWord: "\u7A7A\u767D\u3084\u8A18\u53F7\u3060\u3051\u3067\u306F\u306A\u3044\u30011\uFF5E100 \u6587\u5B57\u306E\u8A9E\u53E5\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    batchIntro: "\u5206\u6790\u7D50\u679C\u304B\u3089\u983B\u51FA\u306E\u672A\u5BFE\u5FDC\u8A9E\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u300C\u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C\u300D\u3067\u78BA\u8A8D\u3057\u3066\u304B\u3089\u3001\u7DE8\u96C6\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u3067\u660E\u793A\u7684\u306B\u6709\u52B9\u5316\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5B8C\u5168\u4E00\u81F4\u306F\u30C7\u30FC\u30BF\u306E\u5B58\u5728\u3092\u793A\u3059\u3060\u3051\u3067\u3001\u624B\u8A71\u306E\u6B63\u78BA\u3055\u3092\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002\u3053\u306E\u30EA\u30B9\u30C8\u306F\u52D5\u4F5C\u306E\u751F\u6210\u30FB\u5909\u66F4\u30FB\u6709\u52B9\u5316\u3092\u884C\u3044\u307E\u305B\u3093\u3002",
    batchAdd: "\u4ECA\u56DE\u306E\u30EA\u30B9\u30C8\u306B\u8FFD\u52A0",
    batchRefresh: "\u5BFE\u5FDC\u72B6\u6CC1\u3092\u66F4\u65B0",
    batchExport: "\u9032\u6357 JSON \u3092\u4FDD\u5B58",
    batchClear: "\u4ECA\u56DE\u306E\u30EA\u30B9\u30C8\u3092\u6D88\u53BB",
    batchClearConfirm: "\u30EA\u30B9\u30C8\u3060\u3051\u3092\u6D88\u53BB\u3057\u307E\u3059\u304B\uFF1F\u52D5\u4F5C\u3068\u6BD4\u8F03\u57FA\u6E96\u306F\u524A\u9664\u3055\u308C\u307E\u305B\u3093\u3002",
    batchRemove: "\u30EA\u30B9\u30C8\u304B\u3089\u5916\u3059",
    batchState: "\u5B9F\u969B\u306E\u5BFE\u5FDC\u72B6\u6CC1 / \u52D5\u4F5C ID",
    batchLoading: "\u73FE\u5728\u306E\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u4E2D\u2026",
    batchEmpty: "\u30EA\u30B9\u30C8\u306F\u7A7A\u3067\u3059\u3002\u7D20\u6750\u3092\u5206\u6790\u3057\u3001\u672A\u5BFE\u5FDC\u8A9E\u3092\u8FFD\u52A0\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    batchMissing: "\u5236\u4F5C\u5F85\u3061 \xB7 \u5B8C\u5168\u4E00\u81F4\u306A\u3057",
    batchDraft: "\u5019\u88DC\u3092\u4FDD\u5B58\u6E08\u307F \xB7 \u672A\u6709\u52B9\u5316\u307E\u305F\u306F\u5B8C\u5168\u4E00\u81F4\u306A\u3057",
    batchMatched: "\u5B8C\u5168\u4E00\u81F4\u3042\u308A \xB7 \u624B\u8A71\u306E\u4EBA\u306B\u3088\u308B\u78BA\u8A8D\u304C\u5FC5\u8981",
    batchUnverified: "\u672A\u691C\u8A3C\u3067\u3059\u3002\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044",
    batchSummary: "\u4ECA\u56DE {count}/{max} \u4EF6 \xB7 \u5B8C\u5168\u4E00\u81F4 {matched} \u4EF6 \xB7 \u7121\u52B9\u306A\u8A18\u9332 {invalid} \u4EF6\u3002\u52D5\u4F5C\u306E\u5909\u66F4\u6642\u306B\u518D\u78BA\u8A8D\u3057\u307E\u3059\u3002",
    batchPrivacy: "\u660E\u793A\u7684\u306B\u8FFD\u52A0\u3057\u305F\u8A9E\u3060\u3051\u3092\u62E1\u5F35\u6A5F\u80FD\u5185\u306B\u4FDD\u5B58\u3057\u3001\u518D\u8AAD\u307F\u8FBC\u307F\u5F8C\u3082\u4FDD\u6301\u3057\u307E\u3059\u3002\u539F\u6587\u30FB\u4F8B\u6587\u306F\u4FDD\u5B58\u3082\u9001\u4FE1\u3082\u3057\u307E\u305B\u3093\u3002\u30EA\u30B9\u30C8\u306F\u52D5\u4F5C\u30D1\u30C3\u30AF\u306B\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u9032\u6357\u30D5\u30A1\u30A4\u30EB\u306B\u306F\u9078\u629E\u8A9E\u3068\u52D5\u4F5C ID \u304C\u5165\u308B\u305F\u3081\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    batchFailure: "\u8A9E\u5F59\u30EA\u30B9\u30C8\u306E\u64CD\u4F5C\u306B\u5931\u6557\uFF1A{detail}",
    batchFull: "\u6700\u5927 8 \u4EF6\u306B\u9054\u3057\u307E\u3057\u305F\u3002\u4E00\u90E8\u3092\u5B8C\u4E86\u307E\u305F\u306F\u524A\u9664\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    batchInvalid: "\u30EA\u30B9\u30C8\u306E\u30C7\u30FC\u30BF\u304C\u7121\u52B9\u3067\u3059\u3002\u5143\u306E\u8A18\u9332\u306F\u7DAD\u6301\u3055\u308C\u307E\u3059\u3002\u660E\u793A\u7684\u306B\u6D88\u53BB\u3057\u3066\u518D\u4F5C\u6210\u3067\u304D\u307E\u3059\u3002",
    batchLockUnavailable: "\u30DA\u30FC\u30B8\u9593\u66F8\u304D\u8FBC\u307F\u30ED\u30C3\u30AF\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u5909\u66F4\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u62E1\u5F35\u6A5F\u80FD\u30D1\u30CD\u30EB\u304B\u3089\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewTitle: "\u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C",
    reviewIntro: "\u4FDD\u5B58\u6E08\u307F\u52D5\u4F5C\u3092\u518D\u751F\u3057\u3001\u6B63\u9762\u30FB\u53F3\u5074\u30FB\u5DE6\u5074\u306E\u56FA\u5B9A\u753B\u50CF\u3092\u624B\u52D5\u78BA\u8A8D\u6E08\u307F\u306E\u57FA\u6E96\u3068\u6BD4\u8F03\u3057\u307E\u3059\u3002\u9AA8\u683C\u3084\u7FFB\u8A33\u306E\u6709\u52B9\u5316\u72B6\u614B\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",
    reviewLimits: "\u4E00\u5EA6\u306B8\u52D5\u4F5C\u307E\u3067\u3001\u5404\u52D5\u4F5C\u306F\u5148\u982D\u3068\u672B\u5C3E\u3092\u542B\u3080\u6700\u592712\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u3092\u62BD\u51FA\u3057\u307E\u3059\u3002\u753B\u50CF\u306F\u76EE\u6A19\u59FF\u52E2\u306E\u307F\u3067\u3001\u5168\u9077\u79FB\u30FB\u885D\u7A81\u30FB\u5B57\u5E55\u6587\u306E\u518D\u751F\u30FB\u624B\u8A71\u306E\u610F\u5473\u306F\u691C\u8A3C\u3067\u304D\u307E\u305B\u3093\u3002\u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002\u5185\u8535\u4E00\u89A7\u306FSIGNS\u306E\u307F\u3067\u3001CHARS\u306F\u542B\u307F\u307E\u305B\u3093\u3002",
    reviewHelp: "\u30D1\u30CD\u30EB \u2192 \u52D5\u4F5C\u306E\u76EE\u8996\u691C\u8A3C\u3002\u52D5\u4F5C\u3092\u9078\u3073\u518D\u751F\u307E\u305F\u306F3\u65B9\u5411\u64AE\u5F71\u3092\u884C\u3044\u3001\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u3081\u308A\u8FBC\u307F\u3092\u78BA\u8A8D\u3057\u3066\u57FA\u6E96\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002\u6B21\u56DE\u306E\u753B\u50CF\u3092\u4E26\u3079\u3066\u6BD4\u8F03\u3067\u304D\u307E\u3059\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u306E\u5909\u66F4\u306F\u518D\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3001\u30E2\u30C7\u30EB\u30FB\u30D6\u30E9\u30A6\u30B6\u30FB\u63CF\u753B\u74B0\u5883\u304C\u7570\u306A\u308B\u5834\u5408\u306F\u6570\u5024\u6BD4\u8F03\u3057\u307E\u305B\u3093\u3002\u57FA\u6E96\u4FDD\u5B58\u306F\u624B\u8A71\u306E\u6B63\u3057\u3055\u3092\u4FDD\u8A3C\u305B\u305A\u3001\u4E0B\u66F8\u304D\u3084\u6709\u52B9\u5316\u72B6\u614B\u3082\u5909\u3048\u307E\u305B\u3093\u3002",
    reviewStorageHelp: "\u57FA\u6E96\u753B\u50CF\u306F\u62E1\u5F35\u6A5F\u80FD\u306EIndexedDB\u306B\u4FDD\u5B58\u3055\u308C\u3001\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3068\u306F\u5225\u3067\u6700\u5927100\u4EF6 / 64 MiB\u3067\u3059\u3002\u52D5\u4F5C\u30D1\u30C3\u30AF\u306B\u306F\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u524A\u9664\u524D\u306BPNG\u3068JSON\u3092\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u57FA\u6E96\u306E\u518D\u53D6\u8FBC\u306F\u672A\u5BFE\u5FDC\uFF09\u3002\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u9001\u4FE1\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
    reviewReload: "\u30E2\u30C7\u30EB\u518D\u8AAD\u8FBC / \u518D\u8A66\u884C",
    reviewSelect: "1 \xB7 \u52D5\u4F5C\u3092\u9078\u629E",
    reviewSearch: "\u540D\u524D\u30FBID\u30FB\u72B6\u614B\u3067\u691C\u7D22\uFF08\u9078\u629E\u306F\u7DAD\u6301\u3055\u308C\u307E\u3059\uFF09",
    reviewCatalogCount: "{total}\u4EF6 \xB7 \u9078\u629E{count}/{max} \xB7 \u7121\u52B9\u30EC\u30B3\u30FC\u30C9{invalid}\u4EF6",
    reviewPlay: "\u5168\u30D5\u30EC\u30FC\u30E0\u3092\u9806\u756A\u306B\u518D\u751F",
    reviewCapture: "\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u30923\u65B9\u5411\u304B\u3089\u64AE\u5F71",
    reviewStop: "\u505C\u6B62",
    reviewPreview: "\u56FA\u5B9A\u8996\u70B9\u30D7\u30EC\u30D3\u30E5\u30FC",
    reviewView: "\u518D\u751F\u8996\u70B9",
    reviewFront: "\u6B63\u9762",
    reviewRight: "\u4EBA\u7269\u306E\u53F3\u5074",
    reviewLeft: "\u4EBA\u7269\u306E\u5DE6\u5074",
    reviewPreviewHelp: "\u30D5\u30ED\u30FC\u30C6\u30A3\u30F3\u30B0\u8868\u793A\u306B\u306F\u5F71\u97FF\u3057\u307E\u305B\u3093\u3002\u5404\u518D\u751F\u306FREST\u304B\u3089\u958B\u59CB\u3057\u3001\u64AE\u5F71\u5F8C\u306F\u6B63\u9762\u306B\u623B\u308A\u307E\u3059\u3002",
    reviewResults: "2 \xB7 \u76EE\u8996\u78BA\u8A8D\u3068\u57FA\u6E96\u6BD4\u8F03",
    reviewExport: "JSON\u30EC\u30DD\u30FC\u30C8\u3092\u4FDD\u5B58",
    reviewBuiltin: "\u5185\u8535 \xB7 \u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981",
    reviewEnabled: "\u30AB\u30B9\u30BF\u30E0 \xB7 \u6709\u52B9",
    reviewDraft: "\u30AB\u30B9\u30BF\u30E0 \xB7 \u4E0B\u66F8\u304D",
    reviewLoading: "\u5B9F\u969B\u306E\u30E2\u30C7\u30EB\u30FB\u9AA8\u683C\u30FB\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u8AAD\u8FBC\u4E2D\u2026",
    reviewReady: "{total}\u52D5\u4F5C\u3092\u8AAD\u8FBC\u5B8C\u4E86\u3002\u9078\u629E\u3057\u3066\u518D\u751F\u307E\u305F\u306F\u64AE\u5F71\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewFailure: "\u691C\u8A3C\u5931\u6557\uFF1A{detail}",
    reviewCatalogChanged: "\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u308F\u3063\u305F\u305F\u3081\u7D50\u679C\u306F\u7121\u52B9\u3067\u3059\u3002\u9078\u629E\u3057\u76F4\u3057\u3066\u64AE\u5F71\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u65E2\u5B58\u306E\u57FA\u6E96\u306F\u81EA\u52D5\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002",
    reviewPlaying: "\u518D\u751F {index}/{total}\uFF1A{name}",
    reviewCapturing: "\u64AE\u5F71 {index}/{total}\uFF1A{name}",
    reviewFinished: "{count}\u52D5\u4F5C\u5B8C\u4E86\u3001\u69CB\u9020\u30A8\u30E9\u30FC{failures}\u4EF6\u3002\u76EE\u8996\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002",
    reviewCancelled: "\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u672A\u5B8C\u4E86\u306E\u64AE\u5F71\u7D50\u679C\u306F\u7834\u68C4\u3057\u3001\u57FA\u6E96\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",
    reviewDiagnostics: "{frames}\u30D5\u30EC\u30FC\u30E0 / {duration}\u79D2\u3001{bones}\u9AA8\u683C\u3002\u753B\u50CF\u306E\u884C\uFF1A{indices}\u3002\u672A\u64AE\u5F71{omitted}\u30D5\u30EC\u30FC\u30E0\u3002",
    reviewSheetOrder: "\u5404\u884C\u306F\u5DE6\u304B\u3089\u6B63\u9762 \u2192 \u4EBA\u7269\u306E\u53F3\u5074 \u2192 \u5DE6\u5074\u3002\u884C\u306F\u30D5\u30EC\u30FC\u30E0\u9806\u3067\u3059\u3002PNG\u3092\u4FDD\u5B58\u3057\u3066\u62E1\u5927\u78BA\u8A8D\u3067\u304D\u307E\u3059\u3002",
    reviewCurrent: "\u73FE\u5728\u306E\u753B\u50CF",
    reviewBaseline: "\u78BA\u8A8D\u6E08\u307F\u306E\u57FA\u6E96\u753B\u50CF",
    reviewNoBaseline: "\u57FA\u6E96\u672A\u4FDD\u5B58\u3002\u52D5\u4F5C\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewCompared: "\u57FA\u6E96\u65E5\u6642{date}\u3002RGB\u5DEE\u5206>16\u306E\u753B\u7D20\uFF1A{ratio}%\u3001\u5E73\u5747\u5DEE\u5206{mean}/255\u3002\u53C2\u8003\u5024\u3067\u3042\u308A\u624B\u8A71\u306E\u6B63\u3057\u3055\u3084\u885D\u7A81\u3092\u4FDD\u8A3C\u3057\u307E\u305B\u3093\u3002",
    reviewMotionChanged: "\u52D5\u4F5C\u30C7\u30FC\u30BF\uFF08\u6642\u9593\u3084\u540D\u79F0\u3092\u542B\u3080\uFF09\u304C\u5909\u308F\u308A\u307E\u3057\u305F\u3002\u65E7\u57FA\u6E96\u306F\u4FDD\u6301\u3057\u3001\u6570\u5024\u6BD4\u8F03\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u518D\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewIncompatible: "\u30E2\u30C7\u30EB\u30FB\u9AA8\u683C\u30FB\u30D6\u30E9\u30A6\u30B6\u30FB\u63CF\u753B\u74B0\u5883\u304C\u7570\u306A\u308A\u307E\u3059\u3002\u6570\u5024\u6BD4\u8F03\u306F\u884C\u308F\u305A\u3001\u65E7\u753B\u50CF\u306F\u53C2\u8003\u7528\u3067\u3059\u3002",
    reviewUnavailable: "\u57FA\u6E96\u8AAD\u8FBC / \u6BD4\u8F03\u5931\u6557\uFF1A{detail}\u3002\u73FE\u5728\u306E\u753B\u50CF\u306F\u4FDD\u5B58\u53EF\u80FD\u3067\u3059\u3002\u57FA\u6E96\u4FDD\u5B58\u3067\u518D\u8A66\u884C\u3057\u307E\u3059\u3002",
    reviewSaveBaseline: "\u76EE\u8996\u57FA\u6E96\u3092\u4FDD\u5B58 / \u7F6E\u63DB",
    reviewDeleteBaseline: "\u3053\u306E\u57FA\u6E96\u3092\u524A\u9664",
    reviewDownloadImage: "\u73FE\u5728\u306EPNG\u3092\u4FDD\u5B58",
    reviewSaveConfirm: "\u300C{name}\u300D\u30923\u65B9\u5411\u304B\u3089\u78BA\u8A8D\u3057\u307E\u3057\u305F\u304B\uFF1F\u65E2\u5B58\u306E\u76EE\u8996\u57FA\u6E96\u3092\u7F6E\u63DB\u3057\u307E\u3059\u3002\u7FFB\u8A33\u306E\u6709\u52B9\u5316\u3084\u624B\u8A71\u306E\u6B63\u3057\u3055\u306E\u8A8D\u8A3C\u306F\u884C\u3044\u307E\u305B\u3093\u3002",
    reviewDeleteConfirm: "\u300C{name}\u300D\u306E\u76EE\u8996\u57FA\u6E96\u3092\u524A\u9664\u3057\u307E\u3059\u304B\uFF1F\u52D5\u4F5C\u81EA\u4F53\u306F\u524A\u9664\u3057\u307E\u305B\u3093\u3002",
    reviewSaved: "\u76EE\u8996\u57FA\u6E96\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u3068\u7FFB\u8A33\u72B6\u614B\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
    reviewDeleted: "\u76EE\u8996\u57FA\u6E96\u3092\u524A\u9664\u3057\u307E\u3057\u305F\u3002\u52D5\u4F5C\u30C7\u30FC\u30BF\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
    reviewStorageError: "\u57FA\u6E96\u30B9\u30C8\u30EC\u30FC\u30B8\u306B\u30A2\u30AF\u30BB\u30B9\u3067\u304D\u307E\u305B\u3093\u3002\u7A7A\u304D\u5BB9\u91CF\u3092\u78BA\u8A8D\u3057\u3001\u62E1\u5F35\u6A5F\u80FD\u30D1\u30CD\u30EB\u304B\u3089\u958B\u304D\u76F4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewStorageFull: "\u57FA\u6E96\u306E\u4E0A\u9650\uFF08100\u4EF6 / 64 MiB\uFF09\u3067\u3059\u3002\u753B\u50CF\u3092\u4FDD\u5B58\u3057\u3066\u4E0D\u8981\u306A\u57FA\u6E96\u3092\u524A\u9664\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewBaselineChanged: "\u5225\u30DA\u30FC\u30B8\u3067\u57FA\u6E96\u304C\u66F4\u65B0\u3055\u308C\u307E\u3057\u305F\u3002\u4E0A\u66F8\u304D\u305B\u305A\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u518D\u64AE\u5F71\u3057\u3066\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewModelError: "\u30E2\u30C7\u30EB\u8AAD\u8FBC\u5931\u6557\u307E\u305F\u306F\u5BF8\u6CD5\u304C\u7121\u52B9\u3067\u3059\u3002\u518D\u30D3\u30EB\u30C9\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewMissingBones: "\u624B\u8A71\u306B\u5FC5\u8981\u306A\u9AA8\u683C\u304C\u4E0D\u8DB3\u3057\u3066\u3044\u308B\u305F\u3081\u505C\u6B62\u3057\u307E\u3057\u305F\u3002",
    reviewRenderError: "\u63CF\u753B\u5931\u6557\u307E\u305F\u306FWebGL\u63A5\u7D9A\u304C\u5931\u308F\u308C\u307E\u3057\u305F\u3002\u505C\u6B62\u3057\u3066\u518D\u8AAD\u8FBC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    reviewInvalidSamples: "\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u62BD\u51FA\u8A2D\u5B9A\u304C\u7121\u52B9\u3067\u3059\u3002",
    reviewImageMismatch: "\u57FA\u6E96\u753B\u50CF\u304C\u7834\u640D\u3057\u3066\u3044\u308B\u304B\u5BF8\u6CD5\u304C\u7570\u306A\u308B\u305F\u3081\u6BD4\u8F03\u3067\u304D\u307E\u305B\u3093\u3002",
    motionPackTitle: "\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u306E\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7 / \u4E00\u62EC\u53D6\u8FBC",
    motionPackHelp: "\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u306B\u5BFE\u5FDC\u3059\u308B\u4FDD\u5B58\u6E08\u307F\u30AB\u30B9\u30BF\u30E0\u52D5\u4F5C\u3092\u3059\u3079\u3066\u66F8\u304D\u51FA\u3057\u307E\u3059\u3002\u672A\u4FDD\u5B58\u306E\u7DE8\u96C6\u3084\u5185\u8535\u8F9E\u66F8\u306F\u542B\u307F\u307E\u305B\u3093\u3002\u30D5\u30A1\u30A4\u30EB\u9078\u629E\u306F\u4E8B\u524D\u78BA\u8A8D\u306E\u307F\u3067\u3059\u3002\u540C\u3058 ID\u30FB\u5185\u5BB9\u306F\u30B9\u30AD\u30C3\u30D7\u3057\u3001\u5185\u5BB9\u304C\u7570\u306A\u308B\u5834\u5408\u306F\u4E00\u62EC\u53D6\u8FBC\u5168\u4F53\u3092\u505C\u6B62\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u52D5\u4F5C\u306F\u4E0B\u66F8\u304D\u3068\u3057\u3066\u8FFD\u52A0\u3057\u3001\u500B\u5225\u306B\u8AAD\u8FBC\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionPackPrivacy: "\u30D5\u30A1\u30A4\u30EB\u306B\u306F\u540D\u524D\u3001\u7167\u5408\u6587\u5B57\u5217\u3001\u30BF\u30B0\u3001\u9AA8\u683C\u60C5\u5831\u3001\u30D5\u30EC\u30FC\u30E0\u3001\u66F8\u51FA\u6642\u306E\u6709\u52B9\u30D5\u30E9\u30B0\u306E\u307F\u542B\u307E\u308C\u3001\u30AD\u30FC\u3084\u5B57\u5E55\u306F\u542B\u307E\u308C\u307E\u305B\u3093\u3002\u540D\u524D\u3084\u30BF\u30B0\u306E\u500B\u4EBA\u60C5\u5831\u3092\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u627F\u8A8D\u8A18\u9332\u306F\u5F15\u304D\u7D99\u304C\u305A\u3001\u30D5\u30A1\u30A4\u30EB\u3082\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u305B\u3093\u3002",
    motionPackExport: "\u4FDD\u5B58\u6E08\u307F\u306E\u5168\u52D5\u4F5C\u3092\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7",
    motionPackFile: "\u52D5\u4F5C\u30D1\u30C3\u30AF JSON \u3092\u9078\u629E\uFF08\u5358\u4E00\u52D5\u4F5C\u30D5\u30A1\u30A4\u30EB\u3067\u306F\u3042\u308A\u307E\u305B\u3093\uFF09",
    motionPackLimits: "1 \u30D1\u30C3\u30AF\u6700\u5927 500 \u52D5\u4F5C\u30FB8 MiB\u30011 \u52D5\u4F5C 2 MiB\u3002\u9AA8\u683C\u3068 REST \u306E\u4E00\u81F4\u304C\u5FC5\u8981\u3067\u3059\u3002",
    motionPackInspect: "\u518D\u5EA6\u4E8B\u524D\u78BA\u8A8D",
    motionPackImport: "\u65B0\u898F\u4E0B\u66F8\u304D\u3068\u3057\u3066\u53D6\u8FBC\u3092\u78BA\u8A8D",
    motionPackClear: "\u53D6\u8FBC\u5F85\u3061\u30D5\u30A1\u30A4\u30EB\u3092\u30AD\u30E3\u30F3\u30BB\u30EB",
    motionPackSummary: "\u4E8B\u524D\u78BA\u8A8D\uFF1A\u65B0\u898F {new}\u3001\u65E2\u5B58 {existing}\u3001ID \u7AF6\u5408 {conflict}\u3002\u307E\u3060\u4FDD\u5B58\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
    motionPackName: "\u52D5\u4F5C / ID",
    motionPackState: "\u51E6\u7406",
    motionPackWarnings: "\u78BA\u8A8D\u4E8B\u9805",
    motionPackNew: "\u65B0\u898F\u4E0B\u66F8\u304D",
    motionPackExisting: "\u540C\u4E00\u5185\u5BB9\u30FB\u30B9\u30AD\u30C3\u30D7",
    motionPackIdConflict: "ID \u7AF6\u5408\u30FB\u4E0A\u66F8\u304D\u7981\u6B62",
    motionPackWasEnabled: "\u30D1\u30C3\u30AF\u4E0A\u3067\u306F\u4EE5\u524D\u6709\u52B9\u3002\u305F\u3060\u3057\u51FA\u6240\u306E\u60C5\u5831\u3067\u3042\u308A\u3001\u4FE1\u983C\u3055\u308C\u305F\u627F\u8A8D\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
    motionPackAliases: "\u7167\u5408\u6587\u5B57\u5217\u304C\u91CD\u8907\u3059\u308B\u53EF\u80FD\u6027\uFF1A{aliases}\u3002\u4E0B\u66F8\u304D\u4FDD\u5B58\u306F\u53EF\u80FD\u3067\u3059\u304C\u3001\u6709\u52B9\u5316\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\uFF08\u7121\u52B9\u306A\u52D5\u4F5C\u3082\u542B\u3080\uFF09\u3002",
    motionPackMaterial: "\u7167\u5408\u6587\u5B57\u5217\u306A\u3057\u3002\u30DD\u30FC\u30BA\u7D20\u6750\u5C02\u7528\u3067\u3001\u7FFB\u8A33\u306B\u306F\u6709\u52B9\u5316\u3067\u304D\u307E\u305B\u3093\u3002",
    motionPackReady: "\u4E8B\u524D\u78BA\u8A8D\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002\u65B0\u898F\u4E0B\u66F8\u304D\u306E\u307F\u8FFD\u52A0\u3057\u3001\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u3068\u65E2\u5B58\u52D5\u4F5C\u306E\u627F\u8A8D\u306F\u5909\u66F4\u3057\u307E\u305B\u3093\u3002",
    motionPackChecking: "\u9AA8\u683C\u3068\u30ED\u30FC\u30AB\u30EB\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u4E2D\u2026",
    motionPackCleared: "\u30AD\u30E3\u30F3\u30BB\u30EB\u3057\u307E\u3057\u305F\u3002\u30E9\u30A4\u30D6\u30E9\u30EA\u306F\u5909\u66F4\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
    motionPackConfirm: "{count} \u4EF6\u306E\u4E0B\u66F8\u304D\u3092\u8FFD\u52A0\u3057\u307E\u3059\u3002\u4E0A\u66F8\u304D\u3084\u81EA\u52D5\u6709\u52B9\u5316\u306F\u3057\u307E\u305B\u3093\u3002\u5229\u7528\u6A29\u9650\u3092\u78BA\u8A8D\u3057\u3001\u53D6\u8FBC\u5F8C\u306B\u624B\u5F62\u30FB\u5411\u304D\u30FB\u610F\u5473\u3092\u500B\u5225\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F",
    motionPackImported: "\u4E0B\u66F8\u304D {imported} \u4EF6\u3092\u8FFD\u52A0\u3001\u65E2\u5B58 {skipped} \u4EF6\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u307E\u3057\u305F\u3002\u4E00\u89A7\u304B\u3089\u500B\u5225\u306B\u8AAD\u8FBC\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionPackExported: "\u4FDD\u5B58\u6E08\u307F {count} \u4EF6\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3092\u958B\u59CB\u3057\u307E\u3057\u305F\u3002\u7D50\u679C\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u672A\u4FDD\u5B58\u306E\u7DE8\u96C6\u306F\u542B\u307F\u307E\u305B\u3093\u3002",
    motionPackInvalid: "\u6709\u52B9\u306A v1 \u52D5\u4F5C\u30D1\u30C3\u30AF JSON \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u5358\u4E00\u52D5\u4F5C\u306B\u306F\u4E0A\u306E\u52D5\u4F5C JSON \u53D6\u8FBC\u3092\u4F7F\u3063\u3066\u304F\u3060\u3055\u3044\u3002",
    motionPackEmpty: "\u30D1\u30C3\u30AF\u304C\u7A7A\u304B\u3001\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3067\u304D\u308B\u4FDD\u5B58\u6E08\u307F\u52D5\u4F5C\u304C\u3042\u308A\u307E\u305B\u3093\u3002",
    motionPackTooLarge: "\u4E0A\u9650\u8D85\u904E\uFF1A1 \u30D1\u30C3\u30AF 8 MiB / 500 \u52D5\u4F5C\u30011 \u52D5\u4F5C 2 MiB\u3002\u4FDD\u5B58\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
    motionPackDuplicateId: "\u30D1\u30C3\u30AF\u5185\u306B\u91CD\u8907 ID \u304C\u3042\u308A\u3001\u52D5\u4F5C\u3092\u7279\u5B9A\u3067\u304D\u306A\u3044\u305F\u3081\u53D6\u8FBC\u3092\u62D2\u5426\u3057\u307E\u3057\u305F\u3002",
    motionPackInvalidStored: "\u30ED\u30FC\u30AB\u30EB\u8A18\u9332\u304C\u7834\u640D\u3057\u3066\u3044\u308B\u304B\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u306B\u975E\u5BFE\u5FDC\u3067\u3059\u3002\u4E0D\u5B8C\u5168\u306A\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u306F\u4F5C\u6210\u305B\u305A\u3001\u5143\u30C7\u30FC\u30BF\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002\u5148\u306B\u8A72\u5F53\u8A18\u9332\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionPackConflict: "\u540C\u3058 ID \u306E\u30ED\u30FC\u30AB\u30EB\u5185\u5BB9\u304C\u7570\u306A\u308B\u304B\u7834\u640D\u3057\u3066\u3044\u307E\u3059\u3002\u5168\u4F53\u306E\u53D6\u8FBC\u3092\u505C\u6B62\u3057\u3001\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002\u5FC5\u8981\u306A\u3089\u5358\u4E00\u52D5\u4F5C\u306E\u53D6\u8FBC\u3067\u30B3\u30D4\u30FC\u3092\u4F5C\u6210\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionPackStale: "\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u66F4\u3055\u308C\u3001\u4E8B\u524D\u78BA\u8A8D\u304C\u5931\u52B9\u3057\u307E\u3057\u305F\u3002\u518D\u5EA6\u4E8B\u524D\u78BA\u8A8D\u3057\u3001\u4E00\u89A7\u3092\u78BA\u8A8D\u3057\u3066\u304B\u3089\u53D6\u308A\u8FBC\u3093\u3067\u304F\u3060\u3055\u3044\u3002",
    motionPackLockUnavailable: "\u30DA\u30FC\u30B8\u9593\u306E\u66F8\u8FBC\u30ED\u30C3\u30AF\u304C\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u4E00\u62EC\u53D6\u8FBC\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u30C4\u30FC\u30EB\u3092\u958B\u304D\u76F4\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionPackEncoding: "\u6709\u52B9\u306A UTF-8 JSON \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6587\u5B57\u30B3\u30FC\u30C9\u3092\u5909\u63DB\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageTitle: "\u8A9E\u5F59\u30AB\u30D0\u30FC\u7387\u5206\u6790",
    coverageHelpWorkflow: "\u30D1\u30CD\u30EB\u304B\u3089\u8A9E\u5F59\u30AB\u30D0\u30FC\u7387\u5206\u6790\u3092\u958B\u304D\u3001\u6587\u7AE0\u307E\u305F\u306F UTF-8 TXT / SRT / VTT \u3092\u5165\u529B\u3057\u3066\u672A\u5BFE\u5FDC\u8A9E\u306E\u983B\u5EA6\u3068\u6587\u8108\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u7DE8\u96C6\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u306B\u306F\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u3060\u3051\u304C\u5165\u529B\u3055\u308C\u307E\u3059\u3002\u52D5\u4F5C\u306E\u4F5C\u6210\u30FB\u78BA\u8A8D\u30FB\u6709\u52B9\u5316\u5F8C\u306B\u518D\u5206\u6790\u3057\u3001\u53CD\u6620\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageIntro: "\u5B9F\u969B\u306E\u6587\u7AE0\u304B\u3089\u4E0D\u8DB3\u3059\u308B\u8A9E\u5F59\u3092\u63A2\u3057\u3001\u52D5\u4F5C\u3092\u4F5C\u6210\u30FB\u78BA\u8A8D\u3057\u307E\u3059\u3002\u624B\u8A71\u306E\u81EA\u52D5\u751F\u6210\u3084\u65E2\u5B58\u30DD\u30FC\u30BA\u306E\u5909\u66F4\u306F\u884C\u3044\u307E\u305B\u3093\u3002",
    coverageInput: "1 \xB7 \u5206\u6790\u3059\u308B\u7D20\u6750",
    coverageTextLabel: "\u6587\u7AE0\u3092\u8CBC\u308A\u4ED8\u3051\uFF081\u884C1\u533A\u9593\uFF09\u3001\u307E\u305F\u306F UTF-8 \u5B57\u5E55\u3092\u8AAD\u307F\u8FBC\u307F",
    coverageLimits: "\u4E0A\u9650\uFF1A\u30D5\u30A1\u30A4\u30EB256 KiB\u300150,000\u6587\u5B57\u30011,000\u533A\u9593\u30011\u533A\u95932,000\u6587\u5B57\u3002SRT / WebVTT \u306F\u5B57\u5E55\u5358\u4F4D\u3067\u5206\u6790\u3057\u307E\u3059\u3002",
    coverageFormat: "\u5F62\u5F0F",
    coveragePlainText: "\u30C6\u30AD\u30B9\u30C8 \xB7 1\u884C1\u533A\u9593",
    coverageImport: "\u30D5\u30A1\u30A4\u30EB\u3092\u8AAD\u307F\u8FBC\u3080",
    coverageAnalyze: "\u73FE\u5728\u306E\u8A9E\u5F59\u3092\u5206\u6790",
    coverageClear: "\u30AF\u30EA\u30A2",
    coverageResults: "2 \xB7 \u8FFD\u52A0\u3059\u308B\u8A9E\u5F59\u306E\u512A\u5148\u9806\u4F4D",
    coverageMetricHelp: "\u30AB\u30D0\u30FC\u7387 = \u4E00\u81F4\u3057\u305F\u5206\u5272\u8A9E\u6570 \xF7\uFF08\u4E00\u81F4 + \u672A\u5BFE\u5FDC\u306E\u5206\u5272\u8A9E\u6570\uFF09\u3002\u7701\u7565\u3057\u305F\u6A5F\u80FD\u8A9E\u30FB\u53E5\u8AAD\u70B9\u306F\u9664\u5916\u3057\u307E\u3059\u3002\u8F9E\u66F8\u306E\u30AB\u30D0\u30FC\u7387\u3067\u3042\u308A\u3001\u624B\u8A71\u306E\u6B63\u78BA\u3055\u30FB\u6587\u610F\u30FB\u518D\u751F\u5B8C\u4E86\u3092\u4FDD\u8A3C\u3059\u308B\u5024\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
    coverageUnknownTitle: "\u672A\u5BFE\u5FDC\u306E\u8A9E \xB7 \u983B\u5EA6\u9806",
    coverageDraftHelp: "\u5206\u5272\u7D50\u679C\u3092\u6587\u8108\u3068\u7167\u5408\u3057\u3001\u53E5\u5168\u4F53\u304C\u5FC5\u8981\u304B\u5224\u65AD\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u30C4\u30FC\u30EB\u306B\u306F\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u306E\u307F\u5165\u529B\u3057\u307E\u3059\u3002\u81EA\u52D5\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u306F\u305B\u305A\u3001\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u304C\u305D\u306E\u8A9E\u306E\u6B63\u3057\u3044\u624B\u8A71\u3068\u306F\u9650\u308A\u307E\u305B\u3093\u3002",
    coverageWord: "\u672A\u5BFE\u5FDC\u306E\u8A9E",
    coverageFrequency: "\u56DE\u6570 / \u533A\u9593\u6570",
    coverageExamples: "\u4F8B\u6587\u306E\u533A\u9593\u756A\u53F7",
    coverageMake: "\u4F5C\u6210\u3068\u78BA\u8A8D",
    coverageDetailsTitle: "3 \xB7 \u533A\u9593\u3054\u3068\u306E\u4E00\u81F4\u7D50\u679C",
    coverageDisplayLimit: "\u672A\u5BFE\u5FDC\u8A9E\u306F100\u4EF6\u3001\u533A\u9593\u306F200\u4EF6\u307E\u3067\u8868\u793A\u3057\u307E\u3059\u3002\u96C6\u8A08\u306F\u5168\u5165\u529B\u304C\u5BFE\u8C61\u3067\u3059\u3002\u5168\u7D50\u679C\u306F\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3067\u304D\u307E\u3059\u3002",
    coverageIncludeText: "\u539F\u6587\u3068\u533A\u9593\u660E\u7D30\u3092\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u306B\u542B\u3081\u308B\uFF08\u500B\u4EBA\u60C5\u5831\u306B\u6CE8\u610F\uFF09",
    coverageExport: "JSON \u30EC\u30DD\u30FC\u30C8\u3092\u51FA\u529B",
    coveragePrivacy: "\u5206\u6790\u306F\u30DA\u30FC\u30B8\u306E\u30E1\u30E2\u30EA\u5185\u306E\u307F\u3067\u884C\u3044\u3001\u9001\u4FE1\u30FB\u81EA\u52D5\u4FDD\u5B58\u3057\u307E\u305B\u3093\u3002\u9589\u3058\u308B\u3068\u7834\u68C4\u3055\u308C\u307E\u3059\u3002\u65E2\u5B9A\u306E\u51FA\u529B\u306F\u539F\u6587\u3092\u9664\u5916\u3057\u307E\u3059\u304C\u672A\u5BFE\u5FDC\u8A9E\u3092\u542B\u3080\u305F\u3081\u3001\u5171\u6709\u524D\u306B\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageSummary: "\u30AB\u30D0\u30FC\u7387 {ratio} \xB7 {segments} \u533A\u9593 \xB7 \u4E00\u81F4 {matched} / \u672A\u5BFE\u5FDC {unknown} / \u7701\u7565 {skipped}",
    coverageNoTokens: "\u5BFE\u8C61\u5916\uFF08\u7FFB\u8A33\u5BFE\u8C61\u8A9E\u306A\u3057\uFF09",
    coverageTruncation: "{count} \u533A\u9593\u304C1\u533A\u959312\u52D5\u4F5C\u306E\u518D\u751F\u4E0A\u9650\u306B\u9054\u3057\u3066\u3044\u307E\u3059\u3002\u4E00\u90E8\u306F\u518D\u751F\u3055\u308C\u306A\u3044\u53EF\u80FD\u6027\u304C\u3042\u308B\u305F\u3081\u3001\u6B8B\u308A\u306E\u6587\u7AE0\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageOccurrences: "{count} \u56DE / {segments} \u533A\u9593",
    coverageUniqueUnknown: "\u672A\u5BFE\u5FDC\u8A9E\u306F {count} \u7A2E\u985E\u3067\u3059\u3002\u9577\u3059\u304E\u308B\u8A9E\u306F\u5206\u5272\u3084\u6587\u8108\u3092\u518D\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageNoUnknown: "\u672A\u5BFE\u5FDC\u8A9E\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u624B\u8A71\u306E\u610F\u5473\u3068\u52D5\u4F5C\u306F\u4EBA\u306B\u3088\u308B\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002",
    coverageMatches: "\u4E00\u81F4\uFF1A{value}",
    coverageUnmatched: "\u672A\u5BFE\u5FDC\uFF1A{value}",
    coverageSkipped: "\u7701\u7565\uFF1A{value}",
    coverageRemaining: "\u518D\u751F\u4E0A\u9650\u4EE5\u964D\u306E\u6587\u7AE0\uFF1A{value}",
    coverageCatalog: "\u8A9E\u5F59\uFF1A\u5185\u8535 {signs} \u4EF6 / \u5225\u540D {aliases} \u4EF6 / \u6587\u5B57 {chars} \u4EF6\u3002\u6709\u52B9\u306A\u72EC\u81EA\u52D5\u4F5C {enabled}\u3001\u7121\u52B9 {drafts}\u3001\u4E0D\u6B63\u30FB\u975E\u4E92\u63DB {invalid}\uFF08\u5143\u30C7\u30FC\u30BF\u306F\u4FDD\u6301\uFF09\u3002",
    coverageReady: "\u8CBC\u308A\u4ED8\u3051\u30FB\u8AAD\u307F\u8FBC\u307F\u5F8C\u306B\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u521D\u56DE\u306F\u30E2\u30C7\u30EB\u3092\u8AAD\u307F\u8FBC\u307F\u3001\u72EC\u81EA\u52D5\u4F5C\u306E\u4E92\u63DB\u6027\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002",
    coverageLoading: "\u30E2\u30C7\u30EB\u3068\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u3057\u3001\u5206\u6790\u3057\u3066\u3044\u307E\u3059\u2026",
    coverageDone: "\u5206\u6790\u5B8C\u4E86\u3002\u4E0D\u8DB3\u3059\u308B\u52D5\u4F5C\u3092\u4F5C\u6210\u3057\u3001\u78BA\u8A8D\u30FB\u6709\u52B9\u5316\u3057\u3066\u304B\u3089\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageChanged: "\u7D20\u6750\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53E4\u3044\u30EC\u30DD\u30FC\u30C8\u306F\u51FA\u529B\u3067\u304D\u307E\u305B\u3093\u3002",
    coverageCatalogChanged: "\u30E9\u30A4\u30D6\u30E9\u30EA\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u5206\u6790\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u53E4\u3044\u30EC\u30DD\u30FC\u30C8\u306F\u51FA\u529B\u3067\u304D\u307E\u305B\u3093\u3002",
    coverageImported: "\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86\u3002\u5206\u6790\u3092\u30AF\u30EA\u30C3\u30AF\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u81EA\u52D5\u518D\u751F\u30FB\u4FDD\u5B58\u306F\u3057\u307E\u305B\u3093\u3002",
    coverageFailure: "\u5206\u6790\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\uFF1A{detail}",
    coverageTooLarge: "\u5BB9\u91CF\u30FB\u533A\u9593\u6570\u30FB\u533A\u9593\u9577\u306E\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\u3002\u5206\u5272\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageEmpty: "\u7A7A\u3067\u306A\u3044\u6587\u7AE0\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageInvalidFormat: "TXT\u3001SRT\u3001WebVTT \u306E\u307F\u5BFE\u5FDC\u3057\u3066\u3044\u307E\u3059\u3002\u6B63\u3057\u3044\u5F62\u5F0F\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageInvalidSubtitles: "\u5B57\u5E55\u5F62\u5F0F\u304C\u4E0D\u6B63\u3067\u3059\u3002\u7A7A\u884C\u3001\u6642\u523B\u3001\u958B\u59CB\u30FB\u7D42\u4E86\u9806\u5E8F\u3001WebVTT \u30D8\u30C3\u30C0\u30FC\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u6642\u523B\u884C\u3092\u672C\u6587\u3068\u3057\u3066\u96C6\u8A08\u3057\u307E\u305B\u3093\u3002",
    coverageEncoding: "UTF-8 \u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6587\u5B57\u30B3\u30FC\u30C9\u3092\u5909\u63DB\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coverageModelError: "\u30E2\u30C7\u30EB\u307E\u305F\u306F\u5171\u6709\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u78BA\u8A8D\u3067\u304D\u307E\u305B\u3093\u3002\u62E1\u5F35\u304B\u3089\u958B\u304D\u3001\u30E2\u30C7\u30EB\u8AAD\u307F\u8FBC\u307F\u3092\u78BA\u8A8D\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u4E0D\u5B8C\u5168\u306A\u96C6\u8A08\u306B\u306F\u5207\u308A\u66FF\u3048\u307E\u305B\u3093\u3002",
    coverageOpenFailed: "\u30C4\u30FC\u30EB\u3092\u958B\u3051\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    coveragePrefilled: "\u5206\u6790\u7D50\u679C\u304B\u3089\u540D\u524D\u3068\u4E00\u81F4\u6587\u5B57\u5217\u3092\u5165\u529B\u3057\u307E\u3057\u305F\u3002\u73FE\u5728\u306E\u30DD\u30FC\u30BA\u306F\u3053\u306E\u8A9E\u306E\u691C\u8A3C\u6E08\u307F\u624B\u8A71\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u4F5C\u6210\u30FB\u4FDD\u5B58\u30FB\u30D7\u30EC\u30D3\u30E5\u30FC\u30FB\u78BA\u8A8D\u3057\u3066\u304B\u3089\u6709\u52B9\u5316\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionLibraryTitle: "\u5171\u6709\u52D5\u4F5C\u30E9\u30A4\u30D6\u30E9\u30EA \xB7 \u7B2C2\u6BB5\u968E",
    motionLibraryHelp: "\u30A8\u30C7\u30A3\u30BF\u30FC\u30FB\u9332\u753B\u30C4\u30FC\u30EB\u30FB\u30A2\u30D0\u30BF\u30FC\u306F\u30E9\u30B8\u30A2\u30F3\u3068 REST \u5DEE\u5206\u3092\u5171\u6709\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u306F\u30D7\u30EC\u30D3\u30E5\u30FC\u3068\u78BA\u8A8D\u5F8C\u306B\u7FFB\u8A33\u3078\u4F7F\u7528\u3057\u307E\u3059\u3002",
    motionName: "\u52D5\u4F5C\u540D\uFF08\u5FC5\u9808\uFF09",
    motionTexts: "\u5BFE\u5FDC\u3059\u308B\u6587\u5B57\uFF08\u30AB\u30F3\u30DE\u533A\u5207\u308A\u30FB\u59FF\u52E2\u7D20\u6750\u306E\u307F\u306A\u3089\u7A7A\u6B04\uFF09",
    motionTags: "\u30BF\u30B0\uFF08\u30AB\u30F3\u30DE\u533A\u5207\u308A\uFF09",
    motionNew: "\u65B0\u3057\u3044\u30B3\u30D4\u30FC",
    motionNewHelp: "\u73FE\u5728\u306E\u59FF\u52E2\u3092\u4FDD\u6301\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u52D5\u4F5C\u540D\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionSave: "\u4E0B\u66F8\u304D\u4FDD\u5B58",
    motionSaved: "\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002\u30D7\u30EC\u30D3\u30E5\u30FC\u3068\u78BA\u8A8D\u5F8C\u306B\u6709\u52B9\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionLoad: "\u9078\u629E\u3092\u8AAD\u307F\u8FBC\u3080",
    motionLoaded: "\u8AAD\u307F\u8FBC\u307F\u307E\u3057\u305F\u3002\u30A4\u30F3\u30DD\u30FC\u30C8\u306F\u81EA\u52D5\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u3055\u308C\u307E\u305B\u3093\u3002\u78BA\u8A8D\u5F8C\u306B\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionChoose: "\u4FDD\u5B58\u6E08\u307F\u306E\u52D5\u4F5C\u3092\u9078\u629E\u2026",
    motionDraft: "\u4E0B\u66F8\u304D / \u7121\u52B9",
    motionEnabled: "\u78BA\u8A8D\u6E08\u307F / \u6709\u52B9",
    motionPreview: "\u73FE\u5728\u306E\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC",
    motionPreviewHelp: "\u30A2\u30D0\u30BF\u30FC\u3068\u540C\u3058\u518D\u751F\u51E6\u7406\u3067\u3059\u3002\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D\u3057\u3001\u5909\u66F4\u5F8C\u306F\u518D\u4FDD\u5B58\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionEnable: "\u78BA\u8A8D\u3057\u3066\u7FFB\u8A33\u306B\u4F7F\u7528",
    motionDisable: "\u9078\u629E\u3057\u305F\u52D5\u4F5C\u3092\u7121\u52B9\u5316",
    motionConfirm: "\u5168\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3001\u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D\u3057\u307E\u3057\u305F\u3002\u5C02\u9580\u5BB6\u306B\u3088\u308B\u624B\u8A71\u8A8D\u8A3C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u6709\u52B9\u306B\u3057\u307E\u3059\u304B\uFF1F",
    motionEnabledHelp: "\u6709\u52B9\u5316\u3057\u307E\u3057\u305F\u3002\u958B\u3044\u3066\u3044\u308B\u30A2\u30D0\u30BF\u30FC\u306B\u81EA\u52D5\u53CD\u6620\u3057\u3001\u65B0\u3057\u304F\u4E00\u81F4\u3057\u305F\u6587\u5B57\u306B\u4F7F\u7528\u3057\u307E\u3059\u3002",
    motionDisabledHelp: "\u7121\u52B9\u5316\u3057\u307E\u3057\u305F\u3002\u4E0B\u66F8\u304D\u3092\u4FDD\u6301\u3057\u3001\u30A2\u30D0\u30BF\u30FC\u306E\u5F85\u6A5F\u4E2D\u306E\u72EC\u81EA\u52D5\u4F5C\u3092\u505C\u6B62\u3057\u307E\u3059\u3002",
    motionRefresh: "\u4E00\u89A7\u66F4\u65B0",
    motionExport: "\u7D71\u4E00 JSON \u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9",
    motionExportCode: "\u30B3\u30FC\u30C9\u51FA\u529B\uFF08\u4FDD\u5B58\u306A\u3057\uFF09",
    motionImport: "\u52D5\u4F5C JSON \u3092\u30A4\u30F3\u30DD\u30FC\u30C8",
    motionImportFormat: "\u30A4\u30F3\u30DD\u30FC\u30C8\u5F62\u5F0F\u3068\u5358\u4F4D",
    motionFormat: "\u7D71\u4E00\u5F62\u5F0F \xB7 \u30E9\u30B8\u30A2\u30F3 / REST \u5DEE\u5206",
    motionLegacyEditor: "\u65E7\u30A8\u30C7\u30A3\u30BF\u30FC\u5DEE\u5206 \xB7 \u5EA6\uFF08\u59FF\u52E2\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u306E\u307F\uFF09",
    motionLegacyRecorder: "\u65E7\u9332\u753B frames.pose \xB7 \u5EA6",
    motionLegacyAbsolute: "\u65E7\u30A8\u30C7\u30A3\u30BF\u30FC\u7D76\u5BFE\u89D2 \xB7 \u30E9\u30B8\u30A2\u30F3",
    motionMigrate: "\u3053\u306E\u30DA\u30FC\u30B8\u306E\u65E7\u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u79FB\u884C",
    motionLegacyConfirm: "\u65E7\u30C7\u30FC\u30BF\u306B\u306F\u30E2\u30C7\u30EB\u60C5\u5831\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u3067\u6B63\u3057\u3044\u5F62\u5F0F\u30FB\u5358\u4F4D\u3067\u3042\u308B\u5834\u5408\u306E\u307F\u7D9A\u884C\u3057\u3001\u5909\u63DB\u5F8C\u306F\u5404\u52D5\u4F5C\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5143\u30C7\u30FC\u30BF\u306F\u524A\u9664\u3057\u307E\u305B\u3093\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F",
    motionMigrated: "{count} \u4EF6\u306E\u4E0B\u66F8\u304D\u3092\u79FB\u884C\u3057\u307E\u3057\u305F\u3002\u5143\u30C7\u30FC\u30BF\u3092\u4FDD\u6301\u3057\u3001\u672A\u6709\u52B9\u3067\u3059\u3002\u518D\u5B9F\u884C\u3059\u308B\u3068\u30B3\u30D4\u30FC\u3092\u4F5C\u6210\u3057\u307E\u3059\u3002",
    motionIgnored: "\u7834\u640D\u307E\u305F\u306F\u30E2\u30C7\u30EB\u4E0D\u4E00\u81F4\u306E {count} \u4EF6\u3092\u9664\u5916\u3057\u307E\u3057\u305F\u3002\u5143\u30C7\u30FC\u30BF\u306F\u4FDD\u6301\u3057\u307E\u3059\u3002",
    motionFailure: "\u672A\u5B8C\u4E86\uFF1A{detail}",
    motionInvalidData: "\u52D5\u4F5C\u5F62\u5F0F\u307E\u305F\u306F\u30D1\u30E9\u30E1\u30FC\u30BF\u30FC\u304C\u7121\u52B9\uFF1A{detail}",
    motionModelNotReady: "\u30E2\u30C7\u30EB\u306E\u8AAD\u307F\u8FBC\u307F\u304C\u5B8C\u4E86\u3057\u3066\u3044\u307E\u305B\u3093\u3002",
    motionRigMismatch: "\u9AA8\u683C\u307E\u305F\u306F REST \u59FF\u52E2\u304C\u4E00\u81F4\u3057\u306A\u3044\u305F\u3081\u3001\u9069\u7528\u3057\u307E\u305B\u3093\u3002",
    motionStorageUnavailable: "\u5171\u6709\u30B9\u30C8\u30EC\u30FC\u30B8\u3092\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u62E1\u5F35\u6A5F\u80FD\u306E\u30D1\u30CD\u30EB\u304B\u3089\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",
    motionSelectFirst: "\u52D5\u4F5C\u3092\u4FDD\u5B58\u307E\u305F\u306F\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionSaveFirst: "\u52D5\u4F5C\u304C\u5909\u66F4\u3055\u308C\u307E\u3057\u305F\u3002\u518D\u4FDD\u5B58\u3068\u30D7\u30EC\u30D3\u30E5\u30FC\u304C\u5FC5\u8981\u3067\u3059\u3002",
    motionPreviewFirst: "\u6709\u52B9\u5316\u306E\u524D\u306B\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionAliasConflict: "\u5BFE\u5FDC\u6587\u5B57\u304C\u7A7A\u6B04\u3001\u307E\u305F\u306F\u65E2\u5B58\u306E\u52D5\u4F5C\u3068\u91CD\u8907\uFF1A{detail}\u3002\u5225\u306E\u8A9E\u53E5\u3092\u6307\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionFileTooLarge: "\u30D5\u30A1\u30A4\u30EB\u307E\u305F\u306F\u9805\u76EE\u6570\u304C\u4E0A\u9650\u3092\u8D85\u3048\u3066\u3044\u307E\u3059\uFF082 MiB\uFF09\u3002",
    motionEditorSingleFrame: "\u30A8\u30C7\u30A3\u30BF\u30FC\u306F\u5358\u4E00\u59FF\u52E2\u5C02\u7528\u3067\u3059\u3002\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002",
    motionFrameLimit: "240 \u30D5\u30EC\u30FC\u30E0\u306B\u9054\u3057\u305F\u305F\u3081\u9332\u753B\u3092\u505C\u6B62\u3057\u307E\u3057\u305F\u3002",
    motionFrameDuration: "\u30D5\u30EC\u30FC\u30E0\u6642\u9593\uFF08\u79D2\u30010.05\u201310\uFF09",
    motionUpdateFrame: "\u9078\u629E\u30D5\u30EC\u30FC\u30E0\u3092\u66F4\u65B0",
    motionHelpRig: "Godette \u306F\u6A19\u6E96 Humanoid \u30DC\u30FC\u30F3\u3068\u5229\u7528\u53EF\u80FD\u306A\u6307\u306E\u30DC\u30FC\u30F3\u30C1\u30A7\u30FC\u30F3\u3092\u4F7F\u3044\u307E\u3059\u3002\u30A8\u30C7\u30A3\u30BF\u30FC\u3001\u9332\u753B\u30C4\u30FC\u30EB\u3001\u30A2\u30D0\u30BF\u30FC\u306F\u540C\u3058 profile \u3068 REST \u30DD\u30FC\u30BA\u3092\u5171\u6709\u3057\u307E\u3059\u3002",
    motionHelpAxes: "X/Y/Z \u306F\u30DC\u30FC\u30F3\u306E\u30ED\u30FC\u30AB\u30EB\u8EF8\u3067\u3001\u56FA\u5B9A\u306E\u4E16\u754C\u65B9\u5411\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u51FA\u529B\u306F REST \u5DEE\u5206\u30E9\u30B8\u30A2\u30F3\u3001\u9332\u753B\u30C4\u30FC\u30EB\u306E\u30B9\u30E9\u30A4\u30C0\u30FC\u306F\u7D76\u5BFE\u30ED\u30FC\u30AB\u30EB\u30E9\u30B8\u30A2\u30F3\u3067\u3059\u3002\u5168\u30DC\u30FC\u30F3\u3092\u540C\u3058\u8EF8\u65B9\u5411\u3068\u307F\u306A\u3055\u306A\u3044\u3067\u304F\u3060\u3055\u3044\u3002",
    motionHelpCreate: "\u5358\u4E00\u30DD\u30FC\u30BA\u306F\u30A8\u30C7\u30A3\u30BF\u30FC\u3001\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u4F5C\u308A\u307E\u3059\u3002\u540D\u524D\u3001\u7167\u5408\u30C6\u30AD\u30B9\u30C8\u3001\u30BF\u30B0\u3092\u5165\u529B\u3057\u3066\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58\u3057\u307E\u3059\u3002\u7167\u5408\u30C6\u30AD\u30B9\u30C8\u304C\u7A7A\u306A\u3089\u7D20\u6750\u3068\u3057\u3066\u4FDD\u5B58\u3067\u304D\u307E\u3059\u3002\u65E2\u5B58\u306E\u7167\u5408\u8A9E\u306F\u4E0A\u66F8\u304D\u3067\u304D\u307E\u305B\u3093\u3002",
    motionHelpReview: "\u4E0B\u66F8\u304D\u3092\u4FDD\u5B58 \u2192 \u73FE\u5728\u306E\u52D5\u4F5C\u3092\u30D7\u30EC\u30D3\u30E5\u30FC \u2192 \u624B\u5F62\u30FB\u65B9\u5411\u30FB\u8CAB\u901A\u30FB\u610F\u5473\u3092\u78BA\u8A8D \u2192 \u7FFB\u8A33\u306B\u6709\u52B9\u5316\u3002\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB\u30D1\u30CD\u30EB\u304B\u3089\u7167\u5408\u8A9E\u3092\u5165\u529B\u3057\u3066\u691C\u8A3C\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u3053\u306E\u78BA\u8A8D\u306F\u624B\u8A71\u306E\u5C02\u9580\u8A8D\u8A3C\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002",
    motionHelpFrames: "\u30BF\u30A4\u30E0\u30E9\u30A4\u30F3\u306E\u30D5\u30EC\u30FC\u30E0\u3092\u9078\u629E\u3057\u3001\u30DC\u30FC\u30F3\u3068\u6642\u9593\u3092\u7DE8\u96C6\u3057\u3066\u300C\u9078\u629E\u30D5\u30EC\u30FC\u30E0\u3092\u66F4\u65B0\u300D\u3092\u62BC\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u59FF\u52E2\u306B\u306F\u30AD\u30FC\u30D5\u30EC\u30FC\u30E0\u3092\u8FFD\u52A0\u3057\u307E\u3059\u30021 \u30D5\u30EC\u30FC\u30E0 0.05\u201310 \u79D2\u3001\u6700\u5927 240 \u30D5\u30EC\u30FC\u30E0\u3001\u5408\u8A08 120 \u79D2\u3002\u81EA\u52D5\u9332\u753B\u306F 0.3 \u79D2\u9593\u9694\u3067\u3059\u3002",
    motionHelpUpdates: "\u4E21\u30C4\u30FC\u30EB\u3068\u30A2\u30D0\u30BF\u30FC\u306F\u540C\u3058\u62E1\u5F35 ID\u30FB\u30D6\u30E9\u30A6\u30B6\u30FC\u30D7\u30ED\u30D5\u30A1\u30A4\u30EB\u306E\u4FDD\u5B58\u9818\u57DF\u3092\u5171\u6709\u3057\u307E\u3059\u3002\u6709\u52B9\u5316\u30FB\u7121\u52B9\u5316\u3067\u30A2\u30D0\u30BF\u30FC\u3068\u5F85\u3061\u884C\u5217\u3092\u66F4\u65B0\u3057\u307E\u3059\u3002\u518D\u4FDD\u5B58\u3059\u308B\u3068\u627F\u8A8D\u3092\u89E3\u9664\u3057\u307E\u3059\u3002\u65B0\u3057\u3044\u30B3\u30D4\u30FC\u306F\u5143\u306E\u52D5\u4F5C\u3092\u4E0A\u66F8\u304D\u3057\u307E\u305B\u3093\u3002",
    motionHelpBackup: "\u7D71\u4E00 JSON \u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3057\u307E\u3059\u3002\u30A8\u30AF\u30B9\u30DD\u30FC\u30C8\u3060\u3051\u3067\u306F\u4FDD\u5B58\u30FB\u6709\u52B9\u5316\u3055\u308C\u307E\u305B\u3093\u3002\u30A4\u30F3\u30DD\u30FC\u30C8\u306F\u65B0\u3057\u3044\u4E0B\u66F8\u304D\u3068\u3057\u3066\u518D\u4FDD\u5B58\u30FB\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059\u3002\u8907\u6570\u30D5\u30EC\u30FC\u30E0\u306F\u9332\u753B\u30C4\u30FC\u30EB\u3067\u958B\u304D\u307E\u3059\u3002\u62E1\u5F35\u306E\u524A\u9664\u3084 ID \u5909\u66F4\u524D\u306B\u30D0\u30C3\u30AF\u30A2\u30C3\u30D7\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionHelpLegacy: "\u65E7\u30E9\u30A4\u30D6\u30E9\u30EA\u306E\u79FB\u884C\u306F sb_gestures \u3092\u6B8B\u3057\u3001\u518D\u5B9F\u884C\u3059\u308B\u3068\u30B3\u30D4\u30FC\u3092\u4F5C\u308A\u307E\u3059\u3002\u65E7 JSON \u306E\u5EA6\u6570\u30FB\u7D76\u5BFE\u30E9\u30B8\u30A2\u30F3\u5F62\u5F0F\u3092\u660E\u793A\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u5358\u4F4D\u3092\u63A8\u6E2C\u305B\u305A\u3001\u30B3\u30FC\u30C9\u3082\u5B9F\u884C\u3057\u307E\u305B\u3093\u3002\u73FE\u5728\u306E\u30E2\u30C7\u30EB\u7528\u30C7\u30FC\u30BF\u3067\u3042\u308B\u3053\u3068\u3092\u78BA\u8A8D\u3057\u3001\u5FC5\u305A\u30D7\u30EC\u30D3\u30E5\u30FC\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionHelpBinding: "\u30D5\u30A1\u30A4\u30EB\u4E0A\u9650\u306F 2 MiB\u3002\u4E0D\u4E00\u81F4\u306E\u30DC\u30FC\u30F3/REST\u3001\u672A\u77E5\u306E\u30DC\u30FC\u30F3\u3001\u4E0D\u6B63\u306A\u5024\u306F\u62D2\u5426\u3057\u307E\u3059\u3002\u3053\u308C\u306F GLB \u5168\u4F53\u3084\u30B9\u30AD\u30F3\u306E\u6307\u7D0B\u3067\u306F\u3042\u308A\u307E\u305B\u3093\u3002\u62E1\u5F35\u30D1\u30CD\u30EB\u304B\u3089\u30C4\u30FC\u30EB\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002localhost \u306E\u30DA\u30FC\u30B8\u3068\u306F\u5171\u6709\u3067\u304D\u307E\u305B\u3093\u3002\u66F4\u65B0\u5F8C\u306F\u62E1\u5F35\u3092\u518D\u8AAD\u8FBC\u3057\u3001\u53E4\u3044\u30C4\u30FC\u30EB\u30BF\u30D6\u3092\u958B\u304D\u76F4\u3057\u307E\u3059\u3002",
    motionHelpCollision: "\u8A72\u5F53\u3059\u308B\u52D5\u4F5C\u3068\u30D5\u30EC\u30FC\u30E0\u3092\u7279\u5B9A\u3057\u3001\u6B63\u9762\u3068\u5074\u9762\u304B\u3089\u8098\u30FB\u624B\u9996\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u305D\u306E\u52D5\u4F5C\u306E\u307F\u4FEE\u6B63\u3057\u3066\u518D\u78BA\u8A8D\u3057\u3001\u5168\u4F53\u306E\u8EF8\u53CD\u8EE2\u3084\u4E00\u62EC\u89D2\u5EA6\u5909\u66F4\u3092\u907F\u3051\u3066\u304F\u3060\u3055\u3044\u3002",
    motionHelpCoverage: "\u4E00\u81F4\u3057\u305F motionIds \u3068\u672A\u4E00\u81F4\u30C6\u30AD\u30B9\u30C8\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u672A\u53CE\u9332\u306E\u5165\u529B\u306F\u73FE\u5728\u306E\u518D\u751F\u3092\u4E2D\u65AD\u3057\u307E\u305B\u3093\u3002",
    motionHelpCatalog: "\u6709\u52B9\u306A\u30AB\u30B9\u30BF\u30E0\u52D5\u4F5C\u6570\u3068\u4E0D\u6B63\u306A\u8A18\u9332\u6570\u3092\u78BA\u8A8D\u3057\u307E\u3059\u3002\u4E0B\u66F8\u304D\u306F\u7FFB\u8A33\u3055\u308C\u307E\u305B\u3093\u3002",
    motionDurationInvalid: "\u6642\u9593\u306F 0.05\u201310 \u79D2\u306B\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    motionLoadingFailed: "\u30E2\u30C7\u30EB\u8AAD\u307F\u8FBC\u307F\u5931\u6557\uFF1A{detail}",
    name: "\u65E5\u672C\u8A9E",
    title: "SignBridge \u2014 \u624B\u8A71\u7FFB\u8A33",
    description: "\u52D5\u753B\u306E\u97F3\u58F0\u3092\u30EA\u30A2\u30EB\u30BF\u30A4\u30E0\u3067\u624B\u8A71\u306B\u7FFB\u8A33\u30013D\u30A2\u30D0\u30BF\u30FC\u3067\u8868\u793A",
    settings: "\u8A2D\u5B9A",
    avatar: "\u30A2\u30D0\u30BF\u30FC",
    language: "\u8A00\u8A9E",
    sourceLanguage: "\u52D5\u753B\u306E\u8A00\u8A9E",
    targetSignLanguage: "\u624B\u8A71\u306E\u7A2E\u985E",
    avatarStyle: "\u30A2\u30D0\u30BF\u30FC\u30B9\u30BF\u30A4\u30EB",
    avatarSize: "\u30A2\u30D0\u30BF\u30FC\u30B5\u30A4\u30BA",
    avatarPosition: "\u30A2\u30D0\u30BF\u30FC\u4F4D\u7F6E",
    positionBottomRight: "\u53F3\u4E0B",
    positionBottomLeft: "\u5DE6\u4E0B",
    positionTopRight: "\u53F3\u4E0A",
    positionTopLeft: "\u5DE6\u4E0A",
    enableAutoDetect: "\u52D5\u753B\u3092\u81EA\u52D5\u691C\u51FA",
    enableSubtitles: "\u5B57\u5E55\u3092\u8868\u793A",
    voiceVolume: "\u97F3\u58F0\u97F3\u91CF",
    speed: "\u624B\u8A71\u306E\u901F\u5EA6",
    about: "\u306B\u3064\u3044\u3066",
    start: "\u7FFB\u8A33\u958B\u59CB",
    stop: "\u7FFB\u8A33\u505C\u6B62",
    loading: "\u8AAD\u307F\u8FBC\u307F\u4E2D...",
    noVideo: "\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
    error: "\u30A8\u30E9\u30FC",
    errorNoVideo: "\u30DA\u30FC\u30B8\u306B\u52D5\u753B\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093",
    ready: "\u6E96\u5099\u5B8C\u4E86",
    translating: "\u7FFB\u8A33\u4E2D...",
    unavailable: "\u3053\u306E\u30DA\u30FC\u30B8\u3067\u306F\u5229\u7528\u3067\u304D\u307E\u305B\u3093",
    inputPlaceholder: "\u624B\u8A71\u306B\u3059\u308B\u30C6\u30AD\u30B9\u30C8\u3092\u5165\u529B...",
    send: "\u9001\u4FE1",
    sent: "\u9001\u4FE1\u6E08\u307F",
    audioOff: "\u52D5\u753B\u97F3\u58F0\uFF1A\u30AA\u30D5",
    audioOn: "\u52D5\u753B\u97F3\u58F0\uFF1A\u30AA\u30F3",
    audioStopped: "\u505C\u6B62\u4E2D",
    audioListening: "\u8A8D\u8B58\u4E2D...",
    audioStarting: "\u97F3\u58F0\u3092\u53D6\u5F97\u4E2D...",
    audioUnavailable: "\u3053\u306E\u30DA\u30FC\u30B8\u3067\u306F\u97F3\u58F0\u3092\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093",
    audioCaptureFailed: "\u97F3\u58F0\u306E\u53D6\u5F97\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
    audioCloudKeyRequired: "\u30AF\u30E9\u30A6\u30C9 API Key \u3092\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044",
    audioPermissionRequired: "ASR \u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u3066\u63A5\u7D9A\u5148\u3092\u8A31\u53EF\u3057\u3066\u304F\u3060\u3055\u3044",
    audioLocalUnavailable: "\u5148\u306B\u30ED\u30FC\u30AB\u30EB Whisper \u3092\u5C0E\u5165\u3057\u3066\u304F\u3060\u3055\u3044",
    asrSettings: "\u97F3\u58F0\u8A8D\u8B58\u8A2D\u5B9A",
    asrTitle: "\u52D5\u753B\u97F3\u58F0\u8A8D\u8B58",
    asrPurpose: "\u30ED\u30FC\u30AB\u30EB Whisper \u307E\u305F\u306F\u30AF\u30E9\u30A6\u30C9 ASR \u3067\u52D5\u753B\u97F3\u58F0\u3092\u624B\u8A71\u52D5\u4F5C\u306B\u5909\u63DB\u3057\u307E\u3059\u3002",
    asrProvider: "\u8A8D\u8B58\u65B9\u5F0F",
    asrLocal: "\u30ED\u30FC\u30AB\u30EB Whisper",
    asrCloud: "\u30AF\u30E9\u30A6\u30C9 ASR",
    asrLocalSettings: "\u30ED\u30FC\u30AB\u30EB Whisper \u8A2D\u5B9A",
    asrLocalPrivacy: "\u30E2\u30C7\u30EB\u3068\u97F3\u58F0\u306F\u62E1\u5F35\u6A5F\u80FD\u5185\u3067\u51E6\u7406\u3055\u308C\u3001\u52D5\u753B\u97F3\u58F0\u306F\u8A8D\u8B58\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u305B\u3093\u3002",
    asrDeployLocal: "\u30ED\u30FC\u30AB\u30EB Whisper \u3092\u5C0E\u5165",
    asrEndpoint: "\u30B5\u30FC\u30D3\u30B9 URL",
    asrModel: "\u30E2\u30C7\u30EB",
    asrModelTiny: "tiny\uFF08\u6700\u901F\u3001\u7D04 75 MB\uFF09",
    asrModelBase: "base\uFF08\u30D0\u30E9\u30F3\u30B9\u3001\u7D04 150 MB\uFF09",
    asrModelSmall: "small\uFF08\u9AD8\u7CBE\u5EA6\u3001\u7D04 500 MB\uFF09",
    asrDeployHint: "\u30AF\u30EA\u30C3\u30AF\u3059\u308B\u3068\u30E2\u30C7\u30EB\u3092\u81EA\u52D5\u3067\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u4FDD\u5B58\u3057\u307E\u3059\u3002Python \u3084\u30ED\u30FC\u30AB\u30EB\u30B5\u30FC\u30D3\u30B9\u306F\u4E0D\u8981\u3067\u3059\u3002",
    asrDeployRequired: "\u9078\u629E\u3057\u305F\u30E2\u30C7\u30EB\u306F\u307E\u3060\u5C0E\u5165\u3055\u308C\u3066\u3044\u307E\u305B\u3093\u3002",
    asrRequestingModelPermission: "\u30E2\u30C7\u30EB\u306E\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u6A29\u9650\u3092\u78BA\u8A8D\u4E2D...",
    asrDeploying: "\u30E2\u30C7\u30EB\u3092\u30C0\u30A6\u30F3\u30ED\u30FC\u30C9\u3057\u3066\u521D\u671F\u5316\u4E2D\uFF1A{progress}%",
    asrDeployReady: "\u30ED\u30FC\u30AB\u30EB\u30E2\u30C7\u30EB {model} \u306E\u6E96\u5099\u304C\u5B8C\u4E86\u3057\u307E\u3057\u305F\u3002",
    asrDeployFailed: "\u30ED\u30FC\u30AB\u30EB\u30E2\u30C7\u30EB\u306E\u5C0E\u5165\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
    asrCloudSettings: "\u30AF\u30E9\u30A6\u30C9 ASR \u8A2D\u5B9A",
    asrCloudPrivacy: "\u52D5\u753B\u97F3\u58F0\u306F\u8A2D\u5B9A\u3057\u305F\u30B5\u30FC\u30D3\u30B9\u3078\u9001\u4FE1\u3055\u308C\u307E\u3059\u3002\u30D7\u30E9\u30A4\u30D0\u30B7\u30FC\u3068\u6599\u91D1\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002",
    asrApiKey: "API Key",
    asrCommonSettings: "\u5171\u901A\u8A2D\u5B9A",
    asrLanguage: "\u8A8D\u8B58\u8A00\u8A9E",
    asrChunkSeconds: "\u97F3\u58F0\u30C1\u30E3\u30F3\u30AF",
    asrTest: "\u63A5\u7D9A\u30C6\u30B9\u30C8",
    asrSave: "\u8A2D\u5B9A\u3092\u4FDD\u5B58",
    asrPermissionDenied: "\u3053\u306E\u30B5\u30FC\u30D3\u30B9\u3078\u306E\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u6A29\u9650\u304C\u3042\u308A\u307E\u305B\u3093\u3002",
    asrSaved: "\u8A2D\u5B9A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F\u3002",
    asrInvalidConfig: "\u30EA\u30E2\u30FC\u30C8URL\u306B\u306FHTTPS\u304C\u5FC5\u8981\u3067\u3059\u3002HTTP\u306F\u30EB\u30FC\u30D7\u30D0\u30C3\u30AF\u306E\u307F\u8A31\u53EF\u3057\u3001URL\u306E\u8A8D\u8A3C\u60C5\u5831\u306F\u7981\u6B62\u3057\u307E\u3059\u3002",
    asrTesting: "\u8A8D\u8B58\u30B5\u30FC\u30D3\u30B9\u3092\u30C6\u30B9\u30C8\u3057\u3066\u3044\u307E\u3059...",
    asrTestPassed: "\u63A5\u7D9A\u30C6\u30B9\u30C8\u306B\u6210\u529F\u3057\u307E\u3057\u305F\u3002",
    asrTestFailed: "\u63A5\u7D9A\u30C6\u30B9\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F",
    poseEditor: "\u30DD\u30FC\u30BA\u7DE8\u96C6",
    recorder: "\u9332\u753B\u30C4\u30FC\u30EB",
    help: "\u30D8\u30EB\u30D7",
    tagline: "\u60C5\u5831\u3092\u30A2\u30AF\u30BB\u30B7\u30D6\u30EB\u306B",
    auto: "\u81EA\u52D5\u691C\u51FA",
    simplifiedChinese: "\u4E2D\u56FD\u8A9E\uFF08\u6A19\u6E96\u8A9E\uFF09",
    footer: "SignBridge \u2014 \u60C5\u5831\u3092\u30A2\u30AF\u30BB\u30B7\u30D6\u30EB\u306B",
    signLanguageTypes: {
      csl: "\u4E2D\u56FD\u624B\u8A71 (CSL)",
      asl: "\u30A2\u30E1\u30EA\u30AB\u624B\u8A71 (ASL)",
      bsl: "\u30A4\u30AE\u30EA\u30B9\u624B\u8A71 (BSL)",
      jsl: "\u65E5\u672C\u624B\u8A71 (JSL)",
      ksl: "\u97D3\u56FD\u624B\u8A71 (KSL)"
    },
    avatarStyles: {
      default: "\u30C7\u30D5\u30A9\u30EB\u30C8",
      friendly: "\u30D5\u30EC\u30F3\u30C9\u30EA\u30FC",
      professional: "\u30D7\u30ED\u30D5\u30A7\u30C3\u30B7\u30E7\u30CA\u30EB",
      anime: "\u30A2\u30CB\u30E1\u98A8"
    }
  }
};
var FALLBACK_LOCALE = "en";
var _currentLocale = null;
function getLocale() {
  return _currentLocale || navigator.language || FALLBACK_LOCALE;
}
function setLocale(locale) {
  _currentLocale = locale;
}
function t(key, replacements = {}) {
  const locale = getLocale();
  let dict = LOCALES[locale] || LOCALES[locale.split("-")[0]] || LOCALES[FALLBACK_LOCALE];
  const keys = key.split(".");
  let value = dict;
  for (const k of keys) {
    if (value && typeof value === "object") value = value[k];
    else {
      value = void 0;
      break;
    }
  }
  if (value === void 0) {
    dict = LOCALES[FALLBACK_LOCALE];
    value = dict;
    for (const k of keys) {
      if (value && typeof value === "object") value = value[k];
      else break;
    }
  }
  if (typeof value !== "string") return key;
  return value.replace(/\{(\w+)\}/g, (_, k) => replacements[k] ?? `{${k}}`);
}

// src/avatar/reference-motion-plan.js
var T08_CHECKPOINT_SHA256 = "438cbe537ad1b5bf14c795375209eb00d87cea5c3e97ed06f880f9764e8f9a5b";
var punctuation = /[\s\p{P}]/u;
function demoTextKey(text) {
  return String(text).normalize("NFKC").replace(/[\s\p{P}]/gu, "").toLocaleLowerCase();
}
function motionSource(clip) {
  return clip.experimental ? "experimental" : clip.runtime_candidate ? "candidate" : "t08";
}
function planReferenceText(input, clips = []) {
  const chars = [...String(input).normalize("NFKC")].slice(0, 500);
  const entries = [];
  for (const c of clips)
    for (const text of c.aliases || [c.text])
      entries.push({
        id: c.id,
        text,
        key: demoTextKey(text),
        source: motionSource(c),
        label: c.text
      });
  entries.sort(
    (a, b) => [...b.key].length - [...a.key].length || (a.source === b.source ? 0 : { t08: 0, candidate: 1, experimental: 2, dictionary: 3 }[a.source] - { t08: 0, candidate: 1, experimental: 2, dictionary: 3 }[b.source])
  );
  const items = [], unknown = [];
  let cursor = 0;
  while (cursor < chars.length) {
    if (punctuation.test(chars[cursor])) {
      cursor++;
      continue;
    }
    const remaining = demoTextKey(chars.slice(cursor).join(""));
    const match = entries.find((e) => e.key && remaining.startsWith(e.key));
    if (!match) {
      unknown.push(chars[cursor++]);
      continue;
    }
    let end = cursor, consumed = "";
    while (end < chars.length && consumed.length < match.key.length) {
      if (!punctuation.test(chars[end]))
        consumed += chars[end].toLocaleLowerCase();
      end++;
    }
    if (/^[a-z]+$/i.test(match.key) && (/[a-z0-9]/i.test(chars[end] || "") || /[a-z0-9]/i.test(chars[cursor - 1] || ""))) {
      unknown.push(chars[cursor++]);
      continue;
    }
    items.push({
      ...match,
      matchedText: chars.slice(cursor, end).join(""),
      start: cursor,
      end
    });
    cursor = end;
    if (items.length >= 40) {
      unknown.push(...chars.slice(cursor));
      break;
    }
  }
  return {
    items,
    unmatched: unknown.join(""),
    truncated: [...String(input)].length > 500,
    matchedCount: items.length
  };
}

// src/avatar/reference-motion-asset.js
function validateT08Bundle(data) {
  if (data?.schema !== "signbridge-t08-demo-v1" || data.checkpoint_sha256 !== T08_CHECKPOINT_SHA256 || data.research_only !== true || data.text_to_sign_trained !== false || data.representation !== "effective-smplx-55-axis-angle" || data.checkpoint_step !== 1e3 || !Array.isArray(data.clips) || data.clips?.length !== 14 || data.parents?.length !== 55 || data.restJoints?.length !== 55)
    throw new Error("demoInvalidAsset");
  const ids = /* @__PURE__ */ new Set();
  for (const c of data.clips) {
    if (ids.has(c.id) || typeof c.id !== "string" || typeof c.text !== "string" || !c.text || c.model_output !== "token_decode" || c.text_to_sign_generated !== false || !Number.isFinite(c.token_decode_parity_max) || c.token_decode_parity_max > 1e-4 || !/^[a-f0-9]{64}$/.test(c.feature_sha256) || !/^[a-f0-9]{64}$/.test(c.source_sha256) || !Number.isInteger(c.frames) || !Number.isFinite(c.fps) || c.fps <= 0 || c.poses?.length !== c.frames || c.frames < 4 || c.frames > 2e3)
      throw new Error("demoInvalidAsset");
    ids.add(c.id);
    if (!["body", "left", "right"].every(
      (s) => Array.isArray(c.tokens?.[s]) && c.tokens[s].length === Math.ceil(c.frames / 4) && c.tokens[s].every(
        (n) => Number.isInteger(n) && n >= 0 && n < (s === "body" ? 16 : 32)
      )
    ))
      throw new Error("demoInvalidAsset");
    if (!c.poses.every(
      (p) => p.length === 55 && p.every((v) => v.length === 3 && v.every(Number.isFinite))
    ))
      throw new Error("demoInvalidAsset");
  }
  if (!data.restJoints.every((p) => p.length === 3 && p.every(Number.isFinite)) || data.parents.some(
    (p, i) => !Number.isInteger(p) || (i === 0 ? p !== -1 : p < 0 || p >= i)
  ))
    throw new Error("demoInvalidAsset");
  return data;
}
function validateT08CandidateBundle(data) {
  if (data?.schema !== "signbridge-t08-motion-candidates-v1" || data.training_checkpoint_sha256 !== T08_CHECKPOINT_SHA256 || data.training_weights_updated !== false || data.training_ready !== false || data.text_to_sign_trained !== false || data.research_only !== true || data.training_checkpoint_step !== 1e3 || data.representation !== "effective-smplx-55-axis-angle" || data.smplx_rest_model_sha256 !== "376021446ddc86e99acacd795182bbef903e61d33b76b9d8b359c2b0865bd992" || data.clips?.length !== 3 || data.parents?.length !== 55 || data.restJoints?.length !== 55)
    throw new Error("demoInvalidCandidateAsset");
  const ids = /* @__PURE__ */ new Set();
  for (const clip of data.clips) {
    if (ids.has(clip.id) || typeof clip.id !== "string" || typeof clip.text !== "string" || !clip.id || !clip.text || !Array.isArray(clip.aliases) || !clip.aliases.every((alias) => typeof alias === "string" && alias) || !/^[a-f0-9]{64}$/.test(clip.feature_sha256) || !/^[a-f0-9]{64}$/.test(clip.source_sha256) || clip.runtime_candidate !== true || clip.training_data_member !== false || clip.training_ready !== false || clip.mirror_orientation_confirmed !== false || clip.speaker_identity_confirmed !== false || clip.authorization_status !== "user_reported" || clip.motion_review_decision_sha256 !== "8297549518aaed82f88b94ff20550f4d708ddfe2229a1c614300a7f962752507" || !Number.isFinite(clip.normalized_reconstruction_mse) || clip.normalized_reconstruction_mse < 0 || clip.model_output !== "token_decode_candidate" || !Number.isFinite(clip.token_decode_parity_max) || clip.token_decode_parity_max > 1e-4 || !Number.isInteger(clip.frames) || !Number.isFinite(clip.fps) || clip.fps <= 0 || clip.poses?.length !== clip.frames || clip.frames < 4 || clip.frames > 2e3)
      throw new Error("demoInvalidCandidateAsset");
    ids.add(clip.id);
    if (!["body", "left", "right"].every(
      (part) => Array.isArray(clip.tokens?.[part]) && clip.tokens[part].length === Math.ceil(clip.frames / 4) && clip.tokens[part].every(
        (token) => Number.isInteger(token) && token >= 0 && token < (part === "body" ? 16 : 32)
      )
    ) || !clip.poses.every(
      (pose) => pose.length === 55 && pose.every(
        (vector) => vector.length === 3 && vector.every(Number.isFinite)
      )
    ))
      throw new Error("demoInvalidCandidateAsset");
  }
  if (!data.restJoints.every(
    (joint) => joint.length === 3 && joint.every(Number.isFinite)
  ) || data.parents.some(
    (parent2, index) => !Number.isInteger(parent2) || (index === 0 ? parent2 !== -1 : parent2 < 0 || parent2 >= index)
  ))
    throw new Error("demoInvalidCandidateAsset");
  return data;
}

// src/demo/demo-retarget.js
import * as THREE from "./three.module.js";

// src/demo/motion-stabilization.js
var MOTION_SMOOTHING_PROFILE = "quaternion-temporal-v1";
var ADAPTIVE_SMOOTHING_PROFILE = "quaternion-temporal-adaptive-v1";
var MOTION_STABILIZATION_PROFILES = Object.freeze({
  [ADAPTIVE_SMOOTHING_PROFILE]: Object.freeze({
    strategy: "isolated-spike",
    minimumResidualDegrees: 2,
    neighborSpreadDegrees: 12,
    maximumCorrectionDegrees: 3,
    correctionGain: 0.75
  }),
  "quaternion-temporal-v1": Object.freeze({
    armWindowMs: 45,
    fingerWindowMs: 30
  }),
  "quaternion-temporal-recovery-v1": Object.freeze({
    armWindowMs: 100,
    fingerWindowMs: 30
  })
});
function stabilizeQuaternionTrack(frames, fps, profile = MOTION_SMOOTHING_PROFILE) {
  if (!Array.isArray(frames) || !frames.length || !Number.isFinite(fps) || fps <= 0 || fps > 120 || !Object.hasOwn(MOTION_STABILIZATION_PROFILES, profile))
    throw new Error("demoInvalidRotation");
  const names = Object.keys(frames[0]);
  if (!names.length) throw new Error("demoInvalidRotation");
  const source = frames.map((frame) => {
    if (!frame || Object.keys(frame).length !== names.length)
      throw new Error("demoInvalidRotation");
    const copy = {};
    for (const name of names) {
      const q = frame[name];
      if (!q?.isQuaternion || !q.toArray().every(Number.isFinite) || q.lengthSq() < 1e-12)
        throw new Error("demoInvalidRotation");
      copy[name] = q.clone().normalize();
    }
    return copy;
  });
  const output = source.map(
    (frame) => Object.fromEntries(names.map((name) => [name, frame[name].clone()]))
  );
  for (const name of names) {
    const windowMs = /Thumb|Index|Middle|Ring|Little/.test(name) ? MOTION_STABILIZATION_PROFILES[profile].fingerWindowMs : MOTION_STABILIZATION_PROFILES[profile].armWindowMs;
    for (let frame = 1; frame < source.length - 1; frame++) {
      const settings = MOTION_STABILIZATION_PROFILES[profile];
      if (settings.strategy === "isolated-spike") {
        const previous = source[frame - 1][name];
        const current = source[frame][name];
        const next = source[frame + 1][name];
        const center = previous.clone().slerp(next, 0.5).normalize();
        const residual = center.angleTo(current);
        const spread = previous.angleTo(next);
        if (residual * 180 / Math.PI >= settings.minimumResidualDegrees && spread * 180 / Math.PI <= settings.neighborSpreadDegrees) {
          const correction = Math.min(
            settings.maximumCorrectionDegrees * Math.PI / 180,
            residual * settings.correctionGain
          );
          output[frame][name] = current.clone().slerp(center, correction / residual).normalize();
        }
        continue;
      }
      const speed = source[frame - 1][name].angleTo(source[frame + 1][name]) * fps / 2;
      const adaptiveWindow = settings.minimumWindowMs ? Math.max(
        settings.minimumWindowMs,
        windowMs / (1 + speed / settings.speedScaleRadiansPerSecond)
      ) : windowMs;
      const sigma = fps * adaptiveWindow / 1e3;
      const radius = Math.ceil(2.5 * sigma);
      const count = Math.min(radius, frame, source.length - frame - 1);
      let total = 1;
      const result = source[frame][name].clone();
      for (let offset = 1; offset <= count; offset++) {
        const weight = 2 * Math.exp(-0.5 * (offset / sigma) ** 2);
        const pair = source[frame - offset][name].clone().slerp(source[frame + offset][name], 0.5).normalize();
        result.slerp(pair, weight / (total + weight)).normalize();
        total += weight;
      }
      output[frame][name] = result;
    }
  }
  return output;
}

// src/demo/demo-retarget.js
function axisAngleQuaternion(vector) {
  if (vector?.length !== 3 || !vector.every(Number.isFinite))
    throw new Error("demoInvalidRotation");
  const v = new THREE.Vector3(...vector), angle = v.length();
  return angle < 1e-9 ? new THREE.Quaternion() : new THREE.Quaternion().setFromAxisAngle(v.divideScalar(angle), angle);
}
function boneFrame(direction, normal) {
  if (!direction.toArray().every(Number.isFinite) || direction.lengthSq() < 1e-12 || !normal.toArray().every(Number.isFinite))
    throw new Error("demoInvalidRotation");
  const y = direction.clone().normalize(), z = normal.clone().addScaledVector(y, -normal.dot(y));
  if (z.lengthSq() < 1e-8) z.set(0, 1, 0).addScaledVector(y, -y.y);
  if (z.lengthSq() < 1e-8) z.set(1, 0, 0).addScaledVector(y, -y.x);
  z.normalize();
  const x = new THREE.Vector3().crossVectors(y, z).normalize();
  z.crossVectors(x, y);
  return new THREE.Quaternion().setFromRotationMatrix(
    new THREE.Matrix4().makeBasis(x, y, z)
  );
}
var links = [
  ["neck", 12, 15],
  ["head", 15, null],
  ["leftShoulder", 13, 16],
  ["rightShoulder", 14, 17],
  ["leftUpperArm", 16, 18],
  ["rightUpperArm", 17, 19],
  ["leftLowerArm", 18, 20],
  ["rightLowerArm", 19, 21],
  ["leftHand", 20, 28],
  ["rightHand", 21, 43]
];
for (const [side, starts] of [
  ["left", [37, 25, 28, 34, 31]],
  ["right", [52, 40, 43, 49, 46]]
]) {
  for (const [i, finger] of [
    "Thumb",
    "Index",
    "Middle",
    "Ring",
    "Little"
  ].entries()) {
    const names = i === 0 ? ["Metacarpal", "Proximal", "Distal"] : ["Proximal", "Intermediate", "Distal"];
    for (let j = 0; j < 3; j++)
      links.push([
        side + finger + names[j],
        starts[i] + j,
        j < 2 ? starts[i] + j + 1 : null
      ]);
  }
}
function createT08Retarget(rig2, modelRoot2, bundle) {
  const playingPose = rig2.capture();
  let binding;
  try {
    rig2.reset();
    modelRoot2.updateMatrixWorld(true);
    const rest = bundle.restJoints.map((v) => new THREE.Vector3(...v));
    const palmNormals = {};
    for (const [side, w, index, little] of [
      ["left", 20, 25, 31],
      ["right", 21, 40, 46]
    ])
      palmNormals[side] = new THREE.Vector3().crossVectors(
        rest[index].clone().sub(rest[w]),
        rest[little].clone().sub(rest[w])
      ).normalize();
    const targetPalm = {};
    for (const side of ["left", "right"]) {
      const w = rig2.bones[side + "Hand"].getWorldPosition(new THREE.Vector3());
      const index = rig2.bones[side + "IndexProximal"].getWorldPosition(new THREE.Vector3()).sub(w);
      const little = rig2.bones[side + "LittleProximal"].getWorldPosition(new THREE.Vector3()).sub(w);
      targetPalm[side] = new THREE.Vector3().crossVectors(index, little).normalize();
    }
    binding = links.map(([name, joint, next]) => {
      const bone = rig2.bones[name];
      if (!bone) throw new Error("demoMissingBone");
      const restWorld = bone.getWorldQuaternion(new THREE.Quaternion());
      const restPosition = bone.getWorldPosition(new THREE.Vector3());
      const sourceDir = next !== null ? rest[next].clone().sub(rest[joint]) : rest[joint].clone().sub(rest[bundle.parents[joint]]);
      let targetChild;
      if (name.endsWith("UpperArm"))
        targetChild = rig2.bones[name.replace("UpperArm", "LowerArm")];
      else if (name.endsWith("LowerArm"))
        targetChild = rig2.bones[name.replace("LowerArm", "Hand")];
      else if (name.endsWith("Shoulder"))
        targetChild = rig2.bones[name.replace("Shoulder", "UpperArm")];
      else if (name.endsWith("Hand"))
        targetChild = rig2.bones[name.replace("Hand", "MiddleProximal")];
      else if (name === "neck") targetChild = rig2.bones.head;
      else if (next !== null) targetChild = bone.children.find((c) => c.isBone);
      const targetDir = targetChild ? targetChild.getWorldPosition(new THREE.Vector3()).sub(restPosition) : restPosition.clone().sub(bone.parent.getWorldPosition(new THREE.Vector3()));
      const side = name.startsWith("left") ? "left" : name.startsWith("right") ? "right" : null;
      const isFinger = joint >= 25 || name.endsWith("Hand");
      const sourceNormal = isFinger ? palmNormals[side] : new THREE.Vector3(0, 0, 1);
      const targetNormal = isFinger ? targetPalm[side] : new THREE.Vector3(0, 0, 1);
      const correction = boneFrame(sourceDir, sourceNormal).multiply(
        boneFrame(targetDir, targetNormal).invert()
      );
      const alignedRest = name === "neck" || name === "head" ? restWorld : correction.multiply(restWorld);
      return { name, bone, joint, alignedRest };
    });
  } finally {
    rig2.interpolate(playingPose, playingPose, 1);
    modelRoot2.updateMatrixWorld(true);
  }
  function poseTargets(pose) {
    rig2.reset();
    modelRoot2.updateMatrixWorld(true);
    const world = [];
    pose.forEach((v, i) => {
      const q = axisAngleQuaternion(v);
      if (i > 0) q.premultiply(world[bundle.parents[i]]);
      world.push(q);
    });
    const targets = {};
    for (const b of binding) {
      const desired = world[b.joint].clone().multiply(b.alignedRest);
      const parentWorld = b.bone.parent.getWorldQuaternion(
        new THREE.Quaternion()
      );
      b.bone.quaternion.copy(parentWorld.invert().multiply(desired));
      b.bone.updateWorldMatrix(false, true);
      targets[b.name] = b.bone.quaternion.clone();
    }
    rig2.reset();
    modelRoot2.updateMatrixWorld(true);
    return targets;
  }
  function compile(clip, {
    stabilize = clip.experimental === true,
    stabilizationProfile = clip.display_stabilization_profile
  } = {}) {
    const snapshot = rig2.capture();
    try {
      const frames = clip.poses.map((p) => poseTargets(p));
      return stabilize ? stabilizeQuaternionTrack(frames, clip.fps, stabilizationProfile) : frames;
    } finally {
      rig2.interpolate(snapshot, snapshot, 1);
      modelRoot2.updateMatrixWorld(true);
    }
  }
  return { compile, mappedBones: binding.length };
}

// src/demo/experimental-motion.js
var digestPattern = /^[a-f0-9]{64}$/;
var EXPERIMENTAL_MODEL_SHA256 = "376021446ddc86e99acacd795182bbef903e61d33b76b9d8b359c2b0865bd992";
var previewFields = [
  "source_batch",
  "preview_only",
  "text_verified",
  "semantics_approved",
  "boundaries_approved",
  "temporal_interpolation",
  "source_annotation_id",
  "source_clip_sha256",
  "source_frames_sha256",
  "source_fit_manifest_sha256",
  "boundary_review_flags"
];
function validPreview(c) {
  if (c.source_batch === void 0) return c.preview_only === void 0;
  return c.source_batch === "source-6" && c.preview_only === true && c.text_verified === "" && c.semantics_approved === false && c.boundaries_approved === false && c.temporal_interpolation === false && typeof c.source_annotation_id === "string" && /^[a-zA-Z0-9_-]+$/.test(c.source_annotation_id) && [
    c.source_clip_sha256,
    c.source_frames_sha256,
    c.source_fit_manifest_sha256
  ].every((v) => digestPattern.test(v)) && Array.isArray(c.boundary_review_flags) && c.boundary_review_flags.every((v) => typeof v === "string");
}
function validMetadata(c, approvalId = void 0) {
  const approved = c?.human_approved === true;
  return typeof c?.id === "string" && /^[a-zA-Z0-9_-]+$/.test(c.id) && typeof c.text === "string" && c.text.trim() && Array.isArray(c.aliases) && c.aliases.length > 0 && c.aliases.every((a) => typeof a === "string" && a.trim()) && Number.isInteger(c.frames) && c.frames >= 4 && c.frames <= 2e3 && Number.isFinite(c.fps) && c.fps > 0 && c.fps <= 120 && c.experimental === true && (c.display_stabilization_profile === void 0 || Object.hasOwn(
    MOTION_STABILIZATION_PROFILES,
    c.display_stabilization_profile
  )) && c.model_output === "smplx_fit_demo" && c.training_data_member === false && c.training_ready === false && c.model_training_ready === false && (approved ? c.motion_review_status === "approved_for_demo_motion" && typeof approvalId === "string" && c.motion_approval_id === approvalId : c.human_approved === false && c.motion_review_status === "needs_review" && c.motion_approval_id === void 0) && c.mirror_status === "unknown" && c.signer_id === "unconfirmed" && validPreview(c) && typeof c.quality_warning === "boolean" && [c.source_sha256, c.feature_sha256, c.fitted_sha256].every(
    (v) => digestPattern.test(v)
  );
}
function validApprovalReference(reference) {
  return reference?.schema === "signbridge-human-motion-approval-ref-v1" && typeof reference.id === "string" && /^[a-zA-Z0-9_-]+$/.test(reference.id) && reference.scope === "motion_quality_only" && reference.asset === "experimental/motion-approval.json" && digestPattern.test(reference.sha256);
}
function validateExperimentalIndex(data) {
  if (data?.schema !== "signbridge-experimental-motion-index-v1" || data.representation !== "effective-smplx-55-axis-angle" || data.smplx_rest_model_sha256 !== EXPERIMENTAL_MODEL_SHA256 || data.training_weights_updated !== false || data.text_to_sign_trained !== false || data.training_ready !== false || data.model_training_ready !== false || data.research_only !== true || !Array.isArray(data.clips) || data.clips.length > 200 || data.restJoints?.length !== 55 || data.parents?.length !== 55 || !data.restJoints.every(
    (v) => Array.isArray(v) && v.length === 3 && v.every(Number.isFinite)
  ) || !data.parents.every(
    (p, i) => Number.isInteger(p) && (i === 0 ? p === -1 : p >= 0 && p < i)
  ))
    throw new Error("demoInvalidExperimentalAsset");
  const approval = data.motion_approval;
  if (approval !== void 0 && !validApprovalReference(approval) || approval === void 0 && data.clips.some((clip) => clip.human_approved === true) || approval !== void 0 && !data.clips.some((clip) => clip.human_approved === true))
    throw new Error("demoInvalidExperimentalAsset");
  const ids = /* @__PURE__ */ new Set();
  for (const c of data.clips) {
    if (!validMetadata(c, approval?.id) || ids.has(c.id) || c.asset !== `experimental/${c.id}.json` || !digestPattern.test(c.sha256))
      throw new Error("demoInvalidExperimentalAsset");
    ids.add(c.id);
  }
  return data;
}
function validateExperimentalApprovalRecord(index, record) {
  const reference = index.motion_approval;
  const approved = index.clips.filter((clip) => clip.human_approved === true);
  if (!reference || record?.schema !== "signbridge-human-motion-approval-v1" || record.id !== reference.id || record.scope !== reference.scope || typeof record.declaration !== "string" || !record.declaration.trim() || record.basis !== "explicit_user_statement_in_current_conversation" || typeof record.captured_at_utc !== "string" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(record.captured_at_utc) || !digestPattern.test(record.source_index_sha256) || !Array.isArray(record.clips) || record.clips.length !== approved.length)
    throw new Error("demoInvalidExperimentalAsset");
  const items = new Map(record.clips.map((item) => [item.id, item]));
  if (items.size !== approved.length)
    throw new Error("demoInvalidExperimentalAsset");
  for (const entry of approved) {
    const item = items.get(entry.id);
    if (!item || !digestPattern.test(item.reviewed_asset_sha256) || item.source_sha256 !== entry.source_sha256 || item.fitted_sha256 !== entry.fitted_sha256 || !digestPattern.test(item.poses_sha256))
      throw new Error("demoInvalidExperimentalAsset");
  }
  return items;
}
function experimentalPoseDigestInput(poses) {
  return poses.flat(2).map((value) => String(Math.floor(value * 1e6 + 0.5))).join(",");
}
function validateExperimentalClip(data, entry) {
  if (data?.schema !== "signbridge-experimental-clip-v1" || !validMetadata(data, entry.motion_approval_id) || ![
    "id",
    "text",
    "frames",
    "fps",
    "source_sha256",
    "feature_sha256",
    "fitted_sha256",
    "quality_warning",
    "display_stabilization_profile",
    "human_approved",
    "motion_review_status",
    "motion_approval_id"
  ].every((key) => data[key] === entry[key]) || JSON.stringify(data.aliases) !== JSON.stringify(entry.aliases) || !previewFields.every(
    (key) => JSON.stringify(data[key]) === JSON.stringify(entry[key])
  ) || data.poses?.length !== data.frames || !data.poses.every(
    (p) => Array.isArray(p) && p.length === 55 && p.every(
      (v) => Array.isArray(v) && v.length === 3 && v.every(Number.isFinite)
    )
  ))
    throw new Error("demoInvalidExperimentalAsset");
  return data;
}
function createExperimentalLoader(index, fetchAsset = (path) => fetch(path)) {
  validateExperimentalIndex(index);
  const cache = /* @__PURE__ */ new Map();
  let approvalPromise;
  async function loadApprovalRecord() {
    if (!index.motion_approval) return null;
    if (!approvalPromise) {
      approvalPromise = (async () => {
        const response = await fetchAsset(index.motion_approval.asset);
        if (!response.ok) throw new Error("demoInvalidExperimentalAsset");
        const bytes = await response.arrayBuffer();
        const hash = [
          ...new Uint8Array(
            await globalThis.crypto.subtle.digest("SHA-256", bytes)
          )
        ].map((v) => v.toString(16).padStart(2, "0")).join("");
        if (hash !== index.motion_approval.sha256)
          throw new Error("demoInvalidExperimentalAsset");
        const record = JSON.parse(new globalThis.TextDecoder().decode(bytes));
        return validateExperimentalApprovalRecord(index, record);
      })();
      approvalPromise.catch(() => {
        approvalPromise = void 0;
      });
    }
    return approvalPromise;
  }
  return {
    async load(id) {
      const entry = index.clips.find((c) => c.id === id);
      if (!entry) throw new Error("demoInvalidExperimentalAsset");
      if (!cache.has(id)) {
        const pending = (async () => {
          const response = await fetchAsset(entry.asset);
          if (!response.ok) throw new Error("demoInvalidExperimentalAsset");
          const bytes = await response.arrayBuffer();
          const hash = [
            ...new Uint8Array(
              await globalThis.crypto.subtle.digest("SHA-256", bytes)
            )
          ].map((v) => v.toString(16).padStart(2, "0")).join("");
          if (hash !== entry.sha256)
            throw new Error("demoInvalidExperimentalAsset");
          const clip = JSON.parse(new globalThis.TextDecoder().decode(bytes));
          validateExperimentalClip(clip, entry);
          if (entry.human_approved === true) {
            const approvalItems = await loadApprovalRecord();
            const item = approvalItems?.get(entry.id);
            const poseHash = [
              ...new Uint8Array(
                await globalThis.crypto.subtle.digest(
                  "SHA-256",
                  new globalThis.TextEncoder().encode(
                    experimentalPoseDigestInput(clip.poses)
                  )
                )
              )
            ].map((v) => v.toString(16).padStart(2, "0")).join("");
            if (!item || poseHash !== item.poses_sha256)
              throw new Error("demoInvalidExperimentalAsset");
          }
          return clip;
        })();
        cache.set(id, pending);
        if (cache.size > 6) cache.delete(cache.keys().next().value);
        pending.catch(() => {
          if (cache.get(id) === pending) cache.delete(id);
        });
      }
      return cache.get(id);
    },
    clear() {
      cache.clear();
    }
  };
}

// src/avatar/runtime-motion-plan.js
function planRealtimeText(input, clips = [], matchers) {
  const chars = [...String(input).normalize("NFKC")];
  const end = Math.min(chars.length, 500);
  const references = planReferenceText(chars.slice(0, end).join(""), clips);
  const items = [], unmatched = [];
  let cursor = 0, cutoff = end;
  function dictionary(start, stop) {
    if (start >= stop) return true;
    if (items.length >= 40) {
      cutoff = start;
      return false;
    }
    const text = chars.slice(start, stop).join("");
    const translation = translateText(text, 12, matchers);
    if (translation) {
      unmatched.push(...translation.unmatched);
      if (translation.remainingText) unmatched.push(translation.remainingText);
      if (translation.matches.length)
        items.push({ source: "dictionary", text, translation });
    }
    return true;
  }
  for (const reference of references.items) {
    if (!dictionary(cursor, reference.start)) break;
    if (items.length >= 40) {
      cutoff = reference.start;
      break;
    }
    items.push({ ...reference, text: reference.matchedText });
    cursor = reference.end;
  }
  if (cutoff === end) dictionary(cursor, end);
  return {
    items,
    unmatched,
    truncated: cutoff < chars.length,
    remainingText: chars.slice(cutoff).join("")
  };
}

// src/avatar/iframe-bundle.js
var renderer;
var scene;
var camera;
var rig = null;
var motionPlayer = null;
var modelRoot = null;
var baseModelY = -0.65;
var modelReady = false;
var modelLoading = false;
var renderFrameId = null;
var breathingFrameId = null;
var blinkTimerId = null;
var translationMatchers = compileTranslationMatchers();
var unsubscribeMotions = null;
var motionLibraryVersion = 0;
var motionLibraryIdentity = "[]";
var t08ReferenceClips = [];
var t08MotionBundlePromise = null;
var t08CandidateBundlePromise = null;
var t08Retarget = null;
var t08CandidateRetarget = null;
var experimentalLoader = null;
var experimentalRetarget = null;
var t08TrackCache = createMotionCache({ maxEntries: 12, maxValues: 5e5 });
var translationQueue = Promise.resolve();
var translationGeneration = 0;
async function loadT08ReferenceIndex() {
  try {
    const response = await fetch(
      chrome.runtime.getURL("avatar/t08-index.json")
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const index = await response.json();
    if (index?.schema !== "signbridge-t08-runtime-index-v1" || index.checkpoint_sha256 !== T08_CHECKPOINT_SHA256 || ![14, 17].includes(index.clips?.length) || index.clips?.filter((clip) => !clip.runtime_candidate).length !== 14 || !index.clips.every(
      (clip) => typeof clip.id === "string" && typeof clip.text === "string" && Array.isArray(clip.aliases) && Number.isFinite(clip.fps) && Number.isInteger(clip.frames) && typeof clip.runtime_candidate === "boolean"
    ))
      throw new Error("T08 reference index provenance is invalid");
    t08ReferenceClips = index.clips;
    console.info(
      "[SB] T08 runtime index ready:",
      t08ReferenceClips.filter((clip) => !clip.runtime_candidate).length,
      "reference +",
      t08ReferenceClips.filter((clip) => clip.runtime_candidate).length,
      "candidate phrases"
    );
  } catch (error) {
    t08ReferenceClips = [];
    console.warn("[SB] T08 index unavailable; dictionary fallback:", error);
  }
  try {
    const response = await fetch(
      chrome.runtime.getURL("demo/experimental-index.json")
    );
    if (!response.ok) throw new Error("Experimental index unavailable");
    const data = await response.json();
    if (!data.unavailable) {
      const index = validateExperimentalIndex(data);
      experimentalLoader = createExperimentalLoader(
        index,
        (path) => fetch(chrome.runtime.getURL("demo/" + path))
      );
      experimentalRetarget = createT08Retarget(rig, modelRoot, index);
      t08ReferenceClips.push(...index.clips);
      console.info(
        "[SB] Experimental fitted motions ready:",
        index.clips.length
      );
    }
  } catch (error) {
    console.warn(
      "[SB] Experimental motions unavailable; dictionary fallback:",
      error
    );
  }
}
function loadT08MotionBundle() {
  if (!t08MotionBundlePromise) {
    const pending = (async () => {
      const response = await fetch(
        chrome.runtime.getURL("demo/t08-motion.json")
      );
      if (!response.ok) throw new Error(`T08 asset HTTP ${response.status}`);
      const bundle = validateT08Bundle(await response.json());
      if (bundle.checkpoint_sha256 !== T08_CHECKPOINT_SHA256)
        throw new Error("T08 checkpoint differs from the runtime index");
      t08Retarget = createT08Retarget(rig, modelRoot, bundle);
      console.info("[SB] T08 token-decoded motion asset loaded");
      return bundle;
    })();
    t08MotionBundlePromise = pending.catch((error) => {
      t08MotionBundlePromise = null;
      throw error;
    });
  }
  return t08MotionBundlePromise;
}
function loadT08CandidateBundle() {
  if (!t08CandidateBundlePromise) {
    const pending = (async () => {
      const response = await fetch(
        chrome.runtime.getURL("demo/t08-candidates.json")
      );
      if (!response.ok)
        throw new Error(`T08 candidate HTTP ${response.status}`);
      const bundle = validateT08CandidateBundle(await response.json());
      t08CandidateRetarget = createT08Retarget(rig, modelRoot, bundle);
      console.info(
        "[SB] T08 motion candidate asset loaded:",
        bundle.clips.length
      );
      return bundle;
    })();
    t08CandidateBundlePromise = pending.catch((error) => {
      t08CandidateBundlePromise = null;
      throw error;
    });
  }
  return t08CandidateBundlePromise;
}
async function loadMotionLibrary() {
  try {
    const library = createMotionLibrary(rig);
    async function refresh() {
      const version = ++motionLibraryVersion;
      try {
        const { entries, invalidCount } = await library.list();
        if (version !== motionLibraryVersion || !modelReady) return;
        const motions = selectEnabledMotions(entries);
        const identity = JSON.stringify(motions);
        if (identity !== motionLibraryIdentity) {
          translationGeneration += 1;
          translationQueue = Promise.resolve();
          motionPlayer?.stop({ reset: true });
          translationMatchers = compileTranslationMatchers(motions);
          motionLibraryIdentity = identity;
        }
        console.log("[SB] Motion library:", {
          enabled: motions.length,
          invalid: invalidCount
        });
      } catch (error) {
        if (version !== motionLibraryVersion) return;
        translationGeneration += 1;
        translationQueue = Promise.resolve();
        motionPlayer?.stop({ reset: true });
        translationMatchers = compileTranslationMatchers();
        motionLibraryIdentity = "[]";
        console.warn("[SB] Motion library unavailable:", error.message);
      }
    }
    unsubscribeMotions = library.subscribe(refresh);
    await refresh();
  } catch (error) {
    console.warn("[SB] Motion library unavailable:", error.message);
  }
}
function textToAnimation(text, manual = false) {
  if (!text || !modelReady) return false;
  if (manual) {
    translationGeneration++;
    translationQueue = Promise.resolve();
    motionPlayer?.stop({ reset: true });
  }
  const generation = translationGeneration;
  const plan = planRealtimeText(text, t08ReferenceClips, translationMatchers);
  console.info("[SB] Realtime motion plan:", {
    items: plan.items.map(({ id, source, text: text2 }) => ({ id, source, text: text2 })),
    unmatched: plan.unmatched,
    truncated: plan.truncated,
    remainingText: plan.remainingText
  });
  if (!plan.items.length) return false;
  const route = async () => {
    if (!modelReady || generation !== translationGeneration) return;
    const motions = [];
    for (const item of plan.items) {
      if (item.source === "dictionary") {
        const motion2 = dictionaryMotion(item.text, item.translation);
        if (motion2) motions.push(motion2);
        continue;
      }
      try {
        const sourceType = item.source;
        const motionBundle = sourceType === "experimental" ? null : sourceType === "candidate" ? await loadT08CandidateBundle() : await loadT08MotionBundle();
        const clip = sourceType === "experimental" ? await experimentalLoader.load(item.id) : motionBundle.clips.find((candidate) => candidate.id === item.id);
        if (!modelReady || generation !== translationGeneration) return;
        if (!clip) throw new Error("T08 clip is missing from its motion asset");
        const compiled = t08TrackCache.get(
          `${sourceType}:${clip.id}`,
          () => (sourceType === "experimental" ? experimentalRetarget : sourceType === "candidate" ? t08CandidateRetarget : t08Retarget).compile(clip)
        );
        motions.push({
          type: "quaternion-track",
          samples: compiled.frames,
          fps: clip.fps,
          duration: clip.frames / clip.fps,
          sourceInfo: {
            sourceType,
            referenceId: clip.id,
            modelOutput: clip.model_output,
            presentation: clip.experimental ? clip.display_stabilization_profile || MOTION_SMOOTHING_PROFILE : "raw",
            frames: clip.frames,
            performance: {
              cacheHit: compiled.cacheHit,
              compileMs: compiled.compileMs,
              numericCacheBytes: t08TrackCache.stats().numericBytes
            },
            matchedText: item.text,
            label: t(
              sourceType === "experimental" ? clip.quality_warning ? "demoExperimentalSmoothedWarningBadge" : "demoExperimentalSmoothedBadge" : sourceType === "candidate" ? "demoCandidateBadge" : "demoSourceT08"
            )
          }
        });
      } catch (error) {
        console.warn(
          "[SB] T08 playback unavailable; using dictionary:",
          item.id,
          error
        );
        if (!modelReady || generation !== translationGeneration) return;
        const fallback = dictionaryMotion(
          item.text,
          translateText(item.text, 12, translationMatchers),
          item.id,
          error.message
        );
        if (fallback) motions.push(fallback);
      }
    }
    if (!modelReady || generation !== translationGeneration || !motions.length)
      return;
    const motion = { type: "motion-sequence", motions };
    if (manual) motionPlayer?.play(motion);
    else
      motionPlayer?.enqueue(motion, { key: normalizeText(text).toLowerCase() });
  };
  const next = translationQueue.then(route, route);
  translationQueue = next.catch((error) => {
    console.error("[SB] Realtime motion dispatch failed:", error);
  });
  return true;
}
function dictionaryMotion(text, result, referenceId = null, fallbackReason = null) {
  if (!result?.matches.length) return null;
  console.log("[SB] Translation coverage:", {
    matches: result.matches.map((match) => match.text),
    motionIds: result.matches.map((match) => match.id),
    unmatched: result.unmatched,
    truncated: result.truncated,
    remainingText: result.remainingText
  });
  return {
    frames: result.frames,
    sourceInfo: {
      sourceType: "dictionary",
      referenceId,
      matchedText: text,
      fallbackReason,
      label: t(fallbackReason ? "demoSourceFallback" : "demoSourceDictionary")
    }
  };
}
function init(modelUrl) {
  if (modelReady) {
    notify("READY", {});
    return;
  }
  if (modelLoading) return;
  modelLoading = true;
  console.log("[SB] Loading:", modelUrl);
  const container = document.getElementById("c");
  if (!container) return;
  renderer = new THREE2.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.clientWidth, container.clientHeight);
  renderer.setClearColor(0, 0);
  container.appendChild(renderer.domElement);
  scene = new THREE2.Scene();
  scene.background = new THREE2.Color(14477557);
  scene.add(new THREE2.AmbientLight(16777215, 1.2));
  const dl = new THREE2.DirectionalLight(16777215, 1);
  dl.position.set(2, 5, 3);
  scene.add(dl);
  const dl2 = new THREE2.DirectionalLight(16777215, 0.6);
  dl2.position.set(-1, 2, -1);
  scene.add(dl2);
  camera = new THREE2.PerspectiveCamera(
    45,
    container.clientWidth / container.clientHeight,
    0.1,
    100
  );
  camera.position.set(0, 0.65, 1.5);
  camera.lookAt(0, 0.5, 0);
  const loader = new GLTFLoader();
  loader.load(
    modelUrl,
    async (gltf) => {
      console.log("[SB] Model loaded");
      let primaryMesh = null;
      gltf.scene.traverse((child) => {
        if (child.isSkinnedMesh && !primaryMesh) {
          primaryMesh = child;
          console.log(
            "[SB] Mesh:",
            child.name,
            "tri:",
            child.geometry?.index?.count || "?"
          );
        }
      });
      const boneCount = primaryMesh?.skeleton?.bones.length || 0;
      console.log("[SB] Bones:", boneCount);
      rig = createHumanoidRig(gltf.scene);
      motionPlayer = createMotionPlayer(rig, {
        onMotionStart(info) {
          console.info(
            "[SB] Realtime motion source:",
            info.sourceType,
            info.referenceId
          );
          notify("MOTION_SOURCE", info);
        }
      });
      console.log(
        "[SB] Humanoid profile:",
        rig.profile.id,
        `${Object.keys(rig.bones).length} mapped`
      );
      if (!rig.isSigningReady) {
        console.error("[SB] Missing signing bones:", rig.missing);
        modelLoading = false;
        notify("ERROR", {
          message: `Missing signing bones: ${rig.missing.join(", ")}`
        });
        return;
      }
      scene.add(gltf.scene);
      gltf.scene.scale.set(0.984, 0.984, 0.984);
      gltf.scene.position.y = -0.65;
      modelRoot = gltf.scene;
      baseModelY = gltf.scene.position.y;
      console.log("[SB] REST saved for", Object.keys(rig.rest).length, "bones");
      await loadT08ReferenceIndex();
      if (!modelRoot) return;
      modelReady = true;
      modelLoading = false;
      await loadMotionLibrary();
      if (!modelReady) return;
      startIdleAnimations();
      setupMouseControls();
      notify("READY", {});
      console.log("[SB] \u2705 Ready");
    },
    void 0,
    (err) => {
      modelLoading = false;
      console.error("[SB] Load error:", err);
      notify("ERROR", { message: err.message || String(err) });
    }
  );
  if (!renderFrameId) animate();
}
function animate() {
  renderFrameId = requestAnimationFrame(animate);
  try {
    if (scene) scene.updateMatrixWorld(true);
    if (renderer && scene && camera) renderer.render(scene, camera);
  } catch {
  }
}
function notify(type, data) {
  try {
    parent.postMessage(
      { source: "signbridge-iframe", type, ...data || {} },
      "*"
    );
  } catch {
  }
}
function startIdleAnimations() {
  function scheduleBlink() {
    const delay = 2e3 + Math.random() * 3e3;
    blinkTimerId = setTimeout(() => {
      if (!modelReady || motionPlayer?.isPlaying) {
        scheduleBlink();
        return;
      }
      blink();
      scheduleBlink();
    }, delay);
  }
  scheduleBlink();
  let breathTime = 0;
  baseModelY = modelRoot?.position.y ?? -0.65;
  function breathingLoop() {
    if (!modelReady || !modelRoot) {
      breathingFrameId = requestAnimationFrame(breathingLoop);
      return;
    }
    breathTime += 0.016;
    const breathe = Math.sin(breathTime * 0.8) * 3e-3;
    if (modelRoot && !motionPlayer?.isPlaying) {
      modelRoot.position.y = baseModelY + breathe;
    }
    breathingFrameId = requestAnimationFrame(breathingLoop);
  }
  breathingFrameId = requestAnimationFrame(breathingLoop);
}
function blink() {
  const le = rig?.bones.leftUpperEyelid, re = rig?.bones.rightUpperEyelid;
  if (!le || !re) return;
  const startY = le.rotation.x;
  const dur = 150;
  let start;
  function step(ts) {
    if (!start) start = ts;
    const t2 = (ts - start) / dur;
    if (t2 < 0.4) {
      const v = t2 / 0.4;
      le.rotation.x = startY + v * 0.3;
      re.rotation.x = startY + v * 0.3;
    } else if (t2 < 0.6) {
      le.rotation.x = startY + 0.3;
      re.rotation.x = startY + 0.3;
    } else if (t2 < 1) {
      const v = 1 - (t2 - 0.6) / 0.4;
      le.rotation.x = startY + v * 0.3;
      re.rotation.x = startY + v * 0.3;
    } else {
      le.rotation.x = startY;
      re.rotation.x = startY;
      rig?.update();
      return;
    }
    rig?.update();
    requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
function setupMouseControls() {
  const canvas = renderer.domElement;
  if (!canvas) return;
  let isDragging = false, lastX = 0, lastY = 0, shiftKey = false;
  canvas.style.cursor = "grab";
  canvas.addEventListener("pointerdown", (e) => {
    isDragging = true;
    shiftKey = e.shiftKey;
    lastX = e.clientX;
    lastY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
    canvas.style.cursor = shiftKey ? "grabbing" : "grabbing";
    e.preventDefault();
    e.stopPropagation();
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!isDragging || !modelRoot) return;
    const dx = e.clientX - lastX;
    const dy = e.clientY - lastY;
    if (!shiftKey) modelRoot.rotation.y += dx * 0.01;
    modelRoot.position.y -= dy * 8e-3;
    baseModelY = modelRoot.position.y;
    lastX = e.clientX;
    lastY = e.clientY;
  });
  canvas.addEventListener("pointerup", () => {
    isDragging = false;
    canvas.style.cursor = "grab";
  });
  canvas.addEventListener("pointerleave", () => {
    if (!isDragging) canvas.style.cursor = "grab";
  });
  canvas.addEventListener(
    "wheel",
    (e) => {
      if (!modelRoot) return;
      e.preventDefault();
      const s = modelRoot.scale.x;
      const ns = Math.max(
        0.2,
        Math.min(2.5, s * (e.deltaY > 0 ? 0.985 : 1.015))
      );
      modelRoot.scale.set(ns, ns, ns);
    },
    { passive: false }
  );
  window.addEventListener("keydown", (e) => {
    if (e.key === "Shift") shiftKey = true;
  });
  window.addEventListener("keyup", (e) => {
    if (e.key === "Shift") shiftKey = false;
  });
}
notify("LOADED", {});
window.addEventListener("message", (ev) => {
  if (ev.source !== parent || !ev.data || ev.data.source !== "signbridge-page")
    return;
  if (ev.data.type !== "SUBTITLE_TEXT") {
    console.log("[SB] iframe rx:", ev.data.type);
  }
  switch (ev.data.type) {
    case "INIT":
      setLocale(
        ev.data.config?.uiLocale === "auto" ? null : ev.data.config?.uiLocale
      );
      init(ev.data.modelUrl);
      break;
    case "SUBTITLE_TEXT":
      if (modelReady && ev.data.text) {
        textToAnimation(ev.data.text, ev.data.manual === true);
      }
      break;
    case "PLAYBACK_RESET":
      translationGeneration += 1;
      translationQueue = Promise.resolve();
      motionPlayer?.stop({ reset: true });
      break;
    case "RESIZE":
      if (renderer) {
        renderer.setSize(ev.data.width, ev.data.height);
        camera.aspect = ev.data.width / ev.data.height;
        camera.updateProjectionMatrix();
      }
      break;
  }
});
window.addEventListener("pagehide", disposeAvatar, { once: true });
function disposeAvatar() {
  modelReady = false;
  translationGeneration += 1;
  translationQueue = Promise.resolve();
  motionLibraryVersion += 1;
  unsubscribeMotions?.();
  motionPlayer?.stop();
  if (renderFrameId) cancelAnimationFrame(renderFrameId);
  if (breathingFrameId) cancelAnimationFrame(breathingFrameId);
  if (blinkTimerId) clearTimeout(blinkTimerId);
  modelRoot?.traverse((object) => {
    object.geometry?.dispose?.();
    const materials = Array.isArray(object.material) ? object.material : [object.material];
    for (const material of materials) {
      if (!material) continue;
      for (const value of Object.values(material)) {
        if (value?.isTexture) value.dispose();
      }
      material.dispose?.();
    }
  });
  motionPlayer = null;
  t08TrackCache.clear();
  t08Retarget = null;
  t08CandidateRetarget = null;
  t08MotionBundlePromise = null;
  t08CandidateBundlePromise = null;
  experimentalLoader?.clear();
  experimentalLoader = null;
  experimentalRetarget = null;
  rig = null;
  modelRoot = null;
  renderer?.dispose();
}
console.log("[SB] v17 \u2014 multi-site + structured gestures + eased blending");
